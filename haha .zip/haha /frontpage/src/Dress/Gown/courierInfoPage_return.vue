<template>
  <section >
    <div class="yclosetContaine" v-if="expressData"><!--comments-->
      <div class="emptyBox"  v-if="expressData.returnCourier.mailNo== ''">
        <div><img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/zExpress.png" alt=""></div>
        <em>暂时没有物流状态</em>
      </div>
      <div v-else>
        <div class="expressompany" >
          <div class="expressName">
            <div class="expressImg"><img :src="expressData.returnCourier.courierLogo" alt=""></div>
            <div class="expressCompany">{{expressData.returnCourier.courier}}</div>
          </div>
          <div class="contactWay"><a :href="'tel:'+expressData.returnCourier.courierContact">联系快递</a></div>
        </div>
        <div class="expressInfoPage">
          <div class="experssDetail">
            <div class="layer">运单编号：{{expressData.returnCourier.mailNo}}</div>
            <div class="layer">揽件地址：{{expressData.returnCourier.address}}</div>
            <div class="layer">寄件人：{{expressData.returnCourier.consignee}} &nbsp;{{expressData.returnCourier.mobile}}</div>
            <div class="layer">预约取件时间：{{expressData.returnCourier.timeSlot}}</div>
          </div>
          <ul class="expressInfoPageList">
            <li v-for="item in expressData.returnCourier.courierRoutes">
              <div class="listLeft"></div>
              <div class="listRight">
                <p class="P1">{{item.acceptAddress}}</p>
                <p class="P2">{{item.acceptTime}}</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>


  </section>
</template>

<script>
  import goBack from 'base/GoBack'
  export default {
    data () {
      return{

      }
    },
    props:[
      "expressData"
    ],
    components:{
      goBack,
    },
    watch:{
    },
    computed: {
      author () {
        return this.$store.state.author
      }
    },
    methods: {
    },
    created () {

    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  section{
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    font-size: 12px;
    background-color: rgb(250, 250, 250);
    color: #999;
    .expressompany{
      wdith:100%;
      .height(45);
      background:#fafafa;
      display:flex;
      flex-direction: row;
      justify-content: space-between;
      .padding(15,0,0,21);
      .expressName{
        .height(32);
        display:flex;
        flex-direction: row;
        .expressImg{
          .width(32);
          .height(32);
          border-radius:50%;
          img{
            height:100%;
            width:100%;
          }
        }
        .expressCompany{
          .font-size(14);
          .line-height(32);
          .margin(0,0,0,7);
          color:#111;
        }
      }
      .contactWay{
        .width(132);
        .height(32);
        text-align: center;
        .font-size(14);

        .line-height(32);
        border-left:1px solid #ededed;
        a{
          color:#ff544b;
        }
      }
    }
    .expressInfoPage{
      display:flex;
      flex-wrap: wrap;
      width:100%;
      .padding(0,0,60,0);
      .experssDetail{
        display: flex;
        flex-direction: column;
        width:100%;
        .height(100);
        .font-size(14);
        color: #000;
        background:white;
        .padding(16,0,0,21);
        .margin(0,0,12,0);
        .layer{
          .width(300);
          .height(17);
          .font-size(12);
          .line-height(17);
          letter-spacing: 0.5px;
          color: #111111;
          .padding(1.5,0,1.5,0);
        }
      }

      ul.expressInfoPageList{
        display:flex;
        width:100%;
        flex-wrap: wrap;
        li{
          display: flex;
          width: 100%;
          height:auto;
          background:#fff;

          .listLeft{
            /*flex:1;*/
            display: flex;
            width:10%;
            background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/middle_long.png") 50% 0% no-repeat;
            background-size: 13px;
          }
          .listRight{
            /*flex:8;*/
            border-bottom: 1px rgba(0,0,0,.05) solid;
            .padding(24,0,24,0);
            .margin(0,12,0,0);
            display: flex;
            flex-wrap: wrap;
            width:90%;
            p{
              color: #999;
              .line-height(16);
              .font-size(12);
              display: flex;
              width:100%;
            }
            .P1{}
            .P2{
              .margin(5,0,0,0)
            }
          }
        }

        li:last-of-type{
          .listLeft{
            background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/percentBottom.png") 50% 0% no-repeat;
            background-size: 13px;
          }
          .listRight{
            border:none;
            .P1{
              /*color:pink;*/
            }
          }
        }

        li:first-of-type{
          .listLeft{
            background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/percentTop.png") 50% 100% no-repeat;
            background-size: 13px;
          }
          .listRight{
            .P1{
              color: #333;
              .font-size(13);
            }
          }
        }

        li:only-child{
          .listLeft{
            background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/percentTop.png") 50% 70% no-repeat;
            background-size: 13px;
          }
          .listRight{
            border-bottom: 1px rgba(0,0,0,.05) solid;
            .P1{
              color: #333;
              .font-size(13);
            }
          }
        }
      }
    }

    .emptyBox{
         position:absolute;
         -webkit-transform: translateX(-50%) translateY(-50%);
         -moz-transform: translateX(-50%) translateY(-50%);
         -ms-transform: translateX(-50%) translateY(-50%);
         transform: translateX(-50%) translateY(-50%);
         width:70%;
         top:50%;
         left:50%;
         text-align:center;
         div{
           font-family: "Futura";
           .height(100);
           .width(100);
           margin:0 auto;
           font-weight: 300;
           font-size: 20px;
           text-align: center;
           line-height: 25px;
           color: #3d3d3d;
           img {
             width: 100%;
             height: 100%;
             border-radius:50%;
           }
         }
      em{
        .margin(17,0,0,0);
        padding: 0px;
        display: block;
        line-height: 17px;
        font-style: normal;
        .font-size(16);
        color: rgba(0, 0, 0, 0.2);
        text-align: center;
        line-height: 17px;
      }
    }
  }
  .gif{
    position:absolute;
    -webkit-transform: translateX(-50%) translateY(-50%);
    -moz-transform: translateX(-50%) translateY(-50%);
    -ms-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    width:50%;
    height:50px;
    top:50%;
    left:50%;
    text-align:center;
    img{
      width:50px;
      height:50px;
    }
  }

</style>
