<template>
  <section class="yclosetContainer">
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <nav class="nav">
        <ul>
          <router-link :to="{path:'/Gown/courierInfoPage',query:{orderId:this.$route.query.orderId}}" >
            <li :class="{active:currentNav==0}">
              收件物流
            </li>
          </router-link>
          <router-link :to="{path:'/Gown/courierInfoPage/courierInfoPage_return',query:{orderId:this.$route.query.orderId}}" >
            <li :class="{active:currentNav==1}">
              返还物流
            </li>
          </router-link>
        </ul>
      </nav>
      <router-view :expressData="expressData"></router-view>
      <div class="footer bottomIphoneX">
        <div class="refresh" @click="afresh(orderId)">刷新物流状态</div>
      </div>
    </div>
  </section>
</template>

<script>
  import goBack from 'base/GoBack'
  import { logistics } from 'api/gown'
  export default {
    name: "box",
    data () {
      return {
        orderId:null,
        currentNav:0,
        expressData:null,
      }
    },
    watch:{

    },
    components:{
      goBack,
    },
    beforeRouteUpdate (to, from, next) {
      if(to.path=='/Gown/courierInfoPage'){
        this.currentNav=0
      }else if(to.path=='/Gown/courierInfoPage/courierInfoPage_return'){
        this.currentNav=1
      }
      next()
    },
    created(){

      let orderId = this.$route.query.orderId;
      this.orderId = orderId
      this.loadData(orderId);

    },
    methods:{
      loadData(orderId) {
        let that = this;
        logistics(orderId).then((res)=>{
          if(res.code == 200){
            that.expressData = res.data
          }else{
            let data={
              returnCourier:{mailNo:''},
              outCourier:{mailNo:''},
            }
            that.expressData = data
          }
        })
      },
      afresh(orderId){
        this.loadData(orderId);
      }

    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  /*;*/
  //
  .nav{
    width: 100%;
    ul{
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      line-height: 3.5;
      box-sizing: border-box;
      background-image:linear-gradient(180deg, #e7e7e7, #e7e7e7 50%, transparent 50%);
      background-size: 120% 1px;
      background-repeat: no-repeat;
      background-position: bottom left;
      background-origin: border-box;
    }
    li{
      display: inline-block;
      text-align: center;
      box-sizing: border-box;
      color: #333;
      margin: 0 15px;
      border-bottom: 2px solid rgba(255, 84, 75, 0);
      &.active{
        color: #ff544b;
        border-bottom: 2px solid #ff544b;
      }
    }
  }
  .footer{
    width:100%;
    .height(54);
    position:fixed;
    bottom:0;
    background-color: #ffffff;
    box-shadow: 0 -1px 0 0 rgba(0, 0, 0, 0.05);
    display:flex;
    flex-direction: row;
    justify-content:flex-end;
    .refresh{
      .width(99);
      .height(36);
      .margin(8,23,0,0);
      .font-size(12);
      background-color: #ffffff;
      .line-height(36);
      color:#111;
      display:flex;
      justify-content:center;
      border: solid 1px rgba(0, 0, 0, 0.05);
    }
  }
</style>
