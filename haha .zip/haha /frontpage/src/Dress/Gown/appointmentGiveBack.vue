<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader">
      <go-back></go-back>
      <p>如果需要归还的衣箱未让快递员取走，可在此处预约上门取件。</p>
    </div>
    <!--<div  v-model="addressInfo" style="display">{{addressInfo.addrId}}</div>-->
    <div class="yclosetCon bG"><!--核心内容部分-->
      <ul class="takeliveryDWrap">
        <li class="takeTime">
          <div class="takeTimeLeft">取件时间</div>
          <span @click="showDemo" v-model="selDate" >{{selDate}}</span>
          <div class="arrows"></div>
        </li>
      </ul>
      <div class="addAdress" @click="listLink()" v-if="addressInfo" v-model="addressInfo">
        <div class="addAdresTop">
          <div>{{addressInfo.consignee}}</div>
          <div>{{addressInfo.mobile}}</div>
        </div>
        <div class="addAdresCon">{{addressInfo.city}}&nbsp;{{addressInfo.country}}</div>
        <div class="addAdresBot">{{addressInfo.address}}</div>
        <div class="arrows"></div>
      </div>
    </div>
    <div class="yclosetFooter">
      <div class="affirm">
        <button @click="affirm">确认预约</button>
      </div>
    </div>
    <yi23-toast :open="toastOpen" @toastColse="toastColse">
      {{ msg }}
    </yi23-toast>

    <div class="page-picker-wrapper">
      <mt-picker :slots="others" v-model="testSlotStatus"  valueKey="date"   :visible-item-count="5" @change="onOthersChange"  @doConfirm="doSelect">
      </mt-picker>
    </div>

  </div>

</template>

<script>
  import goBack from 'base/GoBack'
  import MtPicker from '@/components/lib/picker/picker';
  import { mapGetters } from 'vuex'
  import { expressTime ,reservation } from 'api/gown'
  import yi23Toast from '@/components/lib/Toast.vue'

  export default {
    data () {
      return {
        toastOpen: '',
        testdata:[],
        msg: '',
        selDate:'请选择日期',
        dateSlotStatus:false,
        testSlotStatus:false,
        timeSlotStatus:false,
        periodData:null,
        others:null,
        apptDate:null,
        apptTime:null,
      }
    },
    components:{
      yi23Toast,
      MtPicker,
      goBack
    },
    watch:{

    },
    computed: {
      ...mapGetters({
        addressInfo:'addressInfo'
      })
    },
    methods: {
      dataRequired (options) {
        console.log(options)
        for(var k in options){
          console.log(this[options[k].name])
          if(this[options[k].name] == "请选择日期"){
            this.msg=options[k].msg
            this.toastOpen = true;
            return false;
            break;
          }
        }
        return true
      },
      toastColse () {
        this.toastOpen = false;
      },
      listLink:function(){
        let orderId = this.$route.query.orderId;
        this.$router.push({
          path:'/User/myAddress',
          query:{ redirect:"/Gown/appointmentGiveBack?orderId="+orderId}
        })
      },
      doSelect(values) {

        sessionStorage.setItem("apptDate",values[0].date);
        sessionStorage.setItem("appTime",values[1]);

        let giveBackTime = values[0].date+" "+values[1]
        sessionStorage.setItem("giveBackTime",giveBackTime);
        this.selDate= sessionStorage.getItem("giveBackTime")

      },

      onOthersChange(picker, values) {
        if(values && values.length>0){
          picker.setSlotValues(1, values[0].period);
        }
      },
      showDemo() {
          this.testSlotStatus=true
      },
      affirm:function(){
        let apptDate  =sessionStorage.getItem("apptDate")
        let appTime  =sessionStorage.getItem("appTime")
        let orderId= this.$route.query.orderId;
        if(this.dataRequired([{name:'selDate',msg:'请选择日期'}])){
          let that = this
          let options = {
            addrId:this.addressInfo.addrId,
            orderId: orderId,
            deviceId: 1,
            apptDate: apptDate,
            apptTime: appTime
          }
          console.log(options)
          reservation(options).then((res)=>{
            console.log(res);
            if(res.code == 200){
              window.location = "/yi23/Home/Gown/appointmentSuccess";
            }else {
              that.toastOpen = true;
              that.msg = res.msg
            }
          });
        }
      },

    },
    created () {
      this.$store.dispatch('getAddressInfo');

      let sessionSelDate  =sessionStorage.getItem("giveBackTime")
      if(sessionSelDate){
        this.selDate= sessionStorage.getItem("giveBackTime")
      }
      let that =this
      let orderId= this.$route.query.orderId;
      expressTime(orderId).then((res)=>{
        console.log(res.data)
        if(res.data){
          that.others=[
            {
              flex:1,
              values:res.data
            },
            {
              divider: true,
              content: '-',
              className: 'slot2'
            },
            {
              flex: 1,
              values: res.data[0].period,
              className: 'slot3',
              textAlign: 'center'
            }
          ]
        }else{
          that.toastOpen = true;
          that.msg = res.msg
        }
      });
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  .yclosetHeader{
    p{
      .line-height(21);
      .padding(10,10,10,10);
      color: #fff;
      background: #333;
      .font-size(12);
    }
  }
  .yclosetCon{
    width: 100%;
    overflow: scroll;
    display: block;
    background:#f4f8fb;
    .takeliveryDWrap{
      //<!--.height(88);-->
      .padding(10,20,20,20);
      .font-size(12);
      background:#fff;
      .takeTime{
        position:relative;
        display:flex;
        justify-content:space-between;
        .line-height(43);
        border-bottom: rgb(230,230,230) 1px solid;
        .yi23iconfont{
          .font-size(12)
        }
        span{
          .width(150);
          .padding(0,22,0,0);
          text-align: right;
        }
        .arrows{
          .width(8);
          .height(8);
          border-right:solid #999 1px;
          border-bottom:solid #999 1px;
          transform:rotate(-45deg);
          -ms-transform:rotate(-45deg);
          -moz-transform:rotate(-45deg);
          -webkit-transform:rotate(-45deg);
          -o-transform:rotate(-45deg);
          position:absolute;
          .right(0);
          .top(15);
        }
      }
    }
    .addAdress{
      .height(50);
      .padding(20,20,20,20);
      background:#fff;
      position:relative;
      .addAdresTop{
        display:flex;
        justify-content: space-between;
        .padding(0,45,0,0);
        .font-size(12);
        color:#333;
        .line-height(18);
      }
      .addAdresCon,.addAdresBot{
        .font-size(12);
        .line-height(18);
        color:#999;
      }
      .arrows{
        .width(8);
        .height(8);
        border-right:solid #999 1px;
        border-bottom:solid #999 1px;
        transform:rotate(-45deg);
        -ms-transform:rotate(-45deg);
        -moz-transform:rotate(-45deg);
        -webkit-transform:rotate(-45deg);
        -o-transform:rotate(-45deg);
        position:absolute;
        .right(21);
        .top(31);
      }
    }
  }
  .yclosetFooter{
    position:fixed;
    display: block;
    bottom:0;
    width:100%;
    .onlineServices{
      .padding(0,10,20,10);
      .font-size(14);
      button{
        width:100%;
        .height(38);
        background:white;
        color:#000;
        border: 1px #d7d7d7 solid;
      }
    }
    .affirm{
      .font-size(14);
      /*bottom:0;*/
      button{
        width:100%;
        .height(38);
        background:red;
        color:white;
        border: 1px #d7d7d7 solid;
      }
    }
  }


  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .yclosetFooter{
      .bottom(34)
    }
  }
</style>
