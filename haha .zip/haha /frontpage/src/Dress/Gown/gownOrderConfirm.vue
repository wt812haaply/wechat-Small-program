<template lang="html">
  <section class="yclosetContainer">
    <div class="yclosetHeader" v-if="orderInfo">
      <go-back></go-back>
    </div>
    <div class="yclosetCon bg-color-FA" v-if="orderInfo">
      <div class="content">

        <div class="top pl23 pr23 bg-color-FFF mb10">
          <div class="image-ratio imgbox">
            <img :src="orderInfo.thumbPic">
          </div>
          <div class="inner font-14">
            <h1 class="font-14">{{orderInfo.productName}}</h1>
            <p class="font-14 color-gray-9 fw300">{{orderInfo.brandName}}</p>
            <p class="brand font-14">{{orderInfo.size}}</p>
          </div>
          <!-- <div class="price font-12 yi23red" >¥{{rentPriceAll}}/{{[orderInfo.start,orderInfo.finish] | dayDiff }}日</div> -->
          <div class="price font-12 yi23gold" >¥{{rentPriceAll}}/4日</div>
        </div>

        <div class="info pl23 pr23 bg-color-FFF mb10">
          <div class="item">
            <div class="item-box">
              <span class="font-14">配送方式</span>
              <span class="font-14">顺丰速运</span>
            </div>
          </div>

          <div class="item">
            <div class="item-box mb10">
              <span class="font-14">预计送达时间</span>
              <span class="font-14">{{startTime && Number(startTime) | YYYY_MM_DD}}</span>
            </div>
            <p class="font-12 yi23gold">预计送达时间仅供参考，可能会被天气或物流公司延误影响。请妥善安排起租时间，考虑延误风险。</p>
          </div>

          <div class="item">
            <div class="item-box" @click.stop.prevent = "showPicker(0)">
              <span class="font-14">预约返还时间</span>
              <template v-if="selectedText[0]">
                  <span class="font-14 grayOpcaty20">{{ parseInt(this.backtime) | YYYY_MM_DD}}</span>
                  <span class="font-14 ml10">{{selectedText[0]}}</span>
              </template>
              <span v-else class="font-14 grayOpcaty20">请选择预约返还时间</span>
              <i class="yi23iconfont icon-right font-16 grayOpcaty20"></i>
            </div>
          </div>

          <div class="item address">
            <div class="address-info" v-if="addressInfo" @click="doSelectedAddr">
              <div class="left">
                <p><span class="font-16">{{addressInfo.consignee}}</span><span class="font-16 color-gray-9">{{addressInfo.mobile}}</span></p>
                <p class="font-14"><span>{{addressInfo.city}}</span><span>{{addressInfo.country}}</span></p>
                <p class="font-14"><span>{{addressInfo.address}}</span></p>
              </div>
              <p class="right">
                <span class="font-14 grayOpcaty20">编辑</span>
                <i class="yi23iconfont icon-right font-16 grayOpcaty20"></i>
              </p>
            </div>

            <div class="item-box" v-else @click="doSelectedAddr">
              <span class="font-14">新建收货地址</span>
              <span class="font-14 grayOpcaty20">请填写收货地址</span>
              <i class="yi23iconfont icon-right font-16 grayOpcaty20"></i>
            </div>
          </div>
        </div>

        <div class="cost pl23 pr23 bg-color-FFF mb10">
          <h6 class="font-16 grayOpcaty20">租赁费用</h6>
          <p class="font-14"><span>4日租金</span><span>¥{{rentPriceAll}}</span></p>

          <p class="font-14"><span>押金</span><span>¥{{orderInfo.deposit}}</span></p>

          <p class="font-14" v-if="orderInfo.reduceType">
            <span>折扣（仅抵扣租金）</span>

            <span class="yi23red" v-if="orderInfo.reduceType ==1">-¥{{orderInfo.reduce}}</span>

            <span class="yi23red" v-if="orderInfo.reduceType ==2">{{orderInfo.reduce * 10}}折</span>

          </p>

          <p class="font-14" v-if="orderInfo.isMultiReduce" @click="couponsLayerOpen">
            <span>优惠券（仅抵扣租金）</span>

              <span v-if="JSON.stringify(couponsActive) == '{}' && !nocoupons" class="grayOpcaty20">没有可用优惠券</span>

              <span class="grayOpcaty20" v-if="nocoupons">不使用优惠券</span>

              <template v-if="couponsActive != null && JSON.stringify(couponsActive) != '{}' && !nocoupons">

                <span class="grayOpcaty20" v-if="couponType(couponsActive.couponType)">-¥{{couponsActive.value}}</span>
                <span class="grayOpcaty20" v-else>{{couponsActive.value * 10}}折</span>

              </template>

          </p>
          <p class="font-14"><span>总计：</span><span>¥{{total}}</span></p>
        </div>

        <!-- <div class="invitation-code pl23 pr23 bg-color-FFF">
          <p>
            <input type="text" name="" placeholder="请输入邀请码">
          </p>
        </div> -->

      </div>
    </div>

    <div class="yclosetFooter" v-if="orderInfo">
      <div class="creatPay yi23bgred font-14" @click="toPayAndAgreen">订单确认</div>
    </div>

    <pop-up-layer v-if="couponsLayerShow">
      <Coupons
        @btnClick="unUseCoupons"
        @closedPopLayer="couponsLayerClosed"
        :data="orderInfo.couponInfo"
        >
        <ul class="coupons-wrapper">
          <li class="coupons-item" v-for="(item, index) of orderInfo.couponInfo" @click="choiceCoupon(item)">
            <div class="dec">
              <p>{{item.couponTitle}}</p>
              <span>{{item.startDate | YYYY_MM_DD }}-{{item.expDate | YYYY_MM_DD }}</span>
            </div>

            <div class="money type_a" v-if="couponType(item.couponType)">
              <p><i>¥</i>{{item.value}}</p>
            </div>
            <div class="money type_b" v-else>
              <p>{{item.value * 10}}<i>折</i></p>
            </div>
          </li>
        </ul>

      </Coupons>
    </pop-up-layer>

    <Picker
      :data="pickerData"
      :selected-index="selectedIndex"
      @select="handleSelect(0,arguments)"
      ref= "picker0">
    </Picker>

    <yi23Toast v-model="toastMsg"></yi23Toast>

    <router-view></router-view>

  </section>
</template>

<script>
// const data = {
//     "code":200,
//     "msg":"获取礼服订单成功",
//     "data":{
//         "brandName":"inez & co",
//         "productName":"白色长袖礼服",
//         "thumbPic":"https://yimg.yi23.net/products/Thumbs/e9203a93dbbd407e9f42461962baa546.jpg",
//         "size":"中码L号",
//         "start":"1479312000000",
//         "finish":"1479657600000",
//         "productId":4492,
//         "skuId":6682,
//         "stockId":11025,
//         "reduceType":2,
//         "isMultiReduce":1,
//         "reduce":0.8,
//         "salePrice":339,
//         "marketPrice":1200,
//         "originalPrice":1200,
//         "rentPrice":39.75,
//         "deposit":159,
//         "contract":"1.衣二三保证所有上架外租礼服均系100%正品并保证品质良好，礼服在前一用",
//         "paySuccessUrl":"http://www.95vintage.com/yi23/Dress/Gown/payResult?is_success=T&version=2.7.5",
//         "backTime":[
//             "9:00~13:00",
//             "13:00~17:00"
//         ],
//         "couponInfo":[
//           {
//               "couponId":16100,
//               "couponTitle":"获取用户信息的时候",
//               "uid":1280,
//               "expDate":1553183999000,
//               "startDate":1514649600000,
//               "useType":"1,2,3,4,5,6",
//               "deviceType":1,
//               "eventId":2017122800,
//               "value":1120,
//               "status":3,
//               "addTime":1514679898000,
//               "couponCodeId":0,
//               "valueType":1,
//               "couponType":1,
//               "type":0,
//               "pidListId":0,
//               "remark":"",
//               "valid":0,
//               "desc":"",
//               "createUser":0,
//               "orderInfoId":0,
//               "useLimit":30,
//               "typeIcon":"",
//               "specialName":"",
//               "isExpireRemind":0,
//               "remindDate":null,
//               "remindText":null,
//               "level":null,
//               "usableBrand":null,
//               "limitBrand":null,
//               "usableType":null,
//               "limitType":null
//           }
//         ]
//     }
// }
import GoBack from 'base/GoBack';
import PopUpLayer from 'base/PopUpLayer';
import Coupons from '@/components/Member/_coupons';
import { gownOrderDetail } from 'api/gown';
import { toastMixin } from 'common/js/mixin';
import addressMixin from '@/mixins/address';
import { COUPON_TYPE_JE, COUPON_TYPE_ZK } from 'api/const';
import Picker from 'base/Picker';
export default {
  mixins:[toastMixin,addressMixin],
  data(){
    return {
      orderInfo:null,
      activeBackTime:null,
      pickerData: [[]],
      selectedIndex:[0],
      selectedText:[''],
      couponsLayerShow: false,
      couponsActive: null,
      couponsActiveId:0,
      nocoupons: false,
      startTime: null
    }
  },
  beforeRouteEnter(to, from, next){

    if(to.query && to.query.stockId && to.query.start && to.query.finish && to.query.backtime){
      next()
    }else{
      next({path:'/Index/index',replace:true})
    }

  },
  created(){

    this.backtime = this.$route.query.backtime;
    this.startTime = this.$route.query.start;

    this.getDetail();
  },
  watch:{
    orderInfo:function(newVal,oldVal){

      let activeItem;

      if(Array.isArray(newVal.couponInfo) && newVal.couponInfo.length > 0){
        activeItem = newVal.couponInfo[0];
      }else{
        activeItem = {};
      }

      this.couponsActive = activeItem;

    },
    couponsActive: function(newVal, oldVal) {
      if (this.nocoupons == false && newVal && newVal.couponId) {
        this.couponsActiveId = newVal.couponId;
      } else {
        this.couponsActiveId = 0;
      }
    }
  },
  computed: {

    rentPriceAll(){
      if(this.orderInfo){
        let orderInfo = this.orderInfo;
        let day = this.dayDiff(orderInfo.start,orderInfo.finish)+1;
        return parseInt(day*orderInfo.rentPrice);
      }else{
        return ''
      }
    },
    total(){

      let total = 0;
      let rentPriceAll = Number(this.rentPriceAll) || 0; //租金
      let deposit = Number(this.orderInfo.deposit) || 0; //押金
      let reduceType = Number(this.orderInfo.reduceType); //折扣类型 1、额度，2、折扣
      let reduce = Number(this.orderInfo.reduce); //折扣数值
      let isMultiReduce = Number(this.orderInfo.isMultiReduce);//是否折扣和优惠券共存
      let couponsActive = this.couponsActive; //当前选择的优惠券

      total = rentPriceAll;


      if(isMultiReduce){
        if(couponsActive && couponsActive.couponType == COUPON_TYPE_JE){
          total = parseInt(total-couponsActive.value);
        }else if(couponsActive && couponsActive.couponType == COUPON_TYPE_ZK){
          total = parseInt(total*couponsActive.value);
        }
      }

      if(reduceType == 1){
        total = total-reduce;
      }else if(reduceType == 2){
        total = total*reduce;
      }


      total = total > 0 ? total : 0;

      return parseInt(total + deposit);

    }
  },
  methods:{
    getDetail(){

      let route = this.$route;
      let stockId = route.query.stockId;

      let start = new Date(this.YYYY_MM_DD(Number(route.query.start)).toString()).getTime();
      let finish = new Date(this.YYYY_MM_DD(Number(route.query.finish)).toString()).getTime();

      let params = { stockId,start,finish };

      gownOrderDetail(params).then((res)=>{

        if(res.code == 200){
          this.orderInfo = res.data || {};
          this.creatBackTime(res.data.backTime);
        }else{
          this.setToastMsg(res.msg)
        }

      })

    },
    YYYY_MM_DD(value){
      var date = new Date(value);

      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      return y + '/' + m + '/' + d
    },
    toPayAndAgreen(){

      let route = this.$route;
      let stockId = route.query.stockId;

      if(!stockId){
        this.setToastMsg('缺少礼服数据');
        return;
      }

      if(!this.addressInfo){
        this.setToastMsg('请选择邮寄地址');
        return;
      }

      if(!this.selectedText[0]){
        this.setToastMsg('请选择预约返还时间');
        return;
      }

      let start = new Date(this.YYYY_MM_DD(Number(this.$route.query.start)).toString()).getTime();
      let finish = new Date(this.YYYY_MM_DD(Number(this.$route.query.finish)).toString()).getTime();

      let params = {
        stockId:stockId|| 0,
        start:start || 0,
        finish:finish || 0,
        addrId:this.addressInfo.addrId || 0,
        backTime:this.selectedText[0] || '',
        couponId:this.couponsActiveId || 0,
        payType: 6
      }

      let success  = encodeURIComponent(`PayGownSuccess`);
      let redirect = encodeURIComponent(`${this.$route.fullPath}`);

      this.$router.push({
        path: `/Gown/gownOrderConfirm/agreenment`,
        query:{
          payUrl:encodeURIComponent(`/yi23/Home/Pay/payment?params=${encodeURIComponent(JSON.stringify(params))}&success=${success}&redirect=${redirect}`)
        }
      })
    },
    doSelectedAddr(){
      let urls=this.$route.fullPath;
      this.$router.push({
        path:'/User/myAddress',
        query:{ redirect:encodeURIComponent(urls)}
      })
    },
    choiceCoupon(item){
      this.couponsActive = item;
      this.useCoupons();
      this.couponsLayerClosed();
    },
    couponsLayerOpen(){
      this.couponsLayerShow = true
    },
    couponsLayerClosed(){
      this.couponsLayerShow = false
    },
    clearCouponsActive(){
      this.couponsActive = null;
    },
    unUseCoupons(){
      this.nocoupons = true;
      this.clearCouponsActive();
    },
    useCoupons() {
      this.nocoupons = false;
    },
    couponType(type){
      if(type == COUPON_TYPE_JE){
        return true
      }
      return false
    },
    showPicker(index){
      let picker = this.$refs['picker' + index];
      this.creatBackTime()
      picker.show()
    },
    dayDiff(start, finish){
      start = parseInt(start || 0)
      finish = parseInt(finish || 0);
      let days = parseInt((finish - start) / (60 * 60 * 24 * 1000));
      return days
    },
    creatBackTime(){
      let backTime = this.orderInfo.backTime;

      if(!backTime)return;

      let _t = this;
      let arr = [];

      backTime.map(function(el){
        let obj = {
          text: el+'',
          value: el
        }
        arr.push(obj);
      })

      this.$refs.picker0.setData([arr]);
      this.$refs.picker0.setSelectedIndex([0]);

    },
    handleSelect(index,args){
      this.selectedText.splice(index, 1, args[2].join(','))
    }
  },
  components:{
    GoBack,
    Picker,
    PopUpLayer,
    Coupons
  }
}

</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";
  .couponsShow();

  .bg-color-FA{
    background: #FAFAFA;
  }

  .bg-color-FFF{
    background: #FFF;
  }

  .pl23{
    padding-left: 1.226667rem /* 23/18.75 */;
  }
  .pr23{
    padding-right: 1.226667rem /* 23/18.75 */;
  }
  .mb10{
    margin-bottom: .533333rem /* 10/18.75 */;
  }
  .ml10{
    margin-left: .533333rem /* 10/18.75 */;
  }
  .font-12{
    font-size: .64rem /* 12/18.75 */;
  }
  .font-14{
    font-size: .746667rem /* 14/18.75 */;
  }
  .font-16{
    font-size: .853333rem /* 16/18.75 */;
  }
  .grayOpcaty20{
    color:rgba(0,0,0,.2)
  }

  .color-gray-9{
    color: #999;
  }

  .fw300{
    font-weight: 300;
  }

  .creatPay{
    width: 100%;
    height: 2.56rem /* 48/18.75 */;
    line-height: 2.56rem /* 48/18.75 */;
    text-align: center;
    color: #fff;
  }

  .invitation-code{
    padding: 1.28rem /* 24/18.75 */;
    p{
      padding-bottom: 16px;
      border-bottom: 1px solid rgba(0,0,0,.2);
    }
    input[type='text']{
      width: 100%;
    }
  }

  .cost{
    padding-top: 1.28rem /* 24/18.75 */;
    padding-bottom: 1.28rem /* 24/18.75 */;
    p{
      display: box;
      display: flex;
      padding-top: 1.28rem /* 24/18.75 */;
      span:first-child{
        flex:1;
        box-flex:1;
      }
    }
  }
  .address-info{
    display: box;
    display: flex;
    .left{
      flex:1;
      box-flex:1;
      p{
        padding-bottom: .533333rem /* 10/18.75 */;
        &:last-child{
          padding-bottom:0;
        }
      }
      p span{
        padding-left: .533333rem /* 10/18.75 */;
        &:first-child{
          padding: 0;
        }
      }
    }
  }
  .info .item{
    border-bottom: 1px solid rgba(0,0,0,.2);
    padding: 1.2rem /* 22.5/18.75 */ 0;
  }

  .info .item:last-child{
    border-bottom: none;
  }

  .info .item .item-box{
    width: 100%;
    display: flex;
    display: box;
  }

  .item .item-box span:first-child{
    flex:1;
    box-flex:1;
  }

  .content{
    padding-top: .533333rem /* 10/18.75 */;
    width: 100%;
    .top{
      display: flex;
      display: box;
      padding-top: .96rem /* 18/18.75 */;
      padding-bottom: .96rem /* 18/18.75 */;
      .imgbox{
        width: 4.106667rem /* 77/18.75 */;
        height: 5.44rem /* 102/18.75 */;
        img{
          display: block;
          width: 100%;
          height: 100%;
        }
      }
      .inner{
        flex:1;
        box-flex:1;
        padding-left: 12px;
        padding-right: 12px;
        position: relative;
        .brand{
          position: absolute;
          z-index: 1;
          left:12px;
          bottom: 0;
        }
      }
    }
  }
</style>
