<template>
  <section >
    <div v-if="loading">
      <div v-if="boxlist.length > 0 ">
        <div class="boxList" v-for="item in boxlist">
          <div class="traverse">
            <div class="expreStatus">
              <div class="statusLeft">{{item.statusDesc}}</div>
              <div class="statusRight" @click="skipUrl(item.orderInfoId)">查看物流</div>
            </div>
            <div class="box"  @click="skipDetail(item.productId)">
              <div class="left" >
                <img :src="item.thumbPic" alt="">
              </div>
              <dl class="right">
                <dd class="clothesName">{{item.productName}}</dd>
                <dd class="clothesBrand">{{item.brandName}}</dd>
                <dd class="clothesSize font-m">{{item.size}}</dd>
              </dl>
              <div class="totalPr">{{item.gownPriceInfo}}</div>
            </div>
            <div class="btnBox " v-if="item.btnStatus==0 || item.btnStatus== 1  || item.btnStatus==2 || item.btnStatus== 3">
              <div class="btn addColord" @click="linkUrl(item.orderInfoId)">
                提前归还礼服
              </div>
            </div>
          </div>
          <div class="blank"></div>
        </div>
      </div>

      <div v-else-if="boxlist.length == 0">
        <div class="emptyBox">
          <div><img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/zDress.png" alt=""></div>
          <em>你还没有礼服订单</em>
        </div>
      </div>
    </div>



  </section>
</template>

<script>
  import {order} from '@/api/gown'
  import store from "@/store"
  export default {
    data () {
      return {
        boxlist:[],
        test:11111,
        orderId:null,
        loading:false,
      }
    },
    computed:{
    },
    methods:{
      linkUrl(orderId){

        this.$router.push({
          path:'/Gown/appointmentGiveBack',
          query:{orderId:orderId}
        })

      },
      skipUrl(mailNo){
        this.$router.push({
          path:'/Gown/courierInfoPage',
          query:{orderId:mailNo}
        })
      },
      skipDetail(productId){
        this.$router.push({
          path:'/Gown/gownDetailPage',
          query:{productId:productId}
        })
      }
    },
    watch:{

    },
    components:{
    },
    created() {
      let that = this;
      order().then((res)=>{
        if(res.code == 200){
          this.loading = true
          that.boxlist = res.data
        }
        store.commit('bigLoading', false)
      })
    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  section{
    width: 100%;
    height: 100%;
    padding: 10px 0;
    box-sizing: border-box;
    font-size: 12px;
    background-color: rgb(250, 250, 250);
    color: #999;
    .blank{
      width:100%;
      .height(11);
      background:#f3f3f3;
    }
    .boxList{
      //
      background:white;
      .traverse{
        //.margin(0,0,11,0);
        .padding(23,23,23,23);
      }
    }
    .expreStatus{
      width:100%;
      .height(20);
      .padding(0,0,16,0);
      border-bottom:1px solid  #eee;
      display:flex;
      flex-direction: row;
      justify-content: space-between;
      .line-height(20);
      .statusLeft{
        .font-size(14);
        color:#111111;
      }
      .statusRight{
        .font-size(12);
        color:#999999;
        position:relative;
        .padding(0,8,0,0);
      }
      .statusRight:after{
        border: solid 1px #999999;
        border-bottom-width: 0;
        border-left-width: 0;
        content: " ";
        position: absolute;
        top: 50%;
        right:0;
        width: 5px;
        height: 5px;
        transform: translateY(-50%) rotate(45deg);
      }
    }

    .btnBox{
      width: 100%;
      overflow: hidden;
      box-sizing: border-box;
      /*padding: 0 10px;*/
      background: #ffffff;
      display: flex;
    }
    .btn{
      font-size: 12px;
      color: #ffffff;
      background: #ff544b;
      line-height: 3.5;
      flex: 1;
      .margin(21,0,0,0);
    }
    .addColor{
      background:white;
      border-radius:2rpx;
      color:black;
      border:1px solid #f3f3f3;
    }
    .btn.addBtn{
      background: none;
      color: #3d3d3d;
      border: 1px solid #3d3d3d;
    }
    .buybtn{
      font-size: 12px;
      border: 1px solid rgba(0, 0, 0, 0.11);
      padding: 5px;
      color: #3d3d3d;
    }
    .emptyBox{
      position:absolute;
      -webkit-transform: translateX(-50%) translateY(-50%);
      -moz-transform: translateX(-50%) translateY(-50%);
      -ms-transform: translateX(-50%) translateY(-50%);
      transform: translateX(-50%) translateY(-50%);
      width:70%;
      top:50%;
      left:50%;
      text-align:center;
      div{
        font-family: "Futura";
        .height(100);
        .width(100);
        margin:0 auto;
        font-weight: 300;
        font-size: 20px;
        text-align: center;
        line-height: 25px;
        color: #3d3d3d;
        img {
          width: 100%;
          height: 100%;
          border-radius:50%;
        }
      }
      em{
        .margin(17,0,0,0);
        padding: 0px;
        display: block;
        line-height: 17px;
        font-style: normal;
        .font-size(16);
        color: rgba(0, 0, 0, 0.2);
        text-align: center;
        line-height: 17px;
      }
    }
  }
  .box{
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    position:relative;
    .height(100);
    .padding(12,0,0,0);
    .totalPr{
      position:absolute;
      .right(0);
      .top(25);
      color:#ff544b;
    }
    .left{
      .width(72);
      .height(90);
      position: relative;
      .noneBox{
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        img{
          width: 100%;
          height: 100%;
        }
      }
      img{
        border: 0;
        font-size: 0;
        line-height: 0;
        width: 100%;
        height: 100%;
      }
    }
    .right{
      flex: 1;
      position: relative;
      box-sizing: border-box;
      .height(70);
      .padding(0,0,0,16);
      .font-size(12);
      .clothesName{
        color:#111;
        .margin(0,0,10,0);
      }
      .clothesBrand{
        color: #333;
        .margin(0,0,30,0);
      }
      .clothesSize{
        color: #B3B3B3;
        .margin(0,0,11,0);
      }
      .clothesPrice{
        color: #111;
      }
    }
  }
  .gif{
    position:absolute;
    -webkit-transform: translateX(-50%) translateY(-50%);
    -moz-transform: translateX(-50%) translateY(-50%);
    -ms-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    width:50%;
    height:50px;
    top:50%;
    left:50%;
    text-align:center;
    img{
      width:50px;
      height:50px;
    }
  }
</style>
