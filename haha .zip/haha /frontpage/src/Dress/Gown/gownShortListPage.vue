<template>
  <div class="yclosetContainer"><!--comments-->
    <go-back></go-back>
    <div class="content" :class="{'contentDivShow':contentDiv}"  @click="stopHideFilter">
      <yi23-checklist-btn :options="sizeData" v-model="size" name="filterName" title="尺码" :isSquare="true" @checkName="checkName(name)" @submitFilter="submitFilter()"></yi23-checklist-btn>
    </div>

    <div class="contentDiv" ref="scrollBox"><!--Header-->
    <div class="yclosetCon1 bG" ref="yclosetCon1" v-show="!nothing"><!--核心内容部分-->
      <div class="List">
        <ul class="listCon" v-infinite-scroll="loadMore"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10">
            <prd-list :prodList="prodList" :tipsStatus="true"></prd-list>
        </ul>
      </div>
      <loading-components v-show="loading">加载中...</loading-components>
    </div>

    <div class="yclosetCon NotAThing bG"  v-show="nothing">
      <div class="NotAThingCon ">
        <h2>NOT A THING</h2>
        <p>找不到，请调整筛选条件</p>
      </div>
    </div>
    </div>
    <div class="contentDivShowBox">
      <div class="contentDivShowBg" :class="{'contentDivShow':contentDiv}" @click="contentDivHide">
      </div>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar :pageNumber="1"></bottom-Bar>
    </div>
    <datepicker :show="opened" :userableList="userableList" @datePickerSelect="pickerSelect"></datepicker>
  </div>
</template>
<script>
  import loadingComponents from '@/components/lib/Loading'
  import goBack from 'base/GoBack'
  import bottomBar from 'base/BottomBar'
  import config from '@/api/config'
  import BounceInUp from '@/components/lib/transition/BounceInUp'
  import FadeInRight from '@/components/lib/transition/FadeInRight'
  import yi23ChecklistBtn from '@/components/lib/form/gownCheckListBtn'
  import prdList from '@/base/gownList'
  import Datepicker from '@/components/lib/picker/datePicker'
  import { gownCustomizedFilters } from 'api/gown'
  import  { throttle } from '@/utils/throttle';
  import {
    setTitle
  } from 'common/js/utils'
  export default {
    data () {
      return{
        nothing:false,
        stockFirst:'1',
        size:[],
        sizeData:[
          {filterId: 'XS', filterName: 'XS'},
          {filterId: 'S', filterName: 'S'},
          {filterId: 'M', filterName: 'M'},
          {filterId: 'L', filterName: 'L'},
          {filterId: 'XL', filterName: 'XL'},
          {filterId: 'F', filterName: '均码'}
          ],
        crrentNav:null,
        select:{
          filterId:[],
          size:[],
          scene:[],
          season:[],
          brand_id:[],
          color_id:[],
          price:[]
        },
        contentTop: false,
        otherFilter:null,
        relatedFilter:null,
        loading:false,
        prodList:[],
        count:20,
        totalPage:null,
        page:1,
        isContent:false,
        openPickerData:'',
        datepicker:{
          show:false,
          date:null
        },
        opened:false,
        testdate:0,
        userableList:null,
        contentDiv: false,
        searchKey:'',

      }
    },
    components:{
      yi23ChecklistBtn,
      goBack,
      prdList,
      loadingComponents,
      BounceInUp,
      FadeInRight,
      bottomBar,
      Datepicker,
    },
    watch:{
      stockFirst () {
        this.page=1
        this.getProdList()
        this.$refs.scrollBox.scrollTop=0
      },


    },
    computed: {
    },
    created () {
      let query = this.$route.query
      if(query&&query.name) {
        let name = decodeURIComponent(query.name)
        setTitle(name)
        this.searchKey = name
      }
        this.getProdList()
    },
    methods: {
//      onLineClick:function () {
//        this.isShowFilter=false
//        if(this.noLineNav){
//          this.noLineNav=false
//        }else{
//          this.noLineNav=true
//        }
////      },
//      showFilter:function () {
//        //this.noLineNav=false
//        if(this.isShowFilter){
//          this.isShowFilter=false
//        }else if(this.filterResult){
//          this.isShowFilter=true
//        }
//      },
//      hideFilter () {
//        if(this.isShowFilter){
//          this.isShowFilter=false
//        }
//      },
      submitFilter () {
        this.page=1
        this.getProdList()
        this.$refs.scrollBox.scrollTop=0
        this.isShowFilter=false
        this.isContent = !this.isContent
      },
      stopHideFilter (e) {
        e.stopPropagation()
      },
      getProdList (isConcat) {
        this.loading=true
        this.nothing=false
        let options= {
          page:this.page,
          count:this.count,
          stockFirst:this.stockFirst,
          size:this.size,
          searchKey:this.searchKey,
        }
        this.axios.get(config.gownListPage,
          {
            params:options
          }).then((res)=>{
          if(res.data.code==200){
            let data = res.data.data
            this.totalPage=data.pageInfo.totalPage
            if(isConcat){
              this.prodList=this.prodList.concat(data.productList)
            }else{
              this.prodList=data.productList
            }
            if(this.prodList.length==0){
              this.nothing=true
            }
            this.page=this.page+1
          }
          this.loading=false
        })
      },
      loadMore () {
        console.log(this.totalPage)
        if(this.page<=this.totalPage){
          this.getProdList(true)
        }
      },
      openPicker() {
        this.opened=true
      },
      pickerSelect(val) {
        this.opened=false
        this.openPickerData = val.startDate;
        this.submitFilter()
      },
      showContentDiv(){
        this.contentDiv = true;
      },
      contentDivHide(){
        this.contentDiv = false;
      },
      routerNext(){
        this.$router.push({
          path: '/Subscribe/pdtListPage'
        })
      }
    },
    mounted(){
//      this.$refs.scrollBox.scrollListener = throttle(direct(this.$refs.scrollBox), 20);
//      this.$refs.scrollBox.addEventListener('scroll', this.$refs.scrollBox.scrollListener);


      this.$refs.scrollBox.addEventListener('scroll', () => {
        throttle(direct(this), 2000);
      });
      function direct (e) {
        let yclosetCon1 =  e.$refs.yclosetCon1.getBoundingClientRect().top;
        yclosetCon1<0 ? e.contentTop=true : e.contentTop=false;
      }
    }
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";
  .contentTop{
    display:flex;
    justify-content: space-between;
    flex-flow: row wrap;
    padding: 10px 4%;
    line-height: 1.4rem;
    font-size: 12px;
    color: #666;
    border-bottom: 1px solid #fafafa;
    background: white;
  }
  .contentDivShowBg{
    width: 0;
    height: auto;
    background: black;
    opacity: .4;
  }
   body .yclosetContainer .contentDivShowBox .contentDivShow{
    z-index:4;
    height: 100%;
  }

  body .contentDivShow{
    position: fixed;
    top:0;
    left: 0;
    width: 100%;
    z-index: 5;
  }


  body .contentDiv{
  overflow-y: scroll;
  display: flex;
  flex-wrap: wrap;
  -ms-flex-align: start;
  align-items: flex-start;
  flex: 1;
  width: 100%;
  height: 100%;
  padding-top: .5rem;

    .contentDivShow{
      position: fixed;
      top:40px;
      left: 0;
      width: 100%;
      z-index: 5;
    }

}
  .content-flax{
    position: fixed;
    top:0;
    z-index: 3;
    background: white;
  }
  .content{
    position: relative;
    width: 100%;
    overflow: hidden;
    background: #fff;

    .openPickerBox {
      display:flex;
      justify-content: space-between;
      flex-flow: row wrap;
      padding: 10px 4%;
      line-height: 1.4rem;
      font-size: 12px;
      color: #666;
      border-bottom: 1px solid #fafafa;

      .gray{

        .yi23iconfont{
          font-size: 12px;
          margin-left: 3px;
        }
      }
    }
  }

  .yclosetHeader{
    height: auto;
    background: white;
  }
  .yclosetCon1{
    padding-top: 10px;
    width: 100%;
  }
  .topNavCon{
    width:100%;
    overflow: hidden;
    background-color:#fff;
    .textCell{
      font-size: 12px;
      line-height: 3;
      text-align: center;
      color: #666;
    }
    .submitSize{
        span{
          display: block;
          width: 100px;
          font-size: 12px;
          line-height: 2.7;
          background: #ff544b;
          text-align: center;
          color: #ffffff;
          float: right;
          margin-right:10px;
          border-radius: 3px;
        }
      overflow: hidden;
      padding: 5px 0;

    }
  }
  ul.listTopNav{
    height:40px;
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    /*margin-bottom: .5rem;*/
    border-bottom: 1px rgba(0,0,0,.05) solid;
    justify-content: center;
    li.active{
      color: #ff544b;
      position: relative;
    }
    li.active:after{
      content: '';
      width: 20%;
      height: 2px;
      position: absolute;
      bottom: 1px;
      left: 40%;
      z-index: 1;
      background: red;
    }

    li{
      display: flex;
      align-items: center;
      justify-content:center;;
      width:33.3333%;
      font-size: 12px;
      position: relative;
      i{
        font-size: 6px;
        margin-left: 5px;
      }
      i.active{

      }

    }

  }
  .image-ratio:after{
    padding-top: 100%;
  }
  .icon-wish{
    position: absolute;
    top:8px;
    right:8px;
    font-size:16px;
    color: #999;
  }

  .yclosetContainer{
    background: #fafafa;
  }
  /*img placeholder*/
  .List{
    display: flex;
    width:100%;
    ul.listCon{
      margin:0 2%;
      display: flex;
      flex-wrap: wrap;
      justify-content:space-between;
      width: 100%;
      height:auto;
      padding-bottom: 10px;
      li{
        display: flex;
        flex-wrap: wrap;
        width:49%;
        height:auto;

          .liIMG{
              padding-bottom: 124.9333%;
            }
        .liAttribute{
            display: flex;
            flex-wrap: wrap;
            width:100%;
            padding: 12px 10px 18px 10px;
            p{
              font-size: 12px;
              width:100%;
              flex-wrap: wrap;
              line-height: 1.5;
              color: #333;
            }
            p.Name{

            }
            p.Size{
              i{
                padding-right:5px;
                color:#999;
                font-size: 14px;
              }
              i:last-of-type{
                padding:0;
              }
            }
          }

      }
    }
  }


.etr{
  position: absolute;
  top:8px;
  right: 10px;
}


  .NotAThing{
    display: flex;
    justify-content: center;
    align-items:center;
    flex-wrap: wrap;
    width:100%;
    &Con{
      height:auto;
    h2,p{
      width: 100%;
    }
    h2{
      .font-size(20);
      line-height: 2;
      letter-spacing: .2px;
    }
    p{
      .font-size(12);
    }
    }
  }
</style>
