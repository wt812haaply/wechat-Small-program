<template>
  <div class="appointmentSuccess">
    <div class="success" >
      <img src="https://yimg.yi23.net/webimg/20180420/frontpage/zcySuccess.png" alt="">
      <h2>预约成功 !</h2>
      <p>请耐心等待快递员上门取件，并妥善保存物流凭证，以便查询</p>
      <div class="btn" @click="toProduct">继续逛</div>
      <div class="footer"><p @click="backClothes">返回衣箱</p></div>
    </div>
  </div>
</template>

<script>
  export default {
    data(){
      return{
      }
    },
    created(){
    },
    methods:{

      backClothes(){
        this.$router.push({
          path:'/ClothBox/box/gownOrderListPage',
          // path:'/ClothBox/box',
          replace: true
        })
      },
      toProduct(){
        this.$router.push({
          path:'/Gown/gownListPage',
          replace: true
        })
      }
    }
  }
</script>

<style lang="less" scoped>
  @import '~common/less/mixin.less';
  @import '~common/less/variable.less';
  .appointmentSuccess{
    width: 100%;
    height: 100%;
    background: #fff;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    .success,.fail{
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .success,.fail{
      img{
        width: 100%;
      }
      h2{
        font-size: 20px;
        margin-bottom: 14px;
      }
      p{
        width:53%;
        margin:0 auto;
        text-align: center;
        margin-bottom:21px;
        letter-spacing: 1;
        line-height: 21px;
        font-size: 14px;
        color:#666;
        i{
          font-style: normal;
          color:@color-text;
        }
      }
      .btn{
        width: 44%;
        height: 34px;
        line-height: 34px;
        padding: 0;
        background:#ff544b;
        font-size: 14px;
        font-weight: @font-weight-m;
        color: white;
      }
    }
    .fail{
      padding-top: 0;
      img{
        width: 100%;
      }
      h2{
        margin-top: 36px;
      }
      p{
        width: 70%;
        text-align: center;
      }
    }
  }
  .footer{
    width:100%;
    position:fixed;
    .bottom(40);
    text-align: center;
    p{
      margin-bottom:0 !important;
      color:#111 !important;
      .font-size(15) !important;
    }
  }
</style>
