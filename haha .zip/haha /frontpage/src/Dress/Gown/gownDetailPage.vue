<template>
  <div class="yclosetContainer">
    <go-back></go-back>
    <div class="yclosetCon" v-if="detail">
      <div class="gownDetailPage">
        <div class="gownDetailPageSlide">

          <!--轮播-->
          <swiper :options="swiperOption" style="padding:0 10px">
            <swiper-slide v-for="item of detail.picture" :key="item">
              <div class="imgP image-ratio">
                <img :src="item" alt="">
              </div>
            </swiper-slide>
            <div class="swiper-pagination" slot="pagination"></div>
          </swiper>

          <!--浮动icon-->
          <div class="gownDetailPagePm">
            <div class="callCenter" @click="openSDK()"><i class="yi23iconfont icon-service"></i></div>
            <div class="shopping" @click="userClick()"><i class="yi23iconfont icon-box2"></i></div>
          </div>
        </div>

          <div class="gownDetail">
            <div class="gownDetailMoney">{{detail.productName}}</div>
            <div class="gownDetailMoney">

              <div class="font-m one" v-if="detail.reduceType <= 0 "> ¥{{detail.rentPrice}} / 4日</div>
              <div class="font-m" v-if="detail.reduceType > 0 "><i class="one"> ¥{{detail.discountedPrice}} / 4日</i><i class="two"> ¥{{detail.rentPrice}} / 4日</i></div>

            </div>
            <div class="gownDetailSize">
              <ul class="SizeList">
                <li
                  :class="{'active': activeSize == item.size}"
                  v-for="(item) in detail.skuInfo"
                  :key="item.skuId" v-if="item.stock > 0"
                  @click="gownSizeActive(item.size,item.skuId)">
                  {{item.size}}
                </li>

                <li class="noSize" v-else>{{item.size}}</li>
              </ul>
              <div class="SizeDetail" @click="sizeInfo(detail.productId)" v-if="detail.sizeInfo != '' ">尺码详情<i class="yi23iconfont icon-right"></i></div>
            </div>

            <div class="gownDetailBtn">
              <button class="btn qiZu font-m" @click="dataSelection">选择起租日期</button>
              <!--<button class="btn free font-r">免费试穿 <i class="yi23iconfont icon-other"></i></button>-->
            </div>
          </div>


          <div class="dressInfo">
            <div class="dressInfoTitle">礼服信息</div>
            <ul class="dressInfoTag">
              <!--<li class="font-l" v-for="(item) in detail.tag">{{item}}</li>-->
              <li v-for="(item) in detail.tag" @click="moreInfo(item)">{{item}}</li>
            </ul>

            <ul class="dressInfoList">
              <li class="font-l"><span>市场价</span><span class="Right">￥{{ parseInt(detail.marketPrice) }}<i></i></span></li>
              <li class="font-l" @click="moreInfo(detail.brandName)"><span>礼服品牌</span> <span class="Right">{{detail.brandName}}<i class="yi23iconfont icon-right"></i></span></li>
              <li class="font-l" @click="moreInfo(detail.colorName)"><span>颜色</span><span class="Right">{{detail.colorName}}<i class="yi23iconfont icon-right"></i></span></li>
              <li class="font-l"><span>材质详情</span><span class="Right">{{detail.materialName}}<i></i></span></li>
            </ul>
          </div>

      </div>
    </div>
    <yi23Toast v-model="errorMsg"></yi23Toast>
    <datepicker  :show="opened"  :userableList="userableList" @datePickerSelect="pickerSelect"></datepicker>
  </div>
</template>

<script>
import goBack from "base/GoBack";
import { detail, searchAvailableDays, searchAvailableStock } from "api/gown";
import Datepicker from "@/components/lib/picker/datePicker";
import store from "@/store";
import { mapGetters } from "vuex";

export default {
  data() {
    return {
      detail: null,
      activeSize: "",
      activeSkuId: "",
      toastOpen: false,
      errorMsg: null,
      msg: "请选择尺码",
      opened: false,
      testdate: 0,
      userableList: [],
      swiperOption: {
        spaceBetween: 10,
        effect: "fade",
        loop: "true",
        pagination: {
          el: ".swiper-pagination",
          bulletElement: "li",
          clickable: true
        }
      }
    };
  },
  methods: {
    openPicker() {
      this.opened = true;
    },
    pickerSelect(val) {
      this.opened = false;
      if (
        val.startDate === null &&
        val.endDate === null &&
        val.backDate === null
      ) {
        this.opened = false;
      } else {
        let skuId = this.activeSkuId;
        let start = val.startDate;
        let finish = val.endDate;
        this.getSearchAvailableStock(skuId, start, finish).then(stockId => {
          this.userDate(val.startDate, val.endDate, val.backDate, stockId);
        });
      }
    },
    userDate: function(startDate, endDate, backDate, stockId) {
      this.$router.push({
        path: "/Gown/gownOrderConfirm",
        query: {
          stockId: stockId,
          start: startDate,
          finish: endDate,
          backtime: backDate
        }
      });
    },
    //衣箱
    userClick: function() {
      window.location.href = "/yi23/Home/ClothBox/box";
    },
    //七鱼客服
    openSDK: function() {
      window.location.href = ysf.url();
    },

    /* skuId, start, finish */
    getSearchAvailableStock(skuId, start, finish) {
      return searchAvailableStock(skuId, start, finish).then(res => {
        if (res.code == 200) {
          return Promise.resolve(res.data.stockId);
        } else {
          this.errorMsg = this.msg;
        }
      });
    },

    //数据接收
    getDetail() {
      let productId = this.$route.query.productId;
      let uid = this.$route.query.uid;
      detail(productId, uid).then(res => {
        console.log(res);

        if (res.code == 105) {
          console.log(res.msg);
          this.errorMsg = res.msg;
        }
        this.detail = res.data;
        store.commit("bigLoading", false);
      });
    },

    // 尺码选择
    gownSizeActive(size, skuId) {
      if (this.activeSize != size) {
        this.activeSize = size;
        this.activeSkuId = skuId;
        return false;
      }
      this.activeSize = "";
      this.activeSkuId = "";
    },

    //日租选择
    dataSelection: function() {
      if (this.activeSize) {
        searchAvailableDays(this.activeSkuId).then(res => {
          console.log(res);
          if (res.code == 200) {
            this.userableList = res.data;
            this.userSignIn();
            this.openPicker();
          }
        });
      } else {
        this.errorMsg = this.msg;
      }
    },
    //登录
    userSignIn: function() {
      if (!this.authorization) {
        this.$router.push({
          path: "/loginPage",
          query: { redirect: this.$route.fullPath }
        });
        return false;
      }
    },

    //尺码信息
    sizeInfo: function(productId) {
      this.$router.push({
        path: "/Subscribe/sizeDetailPage",
        query: { productId: productId }
      });
    },

    //更多信息（检索）
    moreInfo: function(isName) {
      this.$router.push({
        path: "/Gown/gownShortListPage",
        query: { name: encodeURIComponent(isName) }
      });
    }
  },
  components: {
    goBack,
    Datepicker
  },
  created() {
    this.getDetail();
  },
  computed: {
    ...mapGetters({
      authorization: "authorization"
    })
  },
  mounted: function() {}
};
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
@import "~common/less/variable";
/deep/ .swiper-pagination .swiper-pagination-bullet-active {
  background: #333;
}
/deep/ .swiper-pagination-bullet {
  background: #fff;
  opacity: 0.9;
}
/deep/ .swiper-pagination-bullet {
  .wh(4, 4);
}
.minW(@w) {
  min-width: @w / 18.75rem;
}
.gownDetailPage {
  display: flex;
  width: 100%;
  flex-wrap: wrap;

  &Slide {
    width: 100%;
    height: auto;
    position: relative;
    top: 0;
    right: 0;
    flex-wrap: wrap;
    display: flex;
    .swiper-container {
      width: 100%;
      .swiper-wrapper {
        width: 100%;
        .swiper-slide {
          width: 100%;
          height: auto;
          .imgP {
            padding-bottom: 125%;
          }
        }
      }
    }
  }
}

/*dm*/
.gownDetailPagePm {
  position: absolute;
  bottom: -20px;
  right: 20px;
  z-index: 2;
  .width(82);
  .height(40);
  display: flex;
  justify-content: space-between;
  align-items: center;

  .callCenter,
  .shopping {
    .width(35);
    .height(35);
    background: #222;
    border-radius: 1.86666667rem;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    i {
      color: #fff;
      .font-size(18);
    }
    i.number {
      position: absolute;
      .top(-4);
      .right(-5);
      width: auto;
      min-width: 6px;
      text-align: center;
      .padding(2, 5, 2, 5);
      border-radius: 10px;
      background: #ff544b;
      .font-size(8);
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}

/*详情*/
.gownDetail {
  display: flex;
  flex-wrap: wrap;
  width: 90%;
  width: 100%;
  //.padding(10,10,10,10);

  &Money {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    padding: 0 10px;
    .line-height(47);
    .font-size(14);
    .one {
      color: #cdab6a;
      .margin(0, 10, 0, 0);
    }
    .two {
      color: #cfcfcf;
      text-decoration: line-through;
    }
  }

  &Size {
    display: flex;
    justify-content: space-between;
    width: 100%;
    flex-wrap: wrap;
    .margin(0, 0, 20, 0);
    .padding(0, 10, 0, 10);
    ul.SizeList {
      display: flex;
      overflow-x: scroll;
      .width(270);
      li {
        display: flex;
        justify-content: center;
        align-items: center;
        .minW(60);
        .height(31);
        .margin(0, 6, 0, 0);
        border: 1px #333 solid;
        color: #333;
        .padding(0, 3, 0, 3);
        text-align: center;
        .font-size(12);
      }
      li.active {
        background: #333;
        color: #fff;
      }
      li.noSize {
        color: #ccc;
        border: 1px #ccc solid;
      }
      li:last-of-type {
        margin-right: 0;
      }
    }
    .SizeDetail {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      text-align: right;
      .width(65);
      min-width: 65px;
      color: #999;
      .font-size(12);
      i {
        color: #222;
      }
      .icon-right {
        .font-size(8);
        display: flex;
        justify-content: center;
        align-items: center;
        .margin(0, 0, 0, 2);
      }
    }
  }

  &Btn {
    padding: 0 10px;
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    button {
      width: 100%;
      .height(48);
      .margin(0, 0, 10, 0);
      .font-size(14);
    }
    button:last-of-type {
      .margin(0, 0, 0, 0);
    }
    button.qiZu {
      background: #ff544b;
      color: #fff;
    }
    button.free {
      border: 1px rgba(0, 0, 0, 0.1) solid;
      background: none;
      color: #666;
    }
  }
}

.dressInfo {
  display: flex;
  width: 100%;
  flex-wrap: wrap;
  border-top: 10px #fafafa solid;
  .padding(0, 24, 20, 24);
  .margin(16, 0, 0, 0);
  &Title {
    .line-height(70);
    color: #666;
    .font-size(16);
  }
}
ul.dressInfoTag {
  display: flex;
  flex-wrap: wrap;
  width: 100%;
  .font-size(12);
  .margin(0, 0, 10, 0);
  li {
    display: flex;
    color: #666;
    align-items: center;
    min-width: 20px;
    .padding(0, 10, 0, 10);
    .height(24);
    .line-height(24);
    text-align: center;
    background: #ededed;
    .margin(0, 10, 10, 0);
    border-radius: 24px;
    .font-size(13);
  }
}
ul.dressInfoList {
  display: flex;
  width: 100%;
  flex-wrap: wrap;
  li {
    color: #333;
    width: 100%;
    .line-height(65);
    border-top: 1px rgba(0, 0, 0, 0.1) solid;
    display: flex;
    justify-content: space-between;
    .padding(0, 14, 0, 0);
    .font-size(14);
    span.Right {
      position: relative;
      top: 0;
      right: 0;
      i {
        color: rgba(0, 0, 0, 0.1);
        position: absolute;
        top: 0;
        right: -20px;
      }
    }
  }
}
</style>
