
/**
 *
 *  已废弃
 *  购卡请转移至paymentNew.js;
 *  押金支付请转移至 payCash.js;
 *
*/

import { ERR_OK, PAY_WAY_WX, PAY_WAY_ALI } from 'api/const';
import { paymentOrder } from 'api/member';

const RESULTKEY = 'is_success';
const RESULTSUC = 'T';
const RESULTFAIL = 'F';
const PAYWAYKEY = 'payWay';
const PAYTYPEKEY = 'payType';

// 新支付
const SUBNEWORDERKEY = 'cardTemplateId';
const payType = {
  '1': 'ALI_WEB', // 支付宝web
  '2': 'WECHAT_WEB', // 微信web
  '3': 'ALI_AUTH_FREEZE', // 花呗预授权
  '4': 'ALI_CREDIT_LIFE', // 芝麻信用免押
  '5': 'ALI_CONTRACT_BINDING', // 花呗连续包月
  '6': 'ALI_POINT' // 活动支付（积分+金额）
};
const cardTemplateId = {
  '1': 1, // 30天月卡
  '2': 2, // 90天季卡
  '3': 3 // 365天年卡
};
// 新支付end

// 会员卡支付组件混合
export default {
  data() {
    return {
      payWay: 0,
      payType: '',
      timer: null
    };
  },
  methods: {
    successMaping(keyName) {
      // 支付宝会在支付结果页面中写入is_success=T或者is_success=F
      // 微信需要自己判断并且在链接上加is_success=T或者is_success=F

      let map = {
        BuyPaySuccess: '/Buy/paySuccess', // 购买优惠券卡券成功页
        MemberPaySuccess: '/Member/paySuccess', // 购买会员卡成功页
        ProductPaySuccess: '/Buy/paySuccessClothes', // 购买衣服成功页
        PayGownSuccess: '/Buy/payGownSuccess', // 礼服成功失败页面
        MayiExchangeSuccess: '/Promotion/mayiExchange_r', // 蚂蚁活动成功失败页面
        ContractResultSuccess: '/Member/contractResultPage'
      };

      if (keyName && map[keyName]) {
        return map[keyName];
      }

      return keyName;
    },
    pay(successmapkey, redirect) {
      this.setPayWay();
      this._subOrder(this.getParams(), successmapkey, redirect);
    },
    setPayWay() {
      // let _payWay = this.getClientPayWay();
      // let buyTypePayWay = this.getBuyTypePayWay();
      // if (buyTypePayWay != 0) _payWay = buyTypePayWay;
      // this.payWay = _payWay;
      throw new Error('component must implement setPayWay method');
    },
    getClientPayWay() {
      let clientType = this.$clientType;

      const clientMap = {
        '3': PAY_WAY_WX,
        '4': PAY_WAY_ALI
      };
      if (clientMap[clientType]) {
        return clientMap[clientType];
      }

      return clientMap[4];
    },
    getClientPayType() {
      let clientType = this.$clientType;

      const clientMap = {
        '3': payType['2'], // 新接口微信支付
        '4': payType['1'] // 新接口支付宝支付
      };
      if (clientMap[clientType]) {
        return clientMap[clientType];
      }

      return clientMap[4];
    },
    setPayWayOrPayType(params) {
      // params 支付请求所带参数
      // 新支付类型通过payType判断
      // 旧支付类型通过payWay判断

      if (params[SUBNEWORDERKEY] != undefined) {
        if (!params[PAYTYPEKEY]) {
          params[PAYTYPEKEY] = this.payType;
        }
        if (!params['subType']) {
          params['subType'] = 2;
        }
      } else {
        if (!params[PAYWAYKEY]) {
          params[PAYWAYKEY] = this.payWay;
        }

        if (!params['subType']) {
          params['subType'] = 1;
        }
      }

      return params;
    },
    getRedirectQueryAll(redirect) {
      // 获取重定向链接中所有参数
      // 格式去除掉?,返回{String}

      let index = redirect.indexOf('?');
      let length = redirect.length;

      if (index > -1) {
        let queryString = redirect.substr(index + 1, length);

        let queryArr = [];

        if (queryString.indexOf('&') > -1) {
          queryArr = queryString.split('&');
        } else {
          queryArr.push(queryString);
        }
        return queryArr;
      }

      return null;
    },
    getQueryGroup(query, newQuery) {
      // query {Array}
      // newQuery {Array} 非必选

      let paramsArr = [];

      if (newQuery) {
        if (Array.isArray(newQuery)) {
          paramsArr = paramsArr.concat(newQuery);
        } else {
          throw new Error('newQuery 必须使用数组格式');
        }
      }

      if (query) {
        console.log(query.concat(paramsArr).join('&'));
        return query.concat(paramsArr).join('&');
      } else {
        console.log(paramsArr.join('&'));
        return paramsArr.join('&');
      }
    },
    getParams() {
      // let itemId = this.$route.query.id;
      // let payType = 7;
      // let payWay = this.payWay;
      // const params = {
      //   itemId,
      //   payType,
      //   payWay
      // }
      // return params
      throw new Error('component must implement getParams method');
    },
    _subOrder(params, successmapkey, redirect) {
      // redirect {String} 携带参数重定向地址

      let _t = this;

      let queryStringArr = this.getRedirectQueryAll(redirect);

      let path;

      if (params.payType == 'ALI_CONTRACT_BINDING') {
        path = `${this.successMaping(successmapkey)}`;
      } else {
        path = `${this.CheckCallbackUrl(
          this.successMaping(successmapkey)
        )}${this.getQueryGroup(queryStringArr, [
          'redirect=' + encodeURIComponent(redirect)
        ])}`;
      }

      let callBackUrl = `${window.location.origin}/yi23/Home${path}`;

      params = this.setPayWayOrPayType(params);

      params = Object.assign({}, params, {
        callBackUrl: callBackUrl
      });

      this.checkPayAPI(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          this.createPayForm(params, res.data, callBackUrl);
        } else if (code == 110) {
          // 新增错误信息
          this.$router.replace({
            path: `${path}&${RESULTKEY}=${RESULTSUC}&msg=${encodeURIComponent(
              res.msg
            ) || ''}`
          });
        } else {
          this.setToastMsg(res.msg);

          setTimeout(() => {
            this.$router.replace({
              path: `${path}&${RESULTKEY}=${RESULTFAIL}&msg=${encodeURIComponent(
                res.msg
              ) || ''}`
            });
          }, 1500);
        }
      });
    },
    checkPayAPI(params) {
      // 通过新接口必传参数来判断API
      return paymentOrder(params);
    },
    createPayForm(params, data, callBackUrl) {
      let _t = this;

      if (params.payWay == PAY_WAY_ALI || params.payType == 'ALI_WEB') {
        this.aliCallPay(data);
      } else if (
        params.payWay == PAY_WAY_WX ||
        params.payType == 'WECHAT_WEB'
      ) {
        let content = data.payContents || '';
        callBackUrl = this.CheckCallbackUrl(callBackUrl);

        this.wxCallPay(content, callBackUrl);
      } else if (params.payType == 'ALI_CREDIT_LIFE') {
        // 芝麻信用租
        if (data) window.location.href = data.creditLink;
      } else if (params.payType == 'ALI_CONTRACT_BINDING') {
        // 连续包月
        if (data) window.location.href = data.contractLink;
      } else if (params.payType == 'ALI_POINT') {
        // 积分+现金支付
        this.aliCallPay(data);
      } else {
        console.log('非常规支付,请查看接口');
      }
    },
    CheckCallbackUrl(callBackUrl) {
      let url = callBackUrl;

      if (url.indexOf('?') > -1) {
        url = `${url}&`;
      } else {
        url = `${url}?`;
      }

      return url;
    },
    aliCallPay(resultData) {
      let formStr;

      formStr = resultData.resHtml;

      const div = document.createElement('div');
      div.innerHTML = formStr;

      this.$nextTick(function() {
        document.body.appendChild(div);
      });

      if (this.timer) {
        clearTimeout(this.timer);
      }

      this.timer = setTimeout(() => {
        document.forms.alipaysubmit.submit();
      }, 20);
    },
    wxCallPay(resultData, callBackUrl) {
      let _t = this;
      WeixinJSBridge.invoke(
        'getBrandWCPayRequest',
        {
          appId: resultData.appId,
          nonceStr: resultData.nonceStr,
          package: resultData.package,
          paySign: resultData.paySign,
          signType: resultData.signType,
          timeStamp: resultData.timeStamp.toString()
        },
        function(res) {
          console.log('微信回调:' + res.err_msg);
          if (res.err_msg == 'get_brand_wcpay_request:ok') {
            window.location.href = `${callBackUrl}${RESULTKEY +
              '=' +
              RESULTSUC}`;
          } else {
            window.location.href = `${callBackUrl}${RESULTKEY +
              '=' +
              RESULTFAIL}`;
          }
        }
      );
      if (typeof WeixinJSBridge == 'undefined') {
        if (document.addEventListener) {
          document.addEventListener(
            'WeixinJSBridgeReady',
            onBridgeReady,
            false
          );
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      } else {
        onBridgeReady();
      }
    }
  }
};
