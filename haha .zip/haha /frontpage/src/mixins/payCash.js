/**
 * 现金支付
 */

import { ERR_OK } from 'api/const';
import { payDeposit } from 'api/member';
import { mapActions } from 'vuex';

/**
 * 结果页面参数
*/
const RESULTKEY = 'is_success';
const RESULTSUC = 'T';
const RESULTFAIL = 'F';

/**
 * 发起支付类型参数
*/

const PAYTYPEKEY = 'payType';

const payType = {
  '1': 'ALI_WEB', // 支付宝web
  '2': 'WECHAT_WEB', // 微信web
  '3': 'ALI_AUTH_FREEZE' // 花呗预授权
};

let map = {};

export default {
  data() {
    return {
      _timer: null,
      __options: null
    };
  },
  methods: {
    ...mapActions(['setErrorMsg']),
    _creatDepositPayment(args) {
      /**
       * {args.params} Object 发起支付所需参数
       * {args.success} String 成功或者失败之后的回调页面地址
       * {args.successParams} Object 成功回调地址后增加的参数
       * {args.redirect} String 成功或者失败之后的回调页面地址; redirect可以在successParams中添加;
       * {args.callBack} function 花呗预授权,支付内发起之后的回调处理。非支付宝内发起回调不处理
       */

      //缓存发起时候的参数 如果发起的是花呗预授权,需要再一次发起现金支付
      this.__options = JSON.parse(JSON.stringify(args));

      args.params = this._setDefalutOptions(args.params || {});

      this._subOrder(args);
    },
    _subOrder(args) {
      let params = args.params;
      let successmapkey = args.success;
      let successParams = args.successParams || {};
      let redirect = args.redirect || '';
      let callBackFn = args.callBack || function() {};

      //支付成功失败回调页面
      let success = this._combSucUrl(successmapkey,successParams);

       //发起支付的回调链接
       let callBackPath
       if(redirect){
         callBackPath  = `${this._formatUrl(success)}redirect=${encodeURIComponent(redirect)}`
       }else{
         callBackPath = success
       }

      //发起支付的全链接
      let callBackFullPath = `${
        window.location.origin
      }/yi23/Home${callBackPath}`;

      //参数中写入回调地址
      params = Object.assign({}, params, {
        url: callBackFullPath
      });

      if (params.payType == 'ALI_WEB') {
        //支付宝
        this._aliPayCreated(params, callBackPath);
      } else if (params.payType == 'WECHAT_WEB') {
        //微信
        /*
        * 微信支付的特殊性
        * 需要验证授权安全地址,spa在路由变化时候，微信内捕捉不到刷新的地址
        * 所以用window.localtion.href 跳转支付拉起页
        */
        let pathName = window.location.pathname;
        if (pathName.indexOf('/yi23/Home/Pay/wxcashpayment') > -1) {
          //微信支付发起页面
          //微信支付
          this._wxPayCreated(params, callBackPath);
        } else {
          //非微信支付发起页面
          window.location.href = `/yi23/Home/Pay/wxcashpayment?params=${encodeURIComponent(
            JSON.stringify(params)
          )}&success=${encodeURIComponent(
            success
          )}&redirect=${encodeURIComponent(redirect)}`;
        }
      } else if (params.payType == 'ALI_AUTH_FREEZE') {
        //花呗预授权
        this._freezePayCreated(params, callBackPath);
      } else if(params.payType == 'ALI_CONTRACT_BINDING'){
        //连续包月
        this._contractPayCreated(params, callBackPath);
      }else{
        console.log('非约定支付类型');
      }
    },

    /**
     * 初始化支付发起参数
     *  */

    _setDefalutOptions(params) {
      /**
       * 支付类型初始化
       * {payType} 支付发起类型，此处根据UA写入微信或者支付宝
       */

      if (!params[PAYTYPEKEY]) {
        params[PAYTYPEKEY] = this._getClientPayType();
      }

      return params;
    },
    /**
     * 格式化回调地址
     */
    _formatUrl(callBackUrl) {
      let url = callBackUrl;
      if (url.indexOf('?') > -1) {
        url = `${url}&`;
      } else {
        url = `${url}?`;
      }
      return url;
    },


    /**
     * 初始化回调地址
     * */
    _combSucUrl(callbackurl,successParams){

      let url = this._successMaping(callbackurl)

      let paramKeyArr = Object.keys(successParams);

      if(paramKeyArr.length > 0){
        let paramArr = [];

        url = this._formatUrl(url);

        let paramKeyArrNew = paramKeyArr.map((el,index)=>{
            el = `${el}=${successParams[el]}`
            return el
        })

        url += paramKeyArrNew.join('&');
      }

      return url;

    },

    _successMaping(keyName) {
      // 支付宝会在支付结果页面中写入is_success=T或者is_success=F
      // 微信需要自己判断并且在链接上加is_success=T或者is_success=F

      /**
       * 在地址map中匹配或者直接使用传入的callbackurl
      */
      if (keyName && map[keyName]) {
        return map[keyName];
      }
      return keyName;
    },

    /**
     * 初始化支付环境,如果为指定此处根据客户端初始化支付环境
     **/
    _getClientPayType() {
      let clientType = this.$clientType;
      const clientMap = {
        '3': payType['2'], // 新接口微信支付
        '4': payType['1'] // 新接口支付宝支付
      };
      if (clientMap[clientType]) {
        return clientMap[clientType];
      }
      return clientMap[4];
    },

    /**
     * 接口
     */
    _postCreated(params) {
      return payDeposit(params);
    },
    /*
    * 支付宝现金支付
    */
    _aliPayCreated(params, path) {
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          _t._aliWebPay(res.data);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          this.setErrorMsg(res.msg);
        }
      });
    },
    _aliWebPay(resultData) {
      console.log(resultData);
      function buildRequestForm(param, method, btnName) {

        /**
         * @param {Obj} param  接口返回加签后的参数
         * @param {str} method form发起的方式
         * @param {str} btnName 按钮名称
        */

        let htmlRes = '';

        htmlRes +='<form id="alipaysubmit" name="alipaysubmit" action="https://mapi.alipay.com/gateway.do?_input_charset=utf-8" method="'+method+'" >';

        Object.keys(param).forEach(item => {
          htmlRes += '<input type="hidden" name="'+item+'" value="'+param[item]+'" />';
        });

        htmlRes += '<input type="submit" value="'+ btnName +'" ></form>';
        htmlRes += '<script>document.forms["alipaysubmit"].submit();</script>';

        return htmlRes;
      }

      let formStr = buildRequestForm(resultData,'GET','');

      const div = document.createElement('div');
      div.innerHTML = formStr;
      this.$nextTick(function() {
        document.body.appendChild(div);
      });
      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._timer = setTimeout(() => {
        document.forms.alipaysubmit.submit();
      }, 20);

    },
    /*
    * 微信现金支付
    */
    _wxPayCreated(params, path) {
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          _t._wxAppPay(res.data.payContents, path);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.replace({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          this.setErrorMsg(res.msg);
        }
      });
    },
    _wxAppPay(resultData, path) {
      let _t = this;
      let routerPath = _t._formatUrl(path);
      WeixinJSBridge.invoke(
        'getBrandWCPayRequest',
        {
          appId: resultData.appId,
          nonceStr: resultData.nonceStr,
          package: resultData.package,
          paySign: resultData.paySign,
          signType: resultData.signType,
          timeStamp: resultData.timeStamp.toString()
        },
        function(res) {
          console.log('微信回调:' + res.err_msg);
          if (res.err_msg == 'get_brand_wcpay_request:ok') {
            _t.$router.replace({
              path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
            });
          } else {
            _t.$router.replace({
              path: `${routerPath}${RESULTKEY}=${RESULTFAIL}`
            });
          }
        }
      );
      if (typeof WeixinJSBridge == 'undefined') {
        if (document.addEventListener) {
          document.addEventListener(
            'WeixinJSBridgeReady',
            onBridgeReady,
            false
          );
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      } else {
        onBridgeReady();
      }
    },
    /*
    * 花呗预授权
    * */
    _freezePayCreated(params, path) {
      /*
      * 发起花呗预授权
      * {params} Object 发起预授权参数
      * {callBack} fun 回调处理
      */
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == 200) {
          //检测是否在支付宝内
          if(this.$clientType === 4){
            //内部拉起花呗预授权
            _t._freezeAppPay(res, path);
          }else{
             //外部拉起花呗
            _t._freezeWebPay(res);
          }
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _freezeWebPay(result) {
      //web拉起花呗预授权
      if (result.data) window.location.href = result.data.freezeLink;
    },
    _freezeAppPay(result, path) {
      //支付宝端拉起花呗预授权
      let _t = this;
      let routerPath = _t._formatUrl(path);

      //将外部链接转换成支付宝端内发起的参数
      if(result.data && result.data.freezeLink && result.data.freezeLink.indexOf('https://mapi.alipay.com/gateway.do?') != -1){
        result.data.freezeLink = result.data.freezeLink.replace('https://mapi.alipay.com/gateway.do?', '');
      }

      AlipayJSBridge.call('tradePay', { orderStr: result.data.freezeLink }, function(
        result
      ) {
        if (result.resultCode == 9000) {

          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTFAIL}`
          });
        }
      });
    },
    /**
     * 连续包月 支付宝
    */
    _contractPayCreated(params, path){
      let _t = this;
      this._postCreated(params).then(res => {
        console.log(res);
        let code = res.code;
        if (code == ERR_OK) {
          _t._contractWebPay(res);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _contractWebPay(result) {
      if (result.data) window.location.href = result.data.contractLink;
    }
  }
};
