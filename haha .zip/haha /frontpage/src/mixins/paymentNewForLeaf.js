
/**
 *
 * leaf新接口不再支持参数中为payway的老接口
 * http://bugs.95vintage.com/browse/UP-159
 *
*/


import { ERR_OK, PAY_WAY_WX, PAY_WAY_ALI } from 'api/const';
import { purchase } from 'api/member';
import { mapActions } from 'vuex';
import map from 'common/config/payment/successMap';
import common from 'common/js/common';

const RESULTKEY = 'is_success';
const RESULTSUC = 'T';
const RESULTFAIL = 'F';

const payType = {
  '1': 'ALI_WEB', // 支付宝web
  '2': 'WECHAT_WEB', // 微信web
  '3': 'ALI_AUTH_FREEZE', // 花呗预授权
  '4': 'ALI_CREDIT_LIFE', // 芝麻信用免押
  '5': 'ALI_CONTRACT_BINDING', // 花呗连续包月
  '6': 'ALI_POINT' // 活动支付（积分+金额）
};

// const cardTemplateId = {
//   '1': 1, // 30天月卡
//   '2': 2, // 90天季卡
//   '3': 3 // 365天年卡,
//   '4': 4 // 连续包月
// };

// let map = {
//   BuyPaySuccess: '/Buy/paySuccess', // 购买优惠券卡券成功页
//   MemberPaySuccess:'/Member/normalResultPage', // 新购买会员卡成功页
//   ProductPaySuccess: '/Buy/paySuccessClothes', // 购买衣服成功页
//   PayGownSuccess: '/Buy/payGownSuccess', // 礼服成功失败页面
//   MayiExchangeSuccess: '/Promotion/mayiExchange_r', // 蚂蚁活动成功失败页面
//   ContractResultSuccess: '/Member/contractResultPage' //连续包月
// };


export default {
  data() {
    return {
      _timer: null,
      __options: null
    };
  },
  methods: {
    ...mapActions(['setErrorMsg']),
    _successMaping(keyName) {
      // 支付宝会在支付结果页面中写入is_success=T或者is_success=F
      // 微信需要自己判断并且在链接上加is_success=T或者is_success=F
      if (keyName && map[keyName]) {
        return map[keyName];
      }
      return keyName;
    },
    _creatPayment(args) {
      /**
       * {args} Object 参数对象
       * {args.params} Object 发起支付所需参数
       * {args.success} String 成功或者失败之后的回调页面地址
       * {args.redirect} String 成功或者失败之后的回调页面地址
       * {args.callBack} function 花呗预授权,支付内发起之后的回调处理。非支付宝内发起回调不处理
       */

      //缓存发起时候的参数 如果发起的是花呗预授权,需要再一次发起现金支付
      this.__options = JSON.parse(JSON.stringify(args));

      args.params = this._setDefalutOptions(args.params || {});

      this._subOrder(args);
    },
    _subOrder(args) {
      let params = args.params;
      let successmapkey = args.success;
      let redirect = args.redirect || '';
      let callBackFn = args.callBack || function() {};
      //支付成功失败回调页面
      let success = this._successMaping(successmapkey);

      //发起支付的回调链接
      let callBackPath
      if(redirect){
        callBackPath  = `${this._formatUrl(success)}&redirect=${encodeURIComponent(redirect)}`
      }else{
        callBackPath = success
      }

      //发起支付的全链接
      let callBackFullPath = `${
        window.location.origin
      }/yi23/Home${callBackPath}`;

      params = Object.assign({}, params, {
        returnUrl: callBackFullPath
      });

      /**
       * 如果是在微信中支付给后端传openId
      */
      this._isInWeChat(params);

      if (params.payType == 'ALI_WEB') {
        //支付宝
        this._aliPayCreated(params, callBackPath);
      } else if (params.payType == 'WECHAT_WEB') {
        //微信
        /*
        * 微信支付的特殊性
        * 需要验证授权安全地址,spa在路由变化时候，微信内捕捉不到刷新的地址
        * 所以用window.localtion.href 跳转支付拉起页
        */
        let pathName = window.location.pathname;
        if (pathName.indexOf('/yi23/Home/Pay/wxpayment') > -1) {
          //微信支付发起页面
          //微信支付
          this._wxPayCreated(params, callBackPath);
        } else {
          //非微信支付发起页面
          window.location.href = `/yi23/Home/Pay/wxpayment?params=${encodeURIComponent(
            JSON.stringify(params)
          )}&success=${encodeURIComponent(
            success
          )}&redirect=${encodeURIComponent(redirect)}`;
        }
      } else if (params.payType == 'ALI_CREDIT_LIFE') {
        //芝麻信用租
        this._creditLifePayCreated(params);
      } else if (params.payType == 'ALI_AUTH_FREEZE') {
        //花呗预授权
        this._freezePayCreated(params);
      } else if (
        params.payType == 'ALI_CONTRACT_BINDING' || params.payType == 'WECHAT_CONTRACT_BINDING' || params.payType == 'WECHAT_WEB_CONTRACT_BINDING'
      ) {
        //连续包月
        this._contractPayCreated(params, callBackPath);
      } else if (params.payType == 'ALI_POINT') {
        // 积分+现金支付
        this._pointPayCreated(params, callBackPath);
      } else {
        console.log('非约定支付类型');
      }
    },
    _isInWeChat(params){

      let wxreg = /^WECHAT/;
      if(wxreg.test(params.payType)){
        //获取微信openID
        params.openId = common.getCookie('wx_flag');
      }

    },
    _setDefalutOptions(params) {

      /**
       * 根据浏览器写入默认支付方式,提供后期发起支付时写入发起参数中
       * params 支付请求所带参数
       */

      if (!params['payType']) {
          params['payType'] = this._getClientPayType();
      }

      return params;
    },
    _getClientPayType() {
      let clientType = this.$clientType;
      const clientMap = {
        '3': payType['2'], // 新接口微信支付
        '4': payType['1'] // 新接口支付宝支付
      };
      if (clientMap[clientType]) {
        return clientMap[clientType];
      }
      return clientMap[4];
    },
    _postCreated(params) {

     let payType = params.payType;

     delete params.payType;

     return purchase(payType,params).then((res)=>{

        /**
         * 缓存支付接口返回的成功页面数据
        */

        if(res.data && JSON.stringify(res.data.successInfo) != '{}'){
          localStorage.setItem('paySuccessInfo', JSON.stringify(res.data.successInfo));
        }

        return res;

      });

    },
    _formatUrl(callBackUrl) {
      let url = callBackUrl;
      if (url.indexOf('?') > -1) {
        url = `${url}&`;
      } else {
        url = `${url}?`;
      }
      return url;
    },

    /*
    * 支付宝现金支付
    */
    _aliPayCreated(params, path) {
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          _t._aliWebPay(res.data);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _aliWebPay(resultData) {

      let formStr;

      formStr = buildRequestForm(resultData.paymentInfo,'GET','');

      function buildRequestForm(param, method, btnName) {

        /**
         * @param {Obj} param  接口返回加签后的参数
         * @param {str} method form发起的方式
         * @param {str} btnName 按钮名称
        */

        let htmlRes = '';

        htmlRes +='<form id="alipaysubmit" name="alipaysubmit" action="https://mapi.alipay.com/gateway.do?_input_charset=utf-8" method="'+method+'" >';

        Object.keys(param).forEach(item => {
          htmlRes += '<input type="hidden" name="'+item+'" value="'+param[item]+'" />';
        });

        htmlRes += '<input type="submit" value="'+ btnName +'" ></form>';
        htmlRes += '<script>document.forms["alipaysubmit"].submit();</script>';

        return htmlRes;
      }

      const div = document.createElement('div');
      div.innerHTML = formStr;

      this.$nextTick(function() {
        document.body.appendChild(div);
      });

      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._timer = setTimeout(() => {
        document.forms.alipaysubmit.submit();
      }, 20);
    },

    /*
    * 微信现金支付
    */
    _wxPayCreated(params, path) {
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          _t._wxAppPay(res.data.paymentInfo, path);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.replace({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _wxAppPay(resultData, path) {
      let _t = this;
      let routerPath = _t._formatUrl(path);

      function onBridgeReady(){
        WeixinJSBridge.invoke(
          'getBrandWCPayRequest',
          {
            appId: resultData.appid,
            nonceStr: resultData.noncestr,
            package: resultData.package,
            paySign: resultData.sign,
            signType: 'MD5',
            timeStamp: resultData.timestamp.toString()
          },
          function(res) {
            if (res.err_msg == 'get_brand_wcpay_request:ok') {
              _t.$router.replace({
                path: `${routerPath}${RESULTKEY}=${RESULTSUC}`,

              });
            } else {
              _t.$router.replace({
                path: `${routerPath}${RESULTKEY}=${RESULTFAIL}`
              });
            }
          }
        );
      }

      if (typeof WeixinJSBridge == 'undefined') {
        if (document.addEventListener) {
          document.addEventListener(
            'WeixinJSBridgeReady',
            onBridgeReady,
            false
          );
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      } else {
        onBridgeReady();
      }

    },

    /*
    * 花呗预授权
    * */
    _freezePayCreated(params) {
      /*
      * 发起花呗预授权
      * {params} Object 发起预授权参数
      * {callBack} fun 回调处理
      */
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == 200) {
          //检测是否在支付宝内
          if(this.$clientType === 4){
            //内部拉起花呗预授权
            _t._freezeAppPay(res);
          }else{
             //外部拉起花呗
            _t._freezeWebPay(res);
          }
        } else if (code == 110) {
          let __options = JSON.parse(JSON.stringify(_t.__options));
          __options.params.payType = ''; //置空payType
          //发起现金支付
          _t._creatPayment(__options);
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _freezeWebPay(result) {
      //web拉起花呗预授权
      if (result.data) window.location.href = result.data.freezeLink;
    },
    _freezeAppPay(result) {

      let _t = this;

      //将外部链接转换成支付宝端内发起的参数
      if(result.data && result.data.freezeLink && result.data.freezeLink.indexOf('https://mapi.alipay.com/gateway.do?') != -1){
        result.data.freezeLink = result.data.freezeLink.replace('https://mapi.alipay.com/gateway.do?', '');
      }

      //支付宝端拉起花呗预授权
      AlipayJSBridge.call('tradePay', { orderStr: result.data.freezeLink }, function(
        result
      ) {
        let __options = JSON.parse(JSON.stringify(_t.__options));
        __options.params.payType = ''; //置空payType
        //发起现金支付
        _t._creatPayment(__options);
      });

    },

    /**
     * 芝麻信用租
     */
    _creditLifePayCreated(params) {
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          _t._creditLifeWebPay(res);
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _creditLifeWebPay(result) {
      if (result.data) window.location.href = result.data.creditLink;
    },

    /*
    * 连续包月 支付宝和微信
    * */
    _contractPayCreated(params, path) {
      let _t = this;
      this._postCreated(params).then(res => {
        console.log(res);
        let code = res.code;
        if (code == ERR_OK) {
          _t._contractWebPay(res);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    _contractWebPay(result) {
     if (result.data) window.location.href = result.data.contractLink;
    },

    /*
    * 活动支付
    * */
    _pointPayCreated(params, path) {
      let _t = this;
      this._postCreated(params).then(res => {
        let code = res.code;
        if (code == ERR_OK) {
          _t._aliWebPay(res.data);
        } else if (code == 110) {
          let routerPath = _t._formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${RESULTKEY}=${RESULTSUC}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    }
  }
};
