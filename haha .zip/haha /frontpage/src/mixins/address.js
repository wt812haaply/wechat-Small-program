import {mapActions, mapGetters} from "vuex";

export default {
  created() {
    console.log("33333");
    this.getAddressInfo();
  },
  computed: {
    ...mapGetters({
      addressInfo: "addressInfo"
    })
  },
  methods: {
    ...mapActions(["getAddressInfo"])
  }
};
