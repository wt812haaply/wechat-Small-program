/**
 * 衣服购买
 */

import { payment } from 'api/member';
import { mapActions } from 'vuex';
import map from 'common/config/payment/successMap';
import common from 'common/js/common';

const SUCCESS_KEY = 'is_success';
const SUCCESS_T = 'T';
const SUCCESS_F = 'F';

const PAY_WAY_WX = 2; //微信支付
const PAY_WAY_ALI = 3; //支付宝支付

export default {
  methods: {
    ...mapActions(['setErrorMsg']),
    clothes_successMaping(keyName) {
      // 支付宝会在支付结果页面中写入is_success=T或者is_success=F
      // 微信需要自己判断并且在链接上加is_success=T或者is_success=F
      if (keyName && map[keyName]) {
        return map[keyName];
      }
      return keyName;
    },
    clothes_creatPayment(args,cb) {
      /**
       * {args} Object 参数对象
       * {args.params} Object 发起支付所需参数
       * {args.success} String 成功或者失败之后的回调页面地址
       * {args.redirect} String 成功或者失败之后的回调页面地址
       * @param {Fun} cb 花呗预授权,支付内发起之后的回调处理。非支付宝内发起回调不处理
       */

      args.params = this.clothes_setDefalutOptions(args.params || {});

      this.clothes_subOrder(args,cb);

    },
    clothes_subOrder(args,cb) {
      let params = args.params;
      let successmapkey = args.success;
      let redirect = args.redirect || '';
      let callBackFn = cb || function() {};
      //支付成功失败回调页面
      let success = this.clothes_successMaping(successmapkey);

      //发起支付的回调链接
      let callBackPath;
      if (redirect) {
        callBackPath = `${this.clothes_formatUrl(
          success
        )}&redirect=${encodeURIComponent(redirect)}`;
      } else {
        callBackPath = success;
      }

      //发起支付的全链接
      let callBackFullPath = `${
        window.location.origin
      }/yi23/Home${callBackPath}`;

      params = Object.assign({}, params, {
        returnUrl: callBackFullPath
      });

      /**
       * 如果是在微信中支付给后端传openId
       */
      this.clothes_isInWeChat(params);

      if (params.payWay == PAY_WAY_ALI) {
        //支付宝
        this.clothes_aliPayCreated(params, callBackPath);
      } else if (params.payWay == PAY_WAY_WX) {
        //微信
        /*
         * 微信支付的特殊性
         * 需要验证授权安全地址,spa在路由变化时候，微信内捕捉不到刷新的地址
         * 所以用window.localtion.href 跳转支付拉起页
         */
        let pathName = window.location.pathname;
        if (pathName.indexOf('/yi23/Home/Pay/wxPayClothes') > -1) {
          //微信支付发起页面
          this.clothes_wxPayCreated(params, callBackPath);
        } else {
          //非微信支付发起页面
          window.location.href = `/yi23/Home/Pay/wxPayClothes?params=${encodeURIComponent(
            JSON.stringify(params)
          )}&success=${encodeURIComponent(
            success
          )}&redirect=${encodeURIComponent(redirect)}`;
        }
      } else {
        console.log('非约定支付类型');
      }
    },
    clothes_isInWeChat(params) {
      let wxreg = /^WECHAT/;
      if (wxreg.test(params.payType) || params.payWay == PAY_WAY_WX) {
        //获取微信openID
        params.openid = common.getCookie('wx_flag');
      }
    },
    clothes_setDefalutOptions(params) {
      /**
       * 根据浏览器写入默认支付方式,提供后期发起支付时写入发起参数中
       * params 支付请求所带参数
       */
      if (!params['payWay']) {
        params['payWay'] = this.clothes_getClientPayType();
      }

      return params;
    },
    clothes_getClientPayType() {

      let clientType = this.$clientType;

      const clientMap = {
        '3': PAY_WAY_WX, //微信支付
        '4': PAY_WAY_ALI //支付宝支付
      };

      if (clientMap[clientType]) {
        return clientMap[clientType];
      }
      return clientMap[4];
    },
    clothes_postCreated(params) {
      return payment(params);
    },
    clothes_formatUrl(callBackUrl) {
      let url = callBackUrl;
      if (url.indexOf('?') > -1) {
        url = `${url}&`;
      } else {
        url = `${url}?`;
      }
      return url;
    },

    /*
     * 支付宝现金支付
     */
    clothes_aliPayCreated(params, path) {
      let _t = this;
      this.clothes_postCreated(params).then(res => {
        let code = res.code;
        if (code == 200) {
          _t.clothes_aliWebPay(res.data);
        } else if (code == 110) {
          let routerPath = _t.clothes_formatUrl(path);
          _t.$router.push({
            path: `${routerPath}${SUCCESS_KEY}=${SUCCESS_T}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    clothes_aliWebPay(resultData) {
      let formStr;

      formStr = buildRequestForm(resultData.paymentInfo, 'GET', '');

      function buildRequestForm(param, method, btnName) {
        /**
         * @param {Obj} param  接口返回加签后的参数
         * @param {str} method form发起的方式
         * @param {str} btnName 按钮名称
         */

        let htmlRes = '';

        htmlRes +=
          '<form id="alipaysubmit" name="alipaysubmit" action="https://mapi.alipay.com/gateway.do?_input_charset=utf-8" method="' +
          method +
          '" >';

        Object.keys(param).forEach(item => {
          htmlRes +=
            '<input type="hidden" name="' +
            item +
            '" value="' +
            param[item] +
            '" />';
        });

        htmlRes += '<input type="submit" value="' + btnName + '" ></form>';
        htmlRes += '<script>document.forms["alipaysubmit"].submit();</script>';

        return htmlRes;
      }

      const div = document.createElement('div');
      div.innerHTML = formStr;

      this.$nextTick(function() {
        document.body.appendChild(div);
      });

      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._timer = setTimeout(() => {
        document.forms.alipaysubmit.submit();
      }, 20);
    },

    /*
     * 微信现金支付
     */
    clothes_wxPayCreated(params, path) {
      let _t = this;
      this.clothes_postCreated(params).then(res => {
        let code = res.code;
        if (code == 200) {
          _t.clothes_wxAppPay(res.data.paymentInfo, path);
        } else if (code == 110) {
          let routerPath = _t.clothes_formatUrl(path);
          _t.$router.replace({
            path: `${routerPath}${SUCCESS_KEY}=${SUCCESS_T}`
          });
        } else {
          //toast
          _t.setErrorMsg(res.msg);
        }
      });
    },
    clothes_wxAppPay(resultData, path) {
      let _t = this;
      let routerPath = _t.clothes_formatUrl(path);

      function onBridgeReady() {
        WeixinJSBridge.invoke(
          'getBrandWCPayRequest',
          {
            appId: resultData.appId,
            nonceStr: resultData.nonceStr,
            package: resultData.package,
            paySign: resultData.sign,
            signType: 'MD5',
            timeStamp: resultData.timeStamp.toString()
          },
          function(res) {
            if (res.err_msg == 'get_brand_wcpay_request:ok') {
              _t.$router.replace({
                path: `${routerPath}${SUCCESS_KEY}=${SUCCESS_T}`
              });
            } else {
              _t.$router.replace({
                path: `${routerPath}${SUCCESS_KEY}=${SUCCESS_F}`
              });
            }
          }
        );
      }

      if (typeof WeixinJSBridge == 'undefined') {
        if (document.addEventListener) {
          document.addEventListener(
            'WeixinJSBridgeReady',
            onBridgeReady,
            false
          );
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      } else {
        onBridgeReady();
      }
    }
  }
};
