/*
 * 老带新，邀请好友，上报App,ab测
 * */

import yi23JsBridge from 'common/js/yi23JSBridge';

import { getClientTypeString } from 'common/js/utils';

export default {
  methods: {
    uploadAdhocName() {
      let osTypeStr = getClientTypeString();
      console.log(osTypeStr);
      if (osTypeStr === 'ios' || osTypeStr === 'android') {
        yi23JsBridge.jsBridgeCall('uploadAdhocName', 'Invite_Post_Share');
      }
    }
  }
};
