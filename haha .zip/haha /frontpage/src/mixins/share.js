import {
  mapActions
} from 'vuex'

export default {
  created() {
    // this.setShareMessage(this.getInitShareMsg());
  },
  methods: {
    ...mapActions([
      'setShareMessage',
      'clearShareMessage',
      'doShare'
    ]),
    getInitShareMsg() {
      return {
        title: document.title,
        url: '',
        shareType: '0',
        message: '一百万件大牌服饰天天上新',
        image: 'http://tu.95vintage.com/web/images/activity/201711/share240logo.png'
      }
    }
  },
  beforeDestroy() {
    this.clearShareMessage(this.getInitShareMsg())
  }
}