// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill';
import Vue from 'vue';
import App from './App';
import router from './router';
import store from './store';
import { mapGetters } from 'vuex';
import { getClientType } from 'common/js/utils';
import * as filter from 'common/js/filter';
import directiveObject from 'common/js/directive/index';
import axios from './utils/http';
import VueAwesomeSwiper from 'vue-awesome-swiper';
import VueLazyload from 'vue-lazyload';
import { InfiniteScroll } from './utils/directive/index';
import { afterEach, beforeEach } from '@/router/globalGuards';
import loginLocal from '@/common/js/login';
import { getUserKey } from 'api/user';
import 'common/less/index.less';
import Worker from '@/common/workers/dataCount.worker.js';
import dataCount from '@/utils/dataCount'
Vue.config.productionTip = false;
import config from '@/api/config'
import components from '@/components';

Vue.use(components);

Vue.mixin({
  computed: {
    ...mapGetters({
      bigLoading: 'getBigLoading'
    })
  },
  beforeRouteEnter(to, from, next) {
    next(vm => {
      try {
        let postion= to.meta.saved_position;
        vm.$nextTick(()=>{
          postion && document.querySelector &&  document.querySelector('.yclosetCon') && (document.querySelector('.yclosetCon').scrollTop=postion.y)
        } )
        if (loginLocal.getToken() && !sessionStorage.getItem('uid_status')) {
          getUserKey().then(res => {
            let uid = '';
            if (res.code == 200) {
              uid = res.data.key;
              sessionStorage.setItem('uid_status', 1);
              if (window.sa && window.sa.login) {
                window.sa.login(uid);
              }
            }
          });
        }
        if (
          window.sa &&
          window.sa.quick &&
          window.canDoCount &&
          !vm.isFatherRouter
        ) {
          window.sa.quick('autoTrackSinglePage');
        } else {
          window.canDoCount = true;
        }
      } catch (e) {
        console.log(e);
      }
    });
  },
  beforeRouteUpdate(to, from, next) {
    next();
    if (from.name == 'pdtDetailPage') {
      sa.quick('autoTrackSinglePage');
    }
  }
});

//过滤器
Object.keys(filter).forEach(key => {
  Vue.filter(key, filter[key]);
});

Object.keys(directiveObject).forEach(key => {
  Vue.directive(key, directiveObject[key]);
});

Vue.prototype.axios = axios;
Vue.prototype.$clientType = getClientType();

Vue.use(VueAwesomeSwiper);
Vue.use(VueLazyload,{
  adapter: {
    loaded ({ bindType, el, naturalHeight, naturalWidth, $parent, src, loading, error, Init }) {

      dataCount.pushLoadData(src)
    },
    loading (listender, Init) {
      // console.log('loading')
      // console.log(listender)
    },
    error (listender, Init) {
      // console.log('error')
    }
  }
});
// Vue.use(VueLazyload);
Vue.use(InfiniteScroll);

router.beforeEach(beforeEach);
router.afterEach(afterEach);

try{
  window.dataWorker=new Worker()
  window.dataWorker.postMessage({type: '6', data: {url:config.hostLeaf+'/user/report'}})
  dataWorker.onmessage=function (e) {
    console.log(e)
  }
}catch (e){
  console.log(e)
}



/* eslint-disable no-new */
window.vueObj = new Vue({
  el: '#app',
  router,
  axios,
  store,
  components: {
    App
  },
  template: '<App/>'
});
