/**
 * Created by ahu on 2018/11/21
 */
export default {
  '/leaf/products/list': {
    paths: [
      {
        name: 'product',
        pid: 'product_id',
        key: 'thumb_pic',
        path:'path',
        type:'product_list',
      }
    ],
    paging: true,
    params: 'page'
  },
  '/leaf/products/XX/recommend': {
    paths: [
      {
        name: 'relatedProducts',
        pid: 'product_id',
        key: 'thumb_pic',
        type:'product_detail_related',
        path:'path',
      },
      {
        name: 'recommendedProducts',
        pid: 'product_id',
        key: 'thumb_pic',
        type:'product_detail_related',
        path:'path',
      },
    ],
  },
  '/yi23/Home/Ajax/Subscribe/promotionListPage': {
    paths: [
      {
        name: 'productinfo',
        pid: 'product_id',
        key: 'thumb_pic',
        path:'path',
        type:'product_short_list',
      }
    ],
    paging: true,
    params: 'page'
  }
}
