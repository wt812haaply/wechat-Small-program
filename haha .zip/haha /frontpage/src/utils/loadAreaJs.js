/**
 * Created by ahu on 2018/5/29
 */
import { getUserKey } from 'api/user'
export default {
  jsUrl:'//webapi.amap.com/maps?v=1.4.0&key=8bdc6ff118ca0b357fcf7c3edb48b3d6&plugin=AMap.iCenter',
  init(callback){
    let _t=this;
    _t.doLoad(_t.jsUrl,function () {

      callback && callback();
    })
  },
  doLoad (url ,callback) {
    let _doc = document.getElementsByTagName("head")[0]
    let _script = document.createElement("script")
    let _body = document.getElementsByTagName("body")[0]
    _script.setAttribute("type","text/javascript");
    _script.setAttribute("src",url);
    _doc.appendChild(_script);
    _script.onload = function () {
      typeof(callback) == 'function' ? callback() : "";
    };
  },

}
