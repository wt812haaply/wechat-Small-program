/**
 * Created by ahu on 2018/5/30
 */
export function  scrollBehavior(to, from, savedPosition) {
  if (to.matched.some(t => t.meta.keepAlive)) {
    if (savedPosition === null) {
      to.meta.saved_position = null;
    } else {
      savedPosition = to.meta.saved_position;
    }
    let back = savedPosition ? savedPosition : {x: 0, y: 0};
    if(to.name=='pdtListPage'){
      document.querySelector &&  document.querySelector('.yclosetCon') && (document.querySelector('.yclosetCon').scrollTop=back.y)
    }else{
      back={x: 0, y: 0}
    }
    return back;
  }else{
    return {x: 0,y: 0}
  }
}
