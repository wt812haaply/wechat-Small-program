/**
 * Created by ahu on 2018/5/29
 */
import { getUserKey } from 'api/user'
export default {
  jsUrl:'//qiyukf.com/script/a97b9e4983d84c522db675daa364254a.js',
  init(name,clientType,needRefresh){
    let _t=this;

    _t.doLoad(_t.jsUrl,function () {

      getUserKey().then((res)=>{
        console.log(res);
        let uid='';
        if(res.data.code==200){
            uid=res.data.key
        }
        let qtype = 41127;//默认值
        if(clientType==4){
          switch (name){
            case 'pdtDetailPage':
              qtype = 49020
              break;
            case 'gownDetailPage':
              qtype = 49021
              break;
            case 'index':
              qtype = 45084
              break;
            default:
              qtype = 41127
              break;
          }
        }

        ysf.on({
          'onload': function(){
            ysf.config({
              uid:uid,
              qtype:qtype
            });
          }
        });
      });

      //如果当前页面需要刷新,iframe中加载一个带needRefreshView标记的资源
      if(needRefresh){
        _t.needRefreshView()
      }

    })
  },
  doLoad (url ,callback) {
    let _doc = document.getElementsByTagName("head")[0]
    let _script = document.createElement("script")
    let _body = document.getElementsByTagName("body")[0]
    _script.setAttribute("type","text/javascript");
    _script.setAttribute("src",url);
    _doc.appendChild(_script);
    _script.onload = function () {
      typeof(callback) == 'function' ? callback() : "";
    };
  },
  needRefreshView(){
    var iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.setAttribute(
      'src',
      '//yimg.yi23.net/webimg/web/images/20180619/iconWee.png?needRefreshView=1'
    );

    var iframeCallback = function() {
      console.log('333333');
      setTimeout(function() {
        iframe.removeEventListener('load', iframeCallback);
        document.body.removeChild(iframe);
      }, 0);
    };

    iframe.addEventListener('load', iframeCallback);

    document.body.appendChild(iframe);

  }
}
