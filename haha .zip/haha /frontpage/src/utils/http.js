import axios from 'axios';
import store from '../store';
import router from '../router';
import loginLocal from '@/common/js/login';
import smallLoading from '@/components/lib/smallLoading';
import qs from 'qs';
import filterImage from '@/utils/filterImage';
import region from '@/common/js/region';
import dataCount from '@/utils/dataCount'
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
// console.log('---axios init--')
axios.defaults.withCredentials = true;
axios.interceptors.request.use(
  config => {
    // console.log(qs.stringify(config.data))
    if (!config.headers.hideLoading) {
      smallLoading.open();
    }
    if (config.method == 'post') {
      //console.log(config.headers.yi23ImgLoad)
      // formData 格式判断处理
      if (config.headers.yi23ImgLoad) {
      } else {
        config.data = qs.stringify(config.data);
      }
    } else {}
    let authorization = loginLocal.getToken();
    if (authorization) {
      config.headers.authorization = authorization;
      store.commit('getToken', authorization);
    }
    if(region.getLocalRegion() && region.getLocalRegion().regionId){
      config.headers.region = region.getLocalRegion().regionId
    }else{
      config.headers.region=52
    }
    // if (store.state.login && store.state.login.authorization) {
    //   config.headers.authorization = store.state.login.authorization;
    // }

    return config;
  },
  err => {
    return Promise.reject(err);
  }
);
axios.interceptors.response.use(
  response => {
    let authorization = loginLocal.getToken();
    smallLoading.close();
    let config =response.config
    filterImage.filterStart(response)
    dataCount.dataProcess(config,response,authorization)
    return response;
  },
  error => {
    smallLoading.close();
    console.log(error);
    if (error.response) {
      switch (error.response.status) {
        case 401:
          store.commit('loginOut');
          store.commit('bigLoading', false);
          console.log('401');
          window.location.href = `/architecture/login?redirect=${encodeURIComponent('/yi23/Home' + router.currentRoute.fullPath)}`;
          break;
         //中台返回错误为400
        case 400:
          return error.response.data;
          break;
      }
    }
    return Promise.reject(error.response);
  }
);

export default axios;
