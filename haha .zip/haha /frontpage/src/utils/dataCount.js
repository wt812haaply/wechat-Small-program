/**
 * Created by ahu on 2018/11/19
 */
import keyPool from './countKeyPool'

export default {
  currentPage: {
    routerName: '',
    url: []
  },
  prevPage: {
    routerName: '',
    url: []
  },
  page: {
    currentIdMap: '',
    prevIdMap: ''
  },
  guid () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  },
  createIdMap (urlId) {
    let uuid = this.guid()
    this.page.prevIdMap = this.page.currentIdMap
    this.page.currentIdMap = {id: uuid, val: urlId}
    return {id: uuid, val: urlId}
  },
  imgRequstMap: {},
  createSendData (urlId, sendData, idMap) {
    window.dataWorker.postMessage({type: '1', data: idMap})
    let resData = {
      id: urlId,
      uuid: idMap.id,
      responseData: {
        list: sendData
      },
      lazyData: {
        list: []
      }
    }
    window.dataWorker.postMessage({type: '0', dataType: '0', data: resData})
  },
  dataProcess (config, response, auth) {
    let urlStr= this.poolCheck(config.url)
    if (urlStr) {
      let urlId = encodeURIComponent(response.request.responseURL)
      let dataFilter = keyPool[urlStr]
      let idMap = this.createIdMap(urlId)
      if(auth){
        window.dataWorker.postMessage({type: '7', data: auth})
      }
      if (dataFilter.paging) {//如果有分页 分页
        let page = config.params[dataFilter.params]
        if (page > 1) {
          // console.log(this.page)
          window.dataWorker.postMessage({type: '2', data: this.page.prevIdMap})
        }
      }
      this.eidtImgUrl(urlId,dataFilter,response,idMap)
    }
    return response
  },
  eidtImgUrl(urlId,dataFilter,response,idMap){
    let paths=dataFilter.paths;
    let sendData = []
    for (var key in paths){
      let item=paths[key]
      response.data.data[item.name] = response.data.data[item.name].map((el) => {
        sendData.push({pid: el[item.pid], path: el[item.path], type: item.type})
        let imgParams='yT=' + idMap.id + '@@' + el[item.pid]+'@@'+el[item.path]+'@@'+item.type;
        if(el[item.key] && el[item.key].indexOf('?')!=-1){
          el[item.key] = el[item.key] + '&'+imgParams
        }else{
          el[item.key] = el[item.key] + '?'+imgParams
        }

        return el
      })
    }
    this.createSendData(urlId, sendData, idMap)
    return response
  },
  pushLoadData (lazyUrl) {
    if(lazyUrl && lazyUrl.indexOf('yT=')!=-1){
      window.dataWorker.postMessage({type: '3', data: lazyUrl})
    }
  },
  poolCheck (url) {
    let keys = Object.keys(keyPool)
    let key = keys.filter((el) => {
      let as = el.split('XX')
      if (as.length > 1) {
        let regStr = as[0] + '.*' + as[1] + '$'
        let reg = new RegExp(regStr)
        if (reg.test(url)) {
          return el
        }
      } else if (url.indexOf(el)!=-1) {
        return el
      }
    })
    return key[0]
  }
}

