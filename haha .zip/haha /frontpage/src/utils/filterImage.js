const actions = () => {
  return new Map([
    [
      /http:\/\/tu\.yi23\.net([^"]+[png|jpe?g|gif|svg])(\!(\d+)w?)?/gi,(response) => {

        let dataStr = JSON.stringify(response.data);
        let replaceData = dataStr.replace(
          /http:\/\/tu\.yi23\.net([^"]+[png|jpe?g|gif|svg])(\!(\d+)w?)?/gi,
          (match, p1, p2, p3) => {
            const getOssProcessStr = function(width) {
              let ossProcessStr = "?x-oss-process=image/resize,m_lfit,w_";
              if (width) return (ossProcessStr += width);
              return "";
            };

            return `https://tu.95vintage.com${p1}${getOssProcessStr(p3)}`;
          }
        );
        response.data = JSON.parse(replaceData);

      }
    ]
  ]);
};

export default {
  /**
   * @param {Object} response
   */

  filterStart(response) {

    let { data } = response;

    if (!data) {
      return response;
    }

    let dataStr = JSON.stringify(data);

    const filterArr = [...actions()].filter(([key, value]) => {
      return key.test(dataStr);
    });

    filterArr.length > 0 &&
      filterArr.forEach(([key, value]) => value.call(this, response));

    return response;
  }
};
