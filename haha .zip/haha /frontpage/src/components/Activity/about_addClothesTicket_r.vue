<template>
  <div>

    <!--成功-->
    <div class="share_Card_Result" v-if="shareCardF_result == 'T'">
      <h2>
        <i><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/iconSuccess.svg" alt=""></i>
        购买成功</h2>
      <p class="font-r">恭喜你成功购买衣二三7天体验卡</p>
      <button class="btnA font-m" @click="newBox()">开启会员随心换穿</button>
      <button class="btnB font-m" @click="download()">下载衣二三APP</button>
    </div>

    <!--失败-->
    <div class="share_Card_Result" v-if="shareCardF_result == 'F'">
      <h2>
        <i><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/iconFailure.jpg" alt=""></i>
        兑换失败</h2>
      <p class="font-r">亲，您支付失败，请冲重新支付～</p>
      <button class="btnA font-m" @click="exchange()">重新购买</button>
    </div>

  </div>
</template>
<script>
  import common from 'common/js/common';
export default {
  data() {
    return {
      shareCardF_result:null,
    }
  },
  components: {},
  computed: {},
  methods: {
    //成功按钮跳转
    newBox:function(){
      window.location.href='/yi23/Home/Index/index'
    },
    download:function () {
      window.location.href='https://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan'
    },
    //重新兑换会员
    exchange:function () {

      let packageCode= this.$route.query.packageCode;
      // let mobile= this.$route.query.mobile;
      //
      // // this.$router.push({
      // //   // path:'/Activity/about_addClothesTicket',
      // //   replace: true,
      // //   query: {
      // //     redirect: this.$route.fullPath
      // //   }
      // // })
      //
      // window.location.href='/yi23/Home/Activity/about_addClothesTicket?packageCode='+packageCode+"&mobile="+mobile;


      common.delCookie('experienceMobile');
      window.location.href='/yi23/Home/Activity/experienceCard?packageCode='+packageCode;
    },

  },
  created() {
    let result = this.$route.query.is_success;
    this.shareCardF_result = result;

    let packageCode= this.$route.query.packageCode;
    let mobile= this.$route.query.mobile;

    if(this.shareCardF_result == "T"){

       window.location.href='/yi23/Home/Activity/experienceCard?packageCode='+packageCode;

    }
  },

}

</script>
<style scoped lang="less">
.share_Card_Result {
  text-align: center;
  padding-top: 7.466667rem;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  flex-wrap: wrap;
  h2 {
    width: 100%;
    font-size: 1.066667rem;
    height: 3.2rem;
    display: flex;
    align-items: center;
    justify-content: center;
    i {
      width: 1.386667rem;
      height: 1.386667rem;
      position: relative;
      top: 0;
      right: 0.266667rem;

      img {
        width: 1.386667rem;
        position: absolute;
        left:0;
        top:0;
      }
    }
  }
  p {
    font-size: 0.746667rem;
    line-height: 1.64;
    letter-spacing: 0.8px;
    text-align: center;
    color: #111111;
    margin-bottom: 2.453333rem;
  }
  button {
    width: 10.773333rem;
    height: 2.133333rem;
    color: #fff;
    font-size: 0.746667rem;
  }
  button.btnA {
    background: #ff544b;
  }
  button.btnB {
    margin-top: 1.066667rem;
    border: 1px #ff544b solid;
    background: transparent;
    color: #ff544b;
  }
}

</style>
