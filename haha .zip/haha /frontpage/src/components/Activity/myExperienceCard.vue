
<template>
  <section class="yclosetContainer">
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="top_box" v-if="item">
        <div class="top">
          <div class="img_load_box">
            <div class="img_load_bg">
              <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/skirt.png" alt="">
            </div>
            <div class="img_load wave current" ref="current"></div>
          </div>
        </div>
        <h1>我目前拥有<span v-text="item.currentPiece"></span>张</h1>
        <p>集齐1张加衣券，下单多加一件哦</p>
        <nav class="nav">
          <ul>
            <li :class="{active:currentTab=='listReward'}" @click="toggleTab('listReward')">
              奖励记录
            </li>
            <li :class="{active:currentTab=='listHave'}" @click="toggleTab('listHave')">
              已获加衣券<span v-if="item.couponList&&item.couponList.length>0">({{item.couponList.length}})</span>
            </li>
          </ul>
        </nav>
      </div>

      <list-have v-show="currentTab == 'listHave'" v-if="item.pieceList" :info="item.couponList"></list-have>
      <list-reward v-show="currentTab == 'listReward'" v-if="item.couponList" :info="item.pieceList"></list-reward>
      <yi23Toast v-model="toastMsg"></yi23Toast>
    </div>
  </section>
</template>

<script>
  import goBack from 'base/GoBack'
  import listHave from './myExperienceCardHave'
  import listReward from './myExperienceCardReward'
  import Validator from 'common/js/class/validator';

  import { shareCouponInfo } from 'api/activity';
  import { ERR_OK }from 'api/const';
  export default {
    name: "box",
    data () {
      return {
        currentTab : 'listHave',
        highlight : 10,
        toastMsg:'',
        item : {}
      }
    },
    watch:{
      highlight:function(val){
        val = val/1.4+35;
        this.comheight(val);
        return val;
      },

      item:function (val) {
        if(!val.couponList&&val.couponList.length==0){
          this.currentTab = 'listReward';
        }
      }
    },
    components:{
      goBack,
      listHave,
      listReward
    },
    created(){
      this.getShareCouponInfo()
    },
    methods:{
      getShareCouponInfo: function () {
        shareCouponInfo().then((res)=>{
          console.log(res);
          if(res.code == ERR_OK){
            console.log(res);
            this.item = res.data;
            this.timer = setTimeout(() => {
              this.highlight = this.item.currentPiece*100;
            }, 500)
          }else{
            this.toastMsg = res.msg;
          }
        })
      },
      toggleTab: function(tab) {
        this.currentTab = tab;
      },
      comheight(val) {
        this.$refs.current.style.height = val +'%';
      },
    },
    mounted(){

    }
  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";
  .yclosetCon{
    display: flex;
    flex-flow: column;
    height: 100%;

    .top_box{
      width: 100%;
      text-align: center;
      .top{
        position: relative;
        width: 29.6vw;
        margin: 0 auto;
        margin-top: 2.133333333333333rem;
        margin-bottom: 1.066666666666667rem;
        overflow: hidden;
        .img_load_bg{
          width: 100%;
          height:auto;
          position: relative;
          z-index: 3;
          img{
            width:100%;
          }
        }
        .img_load{
          position: absolute;
          width: calc(~"100% - 3px");
          height: 0%;
          bottom:1vw;
          left: 1px;
          z-index:1;
          transition:all 2s;
        }
        .wave {
          background-color: #FF544B;

          &::before,
          &::after{
            content: "";
            position: absolute;
            width: 59.2vw;
            height: 59.2vw;
            top: -40%;
            left: 50%;
            background-color: rgba(255, 255, 255, .9);
            border-radius: 45%;
            transform: translate(-50%, -70%) rotate(0);
            animation: rotate 6s linear infinite;
            z-index: 10;
          }

          &::after {
            border-radius: 47%;
            background-color: rgba(255, 255, 255, .8);
            transform: translate(-50%, -70%) rotate(0);
            animation: rotate 10s linear -5s infinite;
            z-index: 20;
          }
        }
        @keyframes rotate {
          50% {
            transform: translate(-50%, -73%) rotate(180deg);
          }
          100% {
              transform: translate(-50%, -70%) rotate(360deg);
            }
        }

      }
      h1{
        color: #FF544B;
        .font-size(12.6);
        .line-height(12.6);
        span{
          .font-size(25.2);
          padding:0 .3rem 0 .3rem;
        }
      }
      p{
        color: #666;
        .font-size(12);
        .margin(10,0,30,0);
      }
    }
    .nav{
      width: 100%;
      ul{
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        line-height: 3.5;
        box-sizing: border-box;
        background-image:linear-gradient(180deg, #e7e7e7, #e7e7e7 50%, transparent 50%);
        background-size: 120% 1px;
        background-repeat: no-repeat;
        background-position: bottom left;
        background-origin: border-box;
      }
      li{
        display: inline-block;
        text-align: center;
        box-sizing: border-box;
        color: #999999;
        .font-size(14);
        .height(38);
        .line-height(38);
        width:50%;
        border-bottom: 1px solid #999;
        position: relative;
        &.active{
          color: #ff544b;
          &::after{
            content: '';
            background: #ff544b;
            .width(53);
            height: 2px;
            position: absolute;
            bottom: 0;
            left: calc(~"50% - 2.826666666666667rem/2");
          }
        }
      }
    }
  }


</style>
