<template>
  <div class="box">

    <div class="shareForCard">
      <!-- top -->
      <div class="PlIMG">
        <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/inviteFriendB.jpg" alt="">
        <div class="input-box">
          <div class="userMb">
            <input type="tel" id="just-mobile" class="mobilePhone font-r" v-model="mobilePhone"  placeholder="请输入衣二三账号（手机号）" >
            <button class="btn btn-defult btn-black font-m active" id="exchange_member" @click="exchange">59元限时体验</button>
          </div>
        </div>
      </div>

    </div>

    <down-app :show="downApp.show"></down-app>

    <yi23Dialog @dialogOk="close" @dialogClose="close" :open="buyOpen" :dialogSm='dialogSm' :hasCannel="false">
      <div slot="body">
        <div class="yi23-dialog__bd" v-text="subMsg"></div>
      </div>
      <div slot="btnOk">现在去选衣</div>
    </yi23Dialog>
    <yi23Toast v-model="toastMsg"></yi23Toast>

    <zhima-verify v-model="zhimaVerify" :showPayBtn="true" @submitPay="submitPay()"></zhima-verify>

  </div>
</template>

<script type="text/ecmascript-6">
  import DownApp from 'base/DownApp';
  import { toastMixin } from 'common/js/mixin';
  import { ERR_OK }from 'api/const';
  import { PAY_WAY_WX , PAY_WAY_ALI } from 'api/const';
  import { share_card_b, exchange_point_payment, confirm_zhima } from 'api/promotion';
  import zhimaVerify from '@/components/Promotion/zhimaVerify';
  let ageList = [];

  export default {
    mixins:[ toastMixin ],
    data(){
      return{
        downApp:{
          show: false
        },
        zhimaVerify: false,
        subMsg   :'您已经是衣二三会员，现在去选衣吧。此卡只限新用户购买哦',
        payInfo:[],
        products:[],
        open: false,
        dialogSm: true,
        hasCannel: true,
        toastOpen: false,
        step: 10000,
        mobilePhone:'',
        specialChannel: '',
        disabled: false,
        buyStatus : '',
        isPass : '',
        buyOpen: false,
      }
    },
    created(){
      this.getArealist();
    },
    computed:{

    },
    watch:{

    },
    mounted(){
      //down-app下拉
      window.addEventListener('scroll', () => {
        var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        if(scrollTop >= 100){
          this.downApp.show = true;
        }else{
          this.downApp.show = false;
        }
      });
    },
    methods:{
      getArealist(){
        this.specialCode = this.$route.query.specialCode;
        this.specialChannel = this.$route.query.specialChannel;
        this.payWay = this.client();
        var urlData = `?specialCode=${this.specialCode}&specialChannel=${this.specialChannel}`;
        share_card_b(urlData).then((res)=>{
          if(res.code == ERR_OK){
            console.log(res);
            this.payInfo = res.data.payInfo;
            this.isPass = res.data.payInfo.depositWaived;
            this.products = res.data.products;
            this.packageCode = res.data.packageCode;
            this.isMember = res.data.payInfo.isToAllMemberType;
            this.allowMember = res.data.payInfo.memberType;
            this.buyStatus = res.data.status;
          }else{
            this.setToastMsg(res.msg);
          }
        })
      },
      client(){
        let clientType = this.$clientType
        const clientMap = {
          '3': PAY_WAY_WX,
          '4': PAY_WAY_ALI
        }
        if (clientMap[clientType]) {
          return clientMap[clientType]
        }
        return clientMap[4]
      },
      showDialog () {
        this.buyOpen = true
      },
      close () {
        this.buyOpen = false
      },
      submitPay () {
        let payData = encodeURIComponent(JSON.stringify({
          'payType':13,
          'couponId':0,
          'aliPointId':this.specialCode,
          'aliAuthToken':'aliAuthToken',
          'payWay':this.payWay,
          'aliUserId':'aliUserId'
        }))
        let host = `${window.location.origin}`;
        let success  = encodeURIComponent(`/Buy/paySuccess`);
        let redirect = encodeURIComponent(`${this.$route.fullPath}`);

        window.location.href = `${host}/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
      },
      exchange () {
        var inputData = `?mobile=${this.mobilePhone}&source=${this.specialChannel}`;
        exchange_point_payment(inputData).then((res)=>{
          if(res.code == ERR_OK) {
            console.log(res);
            var depositStatus = res.data.depositStatus;
            var memberStatus = res.data.memberType;
            if (this.isMember == 0) {
               console.log("user exist")
                var memberArr = this.allowMember.split(',');
                if (memberArr.indexOf(memberStatus.toString())) {
                  this.buyStatus = 'error';
                  this.buyOpen = true;
                  return false;
                }
            }
            if (depositStatus == 0 && this.isPass == 0) {
              console.log(11111)
              //需要支付押金
              this.zhimaVerify = true;
              this.buyOpen = false;
            } else {
              console.log("not")
              //无需支付押金
              this.zhimaVerify = false;
              this.buyOpen = true;
              this.submitPay();
            }
          } else {
            this.setToastMsg(res.msg);
          }
        })
      },
    },
    components:{
      DownApp,
      zhimaVerify
    }
  }
</script>
<style lang="less" rel="stylesheet/less">
  @import "~common/less/share_card_b";
</style>
