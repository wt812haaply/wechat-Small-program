<template>
  <div class="experience">

    <div class="headerImg">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/otherBanner.jpg">
    </div>
    <div class="PlIMG">
      <div class="input-box">
        <div class="userMb">
          <div class="title">当前领取手机号：<span>{{urlmoblie}}</span></div>
          <input type="tel" id="just-mobile" class="mobilePhone font-r" v-model="mobile" placeholder="请输入新的手机号" name="">
          <button class="btn btn-defult btn-black font-m active" id="exchange_member" @click="savePhone">保存</button>
          <div class="tips">温馨提示：修改手机号后，下次将使用新手机号参加领取礼包活动</div>
        </div>
      </div>
    </div>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script type="text/ecmascript-6">
  import yi23Toast from '../lib/Toast.vue';
  import Validator from 'common/js/class/validator';
  export default {
    data(){
      return{
        mobile:'',
        toastMsg:'',
        urlmoblie:""
      }
    },
    components:{
      yi23Toast
    },
    methods:{
      validataFunc(){
        let validator = new Validator();
        //phone
        validator.add(this.mobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },
      savePhone() {
        let msg = this.validataFunc();
        this.toastMsg = msg;
        if(!msg){
            this.$router.go(-1);
        }
      }
    },
    created () {
      let urlmoblie = this.$route.query.moblie;
      this.urlmoblie = urlmoblie
    },
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  /*https://yimg.yi23.net/webimg/web/images/2018/0326/indexVip03.jpg*/

  .experience{
    -webkit-font-smoothing: antialiased;
    width: 100%;
    z-index:10;
    position:relative;
    .headerImg{
      width: 100%;
      .height(200);
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
    .PlIMG {
      width: 100%;
      .height(250);
      overflow: hidden;
      position: relative;
      z-index:1;

      .input-box{
        width: calc(~"100% - 30px");
        position: absolute;
        bottom: 10.5%;
        z-index: 3;
        background: white;
        left: 15px;

        .userMb {
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
          -ms-flex-line-pack: justify;
          align-content: space-between;
          height: auto;
          padding: 1.066667rem;
          padding-top:0;
          .title{
            position: relative;
            display: table;
            white-space: nowrap;
            width: 100%;
            .height(22);
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            .line-height(22);
            letter-spacing: .7px;
            text-align: center;
            color: #666;
            .margin(20,0,10,0);
            .font-size(14);
            span{
              color:#FF544B;
            }
          }
          input {
            width: 100%;
            background: #f4f4f4;
            font-size: .746667rem;
            padding: .853333rem 0 .853333rem .64rem;
            letter-spacing: .2px;
          }

          button {
            width: 100%;
            background: #ff544b;
            letter-spacing: .5px;
            .margin(10,0,0,0);
            font-size: .853333rem;
          }
          .tips{
            color:#FF544B;
            .font-size(12);
            .margin(21,0,0,0);
          }
        }
      }
    }
    .vipInfor {
      width: calc(~"100% - 30px");
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -ms-flex-wrap: wrap;
      flex-wrap: wrap;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      background: #fff;
      margin:0 auto;
      margin-top: .533333rem;
      margin-bottom:10px;
      .title {
        display: table;
        white-space: nowrap;
        width: 90%;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        line-height: 1.77;
        letter-spacing: .7px;
        text-align: center;
        color: #000;
      }
    }
    .footerImg{
      width: 100%;
      .height(70);
      .margin(35,0,0,0);
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
  }
</style>
