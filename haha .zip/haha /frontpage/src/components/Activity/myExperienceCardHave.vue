<template>
  <div class="containe_column">
    <div class="have_list" v-if="info&&info.length>0">
      <div class="card" v-for="item in info" :key="item.id">
        <h1><span> 1 </span>张</h1>
        <p>有效期：<span>{{item.startTime | YYYY_MM_DD}}</span> — <span>{{item.expTime | YYYY_MM_DD}}</span></p>
      </div>
    </div>
    <div class="no_data" v-else>
      <p>您目前还没有完整的加衣券<br>
        再接再厉哦！</p>
    </div>
  </div>
</template>

<script>
  export default {
    name: "list-have",
    data () {
      return {
        currentNav:0
      }
    },
    props:[
      'info'
    ],
    watch:{
      info:function (val) {
        console.log(val)
      }
    },
    created(){
      console.log(this.info);
    }

  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";
  .have_list{
    .padding(20,0,10,0);
    .card{
      .width(306);
      margin: 0 auto;
      margin-bottom: 1.066666666666667rem;
      .height(76);
      background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/blank.jpg") center;background-size: cover;display:block;
      h1,p{
        padding-left: 2.453333333333333rem;
      }
      h1{
        color: #B63A3E;
        .font-size(12.6);
        .line-height(12.6);
        padding-top: 1.013333333333333rem;
        padding-bottom: .32rem;
        span{
          .font-size(25.6);
        }
      }
      p{
        color:#666666;
        .font-size(10);
      }
    }
  }
  .containe_column {
    flex: 1;
    width: 100%;
    height: auto;
    overflow-y: auto;
  }
  .no_data{
    width: 100%;
    height: 100%;
    text-align: center;
    -webkit-display:flex;
    display:flex;
    -webkit-align-items:center;
    align-items:center;
    -webkit-justify-content:center;
    justify-content:center;

    p{
      .font-size(14);
      color: #999999;
      line-height:1.1rem;
      position: relative;
      top:-10%;
    }
  }

</style>
