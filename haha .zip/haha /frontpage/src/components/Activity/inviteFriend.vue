<template>
  <div class="ygirl">

    <div class="headerImg">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/newBg.jpg">
    </div>

    <div class="EntranceCon">
      <div class="title">奖励规则</div>
      <ol class="rules-con">
        <li>
          将礼包分享给微信好友或分享至朋友圈，和好友一起瓜分礼包，共同得奖励；
        </li>
        <li>
          免费体验卡仅限新用户领取，每个礼包最多可被5个新人用户领取；活动期间新人仅可领取1次；

        </li>
        <li>
          新用户领取体验卡后，分享者可随机获得加衣券碎片奖励，奖励会在领取后的24小时内自动放入您的账户中；
        </li>
        <li>
          活动期间有任何问题，请致电衣二三客服进行咨询：400-650-4580。
        </li>
      </ol>
    </div>
    <div class="footerBtn">
      <button @click="shareFor">分享好友得加衣券</button>
    </div>
    <WXbg v-model="shareForImg"></WXbg>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script type="text/ecmascript-6">
  import  WXbg  from 'base/WXbg';
  import {shareBonusCode} from 'api/activity';
  import  shareMixin  from '@/mixins/share';
  import yi23Toast from '../lib/Toast.vue'
  export default {
    mixins:[ shareMixin ],
    data(){
      return{
        toastMsg:null,
        shareForImg:false,
        tips:"请在微信中打开"
      }

    },
    created(){
      let shareid = this.$route.query.shareId;
      let location = this.$route.query.location;
      let yCode  = this.$route.query.yCode;
      let specialChannel  = this.$route.query.specialChannel;
      let reqParam = {
        shareId:shareid,
        location:location,
        yCode:yCode,
        specialChannel:specialChannel
      }
      var urlData = `?shareId=${reqParam.shareId}&location=${reqParam.location}&yCode=${reqParam.yCode}&specialChannel=${reqParam.specialChannel}`;
      shareBonusCode(urlData).then((res)=>{
        if(res && res.code == 200){
          let senData=JSON.parse(res.data.sendData)
          let params = {
            title: senData.title,
            url: res.data.shareWechat.link,
            shareType: senData.shareType,
            message: senData.message,
            image: senData.image,
            thumb_pic:senData.thumb_pic
          }
          this.setShareMessage(params);
        }else{
          this.toastMsg=res.msg
        }
      })
    },
    computed:{

    },
    watch:{

    },
    methods:{
      shareFor(){
        if(this.$clientType == 3){
           this.shareForImg = true;

        }else{
            console.log("toShare")
            this.doShare()

        }
      }
    },
    components:{
      WXbg,
      yi23Toast
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .ygirl{
    -webkit-font-smoothing: antialiased;
    width: 100%;
    z-index:10;
    position:relative;
    .headerImg{
      width: 100%;
      .height(400);
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
    .EntranceCon{
      padding-right:30px;
      padding-left:30px;
      // .margin(0,0,90,0);
      padding-bottom: 4.8rem /* 90/18.75 */;
      .title{
        position: relative;
        display: table;
        white-space: nowrap;
        width: 100%;
        .height(22);
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        .line-height(22);
        letter-spacing: .7px;
        text-align: center;
        color: #111;
        .margin(30,0,20,0);
        .font-size(16);
        &:before{
          border-top:solid 1px rgba(0,0,0,.05);
          content: '';
          display: table-cell;
          position: absolute;
          .width(58);
          .left(0);
          .top(11);
          height: 1.066667rem;
        }
        &:after{
          border-top:solid 1px rgba(0,0,0,.05);
          content: '';
          display: table-cell;
          position: absolute;
          .width(58);
          .right(0);
          .top(11);
          height: 1.066667rem;
        }
      }
      ol{
        .padding(0,0,0,10);
        li{
          color: #666;
          list-style-type: decimal;
          text-align: left;
          .font-size(13);
          line-height: 1.83;
          letter-spacing: .2px;
          text-align: left;
          margin-bottom: 10px;
        }
      }
    }
    .footerBtn{
      position: fixed;
      bottom: 0;
      width: 100%;
      z-index: 1;
      button{
        width: 100%;
        .height(48);
        .font-size(14);
        color: #fff;
        background: #ff544b;
      }
    }
  }
</style>
