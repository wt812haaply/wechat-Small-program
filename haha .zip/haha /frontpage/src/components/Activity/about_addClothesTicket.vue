<template>
  <div>
    <div class="experience" v-if="bonusObj">

      <div class="headerImg">
        <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/otherBanner.jpg">
      </div>

      <div class="EntranceCon" v-if="bonusObj.showType=='MESSAGE'">
          <div class="ticketList">
            <div class="ticketItem">
                  <div class="messageImg">
                          {{bonusObj.showObj}}
                  </div>
              <!--<img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/memberTip.jpg" alt="">-->
            </div>
          </div>
          <!--<div class="youPhone">-->
            <!--&lt;!&ndash;<div>已放入账号:&nbsp;{{urlmobile}}</div>&ndash;&gt;-->
            <!--&lt;!&ndash;<div class="edit" @click="listLink()">修改&ndash;&gt;-->
              <!--&lt;!&ndash;<i class="icon yi23iconfont icon-right"></i>&ndash;&gt;-->
            <!--&lt;!&ndash;</div>&ndash;&gt;-->

          <!--</div>-->
          <div class="examine" @click="shareFor">邀请好友来体验</div>
      </div>
      <!--<div class="EntranceCon" v-if="bonusObj.showType=='BONUS' || bonusObj.userStatus == 'EXPIRED_USER'">-->
      <div class="EntranceCon" v-if="bonusObj.showType !='MESSAGE' && bonusObj.showType != 'PAYMENT'">
        <div class="titleWrap">
          <div class="title slowheight">恭喜你获得</div>
        </div>
        <div class="ticketList">
          <div class="ticketItem" v-for="(item,index) in bonusObj.showObj">
            <div v-if="item.couponType == 3" >

              <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/ticket.png" alt="">
              <div class="amount" > {{item.couponValue/10}}<span>张</span></div>
              <div class="amountTitle">{{item.couponTitle}}</div>
            </div>
            <div v-if="item.couponType == 4">
              <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/integral.png" alt="">
              <div class="amount" > {{item.couponValue}}<span>张</span></div>
              <div class="amountTitle">{{item.couponTitle}}</div>
            </div>
            <div v-if="item.couponType == 1">
              <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/money.png" alt="">
              <div class="amount" > {{item.couponValue}}<span>元</span></div>
              <div class="amountTitle">{{item.couponTitle}}</div>
            </div>
            <div class="ticketList" v-if="item.couponType == 9" >
              {{couponTypeAction(9)}}
              <div class="ticketItem noodWelfare"><img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/noodWelfare.jpg" alt=""></div>
            </div>
          </div>
        </div>
        <div v-if="isShow">
            <div class="youPhone">
              <div>已放入账号:&nbsp;{{urlmobile}}</div>
            </div>
            <div class="examine" @click="linkUrl()">查看我的加衣券</div>
        </div>
        <div v-else>
          <div class="youPhone">
            <div>已放入账号:&nbsp;{{urlmobile}}</div>
          </div>
          <div class="examine" @click="stepIndex">下单领惊喜</div>
        </div>
      </div>
      <!--<div class="EntranceCon" v-if="bonusObj.showType=='PAYBONUS' && bonusObj.depositStatus >1">-->
          <!--<div class="titleWrap">-->
            <!--<div class="title slowheight">恭喜你获得</div>-->
          <!--</div>-->
          <!--<div class="ticketList">-->
            <!--<div class="ticketItem noodWelfare"><img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/noodWelfare.jpg" alt=""></div>-->
          <!--</div>-->
          <!--<div class="youPhone">-->
            <!--<div>已放入账号:&nbsp;{{urlmobile}}</div>-->
          <!--</div>-->
          <!--<div class="examine" @click="stepIndex">立即免费体验</div>-->
      <!--</div>-->

      <div class="ticketDetails" v-if="isNewUser">
        <div class="titleWrap">
          <div class="title">关于加衣券碎片</div>
        </div>
        <div class="outerBorder">
          <div class="innerBorder">
            <ol class="rules-con">
              <li>
                当礼包被新用户领取，发起人可获得加衣券碎片奖励；
              </li>
              <li>
                奖励会在领取后的24小时内自动放入您的账户；
              </li>
              <li>加衣券碎片可累积，满一张时自动兑换成【加衣券】，可在下单时使用；</li>
              <li>
                【加衣券】可在APP【我的】进行查看。
              </li>
            </ol>
          </div>
        </div>
      </div>
      <!--<div class="ticketDetails" v-if="isNewUser==1">-->
      <div class="ticketDetails" v-if="showNew">
        <div class="titleWrap">
          <div class="title">关于7天体验卡</div>
        </div>
        <div class="outerBorder">
          <div class="innerBorder">
            <ol class="rules-con">
              <li>
                免费7天体验卡仅限新用户领取，活动期间每个新人仅可领取1次；
              </li>
              <li>
                领取体验卡后，您将获得7天有效期，有效期内您可以在衣二三任意下单，百万件名牌时装及配饰任你随意换穿；
              </li>
              <li>领取成功后，您可以直接用该手机号在衣二三app登录下单；</li>
              <li>
                如有问题，欢迎致电衣二三客服进行咨询：400-650-4580。
              </li>
            </ol>
          </div>
        </div>
      </div>
      <div class="getRecord" v-if="recordShow &&  bonusObj.history != false">
        <div class="titleWrap">
          <div class="title">领取记录</div>
        </div>
        <div class="gainedPerson" v-for="(item,index) in bonusObj.history">
            <div class="portrait"><img :src="item.headImg" alt=""></div>
            <div class="userInfo">
                <div class="userName">{{item.nickName}}</div>
                <div class="signature">{{randData[index]}}</div>
            </div>
            <div class="cardMess">
                <div class="time">{{item.addTime | YYYY_MM_DD}}</div>
              <div class="cardType"  v-if="item.couponType==9">7天体验卡</div>
              <div class="cardType"  v-else>加衣券碎片</div>
            </div>
        </div>
      </div>
      <div class="awardRule"  v-if="awardRule">
          <div class="titleWrap">
            <div class="title">奖励规则</div>
          </div>
          <ol class="rules-con">
            <li>
               将礼包分享给微信好友或分享至朋友圈，和好友一起瓜分礼包，共同得奖励；
            </li>
            <li>
              免费体验卡仅限新用户领取，每个礼包最多可被5个新人用户领取；活动期间新人仅可领取1次；

            </li>
            <li>
              新用户领取体验卡后，分享者可随机获得加衣券碎片奖励，奖励会在领取后的24小时内自动放入您的账户中；
            </li>
            <li>
              活动期间有任何问题，请致电衣二三客服进行咨询：400-650-4580。
            </li>
          </ol>
      </div>
      <div class="footerImg">
        <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/footerImg.jpg">
      </div>

      <down-app :show="downApp.show"></down-app>
      <WXbg v-model="shareForImg"></WXbg>

      <zhima-verify v-model="zhimaVerify" :showPayBtn="true" :showClose="false" v-if="bonusObj.showType=='PAYMENT'" @submitPay="submitPay()"></zhima-verify>
    </div>

    <div v-else>
      <div class="gif">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0509/dataLoading.gif" alt=""></div>
    </div>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>
<script type="text/ecmascript-6">
  import  WXbg  from 'base/WXbg';
  import DownApp from 'base/DownApp';
  import {sharePackageDetail,shareBonusCode} from 'api/activity';
  import  shareMixin  from '@/mixins/share';
  import zhimaVerify from '@/components/Promotion/zhimaVerify';
  import yi23Toast from '../lib/Toast.vue';
  import common from 'common/js/common';
  import {
    PAY_WAY_WX,
    PAY_WAY_ALI
  } from 'api/const';
  export default {
    mixins:[ shareMixin ],
    data(){
      return{
        toastMsg:null,
        downApp:{
          show: false
        },
        showNew:false,
        shareForImg:false,
        awardRule:false,
        isNewUser:false,
        recordShow:true,
        aboutTicket:true,
        payWay:'',
        zhimaVerify:false,
        isShow:true,
        showType:'',
        packageCode:'',
        specialCode:'',
        urlmobile:'',
        derict:true,
        randData:[],
        bonusObj:null,
        string:'喜欢的衣服通通带走，这里不剁手,买买买的人看起来很爽，月底都很丧,衣柜衣服千千万，只有新衣最好看,更多尝试，了解更好的自己,花钱比你少，穿衣比你好,对不起， 我从不知道没衣服穿是什么滋味,改变自己，从穿衣开始,You are what you wear,会穿的女人最好命,好看是最直接的名片,你丑你先睡，我美我用衣二三,我比你会穿，我比你好看,谁说好看不能当饭吃,何以解忧，唯有美衣,你穿的这么好看，说什么都对,比三观更重要的是五官',
      }
    },
    created(){
      let newData =  this.string.split(',');
      var num = 7;
      while(this.randData.length < num){
        var temp = (Math.random()*newData.length) >> 0;
        // console.log(temp)
        this.randData.push(newData.splice(temp,1).toString());
      }

      let urlmobile = this.$route.query.mobile;
      let packageCode = this.$route.query.packageCode;
      let specialChannel = this.$route.query.specialChannel;


      this.packageCode = packageCode
      this.urlmobile = urlmobile

      let params = {
        mobile:urlmobile,
        packageCode:this.packageCode,
        specialChannel:specialChannel
      }
      // console.log(params)
      var urlData='';
      if(specialChannel){
           urlData = `?packageCode=${params.packageCode}&mobile=${params.mobile}&specialChannel=${params.specialChannel}`;
      }else{
           urlData = `?packageCode=${params.packageCode}&mobile=${params.mobile}`;
      }


      sharePackageDetail(urlData).then((res)=>{
          if(res.code == 200){
              // console.log(res.data)
              this.bonusObj = res.data;

              if(res.data.showType == "PAYMENT" && res.data.depositStatus < 1){

                 this.zhimaVerify = true
                 this.aboutTicket = false;

              }else if(res.data.showType == "MESSAGE"){

                  this.aboutTicket =false
                  this.awardRule =true
                  // this.recordShow = false;

              }else if(res.data.showType == 'PAYMENT' && res.data.depositStatus > 0){
                  // console.log(1111111)
                  this.submitPay();
                  this.aboutTicket = false;
              }
                // 新用户 和  过期用户 展示碎片
              if(res.data.userStatus == 'EXPIRED_USER' || res.data.userStatus == 'VALID_USER'){
                  this.isNewUser= true
              }

              if(res.data.wechatConfig){

                  let shareData = res.data.wechatConfig;
                  let params = {

                    title: shareData.title,
                    url: shareData.link,
                    shareType: 1,
                    message: shareData.desc,
                    image: shareData.imageUrl,
                    thumb_pic:shareData.url

                  }
                console.log('params');
                console.log(params);
                this.setShareMessage(params);

              }
          }else{

             this.toastMsg = res.msg

          }
      })
    },
    computed:{

    },
    watch:{

    },
    mounted(){
      //down-app下拉
      window.addEventListener('scroll', () => {
        var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        if(scrollTop >= 100){
          this.downApp.show = true;
        }else{
          this.downApp.show = false;
        }
      });
    },
    methods:{
      couponTypeAction(val) {
          this.isShow = false,
          this.showNew =true;
          this.isNewUser =false;
        console.log('--3--')
        return '';
      },
      listLink(){
        this.$router.push({
          path:'/Activity/revisePhone',
          query:{ moblie:this.urlmobile}
        })
      },
      linkUrl(){
        this.$router.push({
          path:'/Activity/myExperienceCard',
        })
      },
      shareFor(){
        if(this.$clientType == 3){
           this.shareForImg = true;

        }else{
          // this.toastMsg="请在微信中打开"
          this.doShare()

        }
      },
      showButton(val){
        console.log(val)
        console.log("------------------------")
      },
        client(){
        let clientType = this.$clientType
        const clientMap = {
          '3': PAY_WAY_WX,
          '4': PAY_WAY_ALI
        }
        if (clientMap[clientType]) {
          return clientMap[clientType]
        }
        return clientMap[4]
      },
      submitPay () {

        let payData = encodeURIComponent(JSON.stringify({
          'payType':13,
          'couponId':0,
          'packageCode':this.packageCode,
          'aliAuthToken':'aliAuthToken',
          // 'payWay':this.client(),
          'aliUserId':'aliUserId',
          'isEvent' : 1,
        }))
        let host = `${window.location.origin}`;
        let success  = encodeURIComponent(`/Activity/about_addClothesTicket_r`);
        let redirect = encodeURIComponent(`${this.$route.fullPath}`);

        window.location.href = `${host}/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
      },
      stepIndex(){
         window.location.href='/yi23/Home/Index/index'
      }
    },
    components:{
      DownApp,
      yi23Toast,
      zhimaVerify,
      WXbg
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .experience{
    -webkit-font-smoothing: antialiased;
    width: 100%;
    z-index:10;
    /*position:relative;*/
    .headerImg{
      width: 100%;
      .height(200);
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
    .EntranceCon{
      padding-right:30px;
      padding-left:30px;
      height:auto;
      margin-top:30px;
      .ticketList{
        width:100%;
        height:auto;
        .ticketItem{
          position:relative;
          //.margin(0,0,10,0);
          width:100%;
          //.height(76);
          img{
            width:100%;
            height:100%;
          }
          .amount{
            position:absolute;
            .top(0.1);
            .right(6);
            .width(110);
            .height(72);
            .font-size(28);
            color:white;
            text-align: center;
            .line-height(72);
            span{
              .font-size(14);
            }
          }
          .amountTitle{
            position:absolute;
            .top(0.1);
            .left(40);
            .width(150);
            .height(72);
            .font-size(16);
            color:#B63A3E;
            text-align: left;
            .padding(0,0,0,5);
            .line-height(53);
            span{
              .font-size(14);
            }
          }
          .amountLeft{
            position:absolute;
            .top(10);
            .left(5);
            .width(15);
            .height(60);
            .font-size(9);
            color:white;
            text-align: center;
            //.line-height(72);
            span{
              .font-size(14);
            }
          }
        }
      }
      .youPhone{
        .height(20);
        .line-height(20);
        .margin(8,0,0,0);
        display:flex;
        justify-content: center;
        div{
          .font-size(13);
          display:inline-block;
        }
        .edit{
          color:red;
          .margin(0,0,0,10);
          .padding(0,30,0,0);
          background:url(https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/arrows.jpg) no-repeat 33px 6px;
          background-size:5px;
          .icon{
            width:5px !important;
            height:5px !important;
            .font-size(1) !important;
          }
        }
      }
      .examine{
        width:100%;
        .height(48);
        .margin(20,0,0,0);
        background: #FF544B;
        .font-size(15);
        color:white;
        .line-height(48);
        text-align:center;
      }
    }
    .ticketDetails{
      height:auto;
      .outerBorder{
        .width(345);
       // .height(203);
        height:auto;
        border:1px solid #000;
        margin:0 auto;
        .innerBorder{
          .width(334);
         // .height(192);
          height:auto;
          .margin(5,5,5,5);
          border:0.5px solid #ccc;
          .padding(0,0,10,0);
          ol{
            .width(300);
            margin:0 auto;
            .padding(20,0,0,20);
            li{
              color: #B63A3E;
              list-style-type: decimal;
              text-align: left;
              .font-size(14);
              line-height: 1.83;
              letter-spacing: .2px;
              text-align: left;
              margin-bottom: 5px;
            }
          }
        }
      }
    }
    .getRecord{
      height:auto;
      .margin(0,0,40,0);
      .gainedPerson{
        display:flex;
        flex-direction: row;
        justify-content: space-between;
        .width(315);
        .height(43);
        margin:0 auto;
        margin-bottom:20px;
        .portrait{
          .width(40);
          .height(40);
          margin-right:10px;
          -webkit-border-radius: 50%;
          -moz-border-radius: 50%;
          border-radius: 50%;
          img{
            width:100%;
            height:100%;
            border-radius: 50%;
          }
        }
        .userInfo{
          flex:1;
          .userName{
            .font-size(15);
            .margin(0,0,10,0);
          }
          .signature{
            .font-size(10);
          }
        }
        .cardMess{
           .width(92);
           .height(43);
          .time{
            .font-size(12);
            .margin(0,0,10,0);
          }
          .cardType{
            .font-size(14);
            color:#B63A3E;
          }
        }
      }
    }
    .awardRule{
      height:auto;
      margin:0 auto;
      ol{
        .width(305);
        margin:0 auto;
        li{
          color: #666;
          list-style-type: decimal;
          text-align: left;
          .font-size(13);
          line-height: 1.83;
          letter-spacing: .3px;
          text-align: left;
          .margin(0,0,10,10)
        }
      }
    }
    .footerImg{
      width: 100%;
      .height(70);
      .margin(35,0,0,0);
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
  }
  .titleWrap{
    .padding(0,30,0,30);
    .title{
      position: relative;
      display: table;
      white-space: nowrap;
      width: 100%;
      .height(22);
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      .line-height(22);
      letter-spacing: .7px;
      text-align: center;
      color: #111;
      .margin(40,0,20,0);
      .font-size(16);
      &:before{
        border-top:solid 1px rgba(0,0,0,.05);
        content: '';
        display: table-cell;
        position: absolute;
        .width(58);
        .left(0);
        .top(11);
        height: 1.066667rem;
      }
      &:after{
        border-top:solid 1px rgba(0,0,0,.05);
        content: '';
        display: table-cell;
        position: absolute;
        .width(58);
        .right(0);
        .top(11);
        height: 1.066667rem;
      }
    }
  }
  .noodWelfare{
    .height(170) !important;
  }
  .slowheight{
    .margin(7.5,0,11.25,0) !important;
  }
  .gif {
    position: absolute;
    -webkit-transform: translateX(-50%) translateY(-50%);
    -moz-transform: translateX(-50%) translateY(-50%);
    -ms-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    width: 50%;
    height: 50px;
    top: 50%;
    left: 50%;
    text-align: center;
    img {
      width: 50px;
      height: 50px;
    }
  }
  .close{
     display:none !important;
  }
  .messageImg{
    width:100%;
    height:74px;
    text-align:center;
    line-height:74px;
    margin:0 auto;
    .font-size(16);
    color: #999999;
    background:url(https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/messageBg.png) no-repeat;
    background-size: 100% 100%;
  }
</style>
