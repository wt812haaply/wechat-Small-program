<template>
  <div class="containe_column">
    <ul class="list"  v-if="info&&info.length>0">
      <li  v-for="item in info" :key="item.id">
        <span>{{item.couponValue/10}}张加衣券</span>
        <span>{{item.addTime | YYYY_MM_DD}}</span>
      </li>
    </ul>
    <div class="no_data" v-else>
      <p>您目前还没有奖励哦，<br>分享给好友得奖励吧！</p>
    </div>
  </div>
</template>

<script>
  export default {
    name: "list-reward",
    data () {
      return {
      }
    },
    props:[
      'info'
    ],
    watch:{
      info:function (val) {
        console.log(val)
      }
    },
    created(){

    }

  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";
  .containe_column {
    flex: 1;
    width: 100%;
    height: auto;
    overflow-y: auto;

    ul {
      li {
        .height(60);
        .line-height(60);
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        font-size: .64rem;
        .padding(0, 30, 0, 30);
        border-bottom: 1px #DDDDDD solid;
        span {
          .font-size(14);
          color: #4A4A4A;
          &:last-child {
            color: #9B9B9B;
          }
        }
      }
    }

    .no_data{
      width: 100%;
      height: 100%;
      text-align: center;
      -webkit-display:flex;
      display:flex;
      -webkit-align-items:center;
      align-items:center;
      -webkit-justify-content:center;
      justify-content:center;

      p{
        .font-size(14);
        color: #999999;
        line-height:1.1rem;
        position: relative;
        top:-10%;
      }
    }

  }
  /*;*/
  //

</style>
