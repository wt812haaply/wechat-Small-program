<template>
  <div class="experience">

    <div class="headerImg">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/insteadH.jpg">
    </div>
    <div class="PlIMG">
      <div class="input-box">
        <div class="userMb">
          <input type="tel" id="just-mobile" class="mobilePhone font-r" v-model="mobile"   placeholder="请输入手机号" name="">
          <button class="btn btn-defult btn-black font-m active" id="exchange_member" @click="getTicket">0元领取</button>
        </div>
      </div>
    </div>
    <div class="imgList">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/FirstImg.jpg">
    </div>
    <div class="imgList">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/secondImg.jpg">
    </div>
    <div class="imgList">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/thirdImg.jpg">
    </div>
    <div class="imgList">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/fourthImg.jpg">
    </div>
    <div class="imgList">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/fifthImg.jpg">
    </div>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script type="text/ecmascript-6">
  import yi23Toast from '../lib/Toast.vue';
  import Validator from 'common/js/class/validator';
  import DownApp from 'base/DownApp';
  import common from 'common/js/common';
  import  shareMixin  from '@/mixins/share';
  export default {
    mixins:[ shareMixin ],
    data(){
      return{
        downApp:{
          show: false
        },
        mobile:'',
        toastMsg:'',
        packageCode:"",
        specialChannel:''
      }
    },
    created(){
       let  packageCode = this.$route.query.packageCode;
       let  specialChannel = this.$route.query.specialChannel;
       this.specialChannel = specialChannel
       this.packageCode =packageCode

       let experienceMobile = common.getCookie('experienceMobile');
       if(experienceMobile){

         if(this.specialChannel){
           console.log("special exist")
           window.location.href=window.location.origin+'/yi23/Home/Activity/about_addClothesTicket?packageCode='+packageCode+"&mobile="+experienceMobile+"&specialChannel="+this.specialChannel;
         }else{
           console.log("special notexist")
           window.location.href=window.location.origin+'/yi23/Home/Activity/about_addClothesTicket?packageCode='+packageCode+"&mobile="+experienceMobile;
         }

       }
          let params = {
            title: "衣二三限时抢！不花钱穿全球时装",
            url: window.location.href,
            shareType: 0,
            message: '送你一张7天免费体验卡',
            image: 'https://yimg.yi23.net/webimg/web/images/2018/0514/share_bonus_3x.jpg',
            thumb_pic:''
          }

          this.setShareMessage(params);

    },
    computed:{

    },
    watch:{

    },
    mounted(){
      //down-app下拉
      window.addEventListener('scroll', () => {
        var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        if(scrollTop >= 100){
          this.downApp.show = true;
        }else{
          this.downApp.show = false;
        }
      });

    },
    methods:{
      validataFunc(){
        let validator = new Validator();
        //phone
        validator.add(this.mobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },
      getTicket() {
        console.log(this.packageCode)
        let msg = this.validataFunc();
        this.toastMsg = msg;
        if(!msg){
          common.setCookie('experienceMobile',this.mobile);

          if(this.specialChannel){
            console.log("special exist")
            window.location.href=window.location.origin+'/yi23/Home/Activity/about_addClothesTicket?packageCode='+this.packageCode+"&mobile="+this.mobile+"&specialChannel="+this.specialChannel;
          }else{
            console.log("special notexist")
            window.location.href=window.location.origin+'/yi23/Home/Activity/about_addClothesTicket?packageCode='+this.packageCode+"&mobile="+this.mobile;
          }

        }
      }
    },
    components:{
      DownApp,
      yi23Toast,
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  .experience{
    -webkit-font-smoothing: antialiased;
    width: 100%;
    z-index:10;
    position:relative;
    .headerImg{
      width: 100%;
      .height(403);
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
    .PlIMG {
      width: 100%;
      position: relative;
      z-index:1;
      .top(-200);
      .input-box{
        width: calc(~"100% - 30px");
        position: absolute;

        z-index: 3;
        background:url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/insteadsm.png");
        background-size:100% 100%;
        left: 15px;
        border-radius:5px;
        .height(188);
        .userMb {
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
          -ms-flex-line-pack: justify;
          align-content: space-between;
          height: auto;
          .margin(60,0,0,0);
          .padding(0,20,0,20);
          .title{
            position: relative;
            display: table;
            white-space: nowrap;
            width: 100%;
            .height(22);
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            .line-height(22);
            letter-spacing: .7px;
            text-align: center;
            color: #111;
            .margin(20,0,20,0);
            .font-size(16);
            &:before{
              border-top:solid 1px rgba(0,0,0,.05);
              content: '';
              display: table-cell;
              position: absolute;
              .width(58);
              .left(0);
              .top(11);
              height: 1.066667rem;
            }
            &:after{
              border-top:solid 1px rgba(0,0,0,.05);
              content: '';
              display: table-cell;
              position: absolute;
              .width(58);
              .right(0);
              .top(11);
              height: 1.066667rem;
            }
          }
          input {
            width: 100%;
            background: #f4f4f4;
            .font-size(14);
            .padding(14,0,14,20);
            letter-spacing: .2px;
            border-radius:2.5px;
          }

          button {
            width: 100%;
            .height(44);
            background: #ff544b;
            letter-spacing: .5px;
            .margin(10,0,0,0);
            .font-size(14);
            border-radius:2.5px;
          }
        }
      }
    }
    .vipInfor {
      width: calc(~"100% - 60px");
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -ms-flex-wrap: wrap;
      flex-wrap: wrap;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      background: #fff;
      margin:0 auto;
      margin-top: .533333rem;
      margin-bottom:10px;
      .title {
        display: table;
        white-space: nowrap;
        width: 90%;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        line-height: 1.77;
        letter-spacing: .7px;
        text-align: center;
        color: #000;
        &:after, &:before {
          border-top: solid 1px rgba(0,0,0,.04);
          content: '';
          display: table-cell;
          position: relative;
          top: .8rem;
          width: 19%;
          height: 1.066667rem;
        }

        &:after{
          left: 1%;
        }

        &:before{
          right: 1%;
        }

        i{
          padding: 0 .533333rem;
          font-style: normal;
          .font-size(16);
          .margin(0,0,15,0);
        }
      }

      p{
        width: 100%;
        text-align: center;
        font-size: .533333rem;
        color: #ccc;
      }
      .PlIMG{
        img{
          height:auto;
          width: 100%;
        }
      }
      .last{
        .height(270);
        .margin(40,0,0,0);
      }
    }
    .imgList{
      width: 100%;
      .height(70);
      height:auto;
      img{
        display: block;
        width: 100%;
        height:100%;
      }
    }
  }
  .addHeight{
    .height(233) !important;
  }
  .addPadding{
    .padding(40,0,0,0) !important;
  }
</style>
