<template lang="html">
    <div class="yclosetContainer agreenment">
      <div class="yclosetHeader">
        <go-back></go-back>
      </div>
      <div class="yclosetCon leaseAgreement">
        <div class="LACon">
          <div class="listLi">
      			<span class="number">1.</span>
      			<span class="listLiCon">衣二三平台所售商品均为100%正品。购买的租赁流通商品以及全新商品均经严格质检、清洗，筛选的无瑕疵服装/配饰。</span>
      		</div>
          <div class="listLi">
      			<span class="number">2.</span>
      			<span class="listLiCon">衣二三所有售卖商品支持无理由退货不换货，如需退货请于签收后48小时内联系客服办理。如购买全新商品，需保证商品未经使用，可以二次销售（商品未磨损、整洁、没有穿着痕迹），吊牌完整，经客服同意后于7日内将货品寄回到仓。7日内未邮寄到仓或自行退货使用到付，均不予退货处理。我们将于质检完毕后3个工作日内进行退款，非质量问题收取20元/件的清洗费用和回库邮费，因质量问题所产生的邮费均由衣二三承担。</span>
      		</div>
          <div class="listLi">
      			<span class="number">3.</span>
      			<span class="listLiCon">会员选择购买的是手中(衣箱中的)商品，付款后将此商品留下，其余商品寄回即可。购买非手中商品，商品将随下一个新衣箱寄达。如购买后4日内无新衣箱，系统将按照购买订单地址进行单独邮寄, 特殊节假日除外。</span>
      		</div>
        </div>
      </div>
    </div>
</template>

<script>
import GoBack from 'base/GoBack';

export default {
  components:{
    GoBack
  }
}
</script>


<style lang="less" rel="stylesheet/less" scoped>

.agreenment{
  position: fixed;
  z-index: 100;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: #fff;
}

.font-14{
  font-size: .746667rem /* 14/18.75 */;
}

.creatPay{
  width: 100%;
  height: 2.56rem /* 48/18.75 */;
  line-height: 2.56rem /* 48/18.75 */;
  text-align: center;
  color: #fff;
}

@import "~common/less/variable";


/* -------------- 租赁协议 -------------- */
.leaseAgreement{
  padding: 1.066667rem /* 20/18.75 */;
  background: #fff;
  box-sizing: border-box;
  .LATitle{
      font-size: .746667rem /* 14/18.75 */;
      color: #000;
      line-height: 1.5;
      margin-bottom: 1.066667rem /* 20/18.75 */;
  }
  .LACon{
      font-size: .64rem /* 12/18.75 */;
      .listLi{
          display: flex;
          flex: 1;
          text-align: left;
          font-size: .693333rem /* 13/18.75 */;
          line-height: 1.7;
          letter-spacing: 0.2px;
          text-align: left;
          margin-bottom: .8rem /* 15/18.75 */;
          color: #333;
          text.number{
              flex: 1.2;
          }
          text.listLiCon{
              flex: 20;
          }
      }

      .ef{
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: .693333rem /* 13/18.75 */;
          line-height: 1.7;
          letter-spacing: 0.2px;
          margin-bottom: .533333rem /* 10/18.75 */;
          padding-left: 1.066667rem /* 20/18.75 */;

          }

  }

}

</style>
