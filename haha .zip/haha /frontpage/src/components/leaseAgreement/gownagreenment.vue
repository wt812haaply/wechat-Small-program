<template lang="html">
  <transition name="slide">
    <div class="yclosetContainer agreenment">
      <div class="yclosetHeader">
        <go-back></go-back>
      </div>
      <div class="yclosetCon leaseAgreement">
        <div class="LACon">
          <div class="listLi">
      			<span class="number">1.</span>
      			<span class="listLiCon">衣二三保证所有上架外租礼服均系100%正品并保证品质良好，礼服在前一用户退租返还后均会由衣二三特约养护服务商进行清洁保养处理，才会再次上架对外出租。用户选择“【我同意衣二三用户礼服租赁协议】”即视为用户已阅读并接受此协议，并视为用户认可衣二三选定的特约养护服务商及其提供的服务和认定成果。</span>
      		</div>
          <div class="listLi">
      			<span class="number">2.</span>
      			<span class="listLiCon">购买礼服租赁服务的用户仅获得该礼服相应天数的使用权，并不获得该礼服的所有权。</span>
      		</div>
          <div class="listLi">
      			<span class="number">3.</span>
      			<span class="listLiCon">租赁日期一旦确定，不得修改。如用户在租赁到期前欲延长租赁期限的，需及时与衣二三客服取得联系并提出延长申请，经衣二三客服确认不会影响后续客户承租后，由衣二三修改相应修改订单，确认延长租赁期限，并由用户支付延长期间的租金。</span>
      		</div>
          <div class="listLi">
      			<span class="number">4.</span>
      			<span class="listLiCon">用户在约定时间内正常寄回，礼服通过清洗及质检（约需要一周）合格后，24小时内系统自动将全部押金原路退回您的账户。</span>
      		</div>
          <div class="listLi">
      			<span class="number">5.</span>
      			<span class="listLiCon">用户收到礼服后，请在第一时间检查衣物是否完好。若有问题，请您在收货后24小时内联系在线客服，进行拍照举证，并在24小时内使用顺丰到付将礼服寄回。衣二三将联系发货部门核实情况，在收到礼服后24小时内系统自动将全部押金原路退回您的账户。</span>
      		</div>
          <div class="listLi">
      			<span class="number">6.</span>
      			<span class="listLiCon">用户正常使用造成的礼服轻微污渍、成色降低、磨损、老化，由衣二三承担，并由特约养护服务商负责使用后的清洗、保养。</span>
      		</div>
          <div class="listLi">
      			<span class="number">7.</span>
      			<span class="listLiCon">如用户在使用过程中造成对礼服的非正常磨损、严重损坏、丢失或被窃、逾期归还或归还商品不一致的，用户需要承担赔偿责任，赔偿具体规则如下:非正常损坏：经衣二三特约养护服务商查验认为需要对礼服进行“非常规保养”等额外修复后方能再次使用的归还礼服，须由用户承担该礼服的修复费用。衣二三特约养护服务商将出具维护明细及费用清单供用户查阅；严重损坏：用户造成礼服严重损坏，并经衣二三特约养护服务商查验认为该礼服无法再次使用的，衣二三将出具“商品无法修复使用说明”，根据礼服的价值扣取全部押金作为赔偿；• 丢失或被窃：如礼服在用户租用期间丢失或被盗，该用户需立即联系衣二三客服。如该礼服在丢失后30日内未能找回，根据商品的价值以扣取押金的形式要求用户赔偿。如该礼服在丢失后30日内找回并经权威鉴定机构鉴定确系原出租礼服，如未造成商品损坏，则丢失期间视为用户延长的租赁期间，扣取押金补缴租用费用；如礼服造成非正常损坏，则在收取延长租赁期间租金基础之上增加扣除额外修复费用；如礼服造成严重损坏无法使用，衣二三将根据商业的价值扣取全部押金作为赔偿；• 逾期归还：用户在约定的租赁期限届满后未及时归还所租礼服的，系统将会自动扣除您的押金，逾期2天内扣除押金的50%，超过两天将会扣除全部押金；• 归还商品不一致：如寄回的商品与衣二三发出的原礼服不一致的，衣二三有权拒绝收回外租礼服并要求用户赔偿，不一致商品的所有权归该承租用户所有。衣二三在将不一致的认定结果告知用户，用户应将正确的礼服寄回，相关费用由用户承担。所造成的逾期归还参考上条，另予追究；</span>
      		</div>
          <div class="listLi">
      			<span class="number">8.</span>
      			<span class="listLiCon">因所租赁礼服均为高价值属性，用户在确认订单前，请仔细检查商品，以及使用时间，下单后不得换货或退租。用户收到礼服后，若因特殊原因不使用寄回，用户需支付物流及服务费50元。礼服通过清洗质检（约需要一周）合格后，24小时内系统自动将剩余押金原路退回您的账户。</span>
      		</div>
          <div class="listLi">
            <span class="number">9.</span>
            <span class="listLiCon">对于恶意换货等行为，衣二三有权终止该用户账户（包含用户对应唯一手机号）的资格并追究其法律责任。衣二三已与中国人民银行征信中心以及第三方征信公司合作，违约行为会百上报纸上述机构备案，并录入其个人征信记录。个人征信记录的污点，将会对个人未来的住房贷款、汽车贷款、信用卡申请、消费分期、租房、租车、求职等诸多方面造成不利影响。请用户珍稀自己的个人信用。</span>
          </div>
          <div class="listLi">
            <span class="number">10.</span>
            <span class="listLiCon">衣二三保留对租赁规则的调整权和最终解释权。</span>
          </div>
        </div>
      </div>
      <div class="yclosetFooter">
        <div class="creatPay yi23bgred font-14" @click="toPayAndAgreen">同意协议并支付</div>
      </div>
    </div>
  </transition>
</template>

<script>
import GoBack from 'base/GoBack';

export default {
  methods:{
    toPayAndAgreen(){
      if(this.$route.query && this.$route.query.payUrl){
        window.location.href = decodeURIComponent(this.$route.query.payUrl);
      }else{
        cosole.log('没有支付链接无法发起支付');
      }
    }
  },
  components:{
    GoBack
  }
}
</script>


<style lang="less" rel="stylesheet/less" scoped>

.slide-enter-active, .slide-leave-active{
  transition: all 0.3s
}

.slide-enter, .slide-leave-to{
  transform: translate3d(100%, 0, 0)
}


.agreenment{
  position: fixed;
  z-index: 100;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: #fff;
}

.font-14{
  font-size: .746667rem /* 14/18.75 */;
}

.creatPay{
  width: 100%;
  height: 2.56rem /* 48/18.75 */;
  line-height: 2.56rem /* 48/18.75 */;
  text-align: center;
  color: #fff;
}

@import "~common/less/variable";


/* -------------- 租赁协议 -------------- */
.leaseAgreement{
  padding: 1.066667rem /* 20/18.75 */;
  background: #fff;
  box-sizing: border-box;
  .LATitle{
      font-size: .746667rem /* 14/18.75 */;
      color: #000;
      line-height: 1.5;
      margin-bottom: 1.066667rem /* 20/18.75 */;
  }
  .LACon{
      font-size: .64rem /* 12/18.75 */;
      .listLi{
          display: flex;
          flex: 1;
          text-align: left;
          font-size: .693333rem /* 13/18.75 */;
          line-height: 1.7;
          letter-spacing: 0.2px;
          text-align: left;
          margin-bottom: .8rem /* 15/18.75 */;
          color: #333;
          text.number{
              flex: 1.2;
          }
          text.listLiCon{
              flex: 20;
          }
      }

      .ef{
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: .693333rem /* 13/18.75 */;
          line-height: 1.7;
          letter-spacing: 0.2px;
          margin-bottom: .533333rem /* 10/18.75 */;
          padding-left: 1.066667rem /* 20/18.75 */;

          }

  }

}

</style>
