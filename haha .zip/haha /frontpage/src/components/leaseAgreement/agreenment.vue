<template lang="html">
  <div class="yclosetContainer"><!--configPage-->
    <div class=" yclosetHeader">
        <go-back></go-back>
    </div>
    <div class="yclosetCon leaseAgreement">
    	<div class=LATitle>欢迎使用衣二三平台（以下简称“衣二三”）会员租赁服务，您在使用本服务时，即表示您已阅读并接受下列条款和约束，请认真阅读以下条款：</div>
    	<div class="LACon">
    		<div class="listLi">
    			<span class="number">1.</span>
    			<span class="listLiCon">衣二三保证所有上架商品均系正品并品质良好；每件商品在上架前均会按照衣二三的清洗流程进行清洁保养及消毒处理。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">2.</span>
    			<span class="listLiCon">会员支付开通服务，即视为已阅读并接受《衣二三会员租赁协议》，并视为认可衣二三的清洗流程及相应的服务标准；请成功下单的会员悉心使用租赁商品，不得故意对商品进行损坏。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">3.</span>
    			<span class="listLiCon">会员正常更换服装的往返物流服务，其承运商由衣二三分配指定的，往返运费均由衣二三承担。如因会员特殊要求更换往、返物流服务及承运商并产生额外费用的，差价由会员承担。会员应在租赁期限结束前通过衣二三指定的物流合作商将商品寄回（以快递发出时间为准）。会员寄回时应保证商品完好无损。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">4.</span>
    			<span class="listLiCon">购买会员服务的会员仅获得该商品在相应服务期限内的使用权，并不获得该商品的所有权。包月服务的服务期从首次下单之日起，30日内有效。若会员开通会员后15日（含当日）内仍未下单，则自第16日起自动计算会员有效期。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">5.</span>
    			<span class="listLiCon">使用过程中，一组收货信息仅对应一个衣二三会员身份，衣二三有权取消同一会员多个重复账号的会员资格。</span>
    		</div>


    		<div class="listLi">
    			<span class="number">6.</span>
    			<span class="listLiCon">包月换衣会员在会员期内可以随心换穿，会员同时在手中只能保留1个衣箱。预约下单新衣箱时，会员需提前预约归还旧衣箱，预约成功后方可正常提交新衣箱订单。因会员个人原因同时持有多个衣箱的，衣二三有权加倍扣除会员有效期、押金、或额外收取服务费用。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">7.</span>
    			<span class="listLiCon">会员正常使用造成的商品轻微污渍、成色降低、磨损、老化问题，由衣二三承担。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">8.</span>
    			<span class="listLiCon">如会员在使用过程中造成对商品的非正常磨损、丢失或被窃、逾期归还或归还商品不一致的，会员需要承担赔偿责任，具体规则如下：</span>
    		</div>

    		<div class="ef">
    			1) 非正常损耗：经衣二三质检中心查验认为需要对商品进行“非常规处理”等额外修复后方能再次使用的商品，不影响正常穿着的损伤，由衣二三修复并承担修复费用；若质检中心查验认为商品损坏已影响正常穿着，则须由承租的会员对该商品进行赔偿，赔偿金额为该商品页面所示零售价的50%-100%，具体比例由衣二三根据商品流转周期裁定。
    		</div>
    		<div class="ef">
    			2) 丢失或被窃：如商品在会员租用期间丢失或被盗，会员须按照所丢失商品的零售价进行购买。客服人员会在核实商品未跟随其他衣物一并寄回后，进入异常订单流程；在异常订单处理期间，衣服将暂停配送，直至会员按要求缴纳完毕购买费用。
    		</div>

    		<div class="ef">
    			3) 逾期归还：会员在约定的租赁期限届满后未及时归还商品且未进行续费处理的，衣二三客服将向该会员追索未归还的商品，并约定时间取回。若客户逾期2日后仍不归还所租商品，则视为已购买所未归还的商品，须以平台上公布的售卖价格全额支付；衣二三有权优先以客户押金进行抵扣，并保留追偿权利。
    		</div>

    		<div class="ef">
    			4) 归还商品不一致：如会员寄回的商品与衣二三发出的原商品不一致，衣二三客服将提供原订单货品的核实信息向会员进行商品追讨。一旦产生问题，视同订单异常，租赁服务暂停，直至归还商品。
    		</div>

    		<div class="ef">
    			5) 恶意损坏：若会员未能完好归还商品或恶意对商品进行损坏，且在客服追索后拒绝赔偿，则衣二三有权扣除该会员全部押金及会员费，用于抵扣因衣物损坏所造成的损失，并保留追偿权利。
    		</div>

    		<div class="ef">
    			6) 如会员在快递签收时非本人接收，丢失风险由客人自行承担。
    		</div>


    		<div class="listLi">
    			<span class="number">9.</span>
    			<span class="listLiCon">会员收到衣箱后，需在第一时间检查商品是否完好。如有任何问题须在24小时内联系在线客服进行解决。若须寄回衣物或归还，则应整箱衣物一并寄回。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">10.</span>
    			<span class="listLiCon">对于恶意损坏商品、换货、偷窃等行为，衣二三有权终止该账户的会员（包含会员对应唯一手机号、身份证号）资格并追究其法律责任。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">11.</span>
    			<span class="listLiCon">已开通服务的会员如需终止衣二三会员服务，请自首次开通之日起7日内提出终止要求，并在服务开通后10日内完好归还所有租赁商品后，并退还、解除全部因会员身份所得的返现或实物奖励，所缴会员费可全部退回。超过7日提出，或未能完好归还商品、退回所得奖励的，则衣二三有权拒绝终止或在扣除全部押金、会员费，用于抵扣因会员提前终止服务造成的损失。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">12.</span>
    			<span class="listLiCon">请会员于归还衣物前注意整理并取出在衣物中的或附着在衣物上的私人物品。如因会员在还衣时未能取出该等私人物品而造成该等私人物品损坏、遗失或导致会员遭受任何其他损失的，衣二三对该等损失均不承担任何责任。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">13.</span>
    			<span class="listLiCon">若会员未按预约时间归还衣物，导致同时占用两个及以上衣箱时，将无法继续下单；且会员有效期将根据占用衣箱数加倍扣除，多占用1个衣箱，多扣除一倍。（如占用2个衣箱5天，则此期间扣除有效期5x2=10天）。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">14.</span>
    			<span class="listLiCon">衣二三对未通过芝麻信用验证的包月会员一次性收取¥300元的押金。 会员可于会员期结束并完好归还衣箱后致电客服，或联系在线客服申请退还押金。申请通过后，正常情况下押金将在7个工作日内退还至原支付账户。=10天）。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">15.</span>
    			<span class="listLiCon">如发生会员责任导致逾期归还、货品损坏或丢失等情况，在与会员的口头沟通后，如在会员期结束后3天内未将全部衣箱返回衣二三，衣二三有权扣除会员全部押金。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">16.</span>
    			<span class="listLiCon">带有特殊标识(如：轻奢)的单品占用衣位数量不同，具体占用情况视活动规则而定。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">17.</span>
    			<span class="listLiCon">由于技术错误导致会员在使用芝麻信用免押金操作时出现失误造成的损失由衣二三进行承担。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">18.</span>
    			<span class="listLiCon">会员在输入、查看包括但不限于手机号码、身份证等个人保密信息时需妥善保护。由于衣二三信息安全事故导致会员信息泄露，损失由衣二三承担。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">19.</span>
    			<span class="listLiCon">如有疑问，请致电衣二三客服。</span>
    		</div>

    		<div class="listLi">
    			<span class="number">20.</span>
    			<span class="listLiCon">衣二三在法律允许范围内保留对租赁规则的调整权和最终解释权。</span>
    		</div>
    	</div>
    </div>
</div>

</template>

<script>
import goBack from 'base/GoBack'
export default {
  components:{
    goBack
  },
}
</script>

<style scoped lang="less">
  @import "~common/less/variable";


/* -------------- 租赁协议 -------------- */
.leaseAgreement{
    padding: 1.066667rem /* 20/18.75 */;
    background: #fff;
    box-sizing: border-box;
    .LATitle{
        font-size: .746667rem /* 14/18.75 */;
        color: #000;
        line-height: 1.5;
        margin-bottom: 1.066667rem /* 20/18.75 */;
    }
    .LACon{
        font-size: .64rem /* 12/18.75 */;
        .listLi{
            display: flex;
            flex: 1;
            text-align: left;
            font-size: .693333rem /* 13/18.75 */;
            line-height: 1.7;
            letter-spacing: 0.2px;
            text-align: left;
            margin-bottom: .8rem /* 15/18.75 */;
            color: #333;
            text.number{
                flex: 1.2;
            }
            text.listLiCon{
                flex: 20;
            }
        }

        .ef{
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: .693333rem /* 13/18.75 */;
            line-height: 1.7;
            letter-spacing: 0.2px;
            margin-bottom: .533333rem /* 10/18.75 */;
            padding-left: 1.066667rem /* 20/18.75 */;

            }

    }

}

</style>
