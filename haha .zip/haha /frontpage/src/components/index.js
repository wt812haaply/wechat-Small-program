/**
 * Created by ahu on 2018/5/28
 */
import yi23Dialog from '@/components/lib/Dialog.vue'
import yi23Toast from '@/components/lib/Toast.vue'
import yi23AlertImg from '@/components/lib/AlertImg.vue'
const components={
  install(Vue){
    Vue.component('yi23Dialog', yi23Dialog)
    Vue.component('yi23Toast', yi23Toast)
    Vue.component('yi23AlertImg', yi23AlertImg)
  }
}
export default components
