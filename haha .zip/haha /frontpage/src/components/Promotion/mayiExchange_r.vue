<template>
  <div>
    <!--成功-->
    <div class="mayiExchange_r" v-if="eventResult == 'T'">
      <h2>
        <i><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/iconSuccess.svg" alt=""></i>
        兑换成功</h2>
      <p class="font-r">一次可租三件衣服，会员期内随心换穿</p>
      <button class="btnA font-m" @click="newBox()">立即开启新衣箱</button>
    </div>

    <!--失败-->
    <div class="mayiExchange_r" v-if="eventResult == 'F'">
      <h2>
        <i><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/iconFailure.jpg" alt=""></i>
        兑换失败</h2>
      <p class="font-r" style="width: 100%" v-if="textsMsg">{{textsMsg}}</p>
      <p class="font-r" v-else>亲，您支付失败，请重新支付～</p>
      <button class="btnA font-m" @click="exchange()">重新兑换会员</button>
      <button class="btnB font-m" @click="newBox()">进入衣二三</button>
    </div>

  </div>
</template>
<script>
  export default {
    data() {
      return {
        eventResult:null,
        textsMsg:'',
      }
    },
    components: {},
    computed: {},
    methods: {
      //成功按钮跳转
      newBox:function() {
        window.location.href = '/yi23/Home/Index/index?source=fe9fdfb6272bf4da9b92c8fdb55ae3df'
      },
      //重新兑换会员
      exchange:function () {
        let redirect = this.$route.query.redirect;
        this.$router.push({
          path: redirect,
          repalce: true
        })
      },
    },
    created() {
      let query = this.$route.query;
      let resultOff = query.is_success;
      if(query.msg && query.msg != ''){
        console.log(query.msg)
        this.textsMsg = decodeURIComponent(query.msg);
      }
      this.eventResult = resultOff;
    }
  }

</script>
<style scoped lang="less">
  @import "~common/less/variable";
  @import "./20180602/mayiExchange";
</style>
