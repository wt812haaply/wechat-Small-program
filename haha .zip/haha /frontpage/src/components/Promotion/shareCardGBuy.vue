<template>
  <div v-if="cardInfo">
    <div class="cpsPay">
      <div class="PlIMG image-ratio cpsPayBanner">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0427/cpsPayCard.png" alt="">
      </div>
      <ul class="blockOne font-r">
        <li>
          <div class="liLeft">{{cardInfo.payName}}</div>
          <div class="liRight cccColor">￥{{ cardInfo.payOriginal }}</div>
        </li>
        <li v-if="cardInfo.payReductionInfos && cardInfo.payReductionInfos.length>0" v-for="item in cardInfo.payReductionInfos">
            <div class="liLeft">{{item.reductionName}}</div>
            <div class="liRight red">-¥{{item.reductionAmount}}</div>
        </li>
        <li v-if="cardInfo.depositWaived==0 && cardInfo.depositType==0">
          <div class="liLeft">押金<i class="mianya">验证芝麻分可免押</i></div>
          <div class="liRight"><i class="del">￥{{cardInfo.depositAmount}}</i></div>
        </li>
        <li v-if="couponVal==0">
          <div class="liLeft">优惠券</div>
          <div class="liRight">无可用优惠券</div>
        </li>
        <li v-else>
          <div class="liLeft">{{coupon.couponTitle}}</div>
          <div class="liRight red">{{couponVal}}</div>
        </li>
        <li class="font-m">
          <div class="liLeft">实际支付</div>
          <div class="liRight">￥{{(cardInfo.totalFee-couponVal)<=0?0:(Math.floor(cardInfo.totalFee-couponVal))}}</div>
        </li>
      </ul>
      <div class="blockTwo" v-if="cardInfo.depositWaived==0 && cardInfo.depositType==0">
        <div class="twoLeft">
          <div class="logo">
            <img src="https://yimg.yi23.net/webimg/web/images/2018/0326/zhimaLOGO.png" alt=""></div>
          <div class="info">
            <h2 class="font-m">使用芝麻信用免押</h2>
            <p class="font-r">芝麻分超过650可享受免押特权</p>
          </div>
        </div>
      </div>
      <div class="Info">付费成为会员代表您已阅读并 <i><router-link to="/Agreement/agree">同意衣二三会员租赁协议</router-link></i></div>
    </div>
    <div class="cpsFooterBtn bottomIphoneX">
      <button class="btn btn-defult" @click="showZhima" v-if="cardInfo.depositWaived==0 && cardInfo.depositType==0">验证芝麻信用分免押金</button>
      <button class="btn btn-defult" @click="submitPay" v-else>去支付</button>
    </div>
    <zhima-verify v-model="zhimaVerify" :showPayBtn="true" @submitPay="submitPay"></zhima-verify>
    <yi23-toast v-model="toastMsg"> </yi23-toast>
  </div>
</template>

<script>
    import zhimaVerify from '@/components/Promotion/zhimaVerify'
    import common from '@/common/js/common'
    import { shareCardG } from '@/api/event'
    export default {
        name: "shareCardGBuy",
        data(){
         return{
           zhimaVerify:false,
           cardInfo:null,
           coupon:'',
           couponVal:0,
           toastMsg:'',
           payWay:3,
         }
        },
        computed:{
          couponId(){
            if(this.coupon && this.coupon.couponId) {
              return this.coupon.couponId
            }else{
              return 0
            }
          }
        },
        methods:{
          showZhima() {
            this.zhimaVerify=true
          },
          submitPay() {
            let extraData=common.getCookie('adparam')?common.getCookie('adparam'):'';
            let payData = encodeURIComponent(JSON.stringify({
              'payType':'ALI_WEB',
              'couponId':this.couponId,
              'cardTemplateId':1,
              'extraData':extraData,
              'isEvent':1,
            }))
            let success = encodeURIComponent('/Promotion/share_card_c_r');
            let redirect = this.$route.fullPath;
            redirect = encodeURIComponent(redirect);
            window.location.href = `/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
          }
        },
        components:{
          zhimaVerify
        },
        created() {
          let params=this.$route.query;
          shareCardG(params).then((res)=>{
              if(res.code==200){
                this.cardInfo=res.data.cardInfo
                this.coupon=res.data.coupon
                this.couponVal=res.data.couponVal
              }else{
                this.toastMsg=res.msg
              }
          })
        }
    }
</script>

<style scoped>
  .none {
    display: none;
  }

  .image-ratio {
    background-color: #fff;
  }

  * {
    outline: none;
  }

  body {
    background: #F8F8F2;
  }

  input {
    border-radius: 0;
  }

  img {
    width: 100%;
    display: block;
  }

  i {
    font-style: normal;
  }

  .PlIMG {
    width: 100%;
    height: 0;
    overflow: hidden;
    padding-bottom: 100%;
    position: relative;
  }

  .PlIMG img {
    width: 100%;
    position: absolute;
  }


  .cpsPay {
    margin: 0 1.226667rem;
    padding-top: 1.066667rem;
  }

  .cpsPayBanner {
    padding-bottom: 42.8571%;
  }

  .cpsPay .image-ratio {
    background-color: transparent;
  }

  .cpsPay ul.blockOne {
    height: auto;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    background: #fff;
    border-radius: 3px;
    padding-top: 0.533333rem;
    -webkit-box-shadow: 0 0 3.2rem rgba(0, 0, 0, .05);
    box-shadow: 0 0 3.2rem rgba(0, 0, 0, .05);
    margin-bottom: 0.533333rem;
  }

  .cpsPay ul.blockOne li {
    width: 100%;
    height: 1.813333rem;
    line-height: 1.813333rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    font-size: 0.64rem;
    padding: 0 1.28rem;
  }

  .cpsPay ul.blockOne li .liLeft i.mianya {
    padding: 0.266667rem;
    background: #5A8AC1;
    color: #fff;
    margin-left: 0.426667rem;
    position: relative;
    top: -1px;
  }

  .cpsPay ul.blockOne li .liRight i.del {
    text-decoration: line-through;
    -webkit-text-decoration-color: #000;
    text-decoration-color: #000;
  }

  .cpsPay ul.blockOne li .red {
    color: #ff544b;
  }

  .cpsPay ul.blockOne li .cccColor {
    color: #ccc;
  }

  .cpsPay ul.blockOne li:last-of-type {
    height: 3.2rem;
    line-height: 3.2rem;
    border-top: 1px #EFEFEF solid;
    font-size: 0.96rem;
    margin-top: 0.266667rem;
  }

  .cpsPay .blockTwo {
    padding: 0 1.28rem;
    height: 4.8rem;
    margin-bottom: 0.533333rem;
    background: #fff;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    border-radius: 3px;
    -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, .05);
    box-shadow: 0px 1px 3px rgba(0, 0, 0, .05);
  }

  .cpsPay .blockTwo .twoLeft {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
  }

  .cpsPay .blockTwo .twoLeft .logo {
    width: 1.6rem;
    height: 1.92rem;
  }

  .cpsPay .blockTwo .twoLeft .info {
    padding-left: 0.533333rem;
  }

  .cpsPay .blockTwo .twoLeft .info h2 {
    font-size: 0.746667rem;
  }

  .cpsPay .blockTwo .twoLeft .info p {
    font-size: 0.64rem;
    color: #B1B1B3;
  }

  .cpsPay .blockTwo .twoRight .rightBtn {
    width: 3.306667rem;
    height: 1.546667rem;
    line-height: 1.546667rem;
    text-align: center;
    border-radius: 1.546667rem;
    background: #ff544b;
    color: #fff;
    font-size: 0.746667rem;
  }

  .cpsPay .blockTwo .twoRight .active {
    width: 1.546667rem;
    height: 1.546667rem;
  }

  .cpsPay .Info {
    font-size: 0.586667rem;
    line-height: 1.066667rem;
    color: #B1B1B3;
  }

  .cpsPay .Info i {
    padding-left: 0.426667rem;
  }

  .cpsPay .Info a {
    color: #5C8CC2;
  }
  .cpsFooterBtn {
    position: fixed;
    bottom: 0;
    width: 100%;
    z-index: 1;
  }

  .cpsFooterBtn button {
    width: 100%;
    height: 2.56rem;
    font-size: 0.853333rem;
  }
</style>
