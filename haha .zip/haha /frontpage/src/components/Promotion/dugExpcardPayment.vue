<template>
  <div class="WaO" id="waTop">
    <div class="bannerBox">
      <div class="imgP image-ratio WaOBanner">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/header_ee33.jpg" alt="">
      </div>
      <div class="WaOCon">
        <!--<div class="cardType">-->
          <!--&lt;!&ndash;<h2 class="font-m">新用户专享<span style="color: #ff544b"> 7天免费体验</span></h2>&ndash;&gt;-->
          <!--&lt;!&ndash;<p class="font-m">仅限新用户，老用户可得折扣券</p>&ndash;&gt;-->
        <!--</div>-->
        <div class="cardType cardType__title">
          衣二三 X 花呗专享优惠券
        </div>
        <div class="wa_border"></div>
        <!--<div class="wa__price">-->
          <!--<div class="wa__price_red">免费</div>-->
          <!--<div class="wa__price_block">原价：</div>-->
          <!--<div class="wa__price_through font-roboto-b">¥149</div>-->
        <!--</div>-->
        <div class="userMb">
          <input v-model="userMobile" class="mobilePhone font-r" placeholder="请输入手机号" >
          <button class="btn btn-defult btn-black  active" @click="userSubmit">免费领取</button>
        </div>
      </div>
    </div>
    <div class="vipInfor">
      <div class="vipInfor__btn">

        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/btn_1.jpg">
        <div class="vipInfor__btn_custom-service" @click="openCustomService"></div>
        <div class="vipInfor__btn_vip" @click="openVip"></div>
      </div>
      <div class="vipInfor_1">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/1.jpg">
      </div>
      <div class="vipInfor_2" ref="scrollPosition">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/2.jpg">
      </div>
      <div class="vipInfor_3">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/3.jpg">
      </div>
      <div class="vipInfor_4">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/4.jpg">
      </div>
      <div class="vipInfor_5">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/5.jpg">
      </div>
      <div class="vipInfor_6">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/6.jpg">
      </div>
      <div class="vipInfor_7">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1212/iPhone__8.jpg">
      </div>
    </div>

    <BoxPopup :open="open" v-if="+popType<5" class="dug__box">

      <!--<div slot="Box_InnerTop" class="Box_InnerTop">-->
        <!--<img src="https://yimg.yi23.net/webimg/web/images/2018/0808/logo-copy-4@2x.jpg" alt="">-->
        <!--<div>-->
          <!--<h1>恭喜您，抢到{{ PopCont.popTitle[+popType] }}</h1>-->
          <!--<p>为您兑换到账户：{{ userMobile }}</p>-->
        <!--</div>-->
      <!--</div>-->

      <div slot="Box_InneBtm"  @click="buttFunc()" >
        <img :src="'https://yimg.yi23.net/webimg/web/images/2018/0808/'+PopCont.popImg[+popType]" alt="">
      </div>

      <!--<div slot="Box_p" class="Box_p"  >-->
        <!--<p v-if="popType<3 || popType == 4">{{ PopCont.popTxt[+popType]}}</p>-->
        <!--<p v-else></p>-->
        <!--&lt;!&ndash;<p v-else><img src="https://yimg.yi23.net/webimg/web/images/2018/0808/logo@2x.jpg" alt=""><span>需¥300预授权押金即可领取<br>(仅冻结花呗额度，会员期结束后解冻)</span></p>&ndash;&gt;-->
        <!--&lt;!&ndash;<div class="PayBtn">&ndash;&gt;-->
          <!--&lt;!&ndash;<button class="font-r btn active" @click="buttFunc()">{{ PopCont.popButt[+popType] }}</button>&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->
      <!--</div>-->

    </BoxPopup>
    <BoxPopup :open="showLoading" class="animate__box">

      <div slot="Box_InneBtm"  @click="buttFunc()" class="animate__box_background">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/lo.gif" alt="">
      </div>


    </BoxPopup>
    <a class="wa__toTop" href="#waTop" v-if="showTopBtn">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/group_26.png">
    </a>
    <yi23Toast v-model="errorMsg"></yi23Toast>
    <div style="display: none">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0808/res_1.png">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0808/res_2.png">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0808/res_4.png">
    </div>
  </div>
</template>

<script>
  import BoxPopup from '../lib/BoxPopup.vue'
  import yi23Toast from '../lib/Toast.vue'
  import common from '@/common/js/common';
  import { exchangePointPayment,digExperienceCard } from 'api/event'
  import Validator from 'common/js/class/validator'
  import {
    subscribePayment,
    subHuabei,
    subSubscribe,
    paymentOrder,
  } from "api/member";
  import { ERR_OK, COUPON_TYPE_JE } from "api/const"
  import { toastMixin, couponMixin } from "common/js/mixin"
  import { getClientType } from 'common/js/utils.js'
  import _track from 'common/js/track'
  import { throttle } from '@/utils/throttle'
  export default {
    mixins: [toastMixin, couponMixin],
    beforeRouteEnter(to,from,next){
      let ua = getClientType();
      if(ua == 4){
        next()
      }else{
        window.alert('请在支付宝中打开')
      }
    },
    data () {
      return {
        open:false,
        userMobile:'',
        showTopBtn:false,
        refOffsetTop:null,
        toastOpen:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
        depositStatus:null,
        Pay:false,
        cardRes:null,
        showLoading:false,
        //0:加衣券，1：50元续费，2：7天体验免押金，3：7天体验走花呗，4:200元季卡优惠劵
        popType:5,
        PopCont:{
          popTitle:['加衣券','50元续费优惠券','衣二三7天体验卡','衣二三7天体验卡','200元季卡优惠劵'],
          popImg:['res_0.png','res_1.png','res_2.png','res_2.png','res_4.png'],
          popButt:['立即使用','立即使用','立即领取','免费获取','立即使用'],
          popTxt:['礼包仅有一个月有效期，快去使用吧～','礼包仅有一个月有效期，快去使用吧～','体验卡领取后即生效，请尽快使用哦～','','礼包仅有一个月有效期，快去使用吧～']
        },
        requestType:['PAYMENT_REQUEST','EVENT_REQUEST'],//支付，活动
        bonusType:['VALID_USER_WITH_ORDER_OR_NOT','INVALID_USER_WITH_ORDER'],//加衣券，优惠券
      }
    },

    components:{
      BoxPopup,
      yi23Toast
    },
    computed:{
    },
    created () {
      this.groupId = this.$route.query.groupId;
      this.cardType = this.$route.query.cardType;
      let specialChannel = this.$route.query.specialChannel
      if(specialChannel && !this.$route.query.source){
        console.log(specialChannel)
        common.setCookie('source', specialChannel, '.95vintage.com');
      }
      window.addEventListener('scroll',throttle((e)=>{
        let scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        let isShow=false
        if(this.refOffsetTop ){
            if(scrollTop>this.refOffsetTop){
              isShow=true
            }else{
              isShow=false
            }
            if(this.showTopBtn != isShow){
              this.showTopBtn=isShow
            }
        }
      }))

    },
    mounted(){
      this.$nextTick(()=>{
      this.refOffsetTop=this.$refs.scrollPosition.offsetTop
      })
    },
    methods:{
      validataFunc() {
        let validator = new Validator();
        validator.add(this.userMobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },
      userSubmit: function () {
        let errorMsg = this.validataFunc();
        if(errorMsg){
          this.openToast(errorMsg);
          return
        }
        let params = {
          mobile : this.userMobile,
          cardType : this.cardType,
          groupId : this.groupId
        }
        digExperienceCard(params).then((res)=>{
          if(+res.code === 200){
            console.log(res.data);
            this.cardRes = res.data;
            this.createPrize()
          }
          else {
            this.openToast(res.msg);
          }

        })
      },
      createPrize(){
        this.showLoading=true
        setTimeout(()=> {
          this.showLoading=false
          this.judgeCard();
        },3000)
      },
      judgeCard(){
        let request = this.cardRes.requestType || 0;
        let bonus = this.cardRes.bonusType || 0;
        //判断是支付还是活动
        let requestType = this.requestType.indexOf(request);
        if(requestType === 0){
          let depositStatus = +this.cardRes.depositStatus || 0;
          this.popType = depositStatus === 0 ? 3 : 2;
        }else if(requestType === 1){
          //判断是优惠券还是加衣券
//          this.popType = this.cardRes.bonusName.indexOf('优惠券') >= 0 ? 1 : 0;
          if(this.bonusType.indexOf(bonus) === 1){
            this.popType = 1
          }else if(this.bonusType.indexOf(bonus) === 0){
            let reg = /9月|10月|11月/;
            this.popType = reg.test(this.cardRes.bonusName) ? 0 : 4;
          }else{
            this.openToast('数据错误！');
            return false;
          }
        }else{
          this.openToast('数据错误！');
          return false;
        }
        this.$nextTick(this.openBox());
      },
      buttFunc(){
        let popType = this.popType;
        this.saTrack(popType,1);
        switch (popType) {
          case 0:
            //加衣券
            this.jumpUrl(0)
            break;
          case 1:
            //50元续费
            this.jumpUrl(1)
            break;
          case 2:
            //7天体验免押金
            this.paySwitch()
            break;
          case 3:
            //7天体验 直接进行支付
            this.paySwitch()
            break;
          case 4:
            //200元季卡优惠劵
            this.jumpUrl(1)
            break;
        }
      },
      jumpUrl:function (type) {
        let pathUrl = type ? '/Member/payPage?yi23_channel=huabei' : '/Index/index?yi23_channel=huabei';
        this.$router.push({
          path : pathUrl
        })
      },
      saTrack(popType , type){
        if(type){
          _track.frontPageGidButt({
            name: popType
          })
        }else{
          _track.frontPageGidPop({
            name: popType
          })
        }

      },
      _subHuabei() {
        //花呗预授权 => code:200 链接跳转授权或者JSBridge授权 => 发起支付,判断是否为连续包月
        let _t = this;
        //新老支付
        let couponId = 0;
        let payType = "ALI_AUTH_FREEZE";
        //新老支付
        let cardTemplateId = this.cardRes.cardTemplateId;
        //新老支付
        let subType = 2;
        let isEvent = 1;
        let mobile = this.userMobile;

        paymentOrder({ couponId, payType, cardTemplateId, subType, isEvent, mobile }).then(res => {
          console.log(res);
          if (+res.code === 102) {
            window.location.href = res.data.freezeLink;
          } else if (+res.code === 103) {
            AlipayJSBridge.call("tradePay", { orderStr: res.data }, function(
              result
            ) {
              if (+result.resultCode === 9000 ) {
                //正常发起支付
                _t.paySwitch();
              }else{
                console.log(result);
                _t.paySwitch();
              }
            });
          } else if (+res.code === 110) {
            //正常发起支付
            _t.paySwitch();
          } else {
            _t.errorMsg = res.msg
          }
        });
      },
      openCustomService(){
        location.href='/yi23/Home/Others/qna?yi23_channel=huabei'
      },
      openVip(){
          location.href='/yi23/Home/Index/index?yi23_channel=huabei'
      },
      paySwitch() {
        let params = this.getParams();
        let cardTemplateId = this.cardType;
        let success = encodeURIComponent('/Promotion/dugExpcardPayment_r');

        //发起常规支付
        window.location.href = `/yi23/Home/Pay/payment?params=${encodeURIComponent(
          JSON.stringify(params)
        )}&success=${success}&redirect=${encodeURIComponent(
          this.$route.fullPath
        )}`;

      },
      getParams() {
        let cardTemplateId = this.cardRes.cardTemplateId;
        let couponId = 0;
        let isEvent  = 1;
        let mobile = this.userMobile;
        const params = {
          couponId,
          cardTemplateId,
          isEvent,
          mobile,
        };
        return params;
      },
      toastColse(){
        this.toastOpen = false
      },
      openBox:function () {
        this.open = true;
        this.saTrack(this.popType,0);
      },
      openToast(msg){
        this.errorMsg = msg;
      },

    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
.leftabc{
  display: flex;
  align-items:center;
  width:100%;
  height:40px;
  background: red;
}
.rightabc{
  display: flex;
  align-items:center;
  width:100%;
  height:40px;
  background: red;
  }
.WaO{
    /*background: #FFF5F3;*/
  background: #fff;
  &Banner{
    padding-bottom:65.6%;
  }
  &Con{
    margin: 0 0.853333rem;
    position: absolute;
    top: 11.04rem;
    left: 0;
  }
}
.bannerBox{
  position: relative;
}
  .cardType{
    text-align: left;
    height: auto;
    background: #fff;
    padding:24/18.75rem 1.066667rem 0;

    h2{
      width: 100%;
      /*margin-top: 0.426667rem;*/

      font-size: 18/18.75rem;
      /*font-weight: bold;*/
      line-height: 18/18.75rem;
    }
    p{
      margin-top: 10/18.75rem;
      font-size: 13/18.75rem;
      line-height: 14/18.75rem;
      color: #afafaf;
      font-weight: 300;
    }
  }


  .userMb{
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
    height: auto;
    background: #fff;
    padding: 20/18.75rem;
    margin-bottom: 0.426667rem;
    width: 80vw;

    input.mobilePhone{
      width: 100%;
      background: #f4f4f4;
      font-size: 0.746667rem;
      height: 44/18.75rem;
      line-height: 44/18.75rem;
      letter-spacing: 0.2px;
      font-size: 14/18.75rem;
      text-align: center;
    }
    button{
      border-radius: 0.106667rem;
    }
    button.btn{
      width: 100%;
      height: 44/18.75rem;
      letter-spacing: 0.5px;
      margin-top: 10/18.75rem;
      font-size: 14/18.75rem;
      /*background: #ccc;*/
      background-color: #ff544b;
    }
    button.btn.active{
      /*background: #111;*/
      background-color: #ff544b;
    }
  }
  .vipInfor{
    margin-top: 253 * @unit;
    img{
      width: 100%;
    }
  }

  .WaOCon{
      background: white;
      box-shadow: 2px 2px 6px 0 rgba(0, 0, 0, 0.05);
      border-radius: 2px;
      overflow: hidden;
  }
  .Rule{
    padding: 0 1.6rem 70px 1.6rem;
    background: #fff;
    h2{
      font-size: 0.853333rem;
      line-height: 4;
    }
    ol.rules-con{
      font-size: 0.64rem;
      padding-left: 0.533333rem;
      li{
        color: #666;
        list-style-type: decimal;
        text-align: left;
        font-size: 0.64rem;
        line-height:1.83;
        letter-spacing: 0.2px;
        margin-bottom: 0.8rem;
      }
      li:last-of-type{
        margin-bottom: 0;
      }
    }
    .RuleIMG{
      padding-bottom: 71.5408%;
    }
  }
  body .yi23-imgalert .Box_Inner{
    border-radius: 5px;
  }
  body .Box_InnerTop{
    padding-top: 30/18.75rem;
    text-align: center;
    img{
      width: 93/18.75rem;
    }
    h1{
      font-size: 14/18.75rem;
      line-height: 14/18.75rem;
      font-weight: bold;
      color: #111111;
      margin-top: 20/18.75rem;
    }
    p{
      font-size: 12/18.75rem;
      line-height: 12/18.75rem;
      color: #999999;
      padding:11/18.75rem 0 15/18.75rem 0;
    }
  }
  /*body .Box_InneBtm{*/
    /*text-align: center;*/
    /*img{*/
      /*width: 80%;*/
    /*}*/

  /*}*/
  body .Box_p{
    width: 100%;
    p{
      img{
        width: 1rem;
      }
      span{
        display: inline-block;
        text-align: left;
        margin-left: .5rem;
      }
    }
  }

  body .Box_Form p{
    font-size: 12/18.75rem;
    line-height: 17/18.75rem;
    padding:15/18.75rem 0;
    color: #666666;
    letter-spacing: 0.1px;
  }
  body .PayBtn{
    position: relative;
    margin-top: 30/18.75rem;
  }
  body .Box_Form button{
    width: 100%;
    height: 50/18.75rem;
    background-color: #ff544b;
    position: absolute;
    bottom: -22px;
    color: #fff;
    font-size: 14/18.75rem;
  }
  /*二次修改*/
  .cardType__title{
    padding-bottom: 10px;
    text-align: center;
  }
  .wa_border{
    height: 2 * @unit;
    background: #f1f1f1;
    width: 100%;
    margin: 16 * @unit 0;
  }
  .wa__price{
    height: 28 * @unit;
    display: flex;
    align-items: center;
    padding: 0  1.066667rem;
  }
  .wa__price_red{
    color: #ff544b;
    font-size: 20* @unit;
    font-weight: 600;

  }
  .wa__price_block{
    margin-left: 6 * @unit;
    font-size: 10px;
    color: #333333;
  }
  .wa__price_through{
    font-size: 12px;
    color: #333333;
    text-decoration: line-through;
  }
  .wa__toTop{
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 10;
    width: 100%;
    height: 136/2 * @unit;
  }
  .wa__toTop img{
    width: 100%;
    height: 100%;
  }
  .vipInfor__btn{
    height: 64 /2* @unit;
    position: relative;

  }
  .vipInfor__btn_custom-service{
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    width: 49%;
    height: 100%;
  }
  .vipInfor__btn_vip{
    position: absolute;
    top: 0;
    right: 0;
    z-index: 1;
    width: 49%;
    height: 100%;
  }
  .vipInfor_1{
    height: 440 /2 * @unit;
  }
  .vipInfor_2{
    height: 1224 /2 * @unit;
  }
  .vipInfor_3{
    height: 1126 /2 * @unit;
  }
  .vipInfor_4{
    height: 1126 /2 * @unit;
  }
  .vipInfor_5{
    height: 480 /2 * @unit;
  }
  .vipInfor_6{
    height: 616 /2 * @unit;
  }
  .vipInfor_7{
    height: 630 /2 * @unit;
  }
  /deep/ .yi23-imgalert{
      width: 640/2 *@unit;
      height: 592/2 *@unit;
    .yi23-imgalert__ft{
      display: none;
    }
  }
  .animate__box{

    /deep/.yi23-imgalert{
      width: 512/2 *@unit;
      height: 324/2 *@unit;
      .Box_Inner{
        background: none;
      }
      .Box_Form{
        display: none;
      }
    }
    .animate__box_background{
      width: 512/2 *@unit;
      height: 324/2 *@unit;
      display: flex;
      align-items: center;
      justify-content: center;
      background: url("https://yimg.yi23.net/webimg/web/images/2018/1207/back_ani.png") no-repeat;
      background-size: 100%;
      img{
        width: 140/2* @unit;
        height: 140/2* @unit;
      }
    }
  }

  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .Rule{
      padding-bottom:100px;
    }
  }
</style>
