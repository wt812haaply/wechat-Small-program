<template>
  <div class="commit">
    <template v-if="errorstatus == 0">
      <h2>提交成功</h2>
      <p>{{errormsg}}</p>
    </template>
    <template v-else>
      <h2>提交失败了</h2>
      <p style="padding:20px 20%; line-height:1.5;font-size: 13px;">{{errormsg}}</p>
      <template v-if="isrepeat != 1">
        <div>
            <button class="color_red" @click="goYglir">重新提交</button>
        </div>
      </template>
    </template>

    <div class="erm-img">
        <div class="erm-img">
            <button class="color_g" @click="downApp">下载衣二三APP</button>
        </div>
    </div>

  </div>
</template>

<script type="text/ecmascript-6">
export default {
  data(){
    return{
      errormsg: null,
      isrepeat: null,
      errorstatus: null
    }
  },
  created(){
    this.errormsg = this.$route.query.errormsg;
    this.isrepeat = this.$route.query.isrepeat;
    this.errorstatus = this.$route.query.errorstatus;
  },
  methods:{
    goYglir(){
      this.$router.back(-1)
    },
    downApp(){
      window.location.href="http://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan"
    }
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
.commit{
  width: 100%;
  height: 100%;
  display: flex;
  background: url('https://tu.95vintage.com/web_source/Home/Common/images/activity-end-bj.jpg') 0 0 no-repeat;
  background-size: cover;
  -webkit-font-smoothing: antialiased;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  h2{
    font-size: 24px;
    line-height: 24px;
    padding: 20px 0 10px 0;
    font-family: "PingFangSC";
  }
  button{
    color: #fff;
    margin-top: 20px;
    width: 180px;
    height: 44px;
    font-size: 14px;
    font-weight: 600;
    &.color_red{
      background: #FF544B;
    }
    &.color_g{
      background:#CDAB6A;
    }
  }
}
</style>
