<template>
  <div>
    <template v-if="!loginStatus && loginStatus != null">
      <div class="qrlogin yi23_fix_bglogo">
        <div class="banner image-ratio">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0421/GetCodeBanner.jpg">
        </div>
        <div class="form">
          <ul>
            <li class="flex_center">
              <input type="tel" name="tel" placeholder="请输入手机号" v-model="mobile">
            </li>
            <li class="flex_center">
              <input type="text" name="tel" placeholder="请输入验证码" v-model="imgCode">
              <div class="loginPageVerification"><div class="VerificationImg"><img :src="codeImgUrl" @click="checkImg"></div></div>
            </li>
            <li class="flex_center">

              <input type="tel" name="tel" placeholder="请输入手机验证码" v-model='code'>

              <div class="VerificationBtn">
                <button type="submit" @click="getCode">{{btnMsg}}</button>
              </div>
            </li>

          </ul>
          <div class="createdQRcodeBtn font16" @click="doLogin">生成二维码</div>
        </div>
      </div>
    </template>

    <template v-if="loginStatus">
      <share-bonus-e-qrcode></share-bonus-e-qrcode>
    </template>

    <yi23Toast v-model="toastMsg"></yi23Toast>

  </div>
</template>

<script type="text/ecmascript-6">
  import login from '@/api/login';
  import loginLocal from '@/common/js/login';
  import Validator from 'common/js/class/validator';
  import { toastMixin } from 'common/js/mixin';
  import { mapGetters } from 'vuex';
  import shareBonusEQrcode from './share_bonus_e_qrcode';

  export default {
    mixins: [toastMixin],
    data(){
      return{
        loginStatus: null,
        sendingCode:false,
        mobile:'',
        imgCode:'',
        codeImgUrl:'',
        code:'',
        timerNumber:60,
        btnMsg: '发送验证码'
      }
    },
    created(){
      this.checkLogin();
      this.codeImgUrl=login.codeImgUrl();
      console.log(this.$route);
    },
    watch:{
      loginRes (newStatus,oldStatus){
        this.setToastMsg(newStatus.msg);
        if(newStatus.status){
          this.loginStatus = true;
        }
      }
    },
    computed: {
      ...mapGetters({
        loginRes: 'loginRes'
      })
    },
    methods:{
      checkLogin(){
        let authorization = loginLocal.getToken();
        if(authorization){
          this.loginStatus = 1
        }else{
          this.loginStatus = 0
        }
      },
      checkImg(){
        this.codeImgUrl=this.codeImgUrl+1
      },
      timerAction(){

        let timers=setInterval( () =>{
          if(this.timerNumber>0){
            this.timerNumber= --this.timerNumber
            this.btnMsg=this.timerNumber+'s后获取'
          }else{
            clearInterval(timers)
            this.sendingCode=false;
            this.btnMsg='发送验证码';
            this.timerNumber=60;
          }
        },1000)

      },
      getCode () {

        if(!this.sendingCode){

          let errmsg = this.codeValiFunc();

          if(errmsg){
            this.setToastMsg(errmsg)
            return;
          }

          this.timerAction();

          this.sendingCode = true;

          login.getVerifyCode({mobile:this.mobile,code:this.imgCode}).then((res)=>{

            if(res.data.code == 200){

            }else {
              this.setToastMsg(res.data.msg)
            }

          })

        }else{

          this.setToastMsg('验证码已发送,请查收!');

        }

      },
      doLogin () {
        let errmsg = this.validataFunc();

        if(errmsg){
          this.setToastMsg(errmsg);
          return;
        }
        this.$store.dispatch('getUserInfo',{mobile:this.mobile,code:this.code});

      },
      codeValiFunc(){

        let validator = new Validator();

        //手机号
        validator.add(this.mobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确填写手机号'
        }]);

        //验证码
        validator.add(this.imgCode,[{
          strategy:'isNoEmpty',
          errorMsg:'图形验证码不能为空'
        }]);

        return validator.start();

      },
      validataFunc(){

        let validator = new Validator();

        //手机号
        validator.add(this.mobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确填写手机号'
        }]);

        //验证码
        validator.add(this.imgCode,[{
          strategy:'isNoEmpty',
          errorMsg:'图形验证码不能为空'
        }]);

        //手机号验证码
        validator.add(this.code,[{
          strategy:'isNoEmpty',
          errorMsg:'手机验证码不能为空'
        }]);

        return validator.start();

      },
      submitLogin(){
        let errmsg = this.validataFunc();

        if(errmsg){
          this.setToastMsg(errmsg)
        }
      }
    },
    components:{
      shareBonusEQrcode
    }
  }

</script>

<style scoped lang="less">

  @import "~common/less/variable";

  //qrlogin
  .qrlogin{
    width: 100%;
    height: 100%;
    .banner{
      width: 100%;
      height: 10.666667rem /* 200/18.75 */;
      img{
        display: block;
        width: 100%;
        height: 100%;
      }
    }
    .form{
      padding: 0 1.92rem;
      li{
        padding: 1.386667rem 0 .533333rem 0;
        border-bottom:1px solid #ccc;
      }
      input{
        width: 10.666667rem;
        height: 1.173333rem;
        font-size: .746667rem;
        display: block;
        flex: 1;
      }
    }
    .createdQRcodeBtn{
      width: 100%;
      height: 2.56rem;
      line-height: 2.56rem;
      margin-top: 1.493333rem;
      text-align: center;
      color: #fff;
      background: @color-bz-red;
      border-radius: .16rem /* 3/18.75 */;
    }
    .VerificationBtn{
      font-size: .586667rem;
    }
    .VerificationBtn button{
      border: 1px #666 solid;
      color: #666;
      width: 5.333333rem;
      padding: 0 .266667rem;
      background: 0 0;
      height: 1.6rem;

    }
  }
  .yi23_fix_bglogo{
    background:url('https://yimg.yi23.net/webimg/web/images/2018/0421/logo.png') no-repeat;
    background-position: center 97%;
    background-size: 4.8rem /* 90/18.75 */ 1.333333rem /* 25/18.75 */;
  }
  .flex_center{
    display: flex;
    display: -webkit-flex;
    display: -moz-flex;
    justify-content:center;
    align-items:center;
  }
  .font16{
    font-size: .853333rem;
  }
  input::-webkit-input-placeholder{
    color:#ccc;
  }
</style>
