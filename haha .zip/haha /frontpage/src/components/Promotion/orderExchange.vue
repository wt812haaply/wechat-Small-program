<template>
  <div class="orderExchange">
    <div class="maYi">
      <section class="" v-if="orderList && orderList.length > 1">
        <div class="myOrder">
          <ul class="oderList">

            <li v-for="(item,index) in orderList" :key="index" >
              <div class="listTop">
                <div class="lineT">
                  <h2 class="font-m">{{item.cardName}}</h2>
                  <p class="font-m" v-if="item.payStatus == 'WAIT_REFUND_POINT'">等待支付</p>
                  <p class="font-m green" v-else-if="item.payStatus == 'PAY_SUCCESS'">支付完成</p>
                  <p class="font-m" v-else-if="item.payStatus == 'REFUND_SUCCESS'">已退还</p>
                </div>
                <div class="lineB">
                  <h3 class="font-m">{{item.createTime}}</h3>
                  <p class="font-m">订单编号：{{item.orderNo}}</p>
                </div>
              </div>
              <div class="listCenter">
                <i>兑换手机号：</i>{{item.mobile}}
              </div>
              <div class="listBottom">
                <span class="font-m"><i>面额：</i>{{item.payTotal}}元</span>
                <span class="font-m"><i>积分：</i>{{item.point}}分</span>
                <span class="font-m"><i>扣款：</i>{{item.total}}元</span>
              </div>
            </li>

            <!--<li>-->
              <!--<div class="listTop">-->
                <!--<div class="lineT">-->
                  <!--<h2 class="font-m">衣二三7天体验卡</h2>-->
                  <!--<p class="font-m">等待支付</p>-->
                <!--</div>-->
                <!--<div class="lineB">-->
                  <!--<h3 class="font-m">2018-03-20</h3>-->
                  <!--<p class="font-m">订单编号：000000000000000</p>-->
                <!--</div>-->

              <!--</div>-->
              <!--<div class="listCenter">-->
                <!--<i>兑换手机号：</i>18800000000-->
              <!--</div>-->
              <!--<div class="listBottom">-->
                <!--<span class="font-m"><i>面额：</i>1357.00元</span>-->
                <!--<span class="font-m"><i>积分：</i>28888分</span>-->
                <!--<span class="font-m"><i>扣款：</i>666元</span>-->
              <!--</div>-->
            <!--</li>-->

            <!--<li>-->
              <!--<div class="listTop">-->
                <!--<div class="lineT">-->
                  <!--<h2 class="font-m">衣二三7天体验卡</h2>-->
                  <!--<p class="font-m green">支付完成</p>-->
                <!--</div>-->
                <!--<div class="lineB">-->
                  <!--<h3 class="font-m">2018-03-20</h3>-->
                  <!--<p class="font-m">订单编号：000000000000000</p>-->
                <!--</div>-->

              <!--</div>-->
              <!--<div class="listCenter">-->
                <!--<i>兑换手机号：</i>18800000000-->
              <!--</div>-->
              <!--<div class="listBottom">-->
                <!--<span class="font-m"><i>面额：</i>1357.00元</span>-->
                <!--<span class="font-m"><i>积分：</i>28888分</span>-->
                <!--<span class="font-m"><i>扣款：</i>666元</span>-->
              <!--</div>-->
            <!--</li>-->

            <!--<li>-->
              <!--<div class="listTop">-->
                <!--<div class="lineT">-->
                  <!--<h2 class="font-m">衣二三7天体验卡</h2>-->
                  <!--<p class="font-m green">支付完成</p>-->
                <!--</div>-->
                <!--<div class="lineB">-->
                  <!--<h3 class="font-m">2018-03-20</h3>-->
                  <!--<p class="font-m">订单编号：000000000000000</p>-->
                <!--</div>-->

              <!--</div>-->
              <!--<div class="listCenter">-->
                <!--<i>兑换手机号：</i>18800000000-->
              <!--</div>-->
              <!--<div class="listBottom">-->
                <!--<span class="font-m"><i>面额：</i>1357.00元</span>-->
                <!--<span class="font-m"><i>积分：</i>28888分</span>-->
                <!--<span class="font-m"><i>扣款：</i>666元</span>-->
              <!--</div>-->
            <!--</li>-->

            <!--<li>-->
              <!--<div class="listTop">-->
                <!--<div class="lineT">-->
                  <!--<h2 class="font-m">衣二三7天体验卡</h2>-->
                  <!--<p class="font-m green">支付完成</p>-->
                <!--</div>-->
                <!--<div class="lineB">-->
                  <!--<h3 class="font-m">2018-03-20</h3>-->
                  <!--<p class="font-m">订单编号：000000000000000</p>-->
                <!--</div>-->

              <!--</div>-->
              <!--<div class="listCenter">-->
                <!--<i>兑换手机号：</i>18800000000-->
              <!--</div>-->
              <!--<div class="listBottom">-->
                <!--<span class="font-m"><i>面额：</i>1357.00元</span>-->
                <!--<span class="font-m"><i>积分：</i>28888分</span>-->
                <!--<span class="font-m"><i>扣款：</i>666元</span>-->
              <!--</div>-->
            <!--</li>-->

            <!--<li>-->
              <!--<div class="listTop">-->
                <!--<div class="lineT">-->
                  <!--<h2 class="font-m">衣二三7天体验卡</h2>-->
                  <!--<p class="font-m">已退还</p>-->
                <!--</div>-->
                <!--<div class="lineB">-->
                  <!--<h3 class="font-m">2018-03-20</h3>-->
                  <!--<p class="font-m">订单编号：000000000000000</p>-->
                <!--</div>-->

              <!--</div>-->
              <!--<div class="listCenter">-->
                <!--<i>兑换手机号：</i>18800000000-->
              <!--</div>-->
              <!--<div class="listBottom">-->
                <!--<span class="font-m"><i>面额：</i>1357.00元</span>-->
                <!--<span class="font-m"><i>积分：</i>28888分</span>-->
                <!--<span class="font-m"><i>扣款：</i>666元</span>-->
              <!--</div>-->
            <!--</li>-->

          </ul>
        </div>
      </section>

      <section class="none1" v-else>
        <div class="myOrderNull">
          <div class="bae">
            <div class="baeIMG PlIMG image-ratio">
              <img src="http://yimg.yi23.net/webimg/web/images/20180604/none.png" alt="">
            </div>
          </div>
          <p>你现在还没有下单</p>
          <p>有问题可咨询衣二三客服4006504580</p>
        </div>
      </section>
    </div>

    <div class="footerBtn bottomIphoneX">
      <button class="btn btn-defult" @click="openIndex">进入衣二三</button>
    </div>
  </div>
</template>

<script>
  import BoxPopup from '../lib/BoxPopup.vue'
  import { exchangePointPayment } from 'api/event'
  import Validator from 'common/js/class/validator'
  import { aliPointPackageDeposit } from 'api/member'
  import { orderList } from 'api/event'

  export default {
    data () {
      return {
        open:false,
        otherPay:false,
        userMobile:'',
        noneOrder:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
        depositStatus:null,
        orderList:{},
      }
    },

    components:{
      BoxPopup
    },
    computed:{
    },
    created () {
      this.getOrderList()
    },
    mounted(){
    },
    methods:{

      openToast(msg){
        this.errorMsg = msg;
      },

      openIndex : function () {
        this.$router.push({
          path:'/index/index',
          query:{source:'fe9fdfb6272bf4da9b92c8fdb55ae3df'}
        })
      },

      getOrderList: function () {
        orderList().then((res)=>{
          console.log(res);
          if(res.code == 200) {
            this.orderList = res.data.orderList;
            console.log(this.orderList);
          }else {
            this.errorMsg = res.msg
          }
        });
      },
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  @import "./20180602/orderExchange";
</style>
