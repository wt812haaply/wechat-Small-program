<template>
  <div class="">

    <!--成功-->
    <div class="ResultA-Bg" v-if="is_success=='T'">
    <div class="share_Card_C_Result">
        <h2>目前只开放给新用户</h2>
        <p class="font-r">抱歉，您已经是衣二三会员了哦</p>
        <div class="ResultBtn">
          <!--<button class="btnA font-m" @click="goInvite()">立即邀请</button>-->
          <button class="btnB font-m" @click="downApp()">去选衣</button>
        </div>
      </div>
      <div class="share_result_Con">
        <div class="title"><i>奖励规则</i></div>
        <ol class="rules-con font-l">
          <li>分享活动页面给好友，好友通过链接支付成功后，邀请人获得3天会员期奖励；</li>
          <li>链接支持分享给多个好友，会员期奖励可累积；若N个好友通过链接成功购买，则邀请人会员期可延长3*N天；</li>
          <li>若好友成功付费时，您的会员期已结束，仍可获得相应奖励；</li>
          <li>10天体验仅限新用户购买；</li>
        </ol>
    </div>
    <!--遮罩-->
    <div class="yi23-mask" v-if="mask" @click="closeMask()">
      <div class="shareForIcon">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0416/shareForICON.png" alt="">
      </div>
    </div>


    </div>

    <!--失败-->
    <div class="share_Card_C_Result ResultB-Bg" v-if="is_success=='F'">
      <h2>
        <i><img src="https://yimg.yi23.net/webimg/web/images/2018/0326/iconFailure.jpg" alt=""></i>
        支付失败</h2>
      <p class="font-r">亲，您支付失败，请重新支付～
      <div class="ResultBtn">
        <button class="btnA font-m" @click="againPay()">重新支付</button>
      </div>
    </div>


  </div>
</template>
<script>
import  shareMixin  from '@/mixins/share';
import loginLocal from '@/common/js/login'
import { shareCardCO } from 'api/event'
export default {
  data() {
    return {
      shareCardC_r:'',
      is_success:'',
      none:false,
      shareInfo:false,
      mask:false,
    }
  },
  mixins:[shareMixin],
  components: {

  },
  created() {
    this.is_success=this.$route.query.is_success
    shareCardCO({specialChannel:this.$route.query.specialChannel}).then((res)=>{
      // console.log(res)
      if(res.code==200){
        this.shareInfo=res.data.sendData?JSON.parse(res.data.sendData):{};
        this.setShareMessage(this.shareInfo)
      }
    })
  },
  computed: {},
  methods: {
    //立即邀请
    openMask:function () {
      this.mask = true
    },
    closeMask:function () {
      this.mask = false
    },
    //去选衣
    downApp:function () {
      window.location.href='https://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan'
    },
    goInvite:function () {
      let authorization = loginLocal.getToken();
      if(authorization){
        try{
          this.doShare()
        }catch (e){
          console.log(e)
          this.mask=true
        }
      }else{
        this.$router.push({
          path: '/loginPage',
          query: {redirect: this.$route.query.redirect}
        })
      }

    },
    //重新支付
    againPay:function(){
      this.$router.push({
        path:decodeURIComponent(this.$route.query.redirect),
      })
    },
  },
}

</script>
<style scoped lang="less">
  .share_Card_C_Result {
    text-align: center;
    padding-top: 3.04rem;
    padding-bottom:54px ;
    padding-bottom: 2.88rem;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    flex-wrap: wrap;
    background-color: #fff;
    h2 {
      width: 100%;
      font-size: 1.066667rem;
      height: 3.2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      i {
        width: 1.386667rem;
        height: 1.386667rem;
        position: relative;
        top: 0;
        right: 0.266667rem;

        img {
          width: 1.386667rem;
          position: absolute;
          left:0;
          top:0;
        }
      }
    }
    p {
      font-size: 0.746667rem;
      letter-spacing: 0.8px;
      text-align: center;
      color: #111;
      margin-bottom: 2.453333rem;
      margin-bottom: 2.453333rem;
      margin-bottom: 1.6rem;
      width: 100%;
      line-height: 1.28rem;
    }
    .ResultBtn {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      width: 8.533333rem;

      button {
        width: 100%;
        height: 2.24rem;
        border-radius: 2.24rem;
        color: #fff;
        font-size: 0.746667rem;
        text-align: center;
      }
      button.btnA {
        background: #ff544b;
      }
      button.btnB {
        margin-top: 1.066667rem;
        border: 1px #ff544b solid;
        background: transparent;
        color: #ff544b;
      }
    }
  }

  .share_result_Con {
    padding: 0 1.6rem 1.6rem 1.6rem;
    .title {
      display: table;
      white-space: nowrap;
      width: 100%;
      display: flex;
      justify-content: center;
      line-height: 1.77;
      letter-spacing: 0.7px;
      text-align: center;
      color: #111;
      padding-top: 20px;
      padding-bottom: 10px;
      i {
        padding: 0 0.533333rem;
        font-style: normal;
        font-size: 0.853333rem;
      }
    }

    .title:before,
    .title:after {
      border-top: solid 1px rgba(0, 0, 0, 0.04);
      content: '';
      display: table-cell;
      position: relative;
      top: 14px;
      top: 0.746667rem;
      width: 45%;
      height: 1.066667rem;
    }
    .title:before {
      right: 1%;
    }
    .title:after {
      left: 1%;
    }

    ol.rules-con {
      font-size: 0.64rem;
      padding-left: 0.533333rem;
      li {
        color: #666;
        list-style-type: decimal;
        text-align: left;
        font-size: 0.64rem;
        line-height: 1.83;
        letter-spacing: 0.2px;
        text-align: left;
        margin-bottom: 0.8rem;
      }
      li:last-of-type {
        margin-bottom: 0;
      }
    }
  }
  .ResultA-Bg{
    background: #f6f6f6;
    height:100vh;
  }
  .ResultB-Bg{
    background-color: #fff;
  }

  .shareForIcon{
    position: absolute;
    z-index: 3;
    right: 18px;
    top: 18px;
    float: right;
    img{
      width: 100px;
    }
  }
</style>
