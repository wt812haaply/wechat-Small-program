<template>
  <div class="mayiExchange">
    <div class="imgP image-ratio mayiExchangeBanner">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0602/20180602Banner01.jpg" alt="">
    </div>

    <div class="mayiExchangeCon" v-if="cardList">
      <div class="cardType">
        <div class="typeTitle">
          <h2 class="font-m">{{cardList.payName}}</h2>
          <p>市场参考价￥{{cardList.payOriginal}}</p>
        </div>

        <div class="cardLogo">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexLogo02.jpg" alt="">
        </div>
      </div>
      <div class="cardPrice">
        <div class="wer">

          <span class="left font-m">
            <template v-if="cardList.payCost">{{cardList.payCost}}元</template>
            <template v-if="cardList.payCost && cardList.aliPoint"> + </template>
            <template v-if="cardList.aliPoint">{{cardList.aliPoint}}积分</template>
          </span>

          <!--<span class="right" v-if = "cardList.templateId != 33 && cardList.templateId != 36">新用户再减200元</span>-->
          <span class="right" v-if = "cardList.payCost">新用户再减{{reductionAmount}}元</span>
          <!--tid 判断-->
        </div>
      </div>

      <div class="userMb">
        <input v-model="userMobile" class="mobilePhone font-r" placeholder="请输入衣二三账号（手机号）">
        <button class="btn btn-defult btn-black font-m" disabled="disabled" v-show="!showOff">抢光啦</button>
        <button class="btn btn-defult btn-black font-m active" :disabled="isDisabled" @click="userSubmit" v-show="showOff">兑换成为衣二三会员</button>
        <!--<button class="btn btn-defult btn-black font-m active" :disabled="isDisabled" @click="userSubmit" v-show="showOff" v-if="depositStatus == 0">兑换成为衣二三会员</button>-->
        <!--<button class="btn btn-defult btn-black font-m active" :disabled="isDisabled" @click="paySwitch"  v-show="showOff" v-else>兑换成为衣二三会员</button>-->
      </div>
    </div>

    <div class="Rule">
      <h2 class="font-m">活动细则</h2>
      <ol class="rules-con font-r">
        <li>新用户是指衣二三的新用户，以注册手机号为准，卡种购买不限次数，累计购买卡用户有效期往上累计。</li>
        <li>退换规则：兑换成功7天内可根据下单情况进行部分或全部的退款退积分，退还积分48小时内到账，具体退款请拨打衣二三客服电话。</li>
        <li>客服电话：4006504580</li>
        <li>更多衣二三服务，可在支付宝搜索“衣二三”小程序或生活号，或下载app进入选衣页查看更多可租时装配饰。</li>
        <li>会员期计算规则：首次下单前，我们最长可以为您冻结15天，超过15天系统将开始为您计算会员期，请及时选衣下单哦。下单期间如需冻结，只需把所有衣箱归还即可，冻结期最长同样也是15天。</li>
      </ol>
      <h2 class="font-m">兑换流程</h2>
      <div class="imgP RuleIMG image-ratio">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0602/2018060203.jpg" alt="">
      </div>
    </div>

    <BoxPopup :open="open">
      <div slot="Box_InnerTop">
        <div class="Box_InnerTop">
          <p>为您兑换到衣二三账户:</p>
          <p>{{ userMobile }}</p>
          <!--<p v-if = "cardList.templateId != 33 && cardList.templateId != 36">-->
          <p v-if = "cardList.payCost">
            <template v-if="isFirstPay == 1">新用户专享</template>
            <template v-if="isFirstPay != 1">老用户特惠</template>

            <template v-if="cardList.payCost && isFirstPay == 1">{{cardList.payCost - reductionAmount}}元</template>
            <template v-if="cardList.payCost && isFirstPay!=1">{{cardList.payCost}}元</template>
            <template v-if="cardList.payCost && cardList.aliPoint"> + </template>
            <template v-if="cardList.aliPoint">{{cardList.aliPoint}}积分</template>

          </p>
          <p v-else>
            <template v-if="cardList.aliPoint">{{cardList.aliPoint}}积分</template>
          </p>
        </div>
      </div>

      <div slot="Box_InneBtm" style="margin-top:15px;">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0602/2018060205.jpg" alt="">
      </div>

      <!--<div slot="Box_p" v-if = "this.depositStatus == 0 && (cardList.templateId == 33 || cardList.templateId == 36)" >-->
      <!--<div slot="Box_p" v-if = "this.depositStatus == 0 && this.depositWaived == 0" >-->
      <div slot="Box_p" v-if = "depositWaived == 0" >
        <p><i><img src="https://yimg.yi23.net/webimg/web/images/2018/0602/2018060204.jpg" alt=""></i>¥300押金预授权(仅冻结花呗额度，无须支付)</p>
        <div class="PayBtn">
          <button class="font-r btn active" @click="_subHuabei()">确认兑换</button>
        </div>
      </div>
      <div slot="Box_p" v-else>
        <p></p>
        <div class="PayBtn">
          <button class="font-r btn active" @click="paySwitch()">确认兑换</button>
        </div>
      </div>
    </BoxPopup>

    <yi23Toast v-model="errorMsg"></yi23Toast>
  </div>
</template>

<script>
  import BoxPopup from '../lib/BoxPopup.vue'
  import Validator from 'common/js/class/validator'
  import { getMembershipAuthLink } from 'api/member'
  import { getCardStatus,getExchangeUserInfo,antSummer,cardList } from '../../api/event'
  import {
    subscribePayment,
    subHuabei,
    subSubscribe,
    paymentOrder,
  } from "api/member";
  import { ERR_OK, COUPON_TYPE_JE } from "api/const"
  import { toastMixin, couponMixin } from "common/js/mixin"

  export default {
    mixins: [toastMixin, couponMixin],
    data () {
      return {
        cardExchange:{gradeName:1},
        open:false,
        userMobile:'',
        toastOpen:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
//        depositStatus:0,//0为需要花呗预授权
        Pay:false,
        authCode:'',
        cardType:null,
        showOff:false,
        notFirst:'您已参加过活动，请下个月再来兑换~',
        isDisabled:false,
        cardList:{},//列表信息
        isFirstPay:0,//新用户1,可更新
        reductionAmount:200,//优惠金额
        origin:'summer_campaign',
        depositWaived:0,//免押判断（用户+卡）,可更新
      }
    },

    components:{
      BoxPopup
    },
    computed:{
    },
    created () {
      let query =  this.$route.query;
      if(query.tid){
        this.cardType = query.tid
        this._getCardList(query.tid)
      }
    },
    mounted(){
    },
    methods:{

      _getCardList:function (tid) {
        let params = {tid:tid, origin:this.origin}
        cardList(params).then((res)=>{
          console.log(res)
          this.cardList = res.data.showInfo[0];
          this.depositWaived = res.data.showInfo[0].depositWaived;
          this.showOff = res.data.showInfo[0].hasStock;
          this.isFirstPay = res.data.isFirstPay;
          console.log(this.isFirstPay)
        })
      },

      _subHuabei() {
        //花呗预授权 => code:200 链接跳转授权或者JSBridge授权 => 发起支付,判断是否为连续包月
        let _t = this;
        let couponId = 0;//优惠券
        let payType = "ALI_AUTH_FREEZE";
        let cardTemplateId =  this.cardType;//卡类型
        let subType = 2;//新老支付
        let isEvent = 1;
        let mobile = this.userMobile;//手机号

        paymentOrder({ couponId, payType, cardTemplateId, subType, isEvent, mobile }).then(res => {
          console.log(res);
          if (res.code == 102) {
            //102
            window.location.href = res.data.freezeLink;
          } else if (res.code == 103) {
            //103
            AlipayJSBridge.call("tradePay", { orderStr: res.data }, function(
              result
            ) {
              if (result.resultCode == "9000" || result.resultCode == 9000) {
                //正常发起支付
                _t.paySwitch();
              }else{
                console.log(result);
                _t.paySwitch();
              }
            });
          } else if (res.code == 110) {
            //正常发起支付
            _t.paySwitch();
          } else {
            _t.errorMsg = res.msg
          }
        });
      },

      paySwitch() {
        let params = this.getParams();
        let cardTemplateId = this.cardType;
        let success = "MayiExchangeSuccess";

        //发起常规支付
        window.location.href = `/yi23/Home/Pay/payment?params=${encodeURIComponent(
          JSON.stringify(params)
        )}&success=${success}&redirect=${encodeURIComponent(
          this.$route.path
        )}`;

      },
      getParams() {
        let cardTemplateId = this.cardType;
        let couponId = 0;
        let isEvent  = 1;
        let payType  = 'ALI_POINT';
        let mobile = this.userMobile;//手机号
        const params = {
          couponId,
          cardTemplateId,
          isEvent,
          payType,
          mobile,
        };
        return params;
      },

      toastColse(){
        this.toastOpen=false
      },

      openBox:function () {
        this.open = true
      },

      validataFunc() {
        let validator = new Validator();
        //phone
        validator.add(this.userMobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },

      userSubmit: function () {
        let errorMsg = this.validataFunc();
        if(errorMsg){
          this.openToast(errorMsg)
          return
        }
        antSummer(this.cardType,this.userMobile,this.origin).then((res)=>{
          if(res.code == 200){
            console.log(res.data)
//            this.depositStatus = res.data.depositStatus
            this.isFirstPay = res.data.isFirstPay
            this.depositWaived = res.data.depositWaived
            if(res.data.reductionAmount)
              this.reductionAmount = res.data.reductionAmount
            this.openBox()
          }
          else {
            this.errorMsg = res.msg
          }
        });
      },

      openToast(msg){
        this.errorMsg = msg
      },

      //我的订单
      myOrder:function (isName) {
        this.$router.push({
          path:'/Promotion/orderExchange',
          query:{ name:encodeURIComponent(isName)}
        })
      },

      //电话
      callCenter:function () {
        window.location.href='tel://4006504580'
      },

    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  @import "./20180602/mayiExchange";
</style>
