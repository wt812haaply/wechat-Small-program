<template>
  <div>

    <!--成功-->
    <div class="share_Card_Result" v-if="shareCardF_result == 'T'">
      <h2>
        <i><img src="https://yimg.yi23.net/webimg/web/images/2018/0326/iconSuccess.jpg" alt=""></i>
        购买成功</h2>
        <p class="font-r">恭喜成为衣二三会员！邀请好友一起<br>体验，会员期可延长3天哦~</p>

        <div class="ResultBtn">

          <button class="btnA font-m" @click="toShareInfo">立即邀请</button>

          <button class="btnB font-m" onclick="window.location.href='https://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan'">下载衣二三APP</button>

        </div>
        <div class="EntranceCon">
          <div class="title"><i>奖励规则</i></div>
          <ol class="rules-con font-l">
              <li>
                  分享活动页面给好友，好友通过链接支付成功后，邀请人获得3天会员期奖励;
              </li>
              <li>
                  链接支持分享给多个好友，会员期奖励可累积；若N个好友通过链接成功购买，则邀请人会员期可延长3*N天;
              </li>
              <li>此活动仅限有效期内的活动参与；用户过期后，则无法收到相应的有效期奖励;</li>
              <li>
                  10天体验仅限新用户购买;
              </li>
          </ol>
      </div>

    </div>

    <!--失败-->
    <div class="share_Card_Result" v-if="shareCardF_result == 'F'">
      <h2>
        <i><img src="https://yimg.yi23.net/webimg/web/images/2018/0326/iconFailure.jpg" alt=""></i>
              支付失败</h2>
      <p class="font-r">亲，您支付失败，请冲重新支付～</p>
      <button class="btnA font-m" @click="exchange()">重新支付</button>
      <button class="btnB font-m" @click="newBox()">进入衣二三</button>
    </div>

    <WXbg v-model="shareImageShow"></WXbg>

  </div>
</template>
<script>
import common from 'common/js/common';
import WXbg from '@/base/WXbg';
import  shareMixin  from '@/mixins/share';

export default {
  mixins:[shareMixin],
  data() {
    return {
      shareCardF_result:null,
      shareImageShow:false
    }
  },
  components:{
    WXbg
  },
  methods: {
    //成功按钮跳转
    newBox:function(){
      this.$router.replace({
        path:'/Index/index'
      })
    },
    //重新兑换会员
    exchange:function () {
      let redirect = this.$route.query.redirect;
      this.$router.replace({
        path: redirect
      })
    },
    toShareInfo(){
      //立即邀请
      if(common.getAuthCookie()){
          console.log(this.$clientType);
        if(this.$clientType == 1 || this.$clientType == 2){

          this.doShare()

        }else{

          this.shareImageShow = true;

        }

      }else{
        this.toLogin();
      }
    },
    toLogin:function(){

      this.$router.push({
        path:'/loginPage' ,
        query:{
          redirect:this.$route.fullPath
        },
        repalce: true
      })

    }
  },
  created() {
    let result = this.$route.query.is_success;
    this.shareCardF_result = result;
  },

}

</script>
<style scoped lang="less">
.share_Card_Result {
  text-align: center;
  padding-top: 3.5rem;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  flex-wrap: wrap;
  h2 {
    width: 100%;
    font-size: 1.066667rem;
    height: 3.2rem;
    display: flex;
    align-items: center;
    justify-content: center;
    i {
      width: 1.386667rem;
      height: 1.386667rem;
      position: relative;
      top: 0;
      right: 0.266667rem;

      img {
        width: 1.386667rem;
        position: absolute;
        left:0;
        top:0;
      }
    }
  }
  p {
    font-size: 0.746667rem;
    line-height: 1.64;
    letter-spacing: 0.8px;
    text-align: center;
    color: #111111;
    margin-bottom: 2.453333rem;
  }
  button {
    width: 10.773333rem;
    height: 2.133333rem;
    color: #fff;
    font-size: 0.746667rem;
  }
  button.btnA {
    background: #ff544b;
  }
  button.btnB {
    margin-top: 1.066667rem;
    border: 1px #ff544b solid;
    background: transparent;
    color: #ff544b;
  }
}
.EntranceCon{
  background: #f6f6f6;
  margin-top: 45px;
  padding: 0 1.6rem 1.6rem 1.6rem;
}
.EntranceCon .title{
  display: table;
    white-space: nowrap;
    width: 100%;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    line-height: 1.77;
    letter-spacing: .7px;
    text-align: center;
    color: #111;
    padding-top: 20px;
    padding-bottom: 10px;
}
.EntranceCon .title i {
    padding: 0 .533333rem;
    font-style: normal;
    font-size: .853333rem;
}
.EntranceCon ol.rules-con {
    font-size: .64rem;
    padding-left: .533333rem;
}
.EntranceCon ol.rules-con li {
    color: #666;
    list-style-type: decimal;
    text-align: left;
    font-size: .64rem;
    line-height: 1.83;
    letter-spacing: .2px;
    text-align: left;
    margin-bottom: .8rem;
}
</style>
