<template>
  <div>
      <router-view></router-view>
  </div>
</template>
<script>
  import loginLocal from '@/common/js/login'
  import common from '@/common/js/common'
    export default {
        name: "shareCardG",
        data () {
          return {
              loginStatus:0
          }
        },
        created() {
          let authorization = loginLocal.getToken();
          if(authorization){
            this.loginStatus=1
          }else{
            this.loginStatus=0
          }
          let getData= this.$route.query;
          if(getData.aid){
            let adParam = {
              cid:getData.cid || 0,
              wi:getData.wi || '',
              aid:getData.aid || '',
              channel:getData.channel || ''
            };
            common.setCookie('adparam',JSON.stringify(adParam),'','','',15);
          }else if(getData.a_id){
            let adParam = {
              a_id: getData.a_id || '',
              c_id: getData.c_id || '',
              l_id: getData.l_id || '',
              l_type1:getData.l_type1 || ''
            };
            common.setCookie('adparam',JSON.stringify(adParam),'','','',15);
          }
          if(this.loginStatus==0){
            this.$router.push({
              name:'shareCardGLogin',
              query:this.$route.query
            })
          }else {
            this.$router.push({
              name:'shareCardGBuy',
              query:this.$route.query
            })
          }
        }
    }
</script>

<style scoped>

</style>
