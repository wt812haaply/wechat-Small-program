<template>
  <div class="WaO" v-if="shareCardF">
    <div class="imgP image-ratio WaOBanner">
      <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexBanner01.jpg" alt="">
    </div>

    <div class="WaOCon">
      <div class="cardType">
        <h2 class="font-m">{{shareCardF.payData.payName}}</h2>
        <div class="cardLogo">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexLogo02.jpg" alt="">
        </div>
      </div>
      <div class="cardPrice">
        <span class="left">{{shareCardF.payData.payCost}}<i>元</i></span>
        <span class="right">市场参考价¥{{shareCardF.payData.originalCost}}</span>
      </div>
      <div class="userMb">
        <input v-model="userMobile" class="mobilePhone font-r" placeholder="请输入衣二三账号（手机号）" :disabled="isfinish != null && isfinish">
        <template v-if="isfinish != null && !isfinish">
          <button class="btn btn-defult btn-black font-m"  v-if="shareCardF.payData.cardStock <=0 ">库存不足</button>
          <button class="btn btn-defult btn-black font-m active"  @click="userSubmit"  v-else>成为衣二三会员</button>
        </template>
        <template v-if="isfinish != null && isfinish">
          <button class="btn btn-defult btn-black font-m active gray"  @click="userSubmit">活动已结束</button>
        </template>
      </div>
      <div class="vipInfor">
        <h2 class="Title"><i class="font-m">什么是衣二三会员</i></h2>
        <p class="font-l">MEMBERSHIP PLAN</p>

        <div class="imgP vipInforIMG image-ratio">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexVip03.jpg" alt="">
        </div>
        <span class="font-r">
          成为衣二三会员后，您将享受全球精选的时装包月租赁服务，百万件时装及配饰随心换穿。
每次下单可选三件，隔48小时即可再下一单，随心下单，想穿多久穿多久。喜欢的可以买下自留，其余的预约寄回，衣二三负责为您清洗，全程免邮。
        </span>
      </div>

    </div>
    <div class="Rule">
      <h2 class="font-m">活动细则</h2>
      <ol class="rules-con font-r">
        <li>本活动每位用户仅限参与一次，同一手机号、支付宝账号都视为同一用户</li>
        <li>体验卡不享会员期冻结权益，请领取后尽快下单哦</li>
        <li>购买成功后可在支付宝搜索“衣二三”生活号或者小程序进行选衣，也可下载衣二三app进行选衣</li>
        <li>购买会员卡超过7天后不可退卡，成功下单不可退卡</li>
        <li>如有疑问联系衣二三客服 400-650-4580</li>
        <li>一组收货信息仅对应一个衣二三会员身份，衣二三有权取消同一会员多个重复账号的会员资格</li>
        <li v-if="checkDec">{{checkDec}}</li>
      </ol>
    </div>


    <BoxPopup :open="open" >
      <div slot="Box_InnerTop">
        <div class="Box_InnerTop" style="height: 40px">
          <p>为您绑定到衣二三账户：</p>
          <p>{{ userMobile }}</p>
        </div>
      </div>

      <div slot="Box_InneBtm">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexTip05.jpg" alt="">
      </div>

      <div slot="Box_checkbox" v-if="Pay">
        <div class="FormCheckbox" >
          <input type="checkbox" id="sextype" v-model="checkedNames" >
          <label for="sextype"></label>
          <i class="font-m">¥300押金预授权(仅冻结花呗额度，无须支付)</i>
        </div>
        <div class="PayBtn_huabei">
          <button :class="[{'active':checkedNames},'btn','font-r']" @click="payHuaBei()">确认支付</button>
        </div>
      </div>

      <div slot="Box_p" v-else>
        <p>支付成为会员，随心包月租衣</p>
        <div class="PayBtn">
          <button class="font-r btn active" @click="payMethod()">确认支付</button>
        </div>
      </div>

    </BoxPopup>

    <yi23Toast v-model="errorMsg"></yi23Toast>

    <yi23Dialog
      @dialogOk="dialogOK"
      @dialogClose="dialogOK"
      :open="dialogShow"
      :dialogSm='true'
      >
      <div slot="header">错误提示</div>
      <div slot="body">
        <p>网络异常,请刷新重试</p>
      </div>
      </yi23Dialog>
  </div>
</template>

<script>
  import Dialog from '../lib/Dialog.vue'
  import BoxPopup from '../lib/BoxPopup.vue'
  import yi23Toast from '../lib/Toast.vue'
  import { shareCardF,exchangePointPayment,shareCardFAddTime} from 'api/event'
  import Validator from 'common/js/class/validator'
  import { aliPointPackageDeposit } from 'api/member'
  import { getClientType } from 'common/js/utils.js'
  import login from '@/api/login'

  export default {
    beforeRouteEnter(to,from,next){
       let ua = getClientType();
       if(ua == 4){
         next()
       }else{
        window.alert('请在支付宝中打开')
       }
    },
    data () {
      return {
        aliUserId:null,
        shareCardF:null,
        open:false,
        userMobile:'',
        toastOpen:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
        depositStatus:null,
        Pay:false,
        dialogShow: false,
        checkDec:null,
        isfinish:null
      }
    },
    watch:{
      '$route':'aliPayLogin'
    },
    components:{
      BoxPopup,
      yi23Toast,
      Dialog
    },
    created () {
      this.checkDescribe();
      this.aliPayLogin()
      this.getShareCardF();
    },
    methods:{
      checkDescribe(){
        let specialCode = this.$route.query.specialCode;
        let dec;

        switch(specialCode){
          case 'ODRETmxQRVUxQjBCRnQxSkFWcz0':
            dec = '本次活动截至6月30日，先到先得发完即止';
            break;
          case 'QTAyWndwSU42M0MwM2Z4ZDVwYz0':
            dec = '本次活动截至6月30日，先到先得发完即止';
            break;

          case 'RUZDaHNWcWVGMDdEODhrd0NBND0':
            dec = '本次活动截至7月31日，先到先得发完即止';
            break;
          case 'ODY3dkh4MWI3NThENVFUcllxbz0':
            dec = '本次活动截至7月31日，先到先得发完即止';
            break;

          case 'QzdBV2JETzA3NTA0NHJkUUpxTT0':
            dec = '本次活动截至8月31日，先到先得发完即止';
            break;
          case 'MzU0WlB6UHA3MjU0RTRFWHVUTT0':
            dec = '本次活动截至8月31日，先到先得发完即止';
            break;

          case 'MTM1dnU0WDgwQzA2OUw1T3pWST0':
            dec = '本次活动截至9月30日，先到先得发完即止';
            break;

          case 'NDIwMUhOTDgzQzAwNVk2bis1bz0':
            dec = '本次活动截至9月30日，先到先得发完即止';
            break;
        }

        this.checkDec = dec;
      },
      aliPayLogin(){
        let _t = this;
        if(this.$clientType==4){
          let autoCode=this.$route.query.auth_code
          if(autoCode){
            //通过autoCode  获取登陆信息
            login.getAliUserId({code:autoCode}).then((res)=>{
              if(res.data.code==200){
                if(res.data.data == ''){

                  _t.dialogShow = true

                }else{
                  _t.aliUserId = res.data.data.aliUserId;
                }
              }else {
                _t.dialogShow = true
              }
            })

          }else{
            let urls='/yi23/Home'+this.$route.fullPath;
            login.getaliAuthLink({url:urls}).then((res)=>{
              if(res.data.code==200){
                window.location.href=res.data.data;
              }else{
                this.errorMsg= res.data.msg
              }
            })
          }
        }
      },
      dialogOK(){
        //重新刷当前页面
        let specialCode = this.$route.query.specialCode || '';
        let specialChannel = this.$route.query.specialChannel || '';

        window.location.href=`/yi23/Home${this.$route.path}?specialCode=${specialCode}&specialChannel=${specialChannel}`;
      },
      //数据接收
      getShareCardF(){

        let specialCode= this.$route.query.specialCode;
        let specialChannel= this.$route.query.specialChannel;

        shareCardFAddTime(specialCode,specialChannel).then((res)=>{

          //服务器时间
          let serverTime = new Date(res.headers.date).getTime();

          if(res.data.code == 200){
            //过期时间
            let finishTime = res.data.data.payData.finishTime;
            this.isfinish =  serverTime - finishTime >= 0 ? true : false
          }
          this.shareCardF = res.data.data;
        });
      },

      //payHuaBei
      payHuaBei:function () {
        let _t=this;
        if(!this.checkedNames){
          return false
        }

        let options = {
          'aliPointId':this.$route.query.specialCode,
          'aliUserId':this.aliUserId,
          'aliAuthToken': 'aliAuthToken'
        }

        aliPointPackageDeposit(options).then((data)=>{
          console.log(data)
          if (data.code==102){

            window.location.href=data.data

          }else if (data.code==103){
            AlipayJSBridge.call("tradePay",{orderStr: data.data}, function(result){
              _t.payMethod();
            });
          }else if (data.code==110){
            this.payMethod();
          }else{
            this.errorMsg=data.msg
          }
        })
      },
      //支付
      payMethod() {
        let payData = encodeURIComponent(JSON.stringify({
          'payType':'13',
          'payWay':'3',
          'couponId':0,
          'aliPointId':this.$route.query.specialCode,
          'aliUserId':this.aliUserId,
          'aliAuthToken': 'aliAuthToken',
          'isEvent':1
        }))
        let success = encodeURIComponent('/Promotion/share_card_f_r');
        let redirect = `${this.$route.path}?specialCode=${this.$route.query.specialCode || ''}&specialChannel=${this.$route.query.specialChannel || ''}`;
        redirect = encodeURIComponent(redirect);
        window.location.href = `/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
      },
      toastColse(){
        this.toastOpen=false
      },
      openBox:function () {
        this.open = true
      },
      validataFunc() {
        let validator = new Validator();
        //phone
        validator.add(this.userMobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },
      userSubmit: function () {

        //是否已经过期
        let isfinish = this.isfinish;
        if(isfinish){
          //this.openToast('来晚啦活动已结束。下个月早点来哦~');
          return
        }

        let errorMsg = this.validataFunc();
        if(errorMsg){
          this.openToast(errorMsg);
          return
        }

        let channel = this.$route.query.specialChannel;
        let code = this.$route.query.specialCode;

        exchangePointPayment(this.userMobile,channel,code).then((res)=>{
          if(res.code == 200){
            if(res.data.depositStatus == 0  && this.shareCardF.payData.depositWaived == 0 ){
                this.Pay = true;
            }
            else{
              this.Pay = false;
            }
            this.openBox()
          }
          else {
            this.openToast(res.msg);
          }
        })
      },
      openToast(msg){
        this.errorMsg = msg;
      },

    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

.gray{
  background: #ccc !important;
}
.leftabc{
  display: flex;
  align-items:center;
  width:100%;
  height:40px;
  background: red;
}
.rightabc{
  display: flex;
  align-items:center;
  width:100%;
  height:40px;
  background: red;
  }
.WaO{
    background: #FFF5F3;
  &Banner{
    padding-bottom:64%;
  }
  &Con{
    margin: 0 0.853333rem;
    position: relative;
    top: -1.6rem;
    left:0;
  }
}
  .cardType{
    display: flex;
    justify-content: space-between;
    height: auto;
    border-bottom: 1px #efefef solid;
    background: #fff;
    padding:0.853333rem 1.066667rem;

    h2{
      display: flex;
      align-items: flex-start;
      width: 100%;
      font-size: 0.96rem;
      line-height: 1.2;
      margin-top: 0.426667rem;
    }
    .cardLogo{
      border-radius: 50%;
      width: 2.986667rem;
      height: 2.986667rem;
      img{
        border-radius: 50%;
        width: 100%;
      }
    }
  }
  .cardPrice{
    height: 2.773333rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 1.066667rem;
    margin-bottom: 0.426667rem;
    background: #fff;
    span{
      font-size: 0.64rem;
    }
    span.left{
      color: #ff544b;
      font-size: 0.96rem;
      i{
        font-size: 0.64rem;
        font-style: normal;
        padding: 0 0.106667rem;
      }
    }
    span.right{
      color: #999;
      text-decoration: line-through;
    }
  }

  .userMb{
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
    height: auto;
    background: #fff;
    padding: 1.066667rem;
    margin-bottom: 0.426667rem;

    input.mobilePhone{
      width: 100%;
      background: #f4f4f4;
      font-size: 0.746667rem;
      padding: 0.853333rem 0 0.853333rem 0.64rem;
      letter-spacing: 0.2px;
    }
    button{
      border-radius: 0.106667rem;
    }
    button.btn{
      width: 100%;
      height: 2.666667rem;
      letter-spacing: 0.5px;
      margin-top: 0.96rem;
      font-size: 0.853333rem;
      background: #ccc;
    }
    button.btn.active{
      background: #111;
    }
  }
  .vipInfor{
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    justify-content: center;
    background: #fff;

    h2.Title {
      display: table;
      white-space: nowrap;
      width: 90%;
      display: flex;
      justify-content: center;
      line-height: 1.77;
      letter-spacing: 0.7px;
      text-align: center;
      color: #000000;
      padding-top:30px;
      padding-top: 1.6rem;
      i{
        padding: 0 0.533333rem;
        font-style: normal;
        font-size: 0.906667rem;
      }
    }

    h2.Title:before,
    h2.Title:after {
      border-top: solid 1px rgba(0, 0, 0, 0.04);
      content: '';
      display: table-cell;
      position: relative;
      top: 0.8rem;
      width: 45%;
      height: 1.066667rem;
    }
    h2.Title:before {
      right: 1%;
    }
    h2.Title:after {
      left: 1%;
    }
    p{
      width: 100%;
      text-align: center;
      font-size: 0.533333rem;
      color: #ccc;
    }
    .vipInforIMG{
      margin-top: 1.066667rem;
      padding-bottom:40.6976%;
    }

    span{
      margin: 1.066667rem;
      padding: 0.8rem;
      border-radius: 0.16rem;
      background: #f4f4f4;
      font-size: 0.746667rem;
      line-height: 1.64;
      letter-spacing: 0.2px;
      color: #999;
    }
  }

  .Rule{
    padding: 0 1.6rem 70px 1.6rem;
    background: #fff;
    h2{
      font-size: 0.853333rem;
      line-height: 4;
    }
    ol.rules-con{
      font-size: 0.64rem;
      padding-left: 0.533333rem;
      li{
        color: #666;
        list-style-type: decimal;
        text-align: left;
        font-size: 0.64rem;
        line-height:1.83;
        letter-spacing: 0.2px;
        text-align: left;
        margin-bottom: 0.8rem;
      }
      li:last-of-type{
        margin-bottom: 0;
      }
    }
    .RuleIMG{
      padding-bottom: 71.5408%;
    }
  }

  .Box_InnerTop{
    position: absolute;
    margin: 0px;
    top: 50%;
    width: 80%;
    height: 5.333333rem;
    left: 50%;
    display: block;
    transform: translate(-50%, -50%);
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    z-index:2;

    p{
    display: flex;
    width: 100%;
    justify-content: center;
    align-items: center;
    text-align: center;
    font-size: 0.853333rem;
    line-height: 1.4;
    letter-spacing: 0.085333rem
    }
  }



  .Box_Form p{
      font-size: 12px;
      display: flex;
      justify-content:center;
      align-items:center;
      text-align: center;
      min-height: 80px;
      padding:0 20px;
      font-size: 12px;
      line-height: 17px;
  }
  .Box_Form .FormCheckbox{
    display: flex;
    justify-content:center;
    align-items:center;
    min-height: 100px;
    padding:0 20px;
    font-size: 12px;

  }
  .Box_Form .FormCheckbox i{
    padding-left: 10px;
    line-height: 1.5;
  }
  .Box_Form .PayBtn_huabei{
    display: flex;
    width: 100%;
    justify-content: center;
    align-content: center;
    button{
      width: 8.106667rem;
      height: 2.346667rem;
      border-radius: 2.346667rem;
      background: #ccc;
      color: #fff;
      font-size: 0.746667rem;
    }
    button.active{
      background: #ff544b;
    }
  }

  .Box_Form .PayBtn{
    display: flex;
    width: 100%;
    justify-content: center;
    align-content: center;
    button{
      width: 8.106667rem;
      height: 2.346667rem;
      border-radius: 2.346667rem;
      background: #ccc;
      color: #fff;
      font-size: 0.746667rem;
      background: #ff544b;
    }

  }

  .Box_Form .FormCheckbox label{
    display: flex;
    i{
      display: flex;
      justify-content:center;
      align-items:center;
      padding-left: 8px;
    }
  }

  .Box_Form .FormCheckbox input[type=checkbox]{
    position: absolute;
    opacity: 0;
    width:100%;
    height:20px;
  }


  .Box_Form .FormCheckbox input[type=checkbox] + label:before{
    content: "";
    display: inline-block;
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #cccccc;
    -moz-border-radius: 50%;
    -webkit-border-radius: 50%;
    border-radius: 50%;
    background-color: #fff;
  }
  .Box_Form .FormCheckbox input[type=checkbox]:checked + label:before
  {
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #ff544b;
    background:#ff544b  url('https://yimg.yi23.net/webimg/web_source/Home/Common/images/20180312001/dist/images/iconDuihao.svg') 100% 0 no-repeat;
    background-size:100%;
  }

  ::-webkit-input-placeholder{color: rgba(0, 0, 0, .2); }
  ::-moz-placeholder{color: rgba(0, 0, 0, .2); }
  :-ms-input-placeholder{color: rgba(0, 0, 0, .2);}


  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .Rule{
      padding-bottom:100px;
    }
  }
</style>
