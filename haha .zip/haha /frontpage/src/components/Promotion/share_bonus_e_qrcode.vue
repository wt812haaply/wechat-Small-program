<template lang="html">
  <div class="ygirl">

      <div class="titleImg">
         <img src="https://yimg.yi23.net/webimg/web/images/2018/0421/CodeBanner.jpg">
      </div>

      <div class="CodeCon">
          <div class="qrcode image-ratio-new">
            <vue-qr :text="QRtext" :logoSrc="QRcode" :size="220" :margin="0"></vue-qr>
          </div>
          <button>长按保存二维码</button>
      </div>

      <div class="CodeMoney">
          <div class="left">
            <h2>已获红包</h2>
            <p>去衣二三APP资金帐户提现</p>
          </div>
          <div class="right">{{totalNum}}元</div>
      </div>

      <div class="EntranceConB">
          <div class="titleCD">活动规则</div>
          <ol class="rules-con">
            <li>每个手机号只能绑定一个唯一的二维码，邀请伙伴使用微信扫一扫二维码即可购买衣二三会员</li>
            <li>被推荐者成功开通衣二三会员后，推荐者即可获得返现，提取返现，需要下载衣二三app使用二维码绑定的手机号登录APP，从资金账户中提现</li>
            <li>被推荐者购买衣二三体验卡，购买成功后不可退款</li>
            <li>返现会在推荐成功24小时内到达衣二三资金账户，到达后即可申请提现</li>
          </ol>
      </div>

    </div>
</template>

<script>

import VueQr from 'vue-qr';
import { shareBonusE } from 'api/promotion';

export default {
  data(){
    return {
      totalNum:0,
      QRtext:'',
      QRcode:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAEGWlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VQNcC+8AAAFZaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CkzCJ1kAAAUJSURBVHgB7VpNSCRHFP56HN0oZom6syK6GlxzEBYnRNiNejFRF4IRMcJCCLoHLxoQb/6AIJpFFPw/SIxBUIi5xp+buMlFctCD1+yEXBYVRcEf0PizU6nnpKd3tLumnZmuGWbmwcxUv3r1fr5+r6q6axTGCTFMthiO/Tr0OADxDIhxBOIlEOMJgHgGxDMgxhGI+RKwB5oABwcHuLi48Blut9txdXXl5SUlJSEjI8N7HVTj+Ngz/P79oNTcHBwwAPPz8xgbG/Pqo8AJAJXoOjMzE9PT03A6nSr7br9nZ2B/rsH9+jXw9q1n7KNHsH1dA8X5KZCcrOkjgAIARwn0YWhnZwe1tbVYX1/XnNBpkczc3Bz37Y53jgfv/nkK7LdF4OxfX80fpgLPnkJ5+gxI5KC/+Qt44IDt2+985UxcBQwA6V5dXUVDQwMIDCNKSUnBwMAAWltbjUR0+e5ffwH78Sfg8hKw3Ziq3G7PmMRETz8HxNbbA+XzMl1dIuYNzSLR230VFRVoaWlBIjliQKenpxgcHMTGxoaBxG0229sDW1rSD57ECRAVlI9zoXBwFedntxWZ4AQFAOlva2tDVVWV0NTW1hZ6enpwrE5kQmne+Y8L2N3TgjSSVxQoL19ezwk+84GRvA4/aACotvv7+5Gfn6+jXmOtrKxgampKYwha7PgEuHoHqKluJEsrzqW26hiJifhBA0DKaZbv6upCaiqfnAzoktfy+Pg41tbWDCQ0tuJ4CNgTNIZei8C5lwTlQbper2leSAAga42NjaivrxcaplLo7u4G7SFEpDwuAB7zjPL3si4nG8j/RKTKb1/IAKBNT29vL4qKioRGKQOGhoaEMrSeKy9e8HWdZxTd6QSeDe+XA7WTP4DyTR2UhzxbgqCQAUA+5OXl4dUPr5CebpyWVAozMzPXS6jIb1vlcyjfNwOZPEBaCokocPqkfcQnvwbYnn/l4QfxHdQ+wMhuR0cHRkdHud//O64jWFJSgoWFBTgcDp1ejcVcb8D++B3sb74ycFJycqB88SWUJ+JM0zT4adFOMNS0v7/PysvLqYINP3zvwNrb20Nt+s76cOcRJgfwWmfZ2dmGABA4/EGJLS8vm9RojZhlAJC7IyMjjG+FhSAUFxez7e1ta6IzodVSAI6OjlhdXZ0QAMqE5uZmE65aI2IpAOTy5uYmy83NFYLAVw22uLBoTYR+tFoOANnv6+sTAkBZwJ8n2Pn5uR93Q98tBQCq8cLCQiEIWVlZzOVyhT5CPxpDuhHid1KXeHCoqanR7VOZJycn2N3dVS+l/UoBgKKprKwUPiy5+Q7v8PBQWuCqIWkA5PAdHL0dijSSBgAFn0APNQJyv+P7fMkkDQDRc4HkmH3MSQNA9N5Q9ciWIM0d1aS8w1EzGRDVJeCFXNCI6gwwUwJRnQFmSkCQHJZ1yZ91BKFEdQkI4vZ2RXUJeKOMsIa0EjAzCUZ1CZiZBKO6BGI+AyKs9L3uSJsD/JUAHaympaV5HZPVkAaAKCB+foDh4WGUlpaKxCzp0/7VZIl6TanRHECHqZOTkygrK9OEJbakAXCzBAgQek02MTGBggJ+HB4mklYC72cA1XtTUxNmZ2fDGjxhLi0D6P8DFDgdnXd2dl7/t4h44SZLjseNglpaXALt9qqrq41EpPOlAiA9OhMGpc0BJnwJi0gcgLDAHkFG4xkQQTcjLK7EMyAssEeQ0XgGRNDNCIsr/wFBGFge27/ymwAAAABJRU5ErkJggg=="
    }
  },
  created(){
    this.createdQRcode();
  },
  methods:{
    createdQRcode(){
      let specialChannel = this.$route.query.specialChannel;
      let _t = this;
      shareBonusE().then((res)=>{
        if(res.code == 200){
          _t.QRtext = res.data.qrCodeUrl;
          _t.totalNum = res.data.totalSum;
        }else{
          _t.QRtext = res.data.url
        }
      })
    }
  },
  components:{
    VueQr
  }
}
</script>

<style  scoped lang="less">
@import "~common/less/variable";

.image-ratio-new{
  background-color: transparent;
  position: relative;
  overflow: hidden;
  background: #fafafa url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAAC/CAYAAACBryyUAAAACXBIWXMAAAsSAAALEgHS3X78AAAHWklEQVR42u2d23IaOxBFNxhw7MQnsb4rr/lKXvmt9DkJmDtMHkac2DDG3KelWauKl6RcBcOiZ6ulkVrPz88dSS35ZW1mK8H1+PG9K+lOUrvq+ktaqT9Y1P02W8/Pzw+SPnuWVdK/ZlZg1cXk7Ei6l9SV1DniL5eSFpLmdcjbKopCIYSv8Y17ZWJmL1h2lqCtKOjjOxX0WApJU0lT9QerW8rakhScx4FfZrbAupNE/RTvntf6fheSXtQfLK/4Q7trFUV5dw0h9CT9QxzI7nb/5chb/TmMJU3UHxRX+Ayj/2WNwn6W9EAcyELUusYihaSJpNlZ8eDH97sYWe4lFeoPfm7L2pL09Ya/xFP4bWZzbNz7RT/FL7lu5vE1O6jaloJ2JfXia8NM/cHwjaxR2I6kb46/ikKSEQfci1qVa5cxzm2y7aZt2omv9wZ+v9QfLHZkjcJ6b2fNzew3ZiYj6nljlf7A9J7JZjaJvwSv9OKAEPIWdTNok7S/3/Y73nK98hQzNpStqRxFLSTNPpQ1ZsKh4w/SkvSEqN/vnEe2c3jTBts7kxFH3RPigGu+yPdkzulZdcu9Q6bdxvEPiQP+qmpXvqfJz2G03e76UNYYBzyPvJscBx4z/Vwz9Qc7vfSDFjSY2fL1qIw4QFW9IktJo6r/OHj1jZmN5bud1bQ48ClTUX+9N9t17FKxkfy2s5oTB/4u98uJ+T5RpSPXAJjZKoQwlN/VWb0QQq8Bawdyuf2v4916eshi7qMXrJjZPIQwc/zLfgoh5L52IAdZfx67lPDUFeMj+W1nteR7Xe4l6DTxM5wkawLtrG5cjENlbbqsUVjv7azHEMJdpoOrHGjdTNYo7Fh/1yZ6vBhfiABU1tcM5bedlXscoLIeWV1Xkjw/F5VnHGggl6isMrOpyqYucQB8y/oqDnhtZxEH/LGuTdYEFmvnEgeWmci6qk3WKOxCfhdr5xEHLrmBRFMr6ythXxz/+nOJAzlso7SsXdaI59VZOcSB9KPACftiXUVW57NbOcSB1CvrSZ2ja1XWzd4DXttZ3RBCuo+ElI98FMh6WTzPbj3GrZIa9YU7YeZO1gTaWSnHgUmyop7Y0bh2ZfW+90An2ThQDlBSzK4nj2XaN3yDXkewKceBcWLv96w9W28ia4wDI+LAxavr4tT8VwPFuT+uW1VW7+2sTsLdAc897bd3gTMPymjf8t0633sgzThQDla871U7V39w9rilTSXIJg54XVO81IU6QjeXNS7W9trOSrk7MHGYX8vW5YUW39RRWTftLK9N7XS7A/3B0JGwhcodVi52oFu7xg/jebF2upMFpbB1D2SXkuzSh7jVJqvz2a1O4msHxqpvm/2ZPtiz6lQqT2u5Jc4PivsvttzSpNxj4Elvz5S6FmuVGwBfLd7VLmsU9pt8Pg+fxxGc5V6uj7rOTi6bEwUn136KwYusHZUnG3rcbSSfIzhLaR8uVGk3e/5Pb/WojQtZo7CeD4rL60Tuv/u79rT/ZL9tFvE1v9oJ2CnIGoX9Kp+bjuV9Incp7yaGdV7d4ZbxNr++ZAsqF1lbkgJxAKpoe3ozzttZDyGELsog62thyyO/fcIRnMi6g9edtdvK9+wpZCUOQO6VdbMVkdfF2sQBZN0R1uuzW8QBZH03v3rsbxIHkHWnunp+dos4gKw7wk7k89mttthVG1kTigP3jTuRG1k/rK6en90iDiDrjrBen91qzoncyHoUXncm7BEHkHW7unre1IE4gKw7wno9aIM4gKyVjOVzsQtxAFmJA8iaMI5nt4gDyFoprNfFLsQBZK3E60bFxAFkJQ4gK3HgWnHgE6oha1Uc8Di79TmTE7mRtSFxgKWEyLoj7MRpHMjlRG5kbUh34JE4gKwpxQEeNETWZLoD91RXZK3C60ZqVFdk3amum/1EvdFjZgtZq/C67vUe/ZB1u7rO5XOigA0ykLUSjw8ZMshC1ko87vfaQT9krcLl4RXslYWsVbm1kM+eKyBrJSuH74nKiqzJyArImkxupSOArJUUXH9kTWWQxQALWQGQtSm5FZAVkBUAWQGQFZAVAFkBkBWQFQBZAZAVkBUAWQGQFZAVAFkBWQGQFQBZAVkBkBUAWQFZAZAVAFkBWQGQFQBZAVkBkBUAWQFZAZAVAFkBWQGQFQBZAVkBkBUAWQFZAZAVAFkBWQGQFZAVAFkBkBWQFQBZAZAVkBUAWQGQFZAVAFkBkBWQFQBZAZAVkBUAWQGQFZAVAFkBkBWQFQBZAZAVkBUAWQGQFZAVAFkBWQGQFfYy5xIcTodLUAsLSS9mtuRSIKtXCkljM5twKZDVezUdmdmKS4Gsnqvpi5lNuRTI6n0ANTSzgkuBrJ6r6dDMGO0jq2smcRBFNUVWt6xjNV1wKZCVaoqscAbLONKnmiKra8ZmNuYyIKv3ajpiqhRZPcNUKbImAVOlyEo1BWS9BEyVImsS1ZSpUmSlmgKyHsp6z78zVYqsrphKut/6N6ZKE6FVFM36jkIIXUndmE3ntKPS4Q/qR/xL8eoIFgAAAABJRU5ErkJggg==') no-repeat center;
  background-size: 20.5%;
}

.ygirl{
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  width: 100%;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  z-index: 10;
  position:relative;
  .titleImg{
    width: 100%;
    img{
      display: block;
      width: 100%;
    }
  }
  .CodeCon{
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    .qrcode{
      width: 220px;
      height: 220px;
      .margin(30,0,30,0);
      position: relative;
    }
    button{
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      .width(220);
      .height(42);
      margin-top: 0;
      color: #999;
      .font-size(14);
      background: 0 0;
    }
  }
  .CodeMoney{
    border-top: 1px #efefef solid;
    border-bottom: 1px #efefef solid;
    width: 100%;
    .margin(30,30,0,30);
    .padding(18,0,18,0);
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    .left{
      line-height: 2;
      p{
        .font-size(12);
      }
      h2{
        .font-size(16);
      }
    }
  }
  .EntranceConB{
     .padding(0,30,30,30);
     background: #fff;
    .titleCD{
      .padding(25,0,25,0);
      .font-size(16);
    }
    .rules-con{
      .font-size(12);
      .padding(0,0,0,10);
      li{
        color: #666;
        list-style-type: decimal;
        text-align: left;
        .font-size(12);
        .line-height(22);
        letter-spacing: .2px;
        text-align: left;
        .margin(0,0,15,0)
      }
    }
  }
}
</style>
