<template>
  <div class="box" v-if="shareCardC">
    <div class="shareForCard">
      <!-- top -->
      <div class="PlIMG">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0409/topIMG.jpg" alt="">
        <div class="input-box">
          <div class="userMb">
            <input type="tel" v-model="userMobile" class="mobilePhone font-r" placeholder="请输入衣二三账号（手机号）" >
            <button class="btn btn-defult btn-black font-m active" @click="userSubmit">{{shareCardC.payInfo.payCost}}元限时体验</button>
          </div>
        </div>
      </div>
      <!-- content -->
      <div class="centerCon">
        <div class="title">
          <p>▾▾▾</p>
          <h2><i class="font-m">衣二三为你推荐以下单品</i></h2>
        </div>
        <ul class="friendRecommend">
          <li  v-for="item in shareCardC.products" >
            <div class="liIMG PlIMG image-ratio" @click="imgUrl(item.product_id)">
                <img :src="item.thumb_pic">
            </div>
          </li>

        </ul>
        <div class="title">
          <h2><i class="font-m">新用户专享限时体验机会</i></h2>
        </div>
        <ul class="blockOne font-r">
          <li>
            <div class="liLeft">{{shareCardC.payInfo.payName}}</div>
            <div class="liRight">¥{{shareCardC.payInfo.originalCost}}</div>
          </li>
          <li>
            <div class="liLeft">限时特惠</div>
            <div class="liRight red">-¥{{shareCardC.payInfo.originalCost - shareCardC.payInfo.payCost}}</div>
          </li>
          <li>
            <div class="liLeft">押金<i class="mianya">验证芝麻分可免押</i></div>
            <div class="liRight"><i class="del">￥{{shareCardC.payInfo.depositAmount}}</i></div>
          </li>
          <li class="font-m">
            <div class="liLeft">实际支付</div>
            <div class="liRight">￥{{shareCardC.payInfo.payCost}}</div>
          </li>
        </ul>
        <div class="vipInfor">
          <h2 class="title"><i class="font-m">什么是衣二三会员</i></h2>
          <p class="font-l">MEMBERSHIP PLAN</p>
          <div class="PlIMG vipInforIMG">
            <img src="https://yimg.yi23.net/webimg/web/images/2018/0326/indexVip03.jpg" alt="">
          </div>
          <span class="font-r">
          成为衣二三会员后，您将享受全球精选的时装包月租赁服务，百万件时装及配饰随心换穿。
每次下单可选三件，隔48小时即可再下一单，随心下单，想穿多久穿多久。喜欢的可以买下自留，其余的预约寄回，衣二三负责为您清洗，全程免邮。
        </span>
        </div>
      </div>
    </div>

    <down-app :show="downApp.show"></down-app>

    <yi23Toast v-model="errorMsg"></yi23Toast>
    <zhima-verify v-model="zhimaVerify" :showPayBtn="true" @submitPay="payMethod"></zhima-verify>
  </div>
</template>
<script>
  import Validator from 'common/js/class/validator'
  import { exchangePointPayment } from 'api/event'
  import { shareCardC } from 'api/promotion'
  import yi23Toast from '../lib/Toast.vue'
  import DownApp from 'base/DownApp'
  import zhimaVerify from '@/components/Promotion/zhimaVerify'

  export default {
    data () {
      return {
        shareCardC:null,
        toastOpen:false,
        errorMsg:null,
        userMobile:'',
        zhimaVerify:false,
        downApp:{
          show: false
        },
      }
    },
    components:{
      DownApp,
      zhimaVerify
    },

    computed:{
    },
    mounted(){
      //down-app下拉
      window.addEventListener('scroll', () => {
        var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        if(scrollTop >= 100){
          this.downApp.show = true;
        }else{
          this.downApp.show = false;
        }
      });
    },

    methods:{
      //数据接收
      getShareCardC(){
        let packageCode= this.$route.query.packageCode;
        let specialChannel= this.$route.query.specialChannel;
        shareCardC(packageCode,specialChannel).then((res)=>{
          console.log(res);
          this.shareCardC = res.data;
        });
      },
      //imgUrl
      imgUrl:function (pid) {
        this.$router.push({
          path:'/Subscribe/pdtDetailPage',
          query:{pid:pid}
        })
      },
      //oldUser
      oldUser:function () {
        let packageCode= this.$route.query.packageCode;
        let specialChannel= this.$route.query.specialChannel;
        window.location.href='/yi23/Home/Promotion/share_card_c_o?packageCode='+packageCode+"&specialChannel="+specialChannel+"&is_success=T";
      },
      validataFunc() {
        let validator = new Validator();
        //phone
        validator.add(this.userMobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },

      userSubmit: function () {
        let errorMsg = this.validataFunc();
        if(errorMsg){
          this.openToast(errorMsg);
          return
        }
        exchangePointPayment(this.userMobile).then((res)=>{

          if(res.code == 200){
            let isMember =this.shareCardC.payInfo.isToAllMemberType;
            let allowMember = this.shareCardC.payInfo.memberType;
            let memberStatus = res.data.memberType;
            if( isMember== 0){
               let memberArr =allowMember.split(',');
              if(memberArr.indexOf(memberStatus.toString())){
                this.oldUser()
                return false;
              }
            }
            if(res.data.depositStatus== 0 && this.shareCardC.payInfo.depositWaived == 0 ){
               this.zhimaVerify=true;
             }
             else {
               this.payMethod()
             }
          }
          else {
            this.openToast(res.msg);
          }
        })
      },
      payMethod() {
        let payData = encodeURIComponent(JSON.stringify({
          'payType':'13',
          'payWay':'2',
          'couponId':0,
          'aliAuthToken':'aliAuthToken',
          'aliUserId':'aliUserId',
          'isEvent':1,

        }))
        let success = encodeURIComponent('/Promotion/share_card_c_r');
        let redirect = this.$route.fullPath;
        redirect = encodeURIComponent(redirect);
        window.location.href = `/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
      },
      openToast(msg){
        this.errorMsg = msg;
      },
  },
    created(){
      this.getShareCardC();
    },
  }
</script>

<style scoped lang="less">
  .del{
    text-decoration: line-through;
    -webkit-text-decoration-color: #000;
    text-decoration-color: #000;
  }
  @import "~common/less/share_card_b";
  ::-webkit-input-placeholder{color: rgba(0, 0, 0, .2); }
  ::-moz-placeholder{color: rgba(0, 0, 0, .2); }
  :-ms-input-placeholder{color: rgba(0, 0, 0, .2);}


  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .Rule{
      padding-bottom:100px;
    }
  }

</style>
