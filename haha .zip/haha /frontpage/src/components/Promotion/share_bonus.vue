<template>
  <div class="ygirl">

    <div class="iete">
      <img src="https://tu.95vintage.com/web/images/2018/0403/EntranceBanner.jpg">
    </div>

    <div class="EntranceCon">
        <div class="title">奖励规则</div>
        <ol class="rules-con">
          <li>
            下单后分享10天体验卡活动页面给好友，好友通过链接支付成功后，可得到一张加衣券；加衣券可在【优惠券】中进行查看；
          </li>
          <li>
            此链接支持分享给多个好友，若N个好友通过链接支付成功购买10天体验卡，即可得的N张加衣券；
          </li>
          <li>10天体验卡只限新用户进行购买；</li>
          <li>
            如对活动奖励的发放有任何疑问，请致电客服进行咨询。
          </li>
        </ol>
    </div>
    <div class="footerBtn">
      <button @click="shareFor">邀请好友来体验</button>
    </div>

    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script type="text/ecmascript-6">
  import { getShareForNewUserImage ,shareBonus} from 'api/share';
  import  shareMixin  from '@/mixins/share';
  import yi23Toast from '../lib/Toast.vue'
  export default {
    mixins:[ shareMixin ],
    data(){
      return{
        toastMsg:null
      }
    },
    created(){
      let shareid = this.$route.query.shareId;
      let location = this.$route.query.location;
      let yCode  = this.$route.query.yCode;
      let reqParam = {
        shareId:shareid,
        location:location,
        yCode:yCode
      }

      var urlData = `?shareId=${reqParam.shareId}&location=${reqParam.location}&yCode=${reqParam.yCode}`;
      shareBonus(urlData).then((res)=>{
        if(res && res.code == 200){
          let senData=JSON.parse(res.data.sendData)
          let params = {
            title: senData.title,
            url: senData.url,
            shareType: senData.shareType,
            message: senData.message,
            image: senData.image,
            thumb_pic:senData.thumb_pic
          }
            this.setShareMessage(params);
          }else{
            this.toastMsg=res.msg
          }
      })
    },
    computed:{

    },
    watch:{

    },
    methods:{
      shareFor(){

        if(this.$clientType == 1 || this.$clientType == 2){
           this.doShare()
        }else{
          this.toastMsg="请在APP中打开"
        }
      }
    },
    components:{
      yi23Toast
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .ygirl{
    -webkit-font-smoothing: antialiased;
    width: 100%;
    z-index:10;
    position:relative;
    .iete{
      width: 100%;
      img{
        display: block;
        width: 100%;
      }
    }
    .EntranceCon{
      padding-right:20px;
      padding-left:20px;
      .title{
        display: table;
        white-space: nowrap;
        width: 100%;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        line-height: 1.77;
        letter-spacing: .7px;
        text-align: center;
        color: #111;
        padding-top: 20px;
        padding-bottom: 10px;

        font-size:16px;
        &:before,&:after{
          border-top:solid 1px rgba(0,0,0,.04);
          content: '';
          display: table-cell;
          position: relative;
          top: 14px;
          top: .746667rem;
          width: 45%;
          height: 1.066667rem;
        }
      }
      ol{

        .padding(0,0,0,10);
        li{
          color: #666;
          list-style-type: decimal;
          text-align: left;
          font-size: 10px;
          line-height: 1.83;
          letter-spacing: .2px;
          text-align: left;
          margin-bottom: 10px;
        }
      }
    }
    .footerBtn{
      position: fixed;
      bottom: 0;
      width: 100%;
      z-index: 1;
      button{
        width: 100%;
        .height(48);
        .font-size(14);
        color: #fff;
        background: #ff544b;
      }
    }
  }
</style>
