<template>
  <section v-if="currentStatus">
    <div class="tipsCon">

      <div class="tipsItem">
        <div class="tipsWrap">
            <div class="overstriking">还差一步就领取成功啦！</div>
            <div class="exempt">芝麻分超过650可享免押权益</div>
        </div>
        <i class="close icon yi23iconfont icon-close" @click="closeDiv" v-if="showClose"></i>
        <div class="tipsForm">
          <div class="poet">
            <input  placeholder="输入姓名" v-model="realName">
            <input  placeholder="输入身份证号" v-model="idCard">
          </div>
        </div>
        <div class="tipsBtn">
          <button class="btn font-r" @click="submitPay" v-if="showPayBtn">支付¥300押金</button>
          <button class="btn font-r" @click="confirmZhima">验分免押金</button>
        </div>
      </div>
    </div>
    <div class="ECardShade" @click="closeDiv"></div>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </section>
</template>

<script>
    import zhima from '@/api/zhima';
    import Validator from 'common/js/class/validator';
    import { toastMixin } from 'common/js/mixin';
    export default {
      mixins: [toastMixin],
        name: "zhimy-verify",
        data(){
          return {
            currentStatus:this.value,
            realName:'',
            idCard:'',
            toastMsg: ''
          }
        },
        props:['value','showPayBtn','showClose'],
        watch:{
          value(val){
            this.currentStatus=val
          },
          currentStatus (val){
            this.$emit('input',val)
          }
        },
        methods:{
          closeDiv() {
            this.currentStatus=false
          },
          submitPay() {
            this.$emit('submitPay')
          },
          confirmZhima() {
            let errmsg = this.validataFunc();
             if(errmsg){
               this.setToastMsg(errmsg);
               return false
             }
            zhima.confirmZhima({realName:this.realName,idCard:this.idCard}).then((res)=>{
              if(res.data.code==100 || res.data.code==200){
                //验证成功后执行
                this.$emit('submitPay')
              }else{
                this.toastMsg=res.data.msg;
                //2018年5月20日 simon 修改,验证不通过,提示错误
                // if(this.showPayBtn){
                //   this.toastMsg=res.data.msg;
                // }else{
                //   this.$emit('submitPay')
                // }
              }
            })

          },
          // 2018 5/21 by zcy  add
          validataFunc(){
            let validator = new Validator();

            validator.add(this.realName,[{
              strategy:'isNoEmpty',
              errorMsg:'姓名不能为空'
            },{
              strategy:'isChinese',
              errorMsg:'请正确输入姓名'
            }]);

            validator.add(this.idCard,[{
              strategy:'isNoEmpty',
              errorMsg:'身份证号号不能为空'
            },{
              strategy:'isIdentity',
              errorMsg:'请正确输入身份证号'
            }]);

            return validator.start();

          },
        },
        created(){

        }
    }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  .tipsCon {
    position: fixed;
    position: absolute;
    top: 40%;
    left: 50%;
    background: transparent;
    width: 82%;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    z-index: 9999;
  }

  .tipsCon .tipsItem {
    background: #fff;
    width: 100%;
    border-radius: 0.16rem;
    padding-top: 1.6rem;
    position: relative;
    top: 0;
    left: 0;
  }
  .overstriking{
    .font-size(16);
    font-weight:800;
    color:#111111;
    margin:0 auto;
    text-align: center;
  }
  .tipsWrap{
    margin:0 auto;
    width:80%;
  }
  .exempt{
    font-size: 0.6rem;
    text-align: center;
    .width(182);
   .height(20);
    text-align: left;
    .padding(0,0,0,20);
    .line-height(20);
    background:url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/debris_redPacket/credit.png") no-repeat 1px 2px;
    background-size:0.8rem 0.8rem;
    color:#666;
    margin:0 auto;
    margin-top: 0.576rem;
  }
  .tipsCon .tipsItem .close {
    position: absolute;
    right: 1.066667rem;
    top: 1.066667rem;
    width: 0.746667rem;
    height: 0.746667rem;
    font-size: 0.746667rem;
  }

  .tipsCon .tipsItem .tipsForm {
    width: 100%;
  }

  .tipsCon .tipsItem .tipsForm .poet {
    width: 80%;
    margin: 0 auto;
  }

  .tipsCon .tipsItem .tipsForm .poet input {
    border-bottom: 1px #ccc solid;
    height: 0.96rem;
    width: 100%;
     padding: 1.4rem 0 .413333rem 0;
    font-size: 0.746667rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    color:#666;
  }

  .tipsCon .tipsItem .tipsForm p {
    font-size: 0.746667rem;
    color: #000;
    line-height: 1.28rem;
    text-align: center;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    width: 100%;
    padding: 0.64rem 0;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    justify-content: center;
  }

  .tipsCon .tipsItem .tipsBtn {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -ms-flex-line-pack: center;
    align-content: center;
    width: 100%;
    margin: 0 auto;
    padding: 1.7rem 0 1.493333rem 0;
  }

  .tipsCon .tipsItem .tipsBtn button {
    width: 50%;
    height: auto;
    color: #999;
    font-size: 0.746667rem;
    background: none;
    padding: 0;
    font-size: 0.746667rem;
  }

  .tipsCon .tipsItem .tipsBtn button.btn.active {
    /* background: #ff544b; */
  }

  .tipsCon .tipsItem .tipsBtn button:last-of-type {
    border-left: 1px #F1F1F1 solid;
    color: #ff544b;
  }

  .ECardShade {
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    filter: alpha(opacity=0);
    opacity: 0.8;
    z-index: 10;
    position: fixed!important;
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
  }
  ::-webkit-input-placeholder{/*Webkit browsers*/
    color:#999;
  }
  :-moz-placeholder{/*Mozilla Firefox 4 to 8*/
    color:#999;
  }
  ::moz-placeholder{/*Mozilla Firefox 19+*/
    color:#999;
  }
  :-ms-input-placeholder{/*Internet Explorer 10+*/
    color:#999;
  }
</style>
