<template>
<div>
  <div class="CPSCard">
    <!-- top -->
    <div class="topIMG PlIMG image-ratio">
      <div class="ee">
        <div class="reCon">
          <div class="conList">
            <div class="listLeft">
              <input type="" name="" v-model="mobile" placeholder="请输入手机号">
            </div>
            <div class="listRight">
            </div>
          </div>
          <div class="conList">
            <div class="listLeft">
              <input type="" name="" v-model="imgCode" placeholder="请输入验证码">
            </div>
            <div class="listRight">
              <img :src="codeImgUrl" alt="" @click="checkImg">
            </div>
          </div>
          <div class="conList">
            <div class="listLeft">
              <input type="" name="" v-model='code' placeholder="请输入手机验证码">
            </div>
            <div class="listRight">
              <button class="btn active" @click="getCode">{{btnMsg}}</button>
            </div>
          </div>
          <div class="FooterBtn">
            <button class="btn" @click="doLogin">成为衣二三会员</button>
          </div>
        </div>
      </div>
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0427/topIMG.jpg?!" alt="">
    </div>
    <!-- content -->
    <div class="centerCon">
      <div class="vipInfor">
        <div class="PlIMG image-ratio vipInforIMG">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0421/vipInforIMG.jpg" alt="">
        </div>
      </div>
    </div>
  </div>
  <yi23-toast v-model="msg"> </yi23-toast>
</div>
</template>

<script>
  import login from '@/api/login'
  import { mapGetters } from 'vuex'
    export default {
        name: "shareCardGLogin",
        data() {
          return {
            mobile: '',
            imgCode: '',
            showStatus:false,
            codeImgUrl:'',
            btnMsg: '发送验证码',
            sendingCode:false,
            timerNumber:60,
            msg: '',
            code: ''
          }
        },
      watch:{
        loginRes (newStatus,oldStatus){
          this.msg=newStatus.msg
          if(newStatus.status){
            this.$router.push({
              name: 'shareCardGBuy'
            })
          }
        }
      },
      created() {
        this.codeImgUrl=login.codeImgUrl()
      },
      computed: {
        ...mapGetters({
          loginRes: 'loginRes'
        })
      },
        methods:{
          checkImg(){
            this.codeImgUrl=this.codeImgUrl+1
          },
          dataRequired (options) {
            for (var k in options){
              if(this[options[k].name] == ''){
                this.msg= options[k].msg
                this.toastOpen = true;
                return false;
                break;
              }
            }
            return true
          },
          doLogin () {
            if(this.dataRequired([{name:'mobile',msg:'手机号不能为空'},{name:'imgCode',msg:'图形验证码不能为空'},{name:'code',msg:'短信验证码不能为空'}])){
              this.$store.dispatch('getUserInfo',{mobile:this.mobile,code:this.code})
            }
          },
          timerAction(){
            let timers=setInterval( () =>{
              if(this.timerNumber>0){
                this.timerNumber= this.timerNumber-1
                this.btnMsg=this.timerNumber+'s后获取！'
                // console.log(this.btnMsg)
              }else{
                clearInterval(timers)
                this.sendingCode=false
                this.btnMsg='发送验证码'
              }
            },1000)
          },
          getCode () {
            if(!this.sendingCode && this.dataRequired([{name:'mobile',msg:'手机号不能为空'},{name:'imgCode',msg:'图形验证码不能为空'}])){
              this.timerAction();
              this.sendingCode=true
              login.getVerifyCode({mobile:this.mobile,code:this.imgCode}).then((res)=>{
                if(res.data.code == 200){

                }else {
                  this.msg= res.data.msg
                }
              }).catch((error)=>{
                console.log('error'+ error)
              })
            }
          },
        }

    }
</script>

<style scoped lang="less">
  .none {
    display: none;
  }


  .image-ratio {
    background-color: #fff;
  }

  * {
    outline: none;
  }

  body {
    background: #F8F8F2;
  }

  input {
    border-radius: 0;
  }

  img {
    width: 100%;
    display: block;
  }

  i {
    font-style: normal;
  }

  .PlIMG {
    width: 100%;
    height: 0;
    overflow: hidden;
    padding-bottom: 100%;
    position: relative;
  }

  .PlIMG img {
    width: 100%;
    position: absolute;
  }




  /* ----------------cps index----------------*/

  .CPSCard .topIMG {
    padding-bottom: 157.3333%
  }

  .ee {
    position: absolute;
    margin: 0px;
    top: 69%;
    /* top: 359px; */
    width: 344px;
    width: 18.346667rem;
    height: auto;
    left: 50%;
    display: block;
    z-index: 2;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    background-color: #fff;
    border-radius: 0.16rem;
  }

  .ee .reCon {
    padding: 0 1.6rem 1.6rem 1.6rem;
  }

  .ee .reCon .conList {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    padding: 1.386667rem 0 0.533333rem 0;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    border-bottom: .026667rem #ccc solid;
  }

  .ee .reCon .conList .listLeft, .ee .reCon .conList .listRight {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
  }

  .ee .reCon .conList .listLeft input {
    width: 9.6rem;
    height: 1.173333rem;
    font-size: 0.746667rem;
  }

  .ee .reCon .conList .listRight {
    height: 1.6rem;
    position: relative;
  }

  .ee .reCon .conList .listRight img {
    width: 5.333333rem;
    height: 1.6rem;
    position: relative;
    right: 0;
    top: -0.266667rem;
  }

  .ee .reCon .conList .listRight button {
    background: none;
    height: 1.6rem;
    font-size: 0.586667rem;
  }

  .ee .reCon .conList .listRight button.btn {
    border: 1px #666 solid;
    color: #666;
    width: 5.333333rem;
    padding: 0 0.266667rem;
  }

  .ee .reCon .conList .listRight button.active {
    border: 1px #ccc solid;
    color: #ccc;
  }

  .ee .reCon .FooterBtn {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    height: 2.56rem;
    margin-top: 1.493333rem;
  }

  .ee .reCon .FooterBtn button {
    width: 100%;
    background: #ff544b;
    color: #fff;
    font-size: 0.853333rem;
    border-radius: 3px;
    letter-spacing: 1px;
  }

  .centerCon {
    padding-bottom: 2.666667rem;
  }

  .centerCon .vipInfor {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    background: #fff;
    margin: 1.066667rem 0.8rem 30px 0.8rem;
    -webkit-box-shadow: 0 0 3.2rem rgba(0, 0, 0, .05);
    box-shadow: 0 0 3.2rem rgba(0, 0, 0, .05);
    border-radius: 0.106667rem;
  }

  .centerCon .vipInforIMG {
    padding-bottom: 132.8488%;
    border-radius: 0.106667rem;
  }





</style>
