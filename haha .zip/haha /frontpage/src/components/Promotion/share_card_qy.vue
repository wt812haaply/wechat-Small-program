<template>
  <div class="WaO" v-if="shareCardF">
  <!-- <div class="WaO"> -->
    <div class="imgP image-ratio WaOBanner">
      <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/headerbanner.jpg" alt="">
    </div>

    <div class="WaOCon">
      <!-- <div class="cardType">
        <h2 class="font-m">{{shareCardF.payData.payName}}</h2>
        <div class="cardLogo">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexLogo02.jpg" alt="">
        </div>
      </div>
      <div class="cardPrice">
        <span class="left">{{shareCardF.payData.payCost}}<i>元</i></span>
        <span class="right">市场参考价¥{{shareCardF.payData.originalCost}}</span>
      </div> -->
      <div class="userMb radius5">
        <div class="title">
          <h2 class="font-m">免费7天随心换</h2>
        </div>
        <input v-model="userMobile " class="mobilePhone font-r radius2" placeholder="请输入衣二三账号（手机号）" >
        <button class="btn btn-defult btn-black font-m radius2"  v-if="shareCardF.payData.cardStock <=0 ">库存不足</button>
        <button class="btn btn-defult btn-black font-m active" @click="userSubmit"  v-else>0元领取</button>
      </div>
      <div class="vipInfor"></div>
    </div>
    <div class="Rule">
      <div class="imgP image-ratio pt2">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/2@2x.jpg">
        </div>
        <div class="imgP image-ratio pt3">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/3@2x.jpg">
        </div>
        <div class="imgP image-ratio pt4">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/4@2x.jpg">
        </div>
        <div class="imgP image-ratio pt5">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/5@2x.jpg">
        </div>
        <div class="imgP image-ratio pt6">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/6@2x.jpg">
        </div>
        <div class="imgP image-ratio pt7">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/7@2x.jpg">
        </div>
         <div class="imgP image-ratio pt8">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/8@2x.jpg">
        </div>
    </div>
    <BoxPopup :open="open" >
      <div slot="Box_InnerTop">
        <div class="Box_InnerTop" style="height: 40px">
          <p>为您绑定到衣二三账户：</p>
          <p>{{ userMobile }}</p>
        </div>
      </div>

      <div slot="Box_InneBtm">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexTip05.jpg" alt="">
      </div>

      <div slot="Box_checkbox" v-if="Pay">
        <div class="FormCheckbox" >
          <input type="checkbox" id="sextype" v-model="checkedNames" >
          <label for="sextype"></label>
          <i class="font-m">¥300押金预授权(仅冻结花呗额度，无须支付)</i>
        </div>
        <div class="PayBtn_huabei">
          <button :class="[{'active':checkedNames},'btn','font-r']" @click="payHuaBei()">确认授权</button>
        </div>
      </div>

      <div slot="Box_p" v-else>
        <p>支付成为会员，包月租衣随心换穿</p>
        <div class="PayBtn">
          <button class="font-r btn active" @click="payMethod()">确认支付</button>
        </div>
      </div>
    </BoxPopup>
    <yi23Toast v-model="errorMsg"></yi23Toast>
  </div>
</template>

<script>
  import BoxPopup from '../lib/BoxPopup.vue'
  import yi23Toast from '../lib/Toast.vue'
  import { shareCardF,exchangePointPayment } from 'api/event'
  import Validator from 'common/js/class/validator'
  import { aliPointPackageDeposit } from 'api/member'

  export default {
    data () {
      return {
        shareCardF:null,
        open:false,
        userMobile:'',
        toastOpen:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
        depositStatus:null,
        Pay:false,
      }
    },

    components:{
      BoxPopup,
      yi23Toast
    },
    computed:{
    },
    created () {
      this.getShareCardF();
    },
    mounted(){
      //down-app下拉
//      window.addEventListener('scroll', () => {
//        var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
//        if(scrollTop >= 100){
//          this.downApp.show = true;
//        }else{
//          this.downApp.show = false;
//        }
//      });

    },
    methods:{
      //数据接收
      getShareCardF(){
        let specialCode= this.$route.query.specialCode;
        let specialChannel= this.$route.query.specialChannel;

        shareCardF(specialCode,specialChannel).then((res)=>{
          console.log(res);
          this.shareCardF = res.data;
        });
      },

      //payHuaBei
      payHuaBei:function () {
        let _t=this;
        if(!this.checkedNames){
          return false
        }
        aliPointPackageDeposit({}).then((data)=>{
          console.log(data)
          if (data.code==102){

            window.location.href=data.data

          }else if (data.code==103){
            AlipayJSBridge.call("tradePay",{orderStr: data.data}, function(result){
              _t.payMethod();
            });
          }else if (data.code==110){
            this.payMethod();
          }else{
            this.errorMsg=data.msg
          }
        })
      },
      //支付
      payMethod() {
        let payData = encodeURIComponent(JSON.stringify({
          'payType':'13',
          'payWay':'3',
          'couponId':0,
          'aliPointId':this.$route.query.specialCode,
          'aliAuthToken':'aliAuthToken',
          'aliUserId':'aliUserId',
          'isEvent':1,
        }))
        let success = encodeURIComponent('/Promotion/share_card_qy_r');
        let redirect = this.$route.fullPath;
        redirect = encodeURIComponent(redirect);
        window.location.href = `/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
      },
      toastColse(){
        this.toastOpen=false
      },
      openBox:function () {
        this.open = true
      },
      validataFunc() {
        let validator = new Validator();
        //phone
        validator.add(this.userMobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },
      userSubmit: function () {
        let errorMsg = this.validataFunc();
        if(errorMsg){
          this.openToast(errorMsg);
          return
        }

        let channel = this.$route.query.specialChannel;
        let code = this.$route.query.specialCode;

        exchangePointPayment(this.userMobile,channel,code).then((res)=>{
          if(res.code == 200){
            if(res.data.depositStatus == 0  && this.shareCardF.payData.depositWaived == 0 ){
                this.Pay = true;
            }
            else{
              this.Pay = false;
            }
            this.openBox()
          }
          else {
            this.openToast(res.msg);
          }
        })
      },
      openToast(msg){
        this.errorMsg = msg;
      },

    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
.radius5{
  border-radius: .266667rem /* 5/18.75 */;
}
.radius2{
  border-radius: .106667rem /* 2/18.75 */;
}
.leftabc{
  display: flex;
  align-items:center;
  width:100%;
  height:40px;
  background: red;
}
.rightabc{
  display: flex;
  align-items:center;
  width:100%;
  height:40px;
  background: red;
  }
.WaO{
    background: #fff;
  &Banner{
    padding-bottom: 25.706667rem /* 482/18.75 */;
    img{
      z-index: 1;
    }
  }
  &Con{
    position: relative;
    margin: -14.773333rem /* 277/18.75 */ .533333rem /* 10/18.75 */ 0 ;
    z-index:5;
    // position: relative;
    // top: -14.773333rem /* 277/18.75 */;
    // left:0;
  }
}
  .cardType{
    display: flex;
    justify-content: space-between;
    height: auto;
    border-bottom: 1px #efefef solid;
    background: #fff;
    padding:0.853333rem 1.066667rem;

    h2{
      display: flex;
      align-items: flex-start;
      width: 100%;
      font-size: 0.96rem;
      line-height: 1.2;
      margin-top: 0.426667rem;
    }
    .cardLogo{
      border-radius: 50%;
      width: 2.986667rem;
      height: 2.986667rem;
      img{
        border-radius: 50%;
        width: 100%;
      }
    }
  }
  .cardPrice{
    height: 2.773333rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 1.066667rem;
    margin-bottom: 0.426667rem;
    background: #fff;
    span{
      font-size: 0.64rem;
    }
    span.left{
      color: #ff544b;
      font-size: 0.96rem;
      i{
        font-size: 0.64rem;
        font-style: normal;
        padding: 0 0.106667rem;
      }
    }
    span.right{
      color: #999;
      text-decoration: line-through;
    }
  }

  .userMb{
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
    height: auto;
    background: #fff;
    padding: 1.333333rem /* 25/18.75 */ 1.6rem /* 30/18.75 */ 1.866667rem /* 35/18.75 */ 1.6rem /* 30/18.75 */;
    margin-bottom: 0.426667rem;
    z-index: 10;
    background:url('http://ycloset.oss-cn-beijing.aliyuncs.com/webimg/web_source/Home/Common/images/201806130930/mobilebg.jpg') no-repeat 0 0;
    background-size: 100% 100%;
    .title{
      //padding-top: 1.333333rem /* 25/18.75 */;
      padding-bottom: 1.066667rem /* 20/18.75 */;
      width: 100%;
      h2{
        font-size: .96rem /* 18/18.75 */;
        text-align: center;
      }
    }
    input.mobilePhone{
      width: 100%;
      background: #f4f4f4;
      height: 2.346667rem /* 44/18.75 */;
      box-sizing: border-box;
      font-size: .746667rem /* 14/18.75 */;
      padding: 0.813333rem 0 0.813333rem 0.64rem;
      letter-spacing: 0.2px;
      text-align: center;
    }
    button{
      border-radius: 0.106667rem;
    }
    button.btn{
      width: 100%;
      height: 2.346667rem /* 44/18.75 */;
      letter-spacing: 0.5px;
      margin-top: .533333rem /* 10/18.75 */;
      font-size: .746667rem /* 14/18.75 */;
      background: #ccc;
    }
    button.btn.active{
      background: #FF544B;
    }
  }
  .vipInfor{
    width: 100%;
    height: 3.36rem /* 63/18.75 */;
    background: url('https://yimg.yi23.net/webimg/web_source/Home/Common/images/201806130930/1_1@2x.jpg') no-repeat;
    background-size: 100% 100%;
    border-radius: 5px 5px 0 0 ;
    h2.Title {
      display: table;
      white-space: nowrap;
      width: 90%;
      display: flex;
      justify-content: center;
      line-height: 1.77;
      letter-spacing: 0.7px;
      text-align: center;
      color: #000000;
      padding-top:30px;
      padding-top: 1.6rem;
      i{
        padding: 0 0.533333rem;
        font-style: normal;
        font-size: 0.906667rem;
      }
    }

    h2.Title:before,
    h2.Title:after {
      border-top: solid 1px rgba(0, 0, 0, 0.04);
      content: '';
      display: table-cell;
      position: relative;
      top: 0.8rem;
      width: 45%;
      height: 1.066667rem;
    }
    h2.Title:before {
      right: 1%;
    }
    h2.Title:after {
      left: 1%;
    }
    p{
      width: 100%;
      text-align: center;
      font-size: 0.533333rem;
      color: #ccc;
    }
    .vipInforIMG{
      margin-top: 1.066667rem;
      padding-bottom:40.6976%;
    }

    span{
      margin: 1.066667rem;
      padding: 0.8rem;
      border-radius: 0.16rem;
      background: #f4f4f4;
      font-size: 0.746667rem;
      line-height: 1.64;
      letter-spacing: 0.2px;
      color: #999;
    }
  }

  .Rule{
    position: relative;
    z-index: 5;
    .pt{
      &2{
        padding-bottom: 8.96rem /* 168/18.75 */;
      }
      &3{
        padding-bottom: 11.893333rem /* 223/18.75 */;
      }
      &4{
        padding-bottom: 19.626667rem /* 368/18.75 */;
      }
      &5{
        padding-bottom: 24.426667rem /* 458/18.75 */;
      }
      &6{
        padding-bottom: 14.453333rem /* 271/18.75 */;
      }
      &7{
        padding-bottom: 12.64rem /* 237/18.75 */;
      }
      &8{
        padding-bottom: 5.226667rem /* 98/18.75 */;
      }
    }
    h2{
      font-size: 0.853333rem;
      line-height: 4;
    }
    ol.rules-con{
      font-size: 0.64rem;
      padding-left: 0.533333rem;
      li{
        color: #666;
        list-style-type: decimal;
        text-align: left;
        font-size: 0.64rem;
        line-height:1.83;
        letter-spacing: 0.2px;
        text-align: left;
        margin-bottom: 0.8rem;
      }
      li:last-of-type{
        margin-bottom: 0;
      }
    }
    .RuleIMG{
      padding-bottom: 71.5408%;
    }
  }

  .Box_InnerTop{
    position: absolute;
    margin: 0px;
    top: 50%;
    width: 80%;
    height: 5.333333rem;
    left: 50%;
    display: block;
    transform: translate(-50%, -50%);
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    z-index:2;

    p{
    display: flex;
    width: 100%;
    justify-content: center;
    align-items: center;
    text-align: center;
    font-size: 0.853333rem;
    line-height: 1.4;
    letter-spacing: 0.085333rem
    }
  }



  .Box_Form p{
      font-size: 12px;
      display: flex;
      justify-content:center;
      align-items:center;
      text-align: center;
      min-height: 80px;
      padding:0 20px;
      font-size: 12px;
      line-height: 17px;
  }
  .Box_Form .FormCheckbox{
    display: flex;
    justify-content:center;
    align-items:center;
    min-height: 100px;
    padding:0 20px;
    font-size: 12px;

  }
  .Box_Form .FormCheckbox i{
    padding-left: 10px;
    line-height: 1.5;
  }
  .Box_Form .PayBtn_huabei{
    display: flex;
    width: 100%;
    justify-content: center;
    align-content: center;
    button{
      width: 8.106667rem;
      height: 2.346667rem;
      border-radius: 2.346667rem;
      background: #ccc;
      color: #fff;
      font-size: 0.746667rem;
    }
    button.active{
      background: #ff544b;
    }
  }

  .Box_Form .PayBtn{
    display: flex;
    width: 100%;
    justify-content: center;
    align-content: center;
    button{
      width: 8.106667rem;
      height: 2.346667rem;
      border-radius: 2.346667rem;
      background: #ccc;
      color: #fff;
      font-size: 0.746667rem;
      background: #ff544b;
    }

  }

  .Box_Form .FormCheckbox label{
    display: flex;
    i{
      display: flex;
      justify-content:center;
      align-items:center;
      padding-left: 8px;
    }
  }

  .Box_Form .FormCheckbox input[type=checkbox]{
    position: absolute;
    opacity: 0;
    width:100%;
    height:20px;
  }


  .Box_Form .FormCheckbox input[type=checkbox] + label:before{
    content: "";
    display: inline-block;
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #cccccc;
    -moz-border-radius: 50%;
    -webkit-border-radius: 50%;
    border-radius: 50%;
    background-color: #fff;
  }
  .Box_Form .FormCheckbox input[type=checkbox]:checked + label:before
  {
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #ff544b;
    background:#ff544b  url('https://yimg.yi23.net/webimg/web_source/Home/Common/images/20180312001/dist/images/iconDuihao.svg') 100% 0 no-repeat;
    background-size:100%;
  }

  ::-webkit-input-placeholder{color: rgba(0, 0, 0, .2); }
  ::-moz-placeholder{color: rgba(0, 0, 0, .2); }
  :-ms-input-placeholder{color: rgba(0, 0, 0, .2);}


  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .Rule{
      padding-bottom:100px;
    }
  }
</style>
