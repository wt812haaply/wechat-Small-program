<template>
  <div v-if="userInfo">
    <div class="newuser">
      <div class="newuserTop">
        <div class="TopRight">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/antmember/dist/images/topicon.png" alt="">
        </div>
        <div class="TopLeft" v-if="userInfo.grade==3">
          <h2  class="font-m">199元大牌时装体验券</h2>
          <p class="font-r">包月会员使用，自领取30天有效</p>
        </div>
        <div class="TopLeft" v-else-if="userInfo.grade==2">
          <h2  class="font-m">100元大牌时装体验券</h2>
          <p class="font-r">包月会员使用，自领取30天有效</p>
        </div>
        <div class="TopLeft" v-else-if="userInfo.grade==1">
          <h2  class="font-m">50元大牌时装体验券</h2>
          <p class="font-r">包月会员使用，自领取30天有效</p>
        </div>
        <div class="TopLeft" v-else>
          <h2  class="font-m">衣二三体验优惠券</h2>
          <p class="font-r">仅限黄金及以上会员领取</p>
        </div>
      </div>

      <div class="TopButton" v-if="userInfo.grade==0">
        <button class="font-r" style="background-color: #CCC"><i><img src="https://tu.95vintage.com/web_source/Home/Common/images/antmember/dist/images/icon1.png"></i>当前等级无法兑换</button>
      </div>
      <div class="TopButton" v-else @click="antCoupon">
        <button class="font-r confirm_sub" ><i><img src="https://tu.95vintage.com/web_source/Home/Common/images/antmember/dist/images/icon1.png"></i>288积分兑换</button>
      </div>
    </div>


    <section  id="log_panel" v-if="showBox" >
      <div class="yi23-mask"></div>
      <div class="yi23-dialog">
        <div class="yi23-dialog__hd">
          <h4 class="font-m">填写衣二三注册手机号</h4>
        </div>
        <div class="yi23-dialog__bd">
          <input type="tel" placeholder="输入手机号" v-model="mobile" style="width: 100%; color: #111; border-bottom: 1px solid #111;">
        </div>
        <div class="yi23-dialog__ft flex">
          <div class="flex-item yi23-dialog__btn" @click="()=>{this.showBox=false;this.mobile=''}">取消</div>
          <div class="flex-item yi23-dialog__btn_primary confirm_sub" @click="antCoupon">确认兑换</div>
        </div>
      </div>
    </section>


    <div class="newuser">
      <div class="newuserCon">
        <div class="ConTitleA font-m"><i><img src="https://tu.95vintage.com/web_source/Home/Common/images/antmember/dist/images/icon2.png" alt=""></i>权益等级差异</div>
        <div class="ConList">



          <div class="border"></div>
          <p>钻石会员<i class="a1" :class="{'a2':userInfo.grade==3}"></i>288积分兑换衣二三199元体验券</p>
          <p class="font-m">铂金会员<i class="b1" :class="{'b2':userInfo.grade==2}"></i>288积分兑换衣二三100元体验券</p>
          <p>黄金会员<i class="c1" :class="{'c2':userInfo.grade==1}"></i>288积分兑换衣二三50元体验券</p>
          <p>大众会员<i class="d1" :class="{'d2':userInfo.grade==0}"></i>不符合该权益兑换条件</p>



        </div>
      </div>


      <div class="newuserCon">
        <div class="ConTitleA font-m"><i><img src="https://tu.95vintage.com/web_source/Home/Common/images/antmember/dist/images/icon3.png" alt=""></i>活动时间</div>
        <div class="ConList">
          <p>2018-04-16至2018-06-30</p>
        </div>
      </div>


      <div class="newuserCon">
        <div class="ConTitleA font-m"><i><img src="https://tu.95vintage.com/web_source/Home/Common/images/antmember/dist/images/icon4.png" alt=""></i>权益介绍</div>
        <div class="ConList jieshao">
          <p>1.本权益仅限蚂蚁钻石、铂金、黄金会员兑换，每个用户每自然月仅限兑换一次；兑换成功后，积分无法退回；</p>
          <p>2.权益自领取之日起30天内有效，过期作废；</p>
          <p>3.权益兑换成功后，关注并<a href="alipays://platformapi/startapp?appId=20000047&amp;publicId=2016021601145758" style="color:#108ee9;text-decoration:underline;">进入“衣二三生活号”</a>，在“超值福利-我的-优惠券”中查看。</p>
          <p>4.开通会员服务需要缴纳300元押金，花呗用户可以通过冻结花呗额度作为押金，花呗预授权服务不会产生任何费用；</p>
          <p>5.连续包月是衣二三为用户提供的优惠服务，相比普通会员卡每月价格更优惠，到期自动续费，续费一次后即可免费取消（首月取消连续包月服务，需补交100元差价）；</p>
          <p>6.本权益由衣二三提供，如有疑问，请联系衣二三客服热线4006504580。</p>
        </div>
      </div>


    </div>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>

</template>

<script>
    import myMembershipLife from '@/api/myMembershipLife'
    export default {
        name: "my_membership_life",
        data() {
          return {
            showBox:false,
            mobile:'',
            toastMsg:'',
            userInfo:null
          }
        },
        methods:{
          antCoupon (){
            if(!this.mobile){
              this.showBox=true
              return false;
            }
            myMembershipLife.antCoupon({mobile:this.mobile,eventId:this.userInfo.proeventid}).then((res)=>{
              if(res.data.code==200){
                let urls=''
                switch (this.userInfo.grade){
                  case 3:
                    urls='https://www.95vintage.com/yi23/Home/Index/postingPage?id=6867'
                    break;
                  case 2:
                    urls='https://www.95vintage.com/yi23/Home/Index/postingPage?id=6866'
                    break;
                  case 1:
                    urls='https://www.95vintage.com/yi23/Home/Index/postingPage?id=6865'
                    break;
                }
                window.location.href=urls;
              }else{
                this.toastMsg=res.data.msg
              }
            })
          }
        },
        created() {
          let code=this.$route.query.auth_code
          if(!code){
            let urls='/yi23/Home'+this.$route.fullPath ;
            myMembershipLife.getMembershipAuthLink(encodeURIComponent(urls)).then((res)=>{
                if(res.data.code==200){
                  window.location.href=res.data.data;
                }else{
                  this.toastMsg=res.data.msg
                }
            });
          }else{
            myMembershipLife.myMembershipLife({code:code}).then((res)=>{
                if(res.data.code==200){
                  this.userInfo=res.data.data
                }else{
                  this.toastMsg=res.data.msg
                }
            })
          }
        }
    }
</script>

<style scoped lang="less">
  body{
    background: #fff;
  }
  i{display: inline-block}
  img{width: 100%}
  .newuser{
    padding: 0 10px;
    margin-top: 15px;
    border-bottom: 14px #F5F5F7 solid;

    &Top{
      padding:10px 15px;
      border-radius: 6px;
      background: #EEE;
      display: block;

      & .TopLeft{
        margin-right: 95px;
        height: 90px;
        padding: 22px 0 0 0;

        h2{
          font-size: 20px;
          height: 30px;
          line-height: 1;
        }
        p{
          font-size: 12px;
        }
      }

      & .TopRight{
        float: right;
        width: 90px;
        height: 90px;
      }
    }

    & .TopButton{
      display: block;
      margin-top: 25px;
      padding-bottom:15px;

      button{
        width: 100%;
        height: 42px;
        background: #148DE9;
        border-radius: 6px;
        font-size: 16px;
        color: #fff;
        box-sizing: border-box;

        i{
          position: relative;
          top:2px;
          margin-right: 10px;

          img{
            width: 18px;
          }
        }
      }
    }

    &Con{
      & .ConTitleA{
        font-size: 14px;
        color: #111;
        margin-bottom: 10px;
        margin-top: 15px;

        i{
          position: relative;
          top: 1px;
          margin-right: 8px;

          img{
            width: 13px;
          }
        }
      }
      & .ConList, .jieshao{
        border-bottom: 1px #F2F2F2 solid;
        padding-bottom: 10px;
        margin-bottom: 15px;
        position: relative;
        top: 0px;
        & .border{
          position: absolute;
          left: 86px;
          top: 20px;
          border-right: 1px #B3B3B3 solid;
          height: 100px;
        }

        & p{
          display: block;
          font-size: 14px;
          color: #666;
          padding-left: 20px;
          line-height: 34px;
          .a1{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2a1.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }
          .a2{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2a2.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }

          .b1{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2b1.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }
          .b2{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2b2.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }

          .c1{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2c1.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }
          .c2{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2c2.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }

          .d1{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2d1.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }
          .d2{
            background: url('//yimg.yi23.net/webimg/web_source/Home/Common/images/antmember/dist/images/icon2d2.png') 0 100% no-repeat;
            background-size: 16px;
            width: 16px;
            height: 16px;
            position: relative;
            top:0px;
            left: 2px;
            padding: 0 10px;
          }
        }



      }

      & .jieshao{
        border: 0px;
        padding-bottom: 40px;
        p{
          line-height: 22px;
          font-size: 12px;
        }
      }
    }
  }

  .newuser:last-of-type{
    border: 0px;
  }
</style>
