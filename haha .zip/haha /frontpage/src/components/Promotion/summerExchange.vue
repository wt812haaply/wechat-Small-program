<template>
  <div class="maYi" style="padding-bottom: 1rem">
    <div class="bootPage">
      <div class="PlIMG topBanner01 image-ratio">
        <img src="http://yimg.yi23.net/webimg/web/images/2018/0605/bootTopBanner01.png" alt="">
      </div>
      <div class="PlIMG topBanner02 image-ratio">
        <img src="http://yimg.yi23.net/webimg/web/images/2018/0605/bootTopBanner02.png" alt="">
        <div class="topBannerButt" @click="openRule"><span>活动规则</span></div>
      </div>
      <div class="Con">
        <ul v-if="sumList && sumList.length > 0">

          <li @click="summerExchangeBuy(item.templateId)" v-for="(item,index) in sumList" :key="index">
            <div class="left">
              <div class="leftIMG image-ratio">
                <!--<img src="http://yimg.yi23.net/webimg/web/images/2018/0605/bootTopCard04.jpg" alt="">-->
                <img :src="item.cardImage" alt="">
              </div>
              <div class="leftCon">
                <p class="font-m">{{item.payName}}</p>
                <p class="Price font-r">
                  <!--<template v-if = "item.templateId != 33 && item.templateId != 36">衣二三新人价 :<br></template>-->
                  <template v-if = "item.payCost">衣二三新人价 :<br></template>
                  <template v-else>现价 :</template>

                  <template v-if="item.payCost">{{item.payCost-200}}元</template>
                  <!--<template v-if="item.payCost">{{item.payCost-payOriginal()}}元</template>-->
                  <template v-if="item.payCost && item.aliPoint"> + </template>
                  <template v-if="item.aliPoint">{{item.aliPoint}}积分</template>
                </p>
              </div>
            </div>
            <div class="right">
              <button class="btn">兑换</button>
            </div>
          </li>

        </ul>
      </div>

      <div class="inMenu">

        <div class="menuL" @click="callCenter()">
          <span class="iconMeun"><img src="https://yimg.yi23.net/webimg/web/images/2018/0602/20180602Icon01.png" alt=""></span>
          <span>售后服务</span>
          <span><i class="icon yi23iconfont icon-right"></i></span>
        </div>

        <div class="menuR" @click="myOrder()">
          <span class="iconMeun"><img src="https://yimg.yi23.net/webimg/web/images/2018/0602/20180602Icon02.png" alt=""></span>
          <span>我的订单</span>
          <span><i class="icon yi23iconfont icon-right"></i></span>
        </div>
      </div>

    </div>

    <div class="bottomBanner" style="margin-top:0;">
      <div class="PlIMG bottomBannerIMG1 image-ratio">
        <img src="http://yimg.yi23.net/webimg/web/images/2018/0605/bootTopBanner07.jpg" alt="">
      </div>
      <div class="PlIMG bottomBannerIMG2 image-ratio">
        <img src="http://yimg.yi23.net/webimg/web/images/2018/0605/bootTopBanner09.jpg" alt="">
      </div>
    </div>

    <div class="popTop" v-show = 'ruleOpen'>
      <div class="Rule">
        <p><i class="icon yi23iconfont icon-close" @click="closeRule"></i></p>
        <h2 class="font-m">活动细则</h2>
        <ol class="rules-con font-r">
          <li>活动期间7天体验卡每个用户仅限兑换一次，积分兑换年卡限量30个且每人仅限兑换一次，其他卡种不限购买次数</li>
          <li>退换规则：兑换成功7天内可根据下单情况进行部分或全部的退款退积分，退还积分48小时内到账，具体退款请拨打衣二三客服电话。</li>
          <li>客服电话：4006504580</li>
          <li>更多衣二三服务，可在支付宝搜索“衣二三”小程序或生活号，或下载app进入选衣页查看更多可租时装配饰。</li>
          <li>会员期计算规则：首次下单前，我们最长可以为您冻结15天，超过15天系统将开始为您计算会员期，请及时选衣下单哦。下单期间如需冻结，只需把所有衣箱归还即可，冻结期最长同样也是15天。</li>
        </ol>
      </div>
      <div class="popBg"></div>
    </div>
    <yi23Toast v-model="errorMsg"></yi23Toast>
  </div>

</template>

<script>
  import BoxPopup from '../lib/BoxPopup.vue'
  import { exchangePointPayment } from 'api/event'
  import Validator from 'common/js/class/validator'
  import { getMembershipAuthLink, aliPointPackageDeposit } from 'api/member'
  import { cardExchange, cardList } from 'api/event'

  export default {
    data () {
      return {
        open:false,
        otherPay:false,
        userMobile:'',
        toastOpen:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
//        depositStatus:null,
        Pay:false,

        ruleOpen:false,
        depositStatus:0,
        sumList:{},
        auth_code:'',
//        cardExchange:null,
      }
    },

    components:{
      BoxPopup
    },
    computed:{
    },
    created () {
      let query =  this.$route.query;
      if(query.auth_code){
        this.auth_code = query.auth_code
        this.getCardExchange()
      } else {
        this._getMembershipAuthLink()
      }
      this.getsumList()
    },
    mounted(){
    },
    methods:{
      openRule: function () {
        this.ruleOpen = true
      },
      closeRule: function () {
        this.ruleOpen = false
      },
      summerExchangeBuy: function (type) {
//        store.commit('sumList', this.sumList);
        this.$router.push({
          name:'summerExchangeBuy',
          query:{tid:type}
        })
      },
      getsumList: function () {
        let params = {origin:'summer_campaign'}
        cardList(params).then((res)=>{
          console.log(res);
          if(res.code == 200) {
            this.sumList = res.data.showInfo;
            console.log(this.sumList);
          }else {
            this.errorMsg = res.msg
          }
        });
      },
      // auth_code 链接
      _getMembershipAuthLink:function () {
        let url = encodeURIComponent(`/yi23/Home${this.$route.fullPath}`)
        getMembershipAuthLink(url).then((res)=>{
          window.location.href=res.data;
        });
      },
      //卡兑换
      getCardExchange:function () {
        cardExchange(this.auth_code).then((res)=>{
          console.log(res);
//          console.log(res.data)
          if(!res.code == 200){
            this.errorMsg = res.msg
          }
        });
      },
      //我的订单
      myOrder:function (isName) {
        this.$router.push({
          path:'/Promotion/orderExchange',
//          query:{ name:encodeURIComponent(isName)}
        })
      },
      //
      callCenter:function () {
        window.location.href='tel://4006504580'
      },
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  @import "./20180602/mayiExchange";
  @import "./20180602/summerExchange";
</style>
