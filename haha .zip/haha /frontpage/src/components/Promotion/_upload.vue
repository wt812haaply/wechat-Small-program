<template>
  <div class="upload-content">
    <div class="upload-btn" :class="{'upload-btn-hidden': uploadImgUrl != ''}">
      <input ref="file" type="file" name="file" @change="previewFile" accept="image/jpg,image/jpeg,image/png" required="">
    </div>
    <img ref="uploadImgBox" v-if="uploadImgUrl" :src="uploadImgUrl" alt="upload-img-box">
  </div>
</template>

<script>

const UPLOAD_END = 'uploadend';
const UPLOAD_MAX = 'uploadmax';

export default {
  data(){
    return{
      uploadImgUrl:'',
    }
  },
  methods:{
    previewFile(){
      let _this = this;
      let imgbox = this.$refs.uploadImgBox;
      let file = this.$refs.file.files[0];
      let max = 1024 * 2;
      let reader = new FileReader();

      reader.addEventListener('load',() => {

        _this.uploadImgUrl = reader.result;

        this.$emit(UPLOAD_END, _this.uploadImgUrl,file);

      }, false)

      if (file) {
        if(parseInt(file.size/1000) > max){
          this.$emit(UPLOAD_MAX);
          return;
        }
        reader.readAsDataURL(file);
      }

    }
  }

}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  .upload-content{
    width: 4.266667rem /* 80/18.75 */;
    height: 4.266667rem /* 80/18.75 */;
    border: 1px rgba(0,0,0,.2) dashed;
    box-sizing: border-box;
    border-radius: 50%;
    background: url(https://tu.95vintage.com/web_source/Home/Common/images/20170422001/jia.svg) 50% 50% no-repeat;
    position: relative;
    overflow: hidden;
  }
  .upload-btn{
    width: 4.266667rem /* 80/18.75 */;
    height: 4.266667rem /* 80/18.75 */;
    &.upload-btn-hidden{
      display: hidden;
    }
  }
  input{
    position: absolute;
    z-index: 1;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
  }
  img{
    width: 100%;
    height: 100%;
    display: block;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 2;
    border-radius: 50%;
  }

</style>
