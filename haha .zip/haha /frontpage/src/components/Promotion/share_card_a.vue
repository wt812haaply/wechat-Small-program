<template>
  <div class="box">

    <div class="shareForCard">
      <!-- top -->
      <div class="PlIMG">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0403/topIMG_v1.jpg" alt="">
        <div class="input-box">
          <div class="userMb">
            <input type="tel" id="just-mobile" class="mobilePhone font-r" v-model="mobilePhone" :disabled="disabled" placeholder="请输入衣二三账号（手机号）" name="">
            <button class="btn btn-defult btn-black font-m active" id="exchange_member" v-if="payInfo" @click="exchange" :disabled="disabled">{{payInfo.payCost}}元限时体验</button>
          </div>
        </div>
      </div>
      <!-- content -->
      <div class="centerCon" v-if="products && products.length>=3">
        <div class="title">
          <p>▾▾▾</p>
          <h2><i class="font-m">衣二三为你推荐以下单品</i></h2>
        </div>
        <ul class="friendRecommend">
          <!--<%products.forEach(function (item) {%>-->
          <li v-for="item in products" :key="item.id">
            <div class="liIMG PlIMG image-ratio">
              <a :href="`/yi23/Home/Subscribe/pdtDetailPage?pid=${item.product_id}&path=${encodeURIComponent(item.path)}`">
                <img :src="item.thumb_pic">
              </a>
            </div>
          </li>
        </ul>
        <div class="title">
          <h2><i class="font-m">新用户专享限时体验机会</i></h2>
        </div>
        <ul class="blockOne font-r">
          <li>
            <div class="liLeft">{{payInfo.payName}}</div>
            <div class="liRight">¥{{payInfo.originalCost}}</div>
          </li>
          <li>
            <div class="liLeft">限时特惠</div>
            <div class="liRight red">-¥{{payInfo.originalCost-payInfo.payCost}}</div>
          </li>
          <li>
            <div class="liLeft">押金<i class="mianya">验证芝麻分可免押</i></div>
            <div class="liRight"><i class="del">￥{{payInfo.depositAmount}}</i></div>
          </li>
          <li class="font-m">
            <div class="liLeft">实际支付</div>
            <div class="liRight">￥{{payInfo.payCost}}</div>
          </li>
        </ul>
        <div class="vipInfor" v-pre>
          <h2 class="title"><i class="font-m">什么是衣二三会员</i></h2>
          <p class="font-l">MEMBERSHIP PLAN</p>
          <div class="PlIMG vipInforIMG">
            <img src="https://yimg.yi23.net/webimg/web/images/2018/0326/indexVip03.jpg" alt="">
          </div>
          <span class="font-l">
          成为衣二三会员后，您将享受全球精选的时装包月租赁服务，百万件时装及配饰随心换穿。
每次下单可选三件，隔48小时即可再下一单，随心下单，想穿多久穿多久。喜欢的可以买下自留，其余的预约寄回，衣二三负责为您清洗，全程免邮。
          </span>
        </div>
      </div>
    </div>

    <down-app
      :show="downApp.show"
    ></down-app>
    <yi23Toast v-model="toastMsg"></yi23Toast>
    <yi23Dialog @dialogOk="buyOk" @dialogClose="close" :open="buyOpen" :dialogSm='dialogSm' :hasCannel="false">
      <div slot="body">
        <div class="yi23-dialog__bd" v-text="subMsg"></div>
      </div>
      <div slot="btnOk">现在去选衣</div>
    </yi23Dialog>
    <zhima-verify v-model="zhimaVerify" :showPayBtn="false" @submitPay="submitPay()"></zhima-verify>

  </div>
</template>

<script type="text/ecmascript-6">
  import DownApp from 'base/DownApp';
  import { toastMixin } from 'common/js/mixin';
  import Validator from 'common/js/class/validator';
  import zhimaVerify from '@/components/Promotion/zhimaVerify';
  import {
    PAY_WAY_WX,
    PAY_WAY_ALI
  } from 'api/const';
  import { share_card_a, exchange_point_payment, confirm_zhima } from 'api/promotion';
  import { ERR_OK }from 'api/const';

  export default {
    mixins:[ toastMixin ],
    data(){
      return{
        downApp:{
          show: false
        },
        zhimaVerify: false,
        subMsg   :'您已经是衣二三会员，现在去选衣吧。此卡只限新用户购买哦',
        mobilePhone   :'',
        payInfo:[],
        products:[],
        buyOpen: false,
        mayiOpen:false,
        dialogSm: true,
        hasCannel: true,
        toastOpen: false,
        specialCode: '',
        specialChannel: '',
        disabled: false,
        buyStatus : '',
        isPass : '',
        packageCode : '',
        isMember : '',
        allowMember : '',
        payWay:'',
        step: 10000,
        test:{a:1}
      }
    },
    created(){
      this.getArealist();
    },
    computed:{

    },
    watch:{
      buyStatus(val){
        if(val=="error"){
          this.disabled = true;
        }
      }
    },
    mounted(){
      //down-app下拉
      window.addEventListener('scroll', () => {
        var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        if(scrollTop >= 100){
          this.downApp.show = true;
        }else{
          this.downApp.show = false;
        }
      });
    },
    methods:{
      getArealist(){
        this.packageCode = this.$route.query.packageCode;
        // this.packageCode = "5afc452a36a0acfdfb25bb9d514444"
        share_card_a(this.packageCode).then((res)=>{
            if(res.code == ERR_OK){
              this.payInfo = res.data.payInfo;
              this.isPass = res.data.payInfo.depositWaived;
              this.products = res.data.products;
              this.packageCode = res.data.packageCode;
              this.isMember = res.data.payInfo.isToAllMemberType;
              this.allowMember = res.data.payInfo.memberType;
              this.buyStatus = res.data.status;
            }else{
              this.setToastMsg(res.msg);
            }
        })
      },
      showDialog () {
        this.buyOpen = true
      },
      close () {
        this.buyOpen = false
      },
      buyOk () {
        window.location.href = '/yi23/Home/Subscribe/pdtListPage'
      },
      client(){
        let clientType = this.$clientType
        const clientMap = {
          '3': PAY_WAY_WX,
          '4': PAY_WAY_ALI
        }
        if (clientMap[clientType]) {
          return clientMap[clientType]
        }
        return clientMap[4]
      },
      submitPay () {
        let payData = encodeURIComponent(JSON.stringify({
          'payType':13,
          'couponId':0,
          'packageCode':this.packageCode,
          'aliAuthToken':'aliAuthToken',
          'payWay':this.payWay,
          'aliUserId':'aliUserId',
          'isEvent':1,
        }))
        let host = `${window.location.origin}`;
        let success  = encodeURIComponent(`/Promotion/share_card_a_r`);
        let redirect = encodeURIComponent(`${this.$route.fullPath}`);

        window.location.href = `${host}/yi23/Home/Pay/payment?params=${payData}&success=${success}&redirect=${redirect}`;
      },
      exchange () {
        var inputData = `?mobile=${this.mobilePhone}&source=shareCard`;
        exchange_point_payment(inputData).then((res)=>{
          if(res.code == ERR_OK) {
            console.log(res);
            var depositStatus = res.data.depositStatus;
            var memberStatus = res.data.memberType;
            if (this.isMember == 0) {
              var memberArr = this.allowMember.split(',');
              if (memberArr.indexOf(memberStatus.toString())) {
                this.buyStatus = 'error';
                this.buyOpen = true;
                return false;
              }
            }
            if (depositStatus == 0 && this.isPass == 0) {
              //需要支付押金
              this.zhimaVerify = true;
              this.buyOpen = false;
            } else {
              //无需支付押金
              this.zhimaVerify = false;
              this.buyOpen = true;
              this.submitPay();
            }

          } else {
            this.setToastMsg(res.msg);
          }

        })

      },
    },
    components:{
      DownApp,
      zhimaVerify,
    }
  }
</script>
<style lang="less" rel="stylesheet/less">
  @import "~common/less/share_card_b";
</style>
