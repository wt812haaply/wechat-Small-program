<template>
  <div class="mayiExchange" id="mayiTop">
    <div class="imgP image-ratio mayiExchangeBanner">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/header.jpg" alt="">
    </div>

    <div class="mayiExchangeCon" >
      <div class="mayi__header" v-if="cardExchange">
        <div class="cardType" v-if="cardSearch">
          <div class="typeTitle">
            <h2 class="font-m">{{cardSearch.payName}}</h2>
            <p v-if="cardExchange.gradeName < 2">仅限新用户，老用户享¥399续费特惠</p>
            <p v-if="cardExchange.gradeName >= 2">仅限新用户，老用户享¥349续费特惠</p>
          </div>

          <div class="cardLogo">
            <!--<img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexLogo02.jpg" alt="">-->
          </div>
        </div>
        <div class="cardPrice">
          <!--
          大众 gradeName 0  199
          黄金 gradeName 1
          铂金 gradeName 2
          钻石 gradeName 3

          06-20
          -->
          <!-- 大众+黄金 -->
          <div class="wer" v-if="cardExchange.gradeName < 2">
            <span class="left font-m" v-if="cardSearch">￥<p class="font-roboto-b">289</p>+<p class="font-roboto-b">{{cardSearch.aliPoint}}</p>积分</span>
            <!--<span class="left font-m">{{cardSearch.payCost}}元+{{cardSearch.aliPoint}}积分</span>-->
            <span class="right">月卡原价<p class="font-roboto-b">￥499</p></span>
          </div>

          <!-- 铂金+钻石 -->
          <div class="wer" v-if="cardExchange.gradeName >= 2">
            <span class="left font-m" v-if="cardSearch">￥<p class="font-roboto-b">249</p>+<p class="font-roboto-b">{{cardSearch.aliPoint}}</p>积分</span>
            <!--<span class="left font-m">{{cardSearch.payCost}}元+{{cardSearch.aliPoint}}积分</span>-->
            <span class="right">月卡原价<p class="font-roboto-b">￥499</p></span>
          </div>
        </div>

        <div class="userMb">
          <input v-model="userMobile" class="mobilePhone font-r" placeholder="输入手机号">
          <button class="btn btn-defult btn-black" v-if="cardExchange.gradeName < 0">等级未达到</button>
          <button class="btn btn-defult active" @click="userSubmit" v-else>立即兑换</button>
        </div>
      </div>



      <div class="vipInfor">
        <div class="vipInfor__btn">

          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/btn_1.jpg">
          <div class="vipInfor__btn_custom-service" @click="openCustomService"></div>
          <div class="vipInfor__btn_vip" @click="openVip"></div>
        </div>
        <div class="vipInfor_1">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/1.jpg">
        </div>
        <div class="vipInfor_2" >
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/2.jpg">
        </div>
        <div class="vipInfor_3" ref="scrollPosition">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/3.jpg">
        </div>
        <div class="vipInfor_4">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/4.jpg">
        </div>
        <div class="vipInfor_5">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/5.jpg">
        </div>
        <div class="vipInfor_6">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/6.jpg">
        </div>
        <div class="vipInfor_7">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/mayi/7.jpg">
        </div>
      </div>


    </div>
    <div class="Rule">
      <h2 class="font-m">活动细则</h2>
      <ol class="rules-con font-r">
        <li>新用户是指衣二三的新用户，以注册手机号为准，卡种购买不限次数，累计购买卡用户有效期往上累计。</li>
        <li>退换规则：兑换成功7天内可根据下单情况进行部分或全部的退款退积分，退还积分48小时内到账，具体退款请拨打衣二三客服电话：4006504580。</li>
        <li>一组收货信息仅对应一个衣二三会员身份，衣二三有权取消同一会员多个重复账号的会员资格。</li>
        <li>更多衣二三服务，可在支付宝搜索“衣二三”小程序或生活号，或下载app进入选衣页查看更多可租时装配饰。</li>
        <li>会员期计算规则：首次下单前，我们最长可以为您冻结15天，超过15天系统将开始为您计算会员期，请及时选衣下单哦。下单期间如需冻结，只需把所有衣箱归还即可，冻结期最长同样也是15天。</li>
      </ol>
      <h2 class="font-m">兑换流程</h2>
      <div class="imgP RuleIMG image-ratio">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0602/2018060203.jpg" alt="">
      </div>
    </div>


    <BoxPopup :open="open" v-if="Pay">
      <div slot="Box_InneBtm" >
        <div class="mayi__info ">
          <div class="mayi__info_price">
            <span class="mayi__info_price_small">￥</span><span class="font-roboto-b">{{ ExchangeUserInfo.payCost }}</span>+{{ ExchangeUserInfo.aliPoint }}积分
          </div>
          <div class="mayi__info_black">
            月卡原价：<span class="font-roboto-b">￥499</span>
          </div>
          <div class="mayi__info_btn" @click="payMethod()">
            知道了
          </div>
        </div>
      </div>
    </BoxPopup>


    <BoxPopup :open="otherPay">
      <div slot="Box_p">
        <p class="otherPay">花呗暂不可用<br>
          请更换其他付款方式</p>
        <div class="PayBtn">
          <button class="font-r btn active" @click="payMethod()">确认兑换</button>
        </div>
      </div>
    </BoxPopup>
    <a class="mayi__toTop" href="#mayiTop" v-if="showTopBtn">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/1210/mayiduihuan.png">
    </a>
    <yi23Toast v-model="errorMsg"></yi23Toast>
  </div>
</template>

<script>
  import BoxPopup from '../lib/BoxPopup.vue'
  import Validator from 'common/js/class/validator'
  import { getMembershipAuthLink,paymentOrder } from 'api/member'
  import { cardExchange,getExchangeUserInfo,cardSearch } from 'api/event'
  import { throttle } from '@/utils/throttle'

  export default {
    data () {
      return {
        cardExchange:null,
        ExchangeUserInfo:null,
        cardSearch:null,
        isFirstPay:null,
        open:false,
        refOffsetTop:null,
        otherPay:false,
        userMobile:'',
        toastOpen:false,
        errorMsg:null,
        msg:'erer',
        checkedNames:false,
        depositStatus:null,
        Pay:false,
        showTopBtn:false,
        authCode:'',
        notFirst:'您已参加过活动，请下个月再来兑换~',
        tidNumber:0,
        origin:'normal_exchange',
        depositWaived:0,//免押判断（用户+卡）
      }
    },

    components:{
      BoxPopup
    },
    computed:{

    },

    created () {
      window.addEventListener('scroll',throttle((e)=>{
        let scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        let isShow=false
        if(this.refOffsetTop ){
          if(scrollTop>this.refOffsetTop){
            isShow=true
          }else{
            isShow=false
          }
          if(this.showTopBtn != isShow){
            this.showTopBtn=isShow
          }
        }
      }))
      let query =  this.$route.query;
      if(query.auth_code){
//        console.log(query.auth_code)
        this.auth_code = query.auth_code
//        this.tidNumber = query.tid
        this.getCardExchange()
        this.getCardList()
      }
      else
      {
        this._getMembershipAuthLink()
      }
      console.log(this.$route.path);
    },
    mounted(){
      this.$nextTick(()=>{
        this.refOffsetTop=this.$refs.scrollPosition.offsetTop
      })
    },
    methods:{
      openCustomService(){
        location.href='/yi23/Home/Others/qna?yi23_channel=huabei'
      },
      openVip(){
        location.href='/yi23/Home/Index/index?yi23_channel=huabei'
      },
      //花呗预授权
      _subHuabei() {
        //花呗预授权 => code:200 链接跳转授权或者JSBridge授权 => 发起支付,判断是否为连续包月
        let _t = this;
        let couponId = 0;
        let payType = "ALI_AUTH_FREEZE";
        let cardTemplateId = this.tidNumber;
        let subType = 2; // == 2新支付
        let isEvent =1;
        let mobile = this.userMobile;//手机号


        paymentOrder({ couponId, payType, cardTemplateId, subType, isEvent,mobile }).then(res => {
          console.log(res);
          if (res.code == 102) {
            //102
            window.location.href = res.data.freezeLink;
          } else if (res.code == 103) {
            //103
            AlipayJSBridge.call("tradePay", { orderStr: res.data }, function(
              result
            ) {
//              if (result.resultCode == "9000" || result.resultCode == 9000) {
                //正常发起支付
                _t.paySwitch();
//              }else{
//                console.log(result);
//              }
            });
          } else if (res.code == 110) {
            //正常发起支付
            _t.paySwitch();
          } else {
//            _t.setToastMsg(res.msg);
            _t.errorMsg = res.msg
          }
        });
      },

      //常规支付
      paySwitch() {
        let params = this.getParams();
        let cardTemplateId = this.tidNumber;
        let success = "MayiExchangeSuccess";

        //发起常规支付
        window.location.href = `/yi23/Home/Pay/payment?params=${encodeURIComponent(
          JSON.stringify(params)
        )}&success=${success}&redirect=${encodeURIComponent(
          this.$route.path
        )}`;
      },

      getParams() {
        let cardTemplateId = this.tidNumber;
        let couponId = 0;
        let isEvent  = 1;
        let payType  = 'ALI_POINT';
        let mobile = this.userMobile;//手机号
        const params = {
          couponId,
          cardTemplateId,
          isEvent,
          payType,
          mobile
        };
        return params;
      },

      //
      getCardList:function () {
//        let tid= this.$route.query.tid;
//        let eid= this.$route.query.eid;
//        let eid = 2
//        let origin = 'normal_exchange'
//        let params = {tid:tid, eid :eid, origin:origin}
        let params = { origin:this.origin}

        cardSearch(params).then((res)=>{
          console.log(res)
          this.cardSearch = res.data.showInfo[0]
          this.isFirstPay = res.data.isFirstPay
          this.depositWaived = res.data.showInfo[0].depositWaived
          this.tidNumber = res.data.showInfo[0].templateId
        })
      },

      // auth_code 链接
      _getMembershipAuthLink:function () {
        let url = encodeURIComponent(`/yi23/Home${this.$route.fullPath}`)
//        console.log(url)
        getMembershipAuthLink(url).then((res)=>{
//          console.log(res);
          window.location.href=res.data;
//          this.getMembershipAuthLink = res.data;
//          if(!this.auth_code){
//
//          }
//
//          console.log(decodeURIComponent(res.data))
        });
      },
      //蚂蚁会员 常规卡兑换
      getCardExchange:function () {
        cardExchange(this.auth_code).then((res)=>{
          console.log(res);
//          console.log(res.data)
          if(res.code == 200){
            this.cardExchange = res.data;
          }
          else{
            this.errorMsg = res.msg
          }

        });
      },

      //payHuaBei
      payHuaBei:function () {
        //alert('花呗预授权')
        this._subHuabei()
      },
      //支付
      payMethod() {
        //常规支付
        this.paySwitch()
      },

      toastColse(){
        this.toastOpen=false
      },
      openBox:function () {
        this.open = true
      },
      validataFunc() {
        let validator = new Validator();

        //phone
        validator.add(this.userMobile,[{
          strategy:'isNoEmpty',
          errorMsg:'手机号不能为空'
        },{
          strategy:'isMobile',
          errorMsg:'请正确输入手机号'
        }]);
        return validator.start();
      },

      userSubmit: function () {
        let errorMsg = this.validataFunc();
        if(errorMsg){
          this.openToast(errorMsg);
          return
        }

//        let origin = 'normal_exchange';
        getExchangeUserInfo(this.userMobile,this.origin).then((res)=>{
          console.log(res);
          if(res.code == 200){
            this.ExchangeUserInfo = res.data
//            if(res.data.isParticipate == 0 ){
//              this.Pay = true
//              this.openBox()
//            }
//            else {
//              this.errorMsg = this.notFirst
//            }
            this.isFirstPay = res.data.isFirstPay
            this.depositWaived = res.data.depositWaived
            if( this.isFirstPay ==1){
              this.paySwitch();
              return false
            }
            this.Pay = true
            this.openBox()
          }
          else {
            this.errorMsg = res.msg;
          }
        });
      },

      openToast(msg){
        this.errorMsg = msg;
      },
      //我的订单
      myOrder:function (isName) {
        this.$router.push({
          path:'/Promotion/orderExchange',
//          query:{ name:encodeURIComponent(isName)}
        })
      },
      //
      callCenter:function () {
        window.location.href='tel://4006504580'
      },
    }

  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  @import "./20180602/mayiExchange_1";
</style>


<!--
//depositWaived
//depositStatus
//0 无免押
//1 现金押金 ?
//2 信用借还 ?
//3 花呗预授权
//4 芝麻信用分 ?
//5 长期卡免押 ?

//isParticipate 0 没参见过

//memberType 用户类型

memberType = 1; 新用用户
memberType = 2; 过期用户
memberType = 3; 有效用户

-->
