<template>
    <div class="shareForCard">
      <section class="non1e">
        <div class="Result">
          <h2>
            <i><img src="https://yimg.yi23.net/webimg/web/images/2018/0326/iconSuccess.jpg" alt=""></i>
            购买成功</h2>
          <p class="font-r">恭喜成为衣二三会员</p>
          <div class="ResultBtn">
            <button class="btnA font-m">下载衣二三APP</button>
          </div>
        </div>
      </section>
      <!-- 支付失败 C -->
      <section class="non1e">
        <div class="Result">
          <h2>
            <i><img src="https://yimg.yi23.net/webimg/web/images/2018/0326/iconFailure.jpg" alt=""></i>
            支付失败</h2>
          <p class="font-r">亲，您支付失败，请重新支付～
          <div class="ResultBtn">
            <button class="btnA font-m">重新支付</button>
            <button class="btnB font-m">进入衣二三</button>
          </div>
        </div>
      </section>
    </div>
</template>

<script>
    export default {
        name: "shareCardGResult"
    }
</script>

<style scoped>
  /* result */
  .none {
    display: none;
  }


  .image-ratio {
    background-color: #fff;
  }

  * {
    outline: none;
  }

  body {
    background: #F8F8F2;
  }

  input {
    border-radius: 0;
  }

  img {
    width: 100%;
    display: block;
  }

  i {
    font-style: normal;
  }

  .PlIMG {
    width: 100%;
    height: 0;
    overflow: hidden;
    padding-bottom: 100%;
    position: relative;
  }

  .PlIMG img {
    width: 100%;
    position: absolute;
  }

  .shareForTipICON {
    position: absolute;
    z-index: 3;
    right: 0.96rem;
    top: 0.96rem;
    float: right;
  }

  .shareForTipICON img {
    width: 5.333333rem;
  }

  .TipBg {
    background: rgba(0, 0, 0, .85);
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    z-index: 2;
    position: fixed!important;
    position: absolute;
  }

  .Result {
    text-align: center;
    padding-top: 3.04rem;
    padding-bottom: 2.88rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    width: 100%;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    background-color: #fff;
  }

  .Result h2 {
    width: 100%;
    font-size: 1.066667rem;
    height: 3.2rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
  }

  .Result h2 i {
    width: 1.386667rem;
    height: 1.386667rem;
    position: relative;
    top: 0;
    right: 0.266667rem;
  }

  .Result h2 i img {
    width: 1.386667rem;
    position: absolute;
  }

  .Result p {
    font-size: 0.746667rem;
    letter-spacing: 0.8px;
    text-align: center;
    color: #111;
    margin-bottom: 1.6rem;
    width: 100%;
    line-height: 1.28rem;
  }

  .Result .ResultBtn {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    width: 8.533333rem;
  }

  .Result .ResultBtn button {
    width: 100%;
    height: 2.24rem;
    border-radius: 2.24rem;
    color: #fff;
    font-size: 0.746667rem;
    text-align: center;
  }

  .Result .ResultBtn button.btnA {
    background: #ff544b;
  }

  .Result .ResultBtn button.btnB {
    margin-top: 1.066667rem;
    border: 1px #ff544b solid;
    background: transparent;
    color: #ff544b;
  }
</style>
