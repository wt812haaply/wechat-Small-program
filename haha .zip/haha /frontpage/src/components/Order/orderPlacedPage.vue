<template>
    <div class="container">
        <div class="orderImg"><img src="http://tu.yi23.net/order/order_finish_180115.jpg" alt=""></div>
        <div class="new-payment-success">
          <h2><i><img src="https://tu.95vintage.com/web_source/Home/Common/images/order-success-ok.svg"></i>订单完成！</h2>
          <p>邀请好友成为会员，<br>得￥50现金奖励</p>
          <div class="share" @click="shareLink">
            分享得奖励
          </div>
        </div>
        <div class="stroll" @click="listLink">继续逛</div>
    </div>
</template>

<script>
  import box from '@/api/box'
    export default {
      data () {
        return{
        }
      },
      components:{
      },

      computed: {


      },
      created () {

      },
      methods: {
        unlockStock(){
          box.unlockStock().then((res)=>{
            console.log(res.data.code)
          })
        },

        listLink:function(){
          this.$router.push({
            path:'/Subscribe/pdtListPage',
          })
        },
        shareLink:function(){
          this.$router.push({
            path:'/Event/rewardList',
          })
        },
      },
      mounted(){
        this.unlockStock()
      },
    }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .container {
    .orderImg {
      width: 100%;
      .height(186);
      img {
        width: 100%;
        height: 100%;
      }
    }
    .new-payment-success{
      position:absolute;
      -webkit-transform: translateX(-50%) translateY(-50%);
      -moz-transform: translateX(-50%) translateY(-50%);
      -ms-transform: translateX(-50%) translateY(-50%);
      transform: translateX(-50%) translateY(-50%);
      width:70%;
      top:50%;
      left:50%;
      text-align:center;
      h2{
        .font-size(20);
        font-weight: normal;
        font-style: normal;
        font-family: "PingFangSC-Regular";
        img{
          .width(26);
          .height(26);
          display: inline;
        }
        i{
          position:relative;
          .top(5);
          .padding(0,6,0,0);
        }
      }
      p{
        .font-size(14);
        .line-height(21);
        .height(42);
        color: #666;
        .margin(15,0,52,0)
      }
      .share{
        .height(38);
        .line-height(38);
        .width(190);
        margin:auto;
        background: #CDAB6A;
        color: #fff;
        .font-size(14);
        font-family: "PingFangSC-Medium";
      }
    }
    .stroll{
      position: fixed;
      .bottom(40);
      width: 100%;
      text-align: center;
      .font-size(14px);
      color:#111;
    }
  }
</style>
