<template>
  <div>
    <div @click="doSelectedAddr">
      <x-cell v-if="addressInfo" :title="addressInfo.consignee" :isLink="true" :label="addressInfo.city+' '+addressInfo.country" :detail="addressInfo.address" >
        {{addressInfo.mobile}}
      </x-cell>
      <x-cell v-else >
        请添加新地址
      </x-cell>
    </div>
    <div class="contentBox">
      <x-cell title="预计送达时间">{{addressInfo && addressInfo.devDate}}</x-cell>
      <x-cell title="配送方式">往返包邮</x-cell>
      <div class="clothes" v-if="prdList">
        <div class="box " v-for="item in  prdList">
          <div class="left">
            <img :src="item.thumbPic">
          </div>
          <dl class="right">
            <dt class="blackColor">{{item.productName}}</dt>
            <dd>{{item.brandName}}</dd>
            <dd class="blackColor">{{item.size}}</dd>
          </dl>
        </div>

      </div>
    </div>
    <div class="btn btn-defult btn-black doSubmit" @click="submitOrder">提交订单</div>
    <yi23Dialog @dialogOk="doDialogOk" @dialogClose="doDialogClose" :open="open" >
      <div slot="header">地址与商品库存不匹配？</div>
      <div slot="body">
        你的当前位置是[{{cityName}}]，收件地址与商品库存不匹配，请重新去衣箱下单哦
      </div>
    </yi23Dialog>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import XCell from '@/components/lib/cell/Cell';
  import region from '@/common/js/region';
  import order from '@/api/order'
    export default {
        name: "complete-order-info",
        data () {
          return {
            prdList:null,
            cityName:'',
            toastMsg:'',
            open:false
          }
        },
        computed:{
          ...mapGetters({
            addressInfo:'addressInfo'
          })
        },
        methods:{
          doSelectedAddr(){
            let urls=this.$route.fullPath;
            this.$router.push({
              path:'/User/myAddress',
              query:{ redirect:encodeURIComponent(urls)}
            })
          },
          doDialogOk(){
            region.setLocalRegion({cityName:this.addressInfo.city,regionId:this.addressInfo.cityRgn});
            this.$router.replace({path:'/ClothBox/box'})
          },
          submitOrder() {
            let isUseDeposit = this.$route.query.isUseDeposit
            if (isUseDeposit == "1") {
              this.toastMsg= "小仙女，衣物贵重，需要交纳押金哦。"
            } else {
              if(!this.addressInfo){
                this.toastMsg='请填写详细地址';
                return false
              }else {
                let regionObj = region.getLocalRegion();
                this.cityName=regionObj.cityName;
                if(regionObj.regionId!= this.addressInfo.cityRgn){
                  this.open=true
                  return false
                }
              }
              let items= this.$route.query.items;
              order.submitOrder({items:items,addr_id:this.addressInfo.addrId,date:this.addressInfo.devDate}).then((res)=>{
                if(res.data.code==200){
                  this.$router.replace({
                    name:'orderPlacedPage',
                  })
                }else{
                  this.toastMsg=res.data.msg
                }
              })
            }

          },
          doDialogClose(){
            this.open=false
          }
        },
        components:{
          XCell,
        },
        watch:{
        },
        created(){
          this.$store.dispatch('getAddressInfo',{refresh:true});
          let items= this.$route.query.items
          order.completeOrderInfo({items:items}).then((res)=>{
            if(res.data.code==200){
              this.prdList=res.data.data.pdtList
            }else{
              this.toastMsg=res.data.msg
            }
          })
        }

    }
</script>

<style scoped lang="less">
.contentBox{
  padding-bottom: 40px;
  margin-top: 30px;
  .cell /deep/ .cell-wrapper{
    line-height: 1;
    color: #333;
    min-height: 40px;
    &:first-child{
      background-image: none;
    }
  }
  /deep/ .cell:last-child{
    background-image: none;
  }
}
.clothes{
  padding-top: 30px;
  padding-left: 10px;
}
.box{
  background-image:linear-gradient(0, #d2d2d2, #d2d2d2 50%, transparent 50%);
  background-size: 100% 1px;
  background-repeat: no-repeat;
  background-position: bottom;
  padding:10px 0;

  .blackColor{
    color: #333;
  }
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100px;

  .left{
    width: 80px;
    position: relative;
    img{
      border: 0;
      font-size: 0;
      line-height: 0;
      width: 100%;
      height: 100%;
    }
  }
  .right{
    flex: 1;
    position: relative;
    box-sizing: border-box;
    padding:0 10px ;
    dt{
      font-size: 14px;
      line-height: 2;
      padding-bottom: 5px;
    }
    dd{
      font-size: 12px;
      line-height: 1.5;
    }
    i{
      position: absolute;
      right: 5px;
      top: -10px;
    }
  }
}
.doSubmit{
  position: fixed;
  width: 100%;
  left: 0;
  bottom: 0;
}
</style>
