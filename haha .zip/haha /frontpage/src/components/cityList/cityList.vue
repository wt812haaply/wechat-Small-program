<template>
  <div class="yi23-indexlist">
    <h5>
      <span>当前位置</span>
      <i class="one_h3">
         <img src="https://tu.95vintage.com/web_source/Home/Common/images/20170830001/map.svg">
         {{rgnName}}
      </i>
    </h5>
    <div class="yi23-indexlist-section">
      <div class="activeNav">{{currentTitle}}</div>
      <dl>
        <dt data-key="HOT">
          {{currentTitle}}
        </dt>
        <dd v-for="item in hotcity" v-bind:key="item.rgnId" @click="selectCity(item)">{{item.city}}</dd>
      </dl>
      <dl v-for="(cityitem,index) in citylist">
        <dt :data-key="index" ref="content">{{index}}</dt>
        <dd v-for="item in cityitem" v-bind:key="item.rgnId" @click="selectCity(item)">{{item.city}}</dd>
      </dl>
    </div>
    <div class="yi23-indexlist-nav">
      <ul>
        <li v-for="item in navlist" v-bind:key="item" @touchstart="handleTouchStart" ref="nav" class="citylist-navitem">{{item}}</li>
      </ul>
    </div>
    <div class="currentIndicator" v-show="moving">{{currentIndicator}}</div>
  </div>
</template>
<style lang="less" code>
  body{background: #ffffff}
  .yi23-indexlist {
    img{width: auto}
    width: 100%;
    h5{
      width: 100%;
      text-align: center;
      span{color: #ff544b}
      i{font-size: 12px;font-style: normal;}
      padding: 20px 0;
      position: fixed;
      z-index:1;
      background: #ffffff;
      top: 0;
      left: 0;
    }
    dl{width: 100%;overflow: hidden;}
    dt{font-size: 12px; line-height: 2.09;    color: #999;    background-color: #F7F7F7;padding-left: 10px;}
    dd{font-size: 14px;line-height: 3.928;padding-left: 10px;}
  }
  .activeNav{position: fixed;width: 100%;top: 65px;font-size: 12px; line-height: 2.09;    color: #999;    background-color: #F7F7F7;padding-left: 10px;}
  .yi23-indexlist-section{
    padding-top: 65px;
  }
  .yi23-indexlist-nav{
    position: fixed;right: 0;
    top: 75px; width: 60px;text-align: center;
    li{padding: 3px 0; font-size: 12px}

  }
  .currentIndicator{
    position: fixed;
    z-index: 100;
    background: rgba(0, 0, 0, 0.5);
    left: 50%;
    top: 50%;
    margin: -50px 0 0 -50px;
    width: 100px;
    height: 100px;
    line-height: 100px;
    color: #f1f1f1;
    font-size: 64px;
    font-weight: 700;
    text-align: center;
    border-radius: 10px;
  }
</style>
<script>
  import urlConfig from '@/api/config'
  import { throttle } from '@/utils/throttle'
  export default {
    data (){
      return {
        navlist:[],
        citylist:[],
        hotcity:[],
        navTop:{},
        deviceOffsetHeight:'',
        titleHeight: 65,
        moving:false,
        indicatorTimer:null,
        currentIndicator:'',
        navOffsetX:0,
        currentTitle:'HOT',
        rgnName:''
      }
    },
    methods:{
      selectCity (options) {
        console.log(options)
        this.axios.post(urlConfig.confirmLocation, {
          rgnId: options.rgnId,
        }).then( (response)=> {
            this.$store.commit('setRegionInfo',{cityName:options.city,regionId:options.rgnId});
            this.$router.go(-1)
          }).catch(function (error) {
            console.log(error);
          });
      },
      handleTouchStart (e) {
        this.navOffsetX = e.changedTouches[0].clientX;
        this.scrollNavList(e.changedTouches[0].clientY);
        this.moving = true;
        if(this.indicatorTimer){
          clearTimeout(this.indicatorTimer)
        }
        window.addEventListener('touchmove', this.handleTouchMove);
        window.addEventListener('touchend', this.handleTouchEnd);
      },
      handleTouchMove (e) {
        e.preventDefault()
        this.scrollNavList(e.changedTouches[0].clientY);
      },
      handleTouchEnd () {
        // console.log('--333--')
        this.indicatorTimer = setTimeout(() => {
          this.moving = false;
          this.currentIndicator = '';
        }, 500);
        window.removeEventListener('touchmove', this.handleTouchMove);
        window.removeEventListener('touchend', this.handleTouchEnd);
      },
      scrollNavList (y) {
        let currentItem = document.elementFromPoint(this.navOffsetX, y);

        // console.log(currentItem)//<li class="citylist-navitem">A</li>
        if (!currentItem || !currentItem.classList.contains('citylist-navitem')) {
          return;
        }
        // console.log('--??--')
        this.currentIndicator = currentItem.innerText;
        if(this.citylist[currentItem.innerText]){
          window.scrollTo(0,this.navTop[currentItem.innerText]-this.titleHeight)
            this.currentTitle=currentItem.innerText
        }

      },
      getScrollTop  (element) {
        if (element === window) {
          return Math.max(window.pageYOffset || 0, document.documentElement.scrollTop);
        }

        return element.scrollTop;
      }
    },
    created (){
      this.axios.get(urlConfig.locationMap).then((res)=>{
          if( res.data.code == 200){
              let datas=res.data.data
              this.navlist=['HOT', ...Object.keys(datas.citylist)]
              this.citylist=datas.citylist
              this.hotcity=datas.hotcity
              this.rgnName=datas.rgnName
          }
        this.$nextTick().then(()=>{
          this.deviceOffsetHeight = document.documentElement.offsetHeight;
          window.scrollTo(0,0);
          for (var k in this.navlist) {
            let topNumber=document.querySelector('*[data-key='+this.navlist[k]+']').getBoundingClientRect().top;
            let keyName=this.navlist[k];
            this.navTop[keyName]=topNumber
          }
        })

      })

    },
    mounted () {
      window.addEventListener('scroll',
        throttle(()=>{
          let top= this.getScrollTop(window)
          for (var i=0;i<this.navlist.length;i++){
            if(i==(this.navlist.length-1) && top+this.titleHeight > this.navTop[this.navlist[i]]){
              this.currentTitle=this.navlist[i]
              break;
            } else if(top+this.titleHeight > this.navTop[this.navlist[i]] && top+this.titleHeight< this.navTop[this.navlist[i+1]]){
              this.currentTitle=this.navlist[i]
              break;
            }
          }
        },200)
      )
    }
  }
</script>
