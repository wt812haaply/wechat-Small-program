<template lang="html">
  <div class="pay_ment">
    <img src="https://yimg.yi23.net/webimg/web/images/2018/0509/dataLoading.gif" alt="">
  </div>
</template>

<script>
//@{params} 支付所需要的参数
//@{success} 支付成功或失败页面地址
//@{redirect} 错误时候回跳地址
import paymentNewForLeaf from '@/mixins/paymentNewForLeaf';

export default {
  mixins: [paymentNewForLeaf],
  created(){
    //console.log(JSON.parse(decodeURIComponent(this.$route.query.params)).payType);
  },
  mounted(){
    this.creatPay();
  },
  methods:{
    getParams(){
      let params = this.$route.query.params;
      if(params){
        return JSON.parse(decodeURIComponent(params));
      }else{
        return '';
      }
    },
    getSuccessUrl(){
      let url = decodeURIComponent(this.$route.query.success);
      return url || '';
    },
    getRedirect(){
      let path = decodeURIComponent(this.$route.query.redirect);
      return path || '';
    },
    toRedirect(){
      let path = this.getRedirect();
      if(path){
        this.$router.replace({path: path});
      }else{
        this.$router.replace({path: '/Index/index'});
      }
    },
    creatPay(){
      let params = this.getParams();
      let success = this.getSuccessUrl();
      let redirect = this.getRedirect();

      if(params){
        this._creatPayment({params,success,redirect});
      }else{
        this.toRedirect()
      }

    }
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  .pay_ment{
    background: #fff;
    height: 100%;
    width: 100%;
    text-align: center;
    img{
      width: 30px;
      height: 30px;
      margin-top: 50px;
      display: inline-block;
    }
  }
</style>
