<template lang="html">
  <div class="pay_ment">
    <img src="https://yimg.yi23.net/webimg/web/images/2018/0509/dataLoading.gif" alt="">
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script>

//@{params} 支付所需要的参数
//@{success} 支付成功或失败页面地址
//@{redirect} 错误时候回跳地址
import payMixin from '@/mixins/payment';
import { toastMixin } from 'common/js/mixin';

export default {
  mixins: [payMixin,toastMixin],
  created(){
    //console.log(JSON.parse(decodeURIComponent(this.$route.query.params)).payType);
  },
  mounted(){
    this.creatPay();
  },
  methods:{
    setPayWay(){
      let _payWay = this.getClientPayWay();
      let _payType = this.getClientPayType();

      this.payWay = _payWay; //支付方式,旧支付
      this.payType = _payType; //支付方式,新支付

    },
    getParams(){
      let params = this.$route.query.params;
      return JSON.parse(decodeURIComponent(params));
    },
    getSuccessUrl(){
      let url = decodeURIComponent(this.$route.query.success);
      return url;
    },
    toRedirect(){
      let path = decodeURIComponent(this.$route.query.redirect);
      if(path){
        this.$router.replace({path: path});
      }else{
        this.$router.replace({path: '/Index/index'});
      }
    },
    creatPay(){
      if(this.$route.query.params){
        let url = this.getSuccessUrl();
        let redUrl = decodeURIComponent(this.$route.query.redirect);
        this.pay(url,redUrl);
      }else{
        this.toRedirect()
      }
    }
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  .pay_ment{
    background: #fff;
    height: 100%;
    width: 100%;
    text-align: center;
    img{
      width: 30px;
      height: 30px;
      margin-top: 50px;
      display: inline-block;
    }
  }
</style>
