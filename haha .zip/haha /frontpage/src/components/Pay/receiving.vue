<template lang="html">
  <div class="pay_ment">
    <img src="https://yimg.yi23.net/webimg/web/images/2018/0509/dataLoading.gif" alt="">
  </div>
</template>

<script>
import { applyCreatePay } from '@/common/js/payEvent';

export default {
  beforeRouteEnter(to, from, next) {
    let { paytype, apiname, params, success,redirect} = to.query;
    if (paytype && apiname && params && success) {
      next();
    } else {
      window.location.href = decodeURIComponent(redirect) || '/yi23/Home/Index/index';
    }
  },
  created(){

    let { paytype, apiname, params, success,redirect} = this.$route.query;

    applyCreatePay({
      payType: decodeURIComponent(paytype),
      params: JSON.parse(decodeURIComponent(params)),
      apiName: decodeURIComponent(apiname),
      options: {
        success: decodeURIComponent(success),
        redirect: decodeURIComponent(redirect)
      }
    });

  },
  mounted(){

  },
  methods:{
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  .pay_ment{
    background: #fff;
    height: 100%;
    width: 100%;
    text-align: center;
    img{
      width: 30px;
      height: 30px;
      margin-top: 50px;
      display: inline-block;
    }
  }
</style>
