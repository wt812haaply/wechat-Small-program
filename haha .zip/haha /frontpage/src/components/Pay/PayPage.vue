<template>
  <div class="paypage" style="background-color:#fafafa">
    <go-back></go-back>
    <div class="wrapper">
      <div class="swiper-box" v-if="sliderList">
        <!-- <swiper :options="swiperOption" ref="mySwiper" @slideChange="getSwiperIndex">
          <swiper-slide v-for="(slide,index) of sliderList" :key="index">
            <div class="card-content">
              <img :src="slide.cardImage">
            </div>
          </swiper-slide>
        </swiper> -->

        <div class="card-box">
          <img :src="sliderList[currentIndex] && sliderList[currentIndex].cardImage" width="100%">
        </div>

        <div class="slider-tab">
          <div class="tabwrapper">
            <div
            :class="{'item':true, 'align-item-center':true,'active':currentIndex == index}"
            v-for="(list,index) of sliderList"
            :key="list.templateId"
            v-if="list.payType != 9 && sliderList.length > 1"
            @click="getSwiperIndex(index)"
            v-sa_payment="{'userStatus':isFirstPay,'name':'card'}"
            >
                <div class="font-m">{{list.validMonth}}个月</div>
                <div class="dailyprice">
                  <p class="font-weight-300">{{list.dayPrice}}</p>
                  <p class="font-weight-300" v-if="list.payType != 1">原价¥{{list.payOriginal}}</p>
                </div>
                <div class="price">
                  <span>
                    {{list.payCostNew || list.payCostNew == 0 ? list.payCostNew : list.payCost}}
                  </span>
                </div>
                <div class="line_active"></div>
                <!-- 月卡内,有连续包月,勾选连续包月,连续包月卡中有'连续首月立减' -->
                <transition name="slide-fade" appear>
                  <div class="tips"
                  v-if="list.payType == 1 && isContinueCardIn && continueCheckBoxStatus && continueCardTipshow && (index == currentIndex)"
                  >首月特惠¥199</div>
                </transition>
            </div>
          </div>

          <div class="agreen-btn">
            <slide-fadeleft>
              <slot>
                <div v-if="isContinueCardIn && sliderList[currentIndex].payType == 1">
                    <span :class="{'active':continueCheckBoxStatus}" @click="changeContinueStatus">
                      <img src="https://yimg.yi23.net/webimg/web/images/2018/0809/selected@2x.png">
                    </span>
                    <label class="dec font-weight-300"
                    @click="changeContinueStatus"
                    v-sa_payment="{'userStatus':isFirstPay,'name':'continuousMonthly'}"
                    >到期自动续费一个月，可随时取消</label>
                    <i @click="dialogOpen2">?</i>
                </div>
              </slot>
            </slide-fadeleft>
          </div>

        </div>
      </div>

      <div class="card_message" v-if="sliderList && currentObj">
        <div class="detailed">
          <div class="item" v-for="item in currentObj.payReductionInfos">
            <p class="title font-weight-300">{{item.reductionName}}</p>
            <span class="gray cash-color font-weight-300">-¥{{item.reductionAmount}}</span>
            <div class="arrow-box"></div>
          </div>

          <!-- 需要交押金 && 用户未交押金-->
          <div class="item"
          v-if="isdepositWaived"
          v-sa_payment="{'userStatus':isFirstPay,'name':'depositAmountType'}"
          @click="depositSelectShow">
            <p class="title font-weight-300">押金</p>
            <span class="cash-color depositname font-weight-300">
              {{activeDepositTypeList.text[activeDepositTypeList.active].title.replace('$¥','')}}
            </span>
            <span class="cash-color font-weight-300">¥{{currentObj.depositAmount}}</span>
            <div class="arrow-box">
              <i class="icon_arrow"></i>
            </div>
          </div>
          <!-- 不需要交押金 / 需要交押金，用户已交押金-->
          <div class="item" v-else>
            <p class="title font-weight-300">押金</p>
            <span class="depositname font-weight-300">{{currentObj.depositName}}</span>
            <span class="decoration-line-through font-weight-300">¥{{currentObj.depositAmount}}</span>
            <div class="arrow-box"></div>
          </div>
          <!-- end -->

          <!-- 体验卡不显示 -->
          <div class="item"
            v-sa_payment="{'userStatus':isFirstPay,'name':'coupons'}"
            @click="couponsLayerOpen"
            >
            <p class="title font-weight-300">优惠券</p>
            <span class="gray font-weight-300" v-if="(JSON.stringify(couponsActive) == '{}' || !couponsActive) && !nocoupons">没有可用优惠券</span>
            <span class="gray font-weight-300" v-if="nocoupons">不使用优惠券</span>
            <template v-if="couponsActive != null && JSON.stringify(couponsActive) != '{}' && !nocoupons">
              <span class="gray cash-color font-weight-300" v-if="couponType(couponsActive.couponType)">-¥{{couponsActive.value}}</span>
              <span class="gray cash-color font-weight-300" v-else>{{couponsActive.value * 10}}折</span>
            </template>
            <div class="arrow-box">
              <i class="icon_arrow"></i>
            </div>
          </div>
          <div class="item" v-if="showInvitation">
            <p class="title font-weight-300">邀请码</p>
            <span class="gray font-weight-300"
              v-sa_payment="{'userStatus':isFirstPay,'name':'inviteCode'}"
              @click="openinviteCode"
              v-if="!inviteCode">
                <i>输入邀请码获得奖励</i>
            </span>
            <span class="gray font-weight-300"
            @click="openinviteCode"
            v-sa_payment="{'userStatus':isFirstPay,'name':'inviteCode'}"
            v-else>
                <i style="color:#111">{{inviteCode}}</i>
            </span>
            <div class="arrow-box">
              <i class="icon_arrow"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="paymenttype font-weight-300" v-if="sliderList">
        <div>支付方式</div>
        <div v-if="getPaytype == 'wechat'">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0809/icon_wx@2x.png">
          <span class="font-weight-300">微信</span>
        </div>
        <div v-else>
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0809/icon_alipay@2x.png">
          <span class="font-weight-300">支付宝</span>
        </div>
        <div class="arrow-box"></div>
      </div>

      <div class="PayAgreement" v-if="sliderList">
        <!--<p class="font-r"><i>*</i>付费成为会员代表您已经阅读并同意<i @click="linkPayAgreement()">衣二三会员协议</i></p>-->
        <p v-html="cardDesction"></p>
      </div>

    </div>

    <div class="bottomPay font-m bottomIphoneX" v-if="sliderList">
      <div class="left">
        总价:<span>¥</span><i>{{ total }}</i>
      </div>
      <div class="right">
        <div
        @click="_goPayClick"
        v-sa_payment="{'userStatus':isFirstPay,'name':'cardPayment'}"
        >
          <span>去支付</span>
        </div>
      </div>
    </div>

    <pop-up-layer v-if="couponsLayerShow">
      <Coupons
        @btnClick="unUseCoupons"
        @closedPopLayer="couponsLayerClosed"
        :data="couponsList"
      >
        <ul class="coupons-wrapper">
          <li class="coupons-item" v-for="(item, index) of couponsList" @click="choiceCoupon(item)">
            <div class="dec">
              <p>{{item.couponTitle}}</p>
              <span>{{item.startDate | YYYY_MM_DD }}-{{item.expDate | YYYY_MM_DD }}</span>
            </div>

            <div class="money type_a" v-if="couponType(item.couponType)">
              <p><i>¥</i>{{item.value}}</p>
            </div>
            <div class="money type_b" v-else>
              <p>{{item.value * 10}}<i>折</i></p>
            </div>
          </li>
        </ul>

      </Coupons>
    </pop-up-layer>

    <!-- 邀请码 -->
    <div  v-if="inviteCodeState">
      <div class="inviteCode">
          <div class="inviteCodeTitle">
              <i>{{ inviteCodeTitle }}</i>
              <i style="color:#ff544b;">{{ inviteCodeError }}</i>
          </div>
          <div class="inviteCodeCont">
            <input type="" name="" placeholder="请输入邀请码" v-model.lazy="inviteCode2">
          </div>
          <div class="inviteCodeBtn">
            <button class="btn leftBtn" @click="closeBtn">取消</button>
            <button class="btn rightBtn" @click="confirmBtn">确定</button>
          </div>
      </div>
      <div class="inviteCodeMask" v-if="inviteCodeState"></div>
    </div>

    <!-- 押金select -->
    <depositTypeSelect
      v-model="showDepositSelect"
      @selectedDeposit="selectedDeposit"
      :activeDepositType="activeDepositTypeList"
      :depositamount="currentObj&&currentObj.depositAmount"
      >
    </depositTypeSelect>

    <yi23Toast v-model="toastMsg"></yi23Toast>

     <yi23Dialog
      @dialogOk="dialogOK"
      @dialogClose="dialogClose"
      :open="dialogShow"
      :dialogSm='true'
      :hasCannel="true"
      >
      <div slot="header">自动续费专享权益</div>
      <div slot="body">
        <p>开通自动续费服务可享免交300元押金权益，及首月{{continueCardTipInfo}}元优惠，确认放弃权益吗？</p>
      </div>
      </yi23Dialog>

      <!-- 连续包月说明 -->
      <yi23Dialog
      @dialogOk="dialogClose2"
      @dialogClose="dialogClose2"
      :open="dialogShow2"
      :dialogSm='true'
      :hasCannel="false"
      >
      <div slot="header">自动续费服务</div>
      <div slot="body">
        <p style="text-align:left">1 会员到期前2天，自动为您续费499元/月。</p>
        <p style="text-align:left">2 如需解除自动续费服务，请在会员期过期前3天在APP“我的”-“管理连续包月”中申请取消。</p>
        <p style="text-align:left">3 本服务支持7天内退款。</p>
      </div>
      </yi23Dialog>

  </div>
</template>

<script type="text/ecmascript-6">
  import GoBack from 'base/GoBack';
  import PopUpLayer from 'base/PopUpLayer';
  import Coupons from 'components/Member/_coupons';
  import cancelLayer from 'components/Member/_cancelCreditLifeLayer';
  import common from 'common/js/common';
  import { getClientType,isEmptyObject } from 'common/js/utils';
  import { ERR_OK,COUPON_TYPE_JE} from 'api/const';
  import { getCardList,getPayDate,bindingInvitation } from 'api/member';
  import { toastMixin } from 'common/js/mixin';
  import paymentNewForLeaf from '@/mixins/paymentNewForLeaf';
  import depositTypeSelect from "base/depositTypeSelect";
  import extendData from 'common/config/payment/index2';
  import slideFadeleft from 'components/lib/transition/slideFadeLeft';
  import smallLoading from '@/components/lib/smallLoading';

  export default {
    mixins: [toastMixin,paymentNewForLeaf],
    data() {
      return {
        inviteCodeState:false,
        inviteCode:'',
        inviteCode2:'',
        inviteCodeError:'',
        showInviteCode:true,
        inviteCodeMsg:'邀请码兑换成功',
        showInvitation:'',
        data: null,
        sliderList: null,
        //卡列表中是否有连续包月卡
        isContinueCardIn:null,
        //连续包月卡气泡
        continueCardTipshow:false,
        continueCardTipInfo:'',
        //连续包月按钮
        continueCheckBoxStatus: true,
        //连续包月描述
        continueCardTipDec:'',
        couponsListAll:{},
        couponsList:[],
        //支付类型选择弹窗
        showDepositSelect: false,
        //默认的押金方式
        activeDepositTypeList:{},
        isUseCoupon: 1,
        couponsLayerShow: false,
        couponsActive: null,
        couponsActiveId: "",
        nocoupons: false,
        currentIndex: 0,
        currentObj: null,
        checked: false,
        ZMXYLayerShow: false,
        btnAjax: true,
        dialogShow: false,
        dialogShow2: false,
        isFirstPay: null
      }
    },
    created(){
      this._getPayPage();
      this.getDepositTypeList();
    },
    watch:{
      couponsList:function(newVal,oldVal){
        let activeItem;
        if(Array.isArray(newVal) && newVal.length > 0){
          activeItem = newVal[0];
        }else{
          activeItem = {};
        }
        this.couponsActive = activeItem;
      },
      couponsActive:function(newVal,oldVal){
        if(this.nocoupons == false  &&  newVal.couponId){
          this.couponsActiveId = newVal.couponId;
        }else{
          this.couponsActiveId = "";
        }
      },
      currentIndex:function(newVal,oldVal){
        //索引变化改变目标对象
        this.setCurrentObj(newVal);
      },
      continueCheckBoxStatus:function(newVal,oldVal){
        //连续包月状态发生变化改变目标对象
        this.setCurrentObj();
        //连续包月状态发生变化改变优惠券信息
        this._getPayDataLogic();
      }
    },
    computed: {
      getPaytype(){
        let uaName = this.getUaName();
        if(uaName == 'wechat' || uaName == 'ali'){
          return uaName
        }else{
          //浏览器端 处理支付方式
          let card = this.currentObj;
          if(card && card.payType == 9){
            return 'wechat';
          }else{
            return 'ali';
          }
        }
      },
      total(){
        let currentObj = this.currentObj;

        //实际支付价格
        let [ payCost,total = payCost ] = [ currentObj.payCost ];

        let extraReduce = 0; //减免
        let deposit = 0; //押金
        let depositWaived = currentObj.depositWaived; //是否需要交押金
        let payReduce = currentObj.payReduce || 0;//立减总额

        //需要押金 并且选择 是现金支付
        if( depositWaived == 0 && this.activeDepositTypeList.active == 'cash'){

          deposit = currentObj.depositAmount;

        }

        let couponsActive = this.couponsActive;

        if(this.nocoupons == false &&  couponsActive != null && JSON.stringify(couponsActive) != '{}'){
          if(couponsActive.couponType == 1){
            total = payCost - couponsActive.value;
          }else if(couponsActive.couponType == 2){
            total = payCost * couponsActive.value;
          }
        }

        //优惠券以后减去立减价格
        total = parseInt((total - payReduce)*100)/100;

        return  total >= 0 ? total + deposit : deposit;

      },
      isdepositWaived() {

        if(!this.currentObj) return false;

        let cardItem = this.currentObj;

        //depositWaived:0; 0需要交押金,1不需要交押金
        if (cardItem.depositWaived == 0) {
          return true;
        }
        return false;
      },
      cardDesction(){
        /*
        * 显示连续包月卡
        **/
        let dec = '';

        if(this.sliderList){

          //月卡。并且有连续包月。并且勾选了连续包月
          if(this.sliderList[this.currentIndex].payType == 1 && this.isContinueCardIn && this.continueCheckBoxStatus){

            this.continueCardTipDec.split('\n').forEach((el)=>{
              dec += `<p>${el}</p>`;
            })

          }else{
            if(this.sliderList[this.currentIndex].cardDesc){
              this.sliderList[this.currentIndex].cardDesc.split('\n').forEach((el)=>{
                dec += `<p>${el}</p>`;
              })
            }
          }
        }
        return dec
      }
    },
    methods: {
      dialogOK(){
        this.dialogClose();
        //取消连续包月按钮
        this.continueCheckBoxStatus = false;
      },
      dialogClose(){
        this.dialogShow = false;
      },
      dialogOpen(){
        this.dialogShow = true;
      },
      dialogClose2(){
        this.dialogShow2 = false;
      },
      dialogOpen2(){
        this.dialogShow2 = true;
      },
      openinviteCode(){
        this.inviteCodeState = !this.inviteCodeState
        this.inviteCodeTitle = '使用好友的邀请码'
        this.inviteCodeError = '';
      },
      closeBtn(){
        this.inviteCodeState = false
      },
      confirmBtn(){
          if( this.inviteCode2 ){
            this.openinviteCode();
            this._getBindingInvitation();
          } else{
             this.setToastMsg('请输入邀请码');
          }
      },
      changeContinueStatus(){

        /*
        * 获取连续包月勾选状态
        * 如果有首月特惠¥199的弹窗就多弹一个提示窗口
        */

        let status = this.continueCheckBoxStatus;
        if(status){
          if(this.continueCardTipshow){
            this.dialogOpen();
            return false;
          }
        }

        this.continueCheckBoxStatus = !this.continueCheckBoxStatus;

      },
      // 邀请码接口 新支付时绑定老用户
      _getBindingInvitation(){
        bindingInvitation(this.inviteCode2).then((res)=>{
          if(res.code == 200){
            this._getPayPage();
          }else{
            console.log(res.msg)
            this.inviteCodeError = res.msg;
            this.inviteCodeState = true;
            this.inviteCodeTitle = '';
            this.inviteCode = '';
          }
        })
      },
      linkPayAgreement:function(){
        this.$router.push({
          path:'/Agreement/agree',
        })
      },
      choiceCoupon(item){
        this.couponsActive = item;
        this.useCoupons();
        this.couponsLayerClosed();
      },
      couponType(type){
        if(type == COUPON_TYPE_JE){
          return true
        }
        return false
      },
      couponsLayerOpen(){
        this.couponsLayerShow = true
      },
      couponsLayerClosed(){
        this.couponsLayerShow = false
      },
      clearCouponsActive(){
        this.couponsActive = null;
      },
      unUseCoupons(){
        this.nocoupons = true;
        this.clearCouponsActive();
      },
      useCoupons() {
        this.nocoupons = false;
      },
      setCurrentObj(index = this.currentIndex){

        //当前卡行
        let currentPayType = this.sliderList[index].payType;
        let obj;

        //月卡 && 连续包月卡存在 && 连续包月按钮为true
        if(currentPayType == 1 && this.isContinueCardIn && this.continueCheckBoxStatus){
          this.sliderList.forEach((el)=>{
            if(el.payType == 9){
              obj = el
            }
          })
        }else{
         obj = this.sliderList[index];
        }

        //写入当前展示对象
        this.currentObj = obj;

      },
      getSwiperIndex(index) {

        if(this.currentIndex == index) return false;

        // 写入选择的index
        this.currentIndex = index;

        //拉取优惠券
        this._getPayDataLogic();
      },
      _getPayPage(){
        let _t = this;
        //获取微信连续包月cookie
        let contractBindingCookie = common.getCookie('WECHAT_CONTRACT_BINDING');

        if(contractBindingCookie){
          console.log('我是延迟三秒');

          //打开loading
          smallLoading.open();
          //删除3秒标记
          common.delCookie('WECHAT_CONTRACT_BINDING');

          //如果发起过微信联系包月,延迟三秒发起请求,手动遮罩,签约代扣后台比较慢
          window.payPageTimer = window.setTimeout(function(){
            //存入刷新用户数据的cookie
            common.setCookie('jwtRefresh', '1', '.95vintage.com');

            getCard.call(_t);
          },3000)

        }else{
          console.log('我是不延迟');
          getCard.call(_t)
        }

        function getCard(){

          if(window.payPageTimer){
            window.clearTimeout(payPageTimer);
          }

          getCardList().then((res)=>{
            let result = res;

            if(result.code == ERR_OK){

              //是否需要展示邀请码
              this.showInvitation = result.data.showInvitation || result.data.showInvitation > 0;
              this.inviteCode = result.data.inviteCode;

              //新老人
              this.isFirstPay = result.data.isFirstPay;

              this.data = result.data;
              return result.data.paydetail
            }else{
              this.setToastMsg(res.msg);
            }
          }).then((paydetail)=>{
            //写入卡列表
            this.sliderList = this.filterCardLogic(paydetail);

            //初始化 展示的卡详情
            this.setCurrentObj();

            //拉取优惠券
            this._getPayDataLogic();

          })
        }

      },
      filterCardLogic(cardlist = []){
        let listAll;
        //筛卡
        listAll = this.filterCard(cardlist);
        //筛长期卡立减
        listAll = this.addPayCostNew(listAll);
        //计算卡费/天
        listAll = this.countCardDailyPrice(listAll);

        return listAll;
      },
      countCardDailyPrice(cardlist = []){
        let listAll;
        listAll=cardlist.map((el)=>{
          let cost = el.payCostNew || el.payCostNew == 0 ? el.payCostNew : el.payCost;
          el.dayPrice = `¥${parseInt(cost/el.validDays*10)/10}/天`
          return el;
        })
        return listAll;
      },
      addPayCostNew(cardlist = []){
        let listAll;
        listAll = cardlist.map((list)=>{
          list.payReductionInfos.map((el,index)=>{
            if(el.reductionName.indexOf('用户限时折扣')>-1){
              list.payCostNew = parseInt((list.payCost - el.reductionAmount)*100)/100;
            }
            return el
          })
          return list
        })

        return listAll;
      },
      selectedDeposit(activeObj){
        /*
        *当前用户选中的押金
        * activeObj {Object}
        * params key {String} 押金类型字符串
        * params value {String} 押金类型标题
        */
        //console.log(activeObj);
        this.activeDepositTypeList.active = activeObj.key;
      },
      filterCard(cardlist = []){

        //是否需要删除连续包月
        let cardListKey = this.getCardListKey();
        let cardKeys = extendData.cardListMap[cardListKey] || extendData.cardListMap['default'];
        let filterList = [];
        let continueObj = {};//连续包月对象容器

        let cardListFilter = function(listArr){
           listArr.forEach((el)=>{
            cardlist.forEach((ell)=>{
              if(el == ell.payType){
                filterList.push(ell)
              }
            })
          })
        }

        cardListFilter(cardKeys);

        //写入静态数据
        filterList = filterList.map((list)=>{

          if(extendData.extend[list.payType]){
            list = Object.assign({},list,extendData.extend[list.payType]);
          }

          if(list.payType == 9){
            //如果卡型中有连续包月 设置为true
            this.isContinueCardIn = true;
            //卡描述
            this.continueCardTipDec = list.cardDesc;

            //如果连续包月卡中有 连续首月立减100
            if(list.payReductionInfos.length > 0){
              list.payReductionInfos.map((el,index)=>{
                if(el.reductionName.indexOf('连续包月首月特惠')>-1){
                  //月卡提示气泡
                  this.continueCardTipshow = true;
                  //优惠金额
                  this.continueCardTipInfo = el.reductionAmount;
                }
              })
            }
          }
          return list;
        })

        return filterList
      },
      getDepositTypeList(){

        let uaName = this.getUaName();
        let channel = this.getYi23Channel();
        let typeName;
        console.log(channel)
        if(uaName == 'ali'){
          if(channel){
            typeName = channel;
          }else{
            //支付宝内没有channel默认huabei
            typeName = 'huabei';
          }
        }else{
          typeName = uaName;
        }
        this.activeDepositTypeList = extendData.depositType[typeName || 'web'];

      },
      getUaName(){
        let ua = this.$clientType;
        if(ua == 3){
          return 'wechat'
        }else if(ua == 4){
          return 'ali'
        }else{
          return 'web'
        }
      },
      getYi23Channel(){
        let ua = this.getUaName();
        let yi23Channel = common.getCookie('yi23_channel');
        if(ua == 'ali'){
          //支付宝环境中如果yi23_channel为空默认yi23_channel为huabei
          return (yi23Channel == 'huabei'|| yi23Channel == 'zhima') ? yi23Channel : 'huabei';
        }
        //除支付宝环境,其他不需要yi23_channel
        return false
      },
      getCardListKey(){
        let ua = this.getUaName();
        let yi23Channel = common.getCookie('yi23_channel');
        if(ua == 'ali'){
          //支付宝环境中如果yi23_channel为空默认yi23_channel为huabei
          return (yi23Channel == 'huabei'|| yi23Channel == 'zhima') ? yi23Channel : 'huabei';
        }else{
          return ua;
        }
      },
      _getPayDataLogic(){

        let currentPayType = this.sliderList[this.currentIndex].payType;
        let coupon = this.couponsListAll;
        let payTypeObj = {};
        //如果连续包月按钮为true && 当前选择的是月卡 && 卡列表有连续包月 获取连续包月的优惠券
        if(currentPayType == 1 && this.isContinueCardIn && this.continueCheckBoxStatus){
          currentPayType = 9;
        }

        //读取优惠券缓存
        // if(coupon[currentPayType]){
        //   this.couponsList = coupon[currentPayType];
        //   return false;
        // }

        //拉取优惠券
        this._getPayData({payType:currentPayType});
      },
      _getPayData(paytype){
        getPayDate(paytype).then((res)=>{
          // 如果内存中没有优惠券信息,存入type对应优惠券列表
          let paytypeStr = paytype.payType
          // if(!this.couponsListAll[paytypeStr]){
          //   this.couponsListAll[paytypeStr] = res.data
          this.couponsList = res.data || []
          // }
        })
      },
      depositSelectShow() {
        this.showDepositSelect = true;
      },
      depositSelectClosed() {
        this.showDepositSelect = false;
      },
      getParams(){
        let currentObj = this.currentObj;
        let cardTemplateId = currentObj.templateId;
        let couponId = this.couponsActiveId;

        const params = {
          cardTemplateId,
          couponId
        }
        return params
      },
      _goPayClick(){

        let params = this.getParams();
        let currentObj = this.currentObj;
        let activeDeposit = this.activeDepositTypeList;
        let success = 'MemberPaySuccess';
        let payType;
        let options;

        if(currentObj.payType == 9){

          let uaName = this.getUaName();

          if(uaName == 'ali'){
            //连续包月 支付宝
            payType = 'ALI_CONTRACT_BINDING';
          }else if(uaName == 'wechat'){
            //连续包月 微信公众号发起
            payType = 'WECHAT_CONTRACT_BINDING';

            //存入延迟三秒拉列表数据的cookie
            common.setCookie('WECHAT_CONTRACT_BINDING', '1');

          }else{
            //浏览器环境发起了连续包月,暂时默认是微信连续包月
            payType = 'WECHAT_WEB_CONTRACT_BINDING';
            //throw new Error('There is no continuous payment for web');
          }

          success = 'ContractResultSuccess';
        }else if(currentObj.depositWaived == 0){
          //当前选中的卡是否需要交押金
          if(activeDeposit.active == 'huabei'){
            payType = 'ALI_AUTH_FREEZE';
          }else if(activeDeposit.active == 'zhima'){
            payType = 'ALI_CREDIT_LIFE';
          }
        }

        if(payType){
          params.payType = payType;
        }

        this._creatPayment({params,success});

      },
      ZMXYLayerOpen(){
        this.ZMXYLayerShow = true;
      },
      ZMXYLayerClosed(){
        this.ZMXYLayerShow = false;
      }
    },
    components: {
      GoBack,
      PopUpLayer,
      Coupons,
      depositTypeSelect,
      slideFadeleft,
      cancelLayer
    }
  }
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .align-item-center{
    align-items: center;
  }
  .font-weight-300{
    font-weight: 300;
  }

  /* 可以设置不同的进入和离开动画 */
  /* 设置持续时间和动画函数 */
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .5s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to{
     transform: translate(-50%,-10px) !important;
     opacity: 0;
  }

  .arrow-box{
    width: .586667rem /* 11/18.75 */;
    line-height: 2.56rem /* 48/18.75 */;
    font-size: 0;
    margin-left:.16rem /* 3/18.75 */;
  }

  .icon_arrow{
    display: inline-block;
    width: .64rem;
    height: .64rem;
    background: url(http://ycloset.oss-cn-beijing.aliyuncs.com/webimg/web/xy/Image/20180716/arrow@2x.png) no-repeat 0 0;
    background-size: cover;
    margin-right: .106667rem;
    vertical-align: -webkit-baseline-middle;
    vertical-align: middle;
  }

  .gray {
    color: rgb(204,204,204);
  }
  .cash-color {
    color: #ff544b;
  }

  .card-box{
    width: 100%;
    text-align: center;
    padding: .533333rem /* 10/18.75 */ 0 0 0;
    font-size: 0;
    img{
      width: 15.306667rem /* 287/18.75 */;
      height: 8.64rem /* 162/18.75 */;
    }
  }
  .tabwrapper{
    padding: 1.28rem /* 24/18.75 */ 1.226667rem /* 23/18.75 */ 0 1.226667rem /* 23/18.75 */;
    position: relative;
    display: flex;
    .item{
      position: relative;
      padding: .8rem /* 15/18.75 */ 0 .533333rem /* 10/18.75 */ 0;
      box-sizing: border-box;
      height: 6.293333rem /* 118/18.75 */;
      flex:1;
      display: flex;
      flex-direction: column;
      border-radius: .213333rem /* 4/18.75 */;
      margin-left: 1.013333rem /* 19/18.75 */;
      transition: all 500ms;
      box-shadow: 0px 1px 8px 0px rgba(0,0,0,.05);
      text-align: center;
      font-size: .746667rem /* 14/18.75 */;
      &:first-child{
        margin-left:0;
      }
      &.active{
        box-shadow: 0px 1px 8px 0px rgba(0,0,0,.12);
        .line_active {
          transform:scale(1,1);
        }
      }
      .dailyprice{
        flex:1;
        display: flex;
        flex-direction: column;
        justify-content: center;
        font-size: .533333rem /* 10/18.75 */;
        color:rgb(102,102,102);
        p{
          line-height: .746667rem /* 14/18.75 */;
          color:#666666;
        }
      }
      .line_active{
        width: 2.293333rem /* 43/18.75 */;
        height: .106667rem /* 2/18.75 */;
        background: rgb(255,84,75);
        transition: all 500ms;
        transform:scale(0,1);
        transform-origin:50% 50%;
        border-radius: .106667rem /* 2/18.75 */;
      }
      .price{
        height: 1.493333rem /* 28/18.75 */;
        line-height: 1.493333rem /* 28/18.75 */;
        span{
          font-size: 1.066667rem /* 20/18.75 */;
          position: relative;
          font-weight: 500;
          &::before{
            content:'';
            display: block;
            position: absolute;
            left: -.48rem /* 9/18.75 */;
            bottom:.266667rem /* 5/18.75 */;
            z-index: 1;
            background: url('http://yimg.yi23.net/webimg/web/images/20180604/price_icon@3x.png') no-repeat;
            background-size: 100%;
            //font-size: .746667rem /* 14/18.75 */;
            color:rgb(17,17,17);
            font-weight: normal;
            width: .48rem /* 9/18.75 */;
            height: .533333rem /* 10/18.75 */;
            overflow: hidden;
          }
          // &::after{
          //   content:'';
          //   display: block;
          //   position: absolute;
          //   left: 0;
          //   bottom:-.32rem /* 6/18.75 */;
          //   width: 2.293333rem /* 43/18.75 */;
          //   height: .106667rem /* 2/18.75 */;
          //   background: rgb(255,84,75);
          //   border-radius: .106667rem /* 2/18.75 */;
          //   z-index: 1;

          // }
        }

      }
    }
    .tips{
      width: 4.586667rem /* 86/18.75 */;
      height: 1.333333rem /* 25/18.75 */;
      line-height: 1.333333rem /* 25/18.75 */;
      text-align: center;
      //overflow: hidden;
      position: absolute;
      z-index: 2;
      left:50%;
      top: -1.173333rem /* 22/18.75 */;
      transform: translate(-50%,0);
      border-radius: 1.333333rem /* 25/18.75 */;
      background: rgb(157,188,202);
      color: #fff;
      font-size: .533333rem /* 10/18.75 */;
      &:after{
        content:'';
        display: block;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-top: 5px solid rgb(157,188,202);
        position: absolute;
        z-index: 3;
        left: 50%;
        transform: translate(-50%,0);
      }
    }
  }
  .slider-tab{
    .agreen-btn{
      padding: 0 1.226667rem /* 23/18.75 */;
      height: 2.613333rem /* 49/18.75 */;
      line-height: 2.613333rem /* 49/18.75 */;
      span{
        vertical-align: middle;
        display: inline-block;
        width: .746667rem /* 14/18.75 */;
        height: .746667rem /* 14/18.75 */;
        border-radius: 50%;
        border: 1px solid rgba(0,0,0,.1);
        position: relative;
        &.active{
          background:#ff544b;
          border:1px solid #ff544b;
          img{
            transform: scale(1);
            opacity: 1;
          }
        }
        img{
          width: 100%;
          position: absolute;
          left: 0;
          top:0;
          z-index: 1;
          transition: all 300ms;
          transform: scale(.1);
          opacity: 0;
        }
        input{
          position: absolute;
          left: 0;
          top:0;
          width: 15px;
          height: 15px;
          opacity: 0;
          z-index: 2;
        }
      }
      i{
        display: inline-block;
        vertical-align: middle;
        width: .853333rem /* 16/18.75 */;
        height: .853333rem /* 16/18.75 */;
        box-sizing: border-box;
        border-radius: 50%;
        border: 1px solid rgba(0,0,0,.2);
        color:  rgba(0,0,0,.2);
        font-size: .533333rem /* 10/18.75 */;
        text-align: center;
        line-height: .853333rem /* 16/18.75 */;
      }
    }

    .dec{
      font-size: .64rem /* 12/18.75 */;
      color: rgb(17,17,17);
      vertical-align: middle;
    }
  }
  .paymenttype{
    display: flex;
    background: #fff;
    padding: 0 23px;
    margin-top:.64rem /* 12/18.75 */;
    line-height: 2.346667rem /* 44/18.75 */;
    font-size: 0.746667rem /* 14/18.75 */;
    color: #111111;
    &>div:nth-child(2){
      flex:1;
      text-align: right;
      font-size:0;
      img{
        display: inline-block;
        width: .746667rem /* 14/18.75 */;
        height: .746667rem /* 14/18.75 */;
        vertical-align: middle;
      }
      span{
        margin-left:.213333rem /* 4/18.75 */;
        font-size: 0.746667rem /* 14/18.75 */;
        vertical-align: middle;
      }
    }
  }
  .paypage {
    display: flex;
    flex-direction: column;
    //-webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    background: #fff;
    height: 100%;
    .wrapper {
      flex: 1;
      width: 100%;
      overflow-y: scroll;
      .card-content {
        h2 {
          font-size: @font-size-medium-x;
        }
        p {
          font-size: 20px;
          line-height: 30px;
          font-weight: 600;
          i {
            font-style: normal;
          }
        }
        span {
          font-size: @font-size-small;
        }
        img {
          display: block;
          width: 100%;
        }
      }
      .swiper-box {
        background: #fff;
        margin-bottom: .533333rem /* 10/18.75 */;
        .swiper-slide {
          color: rgba(0,0,0,.2);
          text-align: center;
        }
        .swiper-slide-active {
          color: rgba(0,0,0,1);
        }
      }
      .card_message {
        display: block;
        box-sizing: border-box;
        width: 100%;
        padding: 0 23px;
        background-color: #fff;
        .bordertop {
          .px-top();
          border-color: rgba(0,0,0,1);
          padding: 10px 0 5px;
        }
        .all {
          .item {
            font-size: @font-size-medium-x;
            font-weight: @font-weight-l;
          }
        }
        .payment-zmxy{
          .notes{
            margin-bottom: 20px;
            font-size: 10px;
            color: #999;
            font-weight: 500;
            i{
              font-size: 18px;
              color: #FF544B;
              font-weight: 500;
              vertical-align: -webkit-baseline-middle;
              vertical-align: middle;
            }
          }
          .payment-zmxy-sm{
            display: flex;
            background: #FAFAFA;
            border-radius: 2px;
            padding: 1.066667rem /* 20/18.75 */ .906667rem /* 17/18.75 */ 1.066667rem /* 20/18.75 */ .533333rem /* 10/18.75 */;
            align-items: center;
            justify-content: center;
            & > img{
              display: block;
              width: 30px;
            }
            .inner{
              flex:1;
              padding: 0 5px;
              p{
                font-size: 12px;
                &:nth-child(2){
                  color: #999;
                }
              }
            }
            .payment-zmxy-sm-R1{
              width: 55px;
              height: 26px;
              color: #cdab6a;
              text-align: center;
              line-height: 26px;
              border: 1px rgba(205,171,106,.5) solid;
              font-size: 10px;
              padding: 0 5px;
              i{
                font-style: normal;
              }
            }
            .payment-zmxy-checkbox{
              width: 21px;
              height: 21px;

              .checkbox{
                position: relative;
              }
              input[type="checkbox"]{
                position: absolute;
                left: 0;
                top: 0;
                width: 21px;
                height: 21px;
                opacity: 0;
              }
              label{
                display: block;
                width: 1.12rem /* 21/18.75 */;
                height: 1.12rem /* 21/18.75 */;
                border: 1px solid #cccccc;
                background-color: #fafafa;
                &.checked{
                  background: #111 url(https://tu.95vintage.com/web_source/Home/Common/images/dui1.svg) 100% 0 no-repeat;
                  background-size: cover;
                  border: 1px solid #111;
                }
              }
            }
          }
        }
        .item {
          display: flex;
          line-height: 2.56rem /* 48/18.75 */;
          font-size: .746667rem /* 14/18.75 */;
          position: relative;
          color:rgb(17,17,17);
          &:after{
                content: " ";
                position: absolute;
                left: 0;
                bottom: 0;
                right: 0;
                height: 1px;
                border-bottom: 1px solid rgba(0, 0, 0, 0.1);
                color: rgba(0, 0, 0, 0.1);
                -webkit-transform-origin: 0 100%;
                transform-origin: 0 100%;
                -webkit-transform: scaleY(0.5);
                transform: scaleY(0.5);
          }
          &:last-child:after{
            content:none;
          }
          p {
            flex: 1;
            a{
              i{
                position: relative;
                top: 2px;
                width: 0px;
                height: 0px;
                img{
                  width: 14px;
                }
              }
            }
          }
          i {
            font-style: normal;
          }
        }
      }
    }
    .gopay {
      width: 100%;
      height: 52px;
      color: #fff;
      background:#ff544b;
      text-align: center;
      line-height: 52px;
      span {
        font-size: @font-size-medium;
        font-weight: @font-weight-l;
      }
    }
  }

  .depositname{
    margin-right: .373333rem /* 7/18.75 */;
  }

  /*0515更新*/
  .PayAgreement{
    padding: .533333rem  1.066667rem /* 20/18.75 */ 1.28rem /* 24/18.75 */ 1.066667rem /* 20/18.75 */;
    p{
      color:#999;
      line-height: 1.5;
      font-size: 12px;
      i:first-of-type{
        vertical-align: -webkit-baseline-middle;
        font-size: 10px;
      }
      i:last-of-type{
        text-decoration: underline;
      }
    }
  }
  .couponsShow();

  // 0714 wt
.bottomPay{
  width: 100%;
  height: 52 * @unit;
  line-height: 52 * @unit;
  display: flex;
  background-color: #fff;
  box-shadow: 0 -.053333rem /* 1/18.75 */ .213333rem /* 4/18.75 */ 0px rgba(0,0,0,.05);
  position: relative;
  z-index: 3;
}
.bottomPay .left{
  flex:1;
  font-size: 16 * @unit;
  padding-left:20px;
  span{
    padding-left:6px;
    color:#ff544b;
    font-size: .746667rem /* 14/18.75 */;
  }
  i{
    color:#ff544b;
    font-size: 1.066667rem /* 20/18.75 */;
    margin-left: 2px;
  }
}
.bottomPay .right{
  box-shadow: 0 -.053333rem /* 1/18.75 */ .213333rem /* 4/18.75 */ 0px rgba(0,0,0,.05);
  width: 142 * @unit;
  background:#ff544b;
  font-size: 14 * @unit;
  text-align: center;
  color:#fff;
}

.inviteCode{
  position: absolute;
  top: 50%;
  left: 50%;
  .width(239);
  background: pink;
  background: #fff;
  z-index: 99;
  transform: translateX(-50%) translateY(-50%);
  border-radius: 7px;
}

.inviteCodeMask{
  background-color: rgba(37, 38, 45, 0.4);
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  /*FF IE7*/
  z-index: 98;
  position: fixed!important;
  /*FF IE7*/
  position: absolute;
  /*IE6*/
}
.inviteCodeTitle{
  text-align:center;
  .font-size(16);
  .padding(28,0,14,0);
  color:#000;
}
.inviteCodeCont{
  .padding(0,20,0,20);
  input{
    width: 100%;
    .height(40);
    .padding(2,0,15,0);
    display: block;
    background: #fff;
    .font-size(14);
    color:rgba(0,0,0,1);
  }
}
.inviteCodeBtn{
  flex:1;
  display: flex;
  width:100%;
  button{
    .font-size(17);
    background: transparent;
    flex:1;
    .height(50);
    border-top:1px #E5E5E5 solid;
  }
  button.rightBtn{
    border-left: 1px #E5E5E5 solid;
    color:#ff544b;
  }
}
input::-webkit-input-placeholder{
  color:rgba(0,0,0,.3);
}
input::-moz-placeholder{   /* Mozilla Firefox 19+ */
  color:rgba(0,0,0,.3);
}
input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
  color:rgba(0,0,0,.3);
}
input:-ms-input-placeholder{  /* Internet Explorer 10-11 */
  color:rgba(0,0,0,.3);
}
</style>
