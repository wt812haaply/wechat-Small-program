<template>
  <div>
    <ul>
      <li>
        <h2 @click="btnClick('a')">1</h2>
        <p v-show="a">111</p>
      </li>

      <li>
        <h2 @click="btnClick('b')">2</h2>
        <p  class="abc" v-show="b">222333</p>
      </li>

      <li>
        <h2 @click="btnClick('c')">3</h2>
        <p  class="abc" v-show="c">
          您在APP选衣页面选中自己喜爱的美衣，在单品详情页点击租这件，选择自身穿衣尺码，再点选租这件，进入衣箱下单即可。
        </p>
      </li>

      <li>
        <h2 @click="btnClick('d')">4</h2>
        <p class="abc"  v-show="d">4444</p>
      </li>

      <li>
        <h2 @click="btnClick('e')">5</h2>
        <p class="abc"  v-show="e">4444</p>
      </li>
    </ul>
  </div>
</template>


<script>
  export default {
    data() {
      return {
        a:true,
        b:false,
        c:false,
        d:false,
        e:false,
      }
    },
    methods:{
      btnClick: function(rrrr) {
        this[rrrr] = !this[rrrr]
        for(let k in this.$data) {
//          console.log(k)
          if( k != rrrr ){
            this[k] = false
          }
        }
      }
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.abc{
  position:relative;
  /*height:100px;*/
  animation:mymove 1s none;
  animation-delay:-10s;
  animation-name: fadeOutLeft;
  /*Safari and Chrome*/
  -webkit-animation:mymove 1s none;
  /* -webkit-animation-delay:-10s; */
  /* animation-iteration-count:3;
  -webkit-animation-iteration-count:3; */
}

  @keyframes mymove
  {
    /* from {right:0px;}
    to {right:60%;} */
    0%   {top:-10px; bottom:0px; opacity: 0.1}
    25%  {top:0px; bottom:00px;opacity: 0.8}
    50%  {top:0px; bottom:00px; opacity: 1}
    100%   {top:0px; bottom:0px;}
  }

  @-webkit-keyframes mymove /*Safari and Chrome*/
  {
    /* from {right:0px;}
    to {right:60%;} */
    0%   {top:-10px; bottom:0px; opacity: 0.1}
    25%  {top:0px; bottom:00px;opacity: 0.8}
    50%  {top:0px; bottom:00px;opacity: 1}
    100%   {top:0px; bottom:0px;}
  }
</style>



