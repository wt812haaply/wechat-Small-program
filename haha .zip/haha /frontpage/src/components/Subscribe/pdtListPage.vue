<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
      <ul class="listTopNav1">
        <li class="active">包月换衣</li>
        <li @click="routerNext">礼服次租</li>
      </ul>
      <ul class="listTopNav">
        <li @click="onLineClick" :class="{active:stockFirst==1?true:false}">{{stockFirstName}}<i class="icon yi23iconfont icon-down"></i></li>
        <li @click="showFilter" :class="{active:selectedSize}">尺码<i class="icon yi23iconfont icon-down"></i></li>
        <li @click="showFilter" :class="{active:selectedFilter}">筛选<i class="icon yi23iconfont icon-down"></i></li>
      </ul>
      <BounceInLeft>
        <div class="topNavCon" v-show="noLineNav">
          <yi23-radiolist :options="lineData" v-model="stockFirst">
            <div slot="leftBox" slot-scope="props" class="textCell">{{props.option.label}}</div>
          </yi23-radiolist>
        </div>
      </BounceInLeft>
    </div>
    <div class="yclosetCon bG"  ref="scrollBox" v-show="!nothing"><!--核心内容部分-->
      <div class="List">
        <ul class="listCon" v-infinite-scroll="loadMore"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10">

            <prd-list :prodList="prodList" :tipsStatus="true"></prd-list>
        </ul>
      </div>
      <loading-components v-show="loading">加载中...</loading-components>
    </div>

    <div class="yclosetCon NotAThing bG"  v-show="nothing">
      <div class="NotAThingCon ">
        <h2>NOT A THING</h2>
        <p>找不到，请调整筛选条件</p>
      </div>
    </div>





    <div class="filterBox" v-show="isShowFilter" @click="hideFilter">
      <fade-in-right>
          <div class="content" v-if="isShowFilter" @click="stopHideFilter">
              <yi23-checklist-btn :options="filterResult.productSizeFilter.dataList" v-model="select.size" name="filterName" title="尺码"></yi23-checklist-btn>
              <yi23-checklist-btn :options="filterResult.productTypeFilter.dataList" v-model="select.type_id" title="品类"></yi23-checklist-btn>
              <yi23-checklist-btn :options="filterResult.sceneFilter.dataList" v-model="select.scene" title="场景"></yi23-checklist-btn>
              <yi23-checklist-btn :options="filterResult.customizedFilter.dataList" v-model="select.filterId" title="最近上新"></yi23-checklist-btn>
              <yi23-checklist-btn :options="filterResult.productSeasonFilter.dataList" v-model="select.season" title="季节"></yi23-checklist-btn>
              <yi23-check-list-img :options="filterResult.colorFilterList" v-model="select.color_id" title="颜色"></yi23-check-list-img>
              <div class="filterFooter">
                <div class="revert" @click="revertFilter">重置</div>
                <div class="submit" @click="submitFilter">保存筛选</div>
              </div>
          </div>

      </fade-in-right>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar :pageNumber="1"></bottom-Bar>
    </div>
  </div>
</template>
<script>
  import loadingComponents from '@/components/lib/Loading'
  import goBack from 'base/GoBack'
  import bottomBar from 'base/BottomBar'
  import config from '@/api/config'
  import BounceInLeft from '@/components/lib/transition/BounceInLeft'
  import FadeInRight from '@/components/lib/transition/FadeInRight'
  import Yi23Radiolist from "@/components/lib/form/radioList"
  import yi23ChecklistBtn from '@/components/lib/form/checkListBtn'
  import Yi23RadiolistBtn from "@/components/lib/form/radioListBtn"
  import Yi23CheckListImg from "@/components/lib/form/checkListImg"
  import prdList from '@/base/List'
  export default {
    data () {
      return{
        nothing:false,
        noLineNav:false,
        stockFirst:'1',
        isShowFilter:false,
        size:[],
        lineData:[{label: '全部', value: '0'},{label: '在架优先', value: '1'}],
        sizeData:[{label: 'XS', value: 'XS'},{label: 'S', value: 'S'},{label: 'M', value: 'M'},{label: 'L', value: 'L'},{label: 'XL', value: 'XL'},{label: '均码F', value: 'F'}],
        crrentNav:null,
        select:{
          type_id:[],
          size:[],
          scene:[],
          season:[],
          brand_id:[],
          filterId:[],
          color_id:[]
        },
        filterResult:null,
        otherFilter:null,
        relatedFilter:null,
        loading:false,
        prodList:[],
        count:20,
        totalPage:null,
        page:1,
        canLoading:true,
      }
    },
    components:{
      Yi23Radiolist,
      yi23ChecklistBtn,
      Yi23RadiolistBtn,
      Yi23CheckListImg,
      goBack,
      prdList,
      loadingComponents,
      BounceInLeft,
      FadeInRight,
      bottomBar
    },
    watch:{
      stockFirst () {
        this.noLineNav=false
        this.page=1
        this.getProdList()
        this.$refs.scrollBox.scrollTop=0
      }
    },
    computed: {
      stockFirstName () {
        if(this.stockFirst==0){
          return '全部'
        }else {
          return '在架优先'
        }
      },
      selectedSize () {
        if(this.select.size.length>0){
          return true
        }else{
          return false
        }
      },
      selectedFilter () {
        if(this.select.scene.length>0 || this.select.season.length>0 || this.select['color_id'].length>0 ||  this.select['type_id'].length>0  || this.select.filterId.length>0){
          return true
        }else{
          return false
        }
      }
    },
    created () {
      let query=this.$route.query;
      console.log(query)

      for(var k in query) {
        // console.log(k)
        switch (k){
          case "showall":
            this.stockFirst=query[k]
            break;
          case "type_id":
            this.select.type_id=decodeURIComponent(query['type_id']).split(',')
            break;
          case "color_id":
            this.select.color_id=decodeURIComponent(query['color_id']).split(',')
            break;
          case "scene":
            this.select.scene=decodeURIComponent(query['scene']).split(',')
            break;
          case "size":
            this.select.size=decodeURIComponent(query['size']).split(',')
          case "brand_id":
            this.select.brand_id=decodeURIComponent(query['brand_id']).split(',')
            break;
        }
      }
      this.getProdList()
      this.axios.get(config.categoryPage).then((res)=>{
        if(res.data.code==200){
          this.filterResult=res.data.data.filterResult
        }
      })
    },
    methods: {
      onLineClick:function () {
        this.isShowFilter=false
        if(this.noLineNav){
          this.noLineNav=false
        }else{
          this.noLineNav=true
        }
      },
      showFilter:function () {
        this.noLineNav=false
        if(this.isShowFilter){
          this.isShowFilter=false
        }else if(this.filterResult){
          this.isShowFilter=true
        }
      },
      hideFilter () {
        if(this.isShowFilter){
          this.isShowFilter=false
        }
      },
      revertFilter () {
        this.select={
          type_id:[],
          size:[],
          scene:[],
          season:[],
          filterId:[],
          color_id:[]
        }
        this.page=1
        this.getProdList()
        this.$refs.scrollBox.scrollTop=0
        this.isShowFilter=false
      },
      submitFilter () {
        this.page=1
        this.getProdList()
        this.$refs.scrollBox.scrollTop=0
        this.isShowFilter=false
      },
      stopHideFilter (e) {
        e.stopPropagation()
      },
      isArray (obj) {
        if(Object.prototype.toString.call(obj).slice(8,-1)=='Array'){
          return true
        }else{
          return false
        }
      },
      getProdList (isConcat) {
        this.loading=true
        this.nothing=false
        let options= {
          page:this.page,
          count:this.count,
          stockFirst:this.stockFirst
        }
        for (var k in this.select){
          // options[k]=this.isArray(this.select[k])?this.select[k].join(','):this.select[k]
          options[k] = this.select[k]
        }
        this.axios.get(config.productList,
          {
            params:options,
            // headers: {
            //   'hideLoading':true
            // }
          }).then((res)=>{
          if(res.data.code==200){
            this.canLoading=true
            this.totalPage=res.data.data.totalPage
            if(isConcat){
              this.prodList=this.prodList.concat(res.data.data.product)
            }else{
              this.prodList=res.data.data.product
            }
            if(!res.data.data.product || res.data.data.product.length==0){
              this.canLoading=false
            }
            if(this.prodList.length==0){
              this.nothing=true
            }
            this.page=this.page+1
          }else{
            this.canLoading=false
          }
          this.loading=false
        })
      },
      loadMore () {
        if(this.page <= this.totalPage && this.canLoading){
          this.canLoading = false
          this.getProdList(true)
        }
      },
      routerNext(){
        this.$router.push({
          path: '/Gown/gownListPage'
        })
      }
    },
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";

  .yclosetHeader{
    height: auto;
  }
  .yclosetCon{
    padding-top: 10px;
  }
  .topNavCon{
    width:100%;
    overflow: hidden;
    background-color:#fff;
    .textCell{
      font-size: 12px;
      line-height: 3;
      text-align: center;
      color: #666;
    }
    .submitSize{
        span{
          display: block;
          width: 100px;
          font-size: 12px;
          line-height: 2.7;
          background: #ff544b;
          text-align: center;
          color: #ffffff;
          float: right;
          margin-right:10px;
          border-radius: 3px;
        }
      overflow: hidden;
      padding: 5px 0;

    }
  }
  ul.listTopNav{
    height:46px;
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    border-bottom: 1px rgba(0,0,0,.05) solid;
    li.active{
      color: #ff544b;
    }
    li{
      display: flex;
      align-items: center;
      justify-content:center;;
      width:33.3333%;
      font-size: 12px;
      position: relative;
      i{
        font-size: 6px;
        margin-left: 5px;
      }
      i.active{

      }

    }

  }
  .image-ratio:after{
    padding-top: 100%;
  }
  .icon-wish{
    position: absolute;
    top:8px;
    right:8px;
    font-size:16px;
    color: #999;
  }

  .yclosetContainer{
    background: #fafafa;
  }
  /*img placeholder*/
  .List{
    display: flex;
    width:100%;
    ul.listCon{
      margin:0 2%;
      display: flex;
      flex-wrap: wrap;
      justify-content:space-between;
      width: 100%;
      height:auto;
      padding-bottom: 10px;
      li{
        display: flex;
        flex-wrap: wrap;
        width:49%;
        height:auto;

          .liIMG{
              padding-bottom: 124.9333%;
            }
        .liAttribute{
            display: flex;
            flex-wrap: wrap;
            width:100%;
            padding: 12px 10px 18px 10px;
            p{
              font-size: 12px;
              width:100%;
              flex-wrap: wrap;
              line-height: 1.5;
              color: #333;
            }
            p.Name{

            }
            p.Size{
              i{
                padding-right:5px;
                color:#999;
                font-size: 14px;
              }
              i:last-of-type{
                padding:0;
              }
            }
          }

      }
    }
  }


.etr{
  position: absolute;
  top:8px;
  right: 10px;
}
  .filterBox{
    position: fixed;
    width: 100%;
    right: 0;
    z-index: 100;
    left: 0;
    top: 0;
    bottom: 0;
    overflow-y:scroll;
    overflow-scrolling: touch;
    background: rgba(0, 0, 0, 0.54);
    box-sizing: border-box;
    padding-left: 10%;
    .content{
      background: #ffffff;
      position: relative;
      width: 100%;
      padding-bottom: 80px;
      min-height: 100%;
      box-sizing: border-box;
    }
    .filterFooter{
      position: fixed;
      bottom: 0;
      left: 10%;
      right: 0;
      display: flex;
      line-height: 44px;
      font-size: 14px;
      color: #ffffff;
      text-align: center;
      .revert{
        flex: 1;

        background: #000000;
      }
      .submit{
        flex: 1;
        background: #ff544b;
      }
    }
  }

  .NotAThing{
    display: flex;
    justify-content: center;
    align-items:center;
    flex-wrap: wrap;
    width:100%;
    &Con{
      height:auto;
    h2,p{
      width: 100%;
    }
    h2{
      .font-size(20);
      line-height: 2;
      letter-spacing: .2px;
    }
    p{
      .font-size(12);
    }
    }
  }
  ul.listTopNav1{
    height:40px;
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    /*margin-bottom: .5rem;*/
    border-bottom: 1px rgba(0,0,0,.05) solid;
    justify-content: center;
    li.active{
      color: #ff544b;
      position: relative;
    }
    li.active:after{
      content: '';
      width: 20%;
      height: 2px;
      position: absolute;
      bottom: 1px;
      left: 40%;
      z-index: 1;
      background: red;
    }

    li{
      display: flex;
      align-items: center;
      justify-content:center;;
      width:33.3333%;
      font-size: 12px;
      position: relative;
      i{
        font-size: 6px;
        margin-left: 5px;
      }
      i.active{

      }

    }

  }
</style>
