<template>
  <div class="yclosetContainer productDetail"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG" v-if="pdtDetail" ref="yclosetCon" ><!--核心内容部分-->

      <bounce-in-up>
        <div class="tipPro" v-show="tipSizeStats" v-if="pdtDetail">
          <div class="tipProCon">
            <div class="tipClose" @click="tipsShade"><i class="yi23iconfont icon-close"></i></div>
            <div class="tipProConTop">
              <div class="Left">
                <img :src="pdtDetail.product_info.thumb_pic" alt="">
              </div>
              <div class="Right">
                <p class="RightName">{{pdtDetail.product_info.product_name}}</p>
                <p class="RightBrand">{{pdtDetail.product_info.brand_name}}</p>
              </div>
            </div>
            <div class="tipProConCenter">
              <span>请选择尺码</span>
              <span class="topProductBrand font-m" v-if="pdtDetail.size_info.length >= 1"  @click="sizeDetailClick(pdtDetail.product_info.product_id)">
             尺码详情<i class="yi23iconfont icon-arrow"></i>
           </span>
            </div>
            <div class="tipProConBottom">
              <ul class="tipSize">
                <li :class="{'active': activeSize == item.size}" @click="sizeActive(item.size,item.sku_id)" v-for="item of pdtDetail.sku_info" v-if="item.stock > 0">{{item.size}}</li>
                <li class="noSize" v-else>{{item.size}}</li>
              </ul>
            </div>
          </div>
        </div>
      </bounce-in-up>

      <!--轻奢-->
      <yi23Dialog @dialogOk="dialogOk" @dialogClose="dialogClose" :open="dialogOpen" :dialogSm='dialogSm' :hasCannel="true" @show="showDialog">
        <img slot="banner" width="100%" src="//yimg.yi23.net/webimg/web/images/20180604/Bitmap@2x.jpg">
        <h6 slot="header" style="font-size: 16px;">轻奢商品特权</h6>
        <div slot="body">
          <div class="yi23-dialog__bd" style="color: #666666;"> 该商品仅限月卡及以上会员下单
            升级会员即可享受轻奢商品换穿特权</div>
        </div>
        <div slot="btnCannel">我知道了</div>
        <div slot="btnOk">升级会员</div>
      </yi23Dialog>

      <div v-show="tipSizeStats" class="yclosetShade" @click="tipsShade"></div>

      <div class="product" >
        <div class="topProduct">
          <div class="popLeft" v-if="pdtDetail">
            <img :src="pdtDetail.product_info.showTapPath" alt="">
          </div>
          <div class="popRight">
            <collect v-model="pdtDetail.product_info.isFavor" :favor="pdtDetail.product_info.isFavor" :id="pdtDetail.product_info.product_id" :path="singlePath"></collect>
          </div>
          <div class="topProductSlide" >

            <swiper :options="swiperOptionFirst">
              <swiper-slide v-for="(item, indexPic) of pdtDetail.product_info.picture" :key="item">
                <div class="imgP image-ratio">
                  <img :src="item" alt="" @click="showAlertImg(indexPic,pdtDetail.product_info.picture)">
                </div>
              </swiper-slide>
              <div class="swiper-pagination" slot="pagination">

              </div>
            </swiper>

            <div class="cap" v-if="pdtDetail.userStatus == 0 || pdtDetail.userStatus == 2">
              <i class="capA">FREE</i>
              <i class="capB">开通会员免费穿</i>
            </div>

          </div>
          <div class="proBrandOrVipUser">
            <div class="topProductBrand" @click="brandClick(pdtDetail.product.brand_id)">
              {{pdtDetail.product_info.brand_name}}<i class="yi23iconfont icon-right"></i>
            </div>
            <div class="proVipUser">
              <p class="vipUser" v-if="pdtDetail.userStatus == 0 || pdtDetail.userStatus == 2">市场价: <i>￥{{pdtDetail.product_info.market_price}}</i></p>
              <p v-else>会员<i>免费</i></p>
            </div>
          </div>
          <div class="topProductName font-m">{{pdtDetail.product_info.product_name}}</div>
          <div class="topProductSize">
            <ul class="SizeList">
              <li :class="{'active': activeSize == item.size}" @click="sizeActive(item.size,item.sku_id)" v-for="item of pdtDetail.sku_info" v-if="item.stock > 0">{{item.size}}</li>
              <li class="noSize" v-else>{{item.size}}</li>
            </ul>

            <div class="SizeDetail" v-if="pdtDetail.size_info.length >= 1"  @click="sizeDetailClick(pdtDetail.product_info.product_id)">
              尺码详情<i class="yi23iconfont icon-arrow"></i>
            </div>

          </div>
        </div>
        <div class="productsDetail">

          <div class="z_brand" @click="toBrand(pdtDetail.brandInfo.brandName)" >
            <div class="z_brandInfo">

              <div class="z_brandImg">
                <img :src="pdtDetail.brandInfo.coverUrl" alt="">
              </div>
              <div class="z_brandTitle">
                <div class="z_brandN">{{pdtDetail.brandInfo.brandName}}</div>
                <div class="z_skipBrand">
                  <div>进入品牌</div>
                  <div class="z_brandArr"><img  src='https://yimg.yi23.net/aliminiapp/aliapp/zArrow.png' alt=""></div>
                </div>
              </div>
            </div>
            <div class="z_brandArrow"></div>
          </div>
          <div class="z_bannerInfo" v-if="pdtDetail.bannerInfo">
            <div class="z_bannerImg" >
              <img :src="pdtDetail.bannerInfo.imageUrl" alt="">
            </div>
          </div>
          <div class="z_clotheSize" >
            <div class="z_infoTitle">尺码详情</div>
            <div class="z_table" style="flex-direction: row">
              <div class="infoConListLeft">
                <div>尺码</div>
                <div v-for="item of pdtDetail.newSizeInfo.sizeDetail">{{item.column}}</div>
              </div>
              <div class="infoConListRight" >
                <div class="addBackground">
                  <div v-for="item of pdtDetail.newSizeInfo.firstColumn">{{item}}</div>
                </div>
                <div v-for="item of pdtDetail.newSizeInfo.sizeDetail">
                  <div v-for="item of item.size">{{item}}</div>
                </div>
              </div>
            </div>
          </div>
          <div class="z_basicInfo">
            <div class="z_infoTitle">商品信息</div>
            <div class="z_table">
              <div class="infoConList" v-if="pdtDetail.product_info.market_price">
                <span>参考价格</span>
                <span class="addWidth">¥{{pdtDetail.product_info.market_price}}</span>
              </div>
              <div class="infoConList" v-if="pdtDetail.product_info.type_name">
                <span>品类</span>
                <span class="addWidth">{{pdtDetail.product_info.type_name}}</span>
              </div>
              <div class="infoConList" v-if="pdtDetail.product_info.material_name">
                <span>材质详情</span>
                <span class="addWidth">{{pdtDetail.product_info.material_name}}</span>
              </div>
              <div class="infoConList" v-if="pdtDetail.product_info.remark">
                <span>特殊说明</span>
                <span class="addWidth">{{pdtDetail.product_info.remark}}</span>
              </div>
              <div class="infoConList" v-if="pdtDetail.product_info.slot && pdtDetail.product_info.slot > 1">
                <span>衣位说明</span>
                <span class="addWidth">该单品占{{pdtDetail.product_info.slot}}个衣位</span>
              </div>
            </div>
            <div class="z_brandStory"  v-if="pdtDetail.brandInfo">
              <div class="z_infoTitle" >品牌故事</div>
              <div class="z_brandName">{{pdtDetail.brandInfo.brandName}}</div>
              <div :class="isMore ? 'closeLimit' : 'z_textContent' ">
                {{pdtDetail.brandInfo.brandProfile}}
              </div>
              <div class="selMore" @click="takeUpCon" v-if="isMore && pdtDetail.brandInfo.brandProfile.length > 100" >
                <div>
                  收起
                  <div class="comMoreImg takeUpImg"></div>
                </div>
              </div>
              <div class="selMore" @click="addMore" v-if="!isMore &&pdtDetail.brandInfo.brandProfile.length > 100">
                <div>
                  更多
                  <div class="comMoreImg"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="evaluateCon" v-if="productFeedback && productFeedback.feedbackList">
          <div class="evaluaeTitle">
            <div class="siftEval">精选评价</div>
            <div class="l-evalbox row">
              <!--<div class="stars" data-percent="1"></div>-->
              <template v-if="pdtDetail.product_info.feedBackCount">
                <div id="stars" :class='"stars"+pdtDetail.product_info.feedBackScore' ></div>
                <span class="starsAmount">({{pdtDetail.product_info.feedBackCount}})</span>
              </template>
              <template v-else-if="!productFeedback.feedbackList.length">
                <span class="feedback__empty">暂无精选评价</span>
              </template>
            </div>
          </div>
          <div class="userEvaluteItem">
            <div class="user-item"  v-for="(item,index) in productFeedback.feedbackList" >
              <div class="userinfo flex">
                <div class="avater image-ratio">
                  <img :src="item.headImg">
                </div>
                <div class="right">
                  <p class="mobile">{{item.nickName}}</p>
                  <p class="tag-info"><span v-if="item.height">身高{{item.height}}cm&nbsp;|&nbsp;</span><span v-if="item.userSize">常穿{{item.userSize}}&nbsp;|&nbsp;</span><span v-if="item.size">穿过{{item.size}}</span></p>
                </div>
              </div>
              <div class="usersaid">
                {{item.review}}
              </div>
              <swiper :options="swiperOptionThird">
                <swiper-slide v-for="(pic,indexPic) of item.picture" :key="indexPic">
                    <div class="uselifephoto">
                      <!--<div class="uselifephoto-img-box" :style="{backgroundImage:`url(${pic})`}"  @click="showAlertImg(indexPic,item.picture)"></div>-->
                      <div class="uselifephoto-img-box"  @click="showAlertImg(indexPic,item.picture)">
                        <img :src="pic" alt="">
                      </div>
                    </div>
                </swiper-slide>
              </swiper>
            </div>
          </div>

          <!--<div class="moreEvaltue" @click="showMoreEvalute" v-if="moreEvalute == 1">-->
          <div class="moreEvaltue" v-if="productFeedback.pagination.numb > 3 && productFeedback.pagination.page < productFeedback.pagination.total" @click="getFeedbackMore">
            <div class="z_eval" >
              查看更多评价
              <div class="comMoreImg"></div>
            </div>
          </div>
          <!--<div class="moreEvaltue" v-else>-->
            <!--<div class="z_allval">-->
              <!--已加载全部精选评价-->
            <!--</div>-->
          <!--</div>-->
        </div>
        <div class="recommendCon" v-if="pdtDetailRecomment && pdtDetailRecomment.recommendedProducts.length > 0">
          <div class="z_recommendTitle">推荐搭配</div>
          <div class="List" >
            <ul class="listCon">
              <li  v-for="(item, index) of pdtDetailRecomment.recommendedProducts" @click="linkClick(item.product_id,item.path)" v-if="index < 20">
                <div class="Include">
                  <div class="z_tagType"
                       :class="{'product_tag_empty': item.tag.code == 1}"
                       :style="{background: item.tag.color}"
                       v-if="item.tag.code != 0">
                    <template v-if="item.tag.code != 2" >
                      {{item.tag.desc}}
                    </template>
                  </div>
                  <div class="imgP liIMG image-ratio">
                    <img  v-lazy="item.thumb_pic" alt="">
                  </div>
                </div>



                <div class="liAttribute">
                  <p class="Name">
                    <span v-if="item.brand_en_name">{{item.brand_en_name}}</span>
                  </p>
                  <p class="Brand">{{item.type_name}}</p>
                  <p class="Size">
                    <i v-for="size of item.sku_info">{{size.size}}</i>
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="recommendCon" v-if="pdtDetailRecomment && pdtDetailRecomment.relatedProducts.length > 0">
          <div class="z_recommendTitle">相似单品</div>
          <div class="List" >
            <ul class="listCon">
              <li  v-for="(item, index) of pdtDetailRecomment.relatedProducts" @click="linkClick(item.product_id,item.path)" v-if="index < 20">
                <div class="Include">
                  <div class="z_tagType"
                       :class="{'product_tag_empty': item.tag.code == 1}"
                       :style="{background: item.tag.color}"
                       v-if="item.tag.code != 0">
                    <template v-if="item.tag.code != 2" >
                      {{item.tag.desc}}
                    </template>
                  </div>
                  <div class="imgP liIMG image-ratio">
                    <img  v-lazy="item.thumb_pic" alt="">
                  </div>
                </div>
                <div class="liAttribute">
                  <p class="Name">
                    <span v-if="item.brand_en_name">{{item.brand_en_name}}</span>
                  </p>
                  <p class="Brand">{{item.type_name}}</p>
                  <p class="Size">
                    <i v-for="size of item.sku_info">{{size.size}}</i>
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="yclosetFooter"  v-if="pdtDetail">
      <div class="productFooter">
        <div class="callCenter" @click="openSDK()"><i class="yi23iconfont icon-service"></i></div>

        <router-link to="/ClothBox/box" tag="div" class="shopping">
          <i class="yi23iconfont icon-box2"></i>
          <i class="number">{{pdtDetail.product_info.box_num}}</i>
        </router-link>
      </div>

      <ul class="productFooterBtn" v-if="pdtDetail.product_info.stocknum > 0 && pdtDetail.isCanBuy != 0" >


        <li class="btn btn-defult btnBorA" @click="buyClick">
          <i></i>购买这件单品
        </li>

        <li class="btn btn-defult" @click="tipSizeShow"><i class="yi23iconfont icon-add1"></i>添加至衣箱</li>
      </ul>

      <ul class="productFooterBtn" v-if="pdtDetail.product_info.stocknum > 0 && pdtDetail.isCanBuy <= 0">
        <li class="btn btn-defult" @click="tipSizeShow"><i class="yi23iconfont icon-add1"></i>添加至衣箱</li>
      </ul>


      <ul class="productFooterBtn" v-if="pdtDetail.product_info.stocknum <= 0">
        <li class="btn btn-defult btn-black disabled">暂无库存</li>
      </ul>

    </div>

    <yi23Toast v-model="errorMsg"></yi23Toast>

    <yi23-alert-img :open="alertImgOpen" @alertImgClose="alertImgClose">
      <div class="topProductSlide">
        <swiper :options="swiperOptionSecond" ref="mySwiper">
          <swiper-slide v-for="(pic,index3) of pictureList" :key="index3">
            <div class="pictureBox">
              <img :src="pic" alt="">
            </div>
          </swiper-slide>
          <div class="swiper-pagination swiper-pagination3" slot="pagination">
          </div>
        </swiper>
      </div>
    </yi23-alert-img>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import List from 'base/List'
  import { newAddToCart, productsUrl, pdtDetailRecomment, feedbackUrl, recommendUrl} from 'api/subscribe'
  import BounceInUp from '@/components/lib/transition/BounceInUp'
  import  Collect from '@/base/Collect'
  import { mapGetters } from 'vuex'
  import  shareMixin  from '@/mixins/share';
  import store from "@/store"
  import {
    setTitle
  } from 'common/js/utils'
  export default {
    data () {
      return{
        singlePath:'',
        moreEvalute:1,
        variable:5,
        alertImgOpen: false,
        isMore:false,
        dialogOpen: false,
        dialogSm: true,
        pdtDetail:null,
        pdtDetailRecomment:null,
        topNav:false,
        tipSizeStats:false,
        pdtDetailPage:null,
        activeSize:'',
        activeSkuId:'',
        toastOpen:false,
        errorMsg:'',
        swiperOptionFirst: {
          spaceBetween: 10,
          effect:'fade',
          pagination: {
            el: '.swiper-pagination',
            bulletElement : 'li',
            clickable: true
          }
        },
        swiperOptionSecond: {
          slidesPerView: 1,
          spaceBetween: 30,
          mousewheel: true,
          pagination: {
            el: '.swiper-pagination3',
            clickable: true
          },
          notNextTick: true,
        },
        swiperOptionThird: {
          slidesPerView: 2,
          spaceBetween: 5,
        },
        // productFeedback:null,
        pictureList: [],
        // pagination: {
        //     page: 1,
        //     total: 0,
        //     numb: 0
        // }
        productFeedback: {
          feedbackList: [],
          pagination: {
            page: 1,
            total: 0,
            numb: 0
          }
        }
      }
    },
    mixins:[shareMixin],
    components:{
      goBack,
      List,
      BounceInUp,
      Collect,
    },
    watch: {
      $route: ["fetchData", "getpdtDetailRecomment", "getfeedBack"],
      pictureList:function (val, oldVal) {
        this.$nextTick(()=>{
          if(val.length > 0){
            this.swiper = this.$refs.mySwiper.swiper
            this.swiper.slideTo(this.pictureIndex)
          }
        })
      },
    },
    computed: {
      ...mapGetters({
        authorization: 'authorization'
      })
    },
    methods: {
      showDialog() {
        this.dialogOpen = true;
      },
      dialogOk() {
        this.$router.push({
          name: "PayPage",
        });
      },
      dialogClose() {
        console.log("close");
        this.dialogOpen = false;
      },

      openSDK: function(){
        window.location.href = ysf.url();
      },
      tipSizeShow:function () {
        if( !this.authorization){
          this.$router.push({
            path:'/loginPage',
            query: {redirect: this.$route.fullPath}
          })
          return false
        }
        if(this.activeSize){
          let path = this.singlePath
          let skuId = this.activeSkuId || ''
          let query = {}
          if(path){
            query.path = path
          }
          newAddToCart(query, skuId).then((res)=>{
            if(res.code==200 && res.data){
              console.log('添加成功')
              this.addToCart = res.data;
              this.pdtDetail.product_info.box_num = this.pdtDetail.product_info.box_num + 1;
            } else if (res.code == 109) {
              this.showDialog();
              return false;
            }
            this.errorMsg = res.msg;
            this.tipSizeStats = false;
          });
        }
        else {
          this.tipSizeStats = true;
        }
      },
      tipsShade:function () {
        this.tipSizeStats = false
      },
      linkClick:function(pid,path){
        if(!pid){
          return;
        }
        let query = { pid:pid }
        if(path) {
          query.path = path
        }
        this.$router.push({
          name: "pdtDetailPage",
          query: query
        });
      },

      //尺码详情
      sizeDetailClick:function(pid){
        this.$router.push({
          path:'/Subscribe/sizeDetailPage',
          query:{productId:pid}
        })
      },

      //品牌list
      brandClick:function(brand_id){
        this.$router.push({
          path:'/Subscribe/pdtListPage',
          query:{brand_id:brand_id}
        })
      },

      //成为会员
      userClick:function(){
        window.location.href='/yi23/Home/Member/payPage'
      },

      //购买这件单品
      buyClick:function(){
        if(this.activeSize){
          let sku_id= this.activeSkuId
          this.$router.push({
            path:'/Buy/buyPage',
            query:{skuId:sku_id,path:this.pdtDetail.path || ''}
          })
        }
        else {
          this.tipSizeStats = true;
        }
      },

      sizeActive(size,skuId){
        if(this.activeSize != size){
          this.activeSize = size;
          this.activeSkuId=skuId
          return false;
        }
        this.activeSize = '';
        this.activeSkuId='';
      },
      fetchData() {
        let id = this.$route.query.pid
        let params = {
          url: window.location.href,
        }
        let options = {}
        if(this.$route.query && this.$route.query.path){
          options.path = this.$route.query.path
        }
        this.setShareMessage(params);
        productsUrl(id,options).then((res)=>{
          this.$nextTick(function () {
            // setTitle(res.data.product.product_name)
            this.$refs.yclosetCon?this.$refs.yclosetCon.scrollTop=0:''
          })

          if(res.data && JSON.stringify(res.data) != '{}' && res.data.product_info.is_alive != 1){
            this.$router.replace({name:'index'})
          }

          this.pdtDetail = res.data;
          this.singlePath = res.data.path;
          this.activeSkuId = null;
          this.activeSize = null;
        });
      },

      getpdtDetailRecomment(){
        let id= this.$route.query.pid
//        let params = {
//          url: window.location.href,
//        }
//        this.setShareMessage(params);
        recommendUrl(id).then((res)=>{
//          this.$nextTick(function () {
//            // setTitle(res.data.product.product_name)
//            this.$refs.yclosetCon?this.$refs.yclosetCon.scrollTop=0:''
//          })

          this.pdtDetailRecomment = res.data;
          this.activeSkuId = null;
          this.activeSize = null;
          store.commit('bigLoading', false)
        });
      },
      getfeedBack() {
        let id = this.$route.query.pid;
        feedbackUrl(id, {
          count: 3
        }).then(res => {
          if (res.code == 200 && res.data) {
            this.productFeedback = res.data;
            const pagination =  res.data.pageInfo;
            this.productFeedback.pagination = {
              page: pagination.page,
              total: pagination.totalPage,
              numb: pagination.totalNum
            }
          } else {
            this.errorMsg = res.msg;
          }
        });
      },
      getFeedbackMore () {
        const page = this.productFeedback.pagination.page + 1;
        if (page > this.productFeedback.pagination.total) {
          return;
        }
        feedbackUrl(this.$route.query.pid, {
          count: 5,
          page
        }).then(res => {
          if (res.code == 200 && res.data) {
            this.productFeedback.feedbackList = this.productFeedback.feedbackList.concat(res.data.feedbackList);
            console.log('---------')
            console.log(this.productFeedback.feedbackList)
            const pagination =  res.data.pageInfo
            this.productFeedback.pagination.page = pagination.page
            this.productFeedback.pagination.total = pagination.totalPage
          } else {
            this.errorMsg = res.msg;
          }
        })
      },
      takeUpCon(){
        this.isMore = false
      },
      addMore(){
        this.isMore = true
      },
      showAlertImg (index,list) {
        this.pictureList = list
        this.pictureIndex = index
        console.log('--------------ddd-------')
        console.log(this.pictureList)
        console.log(this.pictureIndex)
        this.alertImgOpen = true
      },
      alertImgClose () {
        this.pictureList = []
        this.alertImgOpen = false
      },
      toproduct: function(pid) {
        this.$router.push({
          name: "pdtDetailPage",
          query: {
            pid: pid
          }
        });
      },
      toBrand: function(searchKey) {
        this.$router.push({
          name: "productSearch",
          query: { key: searchKey }
        });
      },
      showMoreEvalute(){
          let feedLength = this.productFeedback.feedbackList.length;
          this.variable += 5;
          console.log(this.variable)
          if (this.variable % 5 || this.variable == feedLength ){
            console.log(this.variable)
            this.moreEvalute = 2
          }
      }
    },
    created () {
      this.fetchData()
      let params = {
        url: window.location.href
      }
      this.getpdtDetailRecomment()
      this.getfeedBack()
    }
  }
</script>

<style scoped lang="less">

    .uselifephoto {
      width: 100%;
      height: 52vw;
      margin: 0.5%;
      &.uselifephoto:after {
        padding-top: 100%;
      }
      .uselifephoto-img-box{
        width: 100%;
        height: 100%;
        background-size: cover;
        img{
          width: 100%;
          height: 100%;
          object-fit:cover;
          display: block
        }
      }
    }
  .yi23-imgalert__box{
    z-index: 1000;
  }
  @import "~common/less/variable";

  .yclosetShade{
    z-index: 3;
  }

  .yclosetHeader{
    height: auto;
  }
  .yclosetFooter{
    .height(64);
    display: flex;
    justify-content:center;
    align-items:center;
    border-top:1px #eee solid;
    z-index: 3;
    position: relative;
  }

  .btn-defult{
    .height(44);
    .width(355);
    justify-content:center;;
    align-items:center;
    display: flex;

  }

  .image-ratio:after{
    padding-top: 100%;
  }
  .yclosetContainer{
    background: #fafafa;
  }
  .tipPro{
    position: absolute;
    .bottom(64);
    left:0;
    z-index: 4;
    width:100%;
    display: block;
    height: auto;
    background: #fff;

    &Con{
      .padding(0,26,0,26);
      position: relative;
      top: 0;
      right:0;
      .tipClose{
        position: absolute;
        .right(16);
        .top(10);
        float: right;
        .padding(5,5,5,5);
        i{
          .font-size(10);
        }
      }
      &Top{
        flex:1;
        width:100%;
        display: flex;
        justify-content:space-between;
        align-items:center;
        flex-wrap: wrap;
        height: auto;
        .padding(20,0,20,0);
        border-bottom: 1px rgba(0,0,0,.04) solid;
        .Left{
          flex:1;
          img{
            width:100%;
            display: block;
          }
        }
        .Right{
          flex:5;
          .margin(0,0,0,10);
          line-height: 2;
          .RightName{
            .font-size(14);
            color: #333;
          }
          .RightBrand{
            .font-size(12);
            color: #999;
          }
        }
      }
      &Center{
        display: flex;
        justify-content:space-between;
        align-items:center;
        width:100%;
        flex:1;
        .height(56);
        span{
          .font-size(14);
          color: #3d3d3d;
        }
        span:last-of-type{
          .font-size(12);
          color: #ff544b;
        }
        span{
          i{
            .font-size(6);
          }
        }
      }
      &Bottom{
        width:100%;
        height:auto;
        ul.tipSize{
          display: flex;
          /*justify-content:space-around;*/
          flex-wrap: wrap;
          width:100%;
          li{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            .wh(52,52);
            .margin(0,10,10,0);
            .font-size(12);
            border:1px rgba(0,0,0,.05) solid;
            color: #111;
          }
          li.active{
            color: #fff;
            background: #222;
          }
          li.noSize{
            color: #eee;
            border:1px rgba(0,0,0,.04) solid;
          }
        }
      }
    }
  }
  .product{
    display: flex;
    width:100%;
    flex-wrap: wrap;
    .topProduct{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      position: relative;
      .popLeft,.popRight{
        position: absolute;
        top:10px;
        z-index: 2;
      }
      .popLeft{
        left:0px;
        width: 67px;
        height:20px;
        img{
          position: absolute;
          top:0px;
        }
      }
      .popRight{
        right:10px;
        width:30px;
        height:30px;
        .font-size(25);
        .yi23iconfont{
          .font-size(25);
        }
        /*.red{*/
        /*color: #ff544b;*/
        /*}*/
      }
      &Slide,&Brand,&Size{
        display: flex;
        width:100%;
        .font-size(14);
      }
      &Slide{
        width: 100%;
        height:auto;
        .margin(0,0,15,0);
        position: relative;

        .swiper-container{
          width:100%;
          .swiper-wrapper{
            width: 100%;
            .swiper-slide{
              width: 100%;
              height:auto;
              .imgP{
                padding-bottom: 125%;
              }
            }
          }
        }
      }
      &Brand{
        width:auto;
        color: #3d3d3d;
        /*padding:0 10px;*/
        .icon-right{
          color: #999;
          .font-size(6);
          .margin(0,0,0,6);
          position: relative;
          top:5 * @unit;
        }
      }
      &Name{
        color: #3d3d3d;
        line-height: 2.5;
        .font-size(20);
        padding-left:16 * @unit;
      }
      &Size{
        color: green;
        .padding(0,16,0,16);
        ul.SizeList{
          display: flex;
          li{
            display: flex;
            justify-content:center;
            align-items:center;
            .width(32);
            .height(32);
            .margin(0,10,0,0);
            border:1px #333 solid;
            color: #333;
          }
          li.active{
            background:#333;
            color: #fff;
          }
          li.noSize{
            color: #ccc;
            border:1px #ccc solid;
          }
          li:last-of-type{
            margin-right: 0;
          }
        }
        .SizeDetail{
          display: flex;
          align-items: center;
          width:auto;
          .padding(0,10,0,10);
          color:#333;
          .font-size(12);
          i{
            color: #222;
          }
          .icon-arrow{
            .font-size(6);
          }
        }
      }
    }
    /*productParameter*/
    ul.productParameter{
      border-top: 1px #e6e6e6 solid;
      .margin(20,10,0,10);
      .padding(15,0,0,0);
      display: flex;
      width:100%;
      flex-wrap: wrap;
      li{
        display: flex;
        width:100%;
        .font-size(12);
        .line-height(31);
        .parameterLeft{
          width:100px;
          flex:1;
        }
        .parameterRight{
          flex:5;
          .line-height(23);
          .margin(5,0,0,0);
          position: relative;
          .MonyDel{
            text-decoration: line-through;
            text-decoration-color: #CDAB6A;
          }
          .Mony{
            text-decoration: line-through;
            text-decoration-color: #CDAB6A;
            color: #999;
            .margin(0,10,0,0);
          }
          .Tips{
            position: absolute;
            border:1px #ff544b solid;
            border-radius: 15px;
            .padding(0,5,0,10);
            .font-size(12);
            .line-height(20);
            color: #ff544b;

            .icon-right{
              color: #ff544b;
              .font-size(6);
            }
          }
        }

      }
    }
    /*搭配*/
    .productCollocation{
      display: flex;
      width:100%;
      flex-wrap: wrap;
      .font-size(14);
      .margin(0,10,0,10);
      &Title{
        display: flex;
        width:100%;
        .line-height(40);
        color: #3d3d3d;
        border-bottom: 1px #e5e5e5 solid;
      }
      ul.productCollocationCon{
        display: flex;
        width:100%;
        flex-wrap: wrap;

        li{
          display: flex;
          width:100%;
          /*justify-content:space-between;*/
          align-items: center;
          .liIcon{
            flex:.6;
            align-items:center;
            justify-content:center;
            display: flex;
            .padding(0,10,0,0);
            .font-size(20);
            color: #666;
          }
          .liCon{
            flex:5;
            border-bottom: 1px #e5e5e5 solid;
            .padding(12,0,12,0);
            display: flex;

            .imgLeft{
              flex:1;
              .imgLeftIMG{
                padding-bottom: 124.9333%;
              }
            }
            .infoRight{
              flex:2;
              .font-size(14);
              .padding(0,12,0,12);
              color: #333;
              .line-height(20);
              &Name{
              }
              &Brand{
              }
              &Size{
                .line-height(50);
                color: #666;
                i{
                  .padding(0,10,0,0);
                }
                i:last-of-type{
                  .padding(0,0,0,0);
                }
              }
            }
          }
        }
        li:last-of-type{
          .liCon{
            border-bottom: none;
          }
        }
      }
    }
    /*推荐*/
  }
  .productRecommend{
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    background: #fafafa;
    &Title{
      width:100%;
      display: flex;
      /*flex-wrap: wrap;*/
      justify-content: center;

      h2.Title {
        display: table;
        white-space: nowrap;
        width: 90%;
        display: flex;
        justify-content: center;
        line-height: 1.77;
        letter-spacing: 0.7px;
        text-align: center;
        .padding(10,0,10,0);

        i{
          .font-size(12);
          color: #999;
          .padding(0,10,0,10);
        }

      }

      h2.Title:before,
      h2.Title:after {
        border-top: solid 1px rgba(0, 0, 0, 0.04);
        content: '';
        display: table-cell;
        position: relative;
        .top(10);
        width: 45%;
        height: 1.066667rem;
      }
      h2.Title:before {
        right: 1%;
      }
      h2.Title:after {
        left: 1%;
      }
    }
  }
  ul.productFooterBtn{
    display: flex;
    justify-content:space-between;
    align-items: center;
    .padding(0,5,0,5);
    flex:1;
    li{
      width:auto;
      display: block;
      .height(44);
      flex:1;
      display: flex;
      justify-content:center;
      align-items:center;
      .margin(0,5,0,5);
      i{
        .font-size(16);
        .margin(0,5,0,0);
      }
    }
    .btn-defult{
      .font-size(12);
    }
    .disabled{
      .font-size(14);
    }
    .btnBorA{
      background: #fff;
      color: #333;
      position: relative;
    }
    .btnBorA:after{
      border:1px rgba(0,0,0,.1) solid;
      content: " ";
      width: 200%;
      height: 200%;
      position: absolute;
      top: 0;
      left: 0;
      transform: scale(.5);
      transform-origin: 0 0;
      box-sizing: border-box;
    }

  }
  .productFooter{
    position: absolute;
    z-index: 1;
    .bottom(70);
    .right(20);
    .width(80);
    height:auto;
    display: flex;
    justify-content:space-between;
    align-items:center;

    .callCenter,.shopping{
      .width(35);
      .height(35);
      background:#222;
      border-radius: 1.86666667rem;
      display: flex;
      justify-content:center;
      align-items:center;
      position: relative;
      i{
        color: #fff;
        .font-size(18)
      }
      i.number{
        position: absolute;
        .top(-4);
        .right(-5);
        width: auto;
        min-width:6px;
        text-align: center;
        .padding(2,5,2,5);
        border-radius: 10px;
        background:#ff544b;
        .font-size(8);
        display: flex;
        justify-content:center;
        align-items: center;
      }
    }
  }

  .icon-padding{
    padding: 5px;
    &.active{
      color: #ff554b;
    }
  }

  /*轻奢*/
  /*雨薇让去掉动画 07-13*/
  .dialog-slide-enter-active {
    animation: zoomIn1 0s;
  }
  .dialog-slide-leave-active {
    animation: zoomIn1 0s reverse;
  }
  .dialog-slide-enter-active .yi23-dialog {
    animation: zoomIn 0s;
  }
  .dialog-slide-leave-active .yi23-dialog{
    animation: zoomIn 0s reverse;
  }
  @keyframes zoomIn1 {
    from {
      opacity: 0;
    }

    50% {
      opacity: 1;
    }
  }
  @keyframes zoomIn {
    from {
      transform: translate(0%,0%) scale(0);
      opacity: 0;
    }

    50% {
      transform: translate(0%,0%) scale(0);
      opacity: 1;
    }
  }

  .yi23-dialog__bd {
    padding: 0 0;
  }
  /deep/.yi23-mask{
    z-index: 15;
  }
  /deep/.dialog-slide-enter-active,
  .dialog-slide-leave-active,
  .dialog-slide-enter-active .yi23-dialog,
  .dialog-slide-leave-active .yi23-dialog{
    z-index: 6;
  }
  /deep/.swiper-container{
    z-index:0;
  }
  /deep/ .swiper-pagination .swiper-pagination-bullet-active{
    background: #333;
  }
  /deep/ .swiper-pagination-bullet{
    .wh(4, 4);
    background: #fff;
  }
  /* Iphone X*/
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .tipPro{
      .bottom(98);
    }
  }
  /*0808*/
  .proBrandOrVipUser{
    display: flex;
    justify-content:space-between;
    width:100%;
    .padding(0,16,0,16);
  }
  .proVipUser{
    font-weight: 500;
    p{
      font-size: 14px;
      i{
        color:#ff544b
      }
    }
    p.vipUser{
      font-size: 14px;
      text-decoration:line-through #1d7864;
    }
    p.freeUser{

    }
  }

  .cap{
    position: absolute;
    right:16 * @unit;
    bottom:-10px;
    width:auto;
    font-size:12 * @unit;
    /*background-color: #399c87;*/
    color:#fff;
    display: flex;

    .capA,.capB{
      background-color: #1d7864;
      .padding(4,4,4,4);
    }
    .capB{
      background-color: #399c87;
      flex:2;
    }
  }
  .vipUserGuide{
    display: flex;
    width: 100%;
    border-top: 1px #e6e6e6 solid;
    .margin(20,10,0,10);
    .padding(20,0,0,0);

    .imgP{
      padding-bottom: 40.2816%;
    }
  }
  .productsDetail{
    width:345 * @unit;
    height:auto;
    padding-left:15 * @unit;
    padding-right:15 * @unit;
    .z_bannerInfo{
      padding-bottom:56%;
      position:relative;
      .z_bannerImg{
        position:absolute;
        width:375 * @unit;
        height:0;
        padding-bottom:56%;
        overflow:hidden;
        top:0;
        left:-15 * @unit;
        img{
          width:100%;
        }
      }
    }
    .z_brand{
      width:345 * @unit;
      height:84 * @unit;
      background:#ffffff;
      position:relative;
      padding-top: 20 * @unit;
      font-size: 14 * @unit;
      font-weight: 500;
      letter-spacing: 0.2 * @unit;
      color: #111111;
      margin-top:20 * @unit;
      border-top: 1 * @unit solid #e6e6e6;
      border-bottom: 1 * @unit solid #e6e6e6;
      .z_brandInfo{
        width:225 * @unit;
        height:64 * @unit;
        margin-left:15 * @unit;
        flex-direction: row;
        display:flex;
        position: relative;
      }
      /*.z_brandImg{*/
        /*width: 64px;*/
        /*height: 64px;*/
        /*overflow: hidden;*/
        /*position: relative;*/
        /*border-radius:50%;*/
        /*z-index: 1;*/
      /*}*/
      /*.z_brandImg img{*/
        /*height: 100%;*/
        /*width: auto;*/
        /*left:50%;*/
        /*position: relative;*/
        /*transform: translateX(-50%);*/
        /*border-radius:50%;*/

      /*}*/
      .z_brandImg{
        width: 64 * @unit;
        height: 64 * @unit;
        overflow: hidden;
        border-radius: 50%;
         img {
           height: 100%;
           width:auto;
           vertical-align: top;
           transform: translateX(-50%);
           margin-left: 50%;
         }
      }

      .z_brandTitle{
        margin-left:10 * @unit;
      }
      .z_skipBrand{
        font-size: 12 * @unit;
        letter-spacing: 0.2 * @unit;
        color: #999999;
        display: flex;
        flex-direction: row;
        width:150 * @unit;
        height:16.5 * @unit;
      }

      .z_brandArr{
        width: 6 * @unit;
        height: 9 * @unit;
        margin-left:3 * @unit;
      }
      .z_brandArr img{
        width:100%;
        height:100%;
      }
      .z_brandN{
        margin-top:11 * @unit;
        margin-bottom:9.5 * @unit;
        font-size:14 * @unit;
        color:#111111;
        font-weight:500;
      }
      .z_brandArrow{
        position: absolute;
        width:8 * @unit;
        height:13 * @unit;
        top:45.5 * @unit;
        right:15 * @unit;
        background-image:url(https://yimg.yi23.net/aliminiapp/aliapp/zArrow.png);
        background-repeat: no-repeat;
        background-size:100%;
      }
    }
    .playingMethod{
      width:100% ;
      height:auto;
      background:#ffffff;
      margin-top:10 * @unit;
    }
    .playingMethod img{
      width:100% ;
      height:auto;
    }
    .z_infoTitle{
      height:55 * @unit;
      width:150 * @unit;
      margin-top:2 * @unit;
      line-height: 55 * @unit;
      font-size:16 * @unit;
    }
    .z_table {
      width: 345 * @unit;
      height: auto;
      display: flex;
      flex-direction: column;
      border-bottom: 1 * @unit solid rgba(0, 0, 0, 0.15);
    }
    .z_clotheSize{
      .infoConListLeft div{
        width:50 * @unit;
        padding:15 * @unit;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size:12 * @unit;
        border: 0.5 * @unit solid rgba(0, 0, 0, 0.15);
        border-bottom:none;
        color:rgb(51, 51, 51);
        background: rgb(245, 245, 245);
      }
      .infoConListRight{
        /*width: auto;*/
        flex:1;
        overflow-x: scroll;
        overflow-y: hidden;
        border-right: 0.5 * @unit solid rgba(0, 0, 0, 0.15);
      }
      .infoConListRight > div{
        width:auto;
        //min-width:350 * @unit;
        display: flex;
        font-size:12 * @unit;
        border: 0.5 * @unit solid rgba(0, 0, 0, 0.15);
        border-left:none;
        border-right:none;
        border-bottom:none;
        color:rgb(51, 51, 51);
      }
      .infoConListRight > div > div{
        width:15 * @unit;
        padding:15 * @unit;
        text-align: center;
      }
      .addBackground{
        background: rgb(245, 245, 245);
      }
    }
    .z_basicInfo{
      .infoConList{
        width: 345 * @unit;
        display:flex;
        height:auto;
        flex-direction: row;
        background:white;
        border:1 * @unit solid rgba(0, 0, 0, 0.15);
        border-bottom:none;
        font-size:12 * @unit;
        color:rgb(51, 51, 51);
      }
      .infoConList span{
        width:50 * @unit;
        padding:15 * @unit;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size:12 * @unit;
        color:rgb(51, 51, 51);
      }
      .infoConList span:nth-child(1){
        background:rgb(245, 245, 245);
      }

      infoConList span:nth-child(2){
        background:white;
      }
      .addWidth{
        width:230 * @unit !important;
        justify-content: left !important;
        border-left: 0.5 * @unit solid rgba(0, 0, 0, 0.15) !important;
      }
    }
    .z_brandStory{
      border-bottom: 1 * @unit solid #e6e6e6;
      .z_brandName{
        font-size:14 * @unit;
        color:rgb(0, 0, 0);
        margin-bottom: 15 * @unit;
        font-weight: 500;
      }
      .z_textContent{
        width: 345 * @unit;
        height:auto;
        margin-bottom:20 * @unit;
        font-size:14 * @unit;
        line-height:22 * @unit;
        color:rgb(17, 17, 17);
        display: -webkit-box;
        word-break: break-all;
        text-overflow: ellipsis;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp:4;
        letter-spacing: 0.2 * @unit;
      }
      .closeLimit{
        width: 345 * @unit;
        height:auto;
        font-size:14 * @unit;
        line-height:22 * @unit;
        letter-spacing: 0.2 * @unit;
        color:rgb(17, 17, 17);
        margin-bottom:20 * @unit;
      }
      .selMore{
        width:100%;
        height:45 * @unit;
        border-top:0.5 * @unit solid rgb(237, 237, 237);
        text-align: center;
        font-size:12 * @unit;
        line-height:45 * @unit;
        color:rgb(153, 153, 153);
        padding-bottom:10 * @unit;
      }
      .selMore>div{
        position:relative;
        width:45 * @unit;
        height:45 * @unit;
        margin:0 auto;
        background-repeat: no-repeat;
        background-size:6 * @unit 6 * @unit;
      }
      .comMoreImg{
        position:absolute;
        width:7.5 * @unit;
        height:7.5 * @unit;
        right:0;
        top:55%;
        font-size:11 * @unit;
        transform: translateX(0%) translateY(-55%);
        background-image:url(https://yimg.yi23.net/aliminiapp/aliapp/downArrow.png);
        background-repeat: no-repeat;
        background-size:100%;

      }
      .takeUpImg{
        top:40% !important;
        transform: translateX(0%) translateY(-40%) rotate(180deg) !important;
      }
    }
  }


  .Include {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    position: relative;



    .z_tagType{
      .width(60);
      .height(24);
      background-color: #98cacc;
      position:absolute;
      z-index: 1;
      top:0;
      left:0;
      .font-size(10);
      color:#ffffff;
      text-align: center;
      .line-height(24)
    }
    .product_tag_empty {
      position: absolute;
      margin: 0px;
      top: 50%;
      left: 50%;
      display: block;
      transform: translate(-50%, -50%);
      z-index: 1;
    }
    .newTag{
      background-color:#d1b686;
    }
  }



  .recommendCon {
    display: flex;
    width: 100%;
    flex-direction:column;
    .z_recommendTitle{
      width: 67.5 * @unit;
      height: 22.5 * @unit;
      font-size: 16 * @unit;
      font-weight: 500;
      color: #111111;
      margin-top:20 * @unit;
      margin-bottom:15 * @unit;
      margin-left:20 * @unit;
    }
    .List{
      display: flex;
      width: 100%;
      ul.listCon {
        margin: 0 20 * @unit;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        width: 100%;
        height: auto;

        li {
          display: flex;
          flex-wrap: wrap;
          width: 49%;
          height: auto;
          background: #fff;
          margin-bottom: 2%;
          .liIMG {
            padding-bottom: 124.9333%;
          }
          .liAttribute {
            display: flex;
            flex-wrap: wrap;
            width: 100%;
            .padding(12, 10, 18, 0);
            p {
              .font-size(12);
              width: 100%;
              flex-wrap: wrap;
              line-height: 1.5;
              color: #333;
            }
            p.Name {
            }
            p.Brand {
              color:#999999;
            }
            p.Size {
              i {
                .padding(0, 5, 0, 0);
                color: #999;
                .font-size(14);
              }
              i:last-of-type {
                padding: 0;
              }
            }
          }
        }
      }
    }
  }

  .evaluateCon{
    width:345 * @unit;
    height:auto;
    padding:0 15 * @unit 0 15 * @unit;
    .evaluaeTitle{
      display:flex;
      flex-direction:row;
      padding-top: 24 * @unit;
      padding-bottom: 24 * @unit;
      border-bottom: 0.5px rgba(0,0,0,.15) solid;
      justify-content: space-between;
      .siftEval{
        width: 67.5 * @unit;
        height: 22.5 * @unit;
        font-size: 16 * @unit;
        font-weight: 500;
        color: #111111;
        padding-top: 5 * @unit;
      }
    }
    .userEvaluteItem .user-item:last-child{
      border:none !important;
    }
    .moreEvaltue{
      width:345 * @unit;
      height:44 * @unit;
      border-radius: 2 * @unit;
      background-color: #f7f7f7;
      text-align: center;
      font-size:12 * @unit;
      line-height:44 * @unit;
      color:#333333;
      .z_eval{
        position:relative;
        width:91 * @unit;
        height:45 * @unit;
        margin:0 auto;
        background-repeat: no-repeat;
        background-size:6 * @unit 6 * @unit;
      }
      .z_allEval{
        position:relative;
        width:120 * @unit;
        height:45 * @unit;
        margin:0 auto;
        background-repeat: no-repeat;
        background-size:6 * @unit 6 * @unit;
      }
      .comMoreImg{
        position:absolute;
        width:7.5 * @unit;
        height:7.5 * @unit;
        right:0;
        top:55%;
        font-size:11 * @unit;
        transform: translateX(0%) translateY(-55%);
        background-image:url(https://yimg.yi23.net/aliminiapp/aliapp/downArrow.png);
        background-repeat: no-repeat;
        background-size:100%;

      }
      .takeUpImg{
        top:40% !important;
        transform: translateX(0%) translateY(-40%) rotate(180deg) !important;
      }
    }
  }
  // 精选
  .user-item {
    margin-top: 1.109333rem /* 20.7/18.75 */;
    margin-bottom: 1.104rem /* 20.7/18.75 */;
    padding-bottom:25 * @unit;
    &:last-child {
      margin-bottom: 0;
    }
    .userinfo {
      .avater {
        width: 1.813333rem /* 34/18.75 */;
        height: 1.813333rem /* 34/18.75 */;
        border-radius: 50%;
        img {
          display: block;
          width: 1.813333rem /* 34/18.75 */;
          height: 1.813333rem /* 34/18.75 */;
        }
      }
      .right {
        padding-left: 0.533333rem /* 10/18.75 */;
        font-size: 12px;
      }
      .mobile {
        line-height: 1.6;
      }
      .tag-info {
        font-size: 10px;
        color: #eee;
        span {
          padding: 0 0.293333rem /* 5.5/18.75 */;
          color: #111111;
          &:first-child {
            padding-left: 0;
          }
          &:last-child {
            padding-right: 0;
          }
        }
      }
    }
    .usersaid {
      font-size: 0.746667rem /* 14/18.75 */;
      line-height: 1.5;
      letter-spacing: 0.5px;
      margin-top: 10 * @unit;
      margin-bottom: 10 * @unit; /* 10/18.75 */;
    }

    .slideImg{
      margin-top: 14 * @unit;
    }
  }
  .feedback__empty {
     font-size: 12px;
     color: #999;
  }
  /*五角星*/
  #stars {
    display:inline-block;
    width:auto;
    position:relative;
    font-size:15 * @unit;
    min-height: 26 * @unit;
    line-height: 26 * @unit;
    white-space:nowrap;
  }
  #stars:BEFORE {
    content:"★ ★ ★ ★ ★";
    position:absolute;
    z-index:1;
    left:0px;
    top:0px;
    color: #ff8e63;
    min-height: 100%;
    overflow:hidden;
    white-space:nowrap;
    /* text-shadow:0px 1px 0 #000, 0 -1px 0 #fff;*/
  }
  .starsAmount{
    font-size: 14 * @unit;
    color:#bbbbbb;
  }
  #stars:AFTER {
    content:"★ ★ ★ ★ ★";
    position:relative;
    color:#bbb;
    white-space:nowrap;
  }
  #stars.rate:AFTER {
    position:absolute;
    left:0px;
  }
  #stars.rate > A {
    color:transparent;
    text-decoration:none;
    position:relative;
    z-index:2;
  }
  #stars.rate:HOVER:BEFORE,
  #stars.rate:HOVER:AFTER {
    display:none;
  }
  #stars:NOT([class]):BEFORE,
  #stars[class="stars0"]:BEFORE {
    display:none;
  }
  /* 1/2 a star */
  #stars[class="stars0.5"]:BEFORE {
    width:7.5%;
  }
  /* 1 star */
  #stars[class="stars0.15"]:BEFORE {
    width:15%;
  }
  /* 1 & 1/2 stars */
  #stars[class="stars1.5"]:BEFORE {
    width:29%;
  }
  /* etc. */
  #stars[class="stars2"]:BEFORE {
    width:40%;
  }
  #stars[class="stars2.5"]:BEFORE {
    width:50%;
  }
  #stars[class="stars3"]:BEFORE {
    width:60%;
  }
  #stars[class="stars3.5"]:BEFORE {
    width:71%;
  }
  #stars[class="stars4"]:BEFORE {
    width:80%;
  }
  #stars[class="stars4.5"]:BEFORE {
    width:92.5%;
  }
  #stars[class="stars5"]:BEFORE {
    width:100%;
  }
</style>
<style lang="less">
  .productDetail .swiper-pagination .swiper-pagination-bullet-active {
    background: #222;
  }
  .productDetail .yi23-imgalert .yi23-imgalert__hd:after{
    display: none;
  }
  .productDetail .yi23-imgalert__hd .pictureBox{
    text-align: center;

    img{
      position: inherit;
      max-height: 85vh;
      /*width: auto;*/
    }
  }



</style>
