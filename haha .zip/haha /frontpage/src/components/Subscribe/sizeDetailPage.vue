<template>
  <div class="yclosetContainer"><!--comments-->
    <go-back></go-back>
    <div class="yclosetCon bG" v-if="sizeDetail"><!--核心内容部分-->
      <div class="gownSize">
        <div class="gownSizeTop">
          <div class="Top_Title">
            <h2>我的尺码</h2>
            <button class="activeBtn" @click="userEditBtn" v-if="editBtn">编辑</button>
            <button :class="{activeBtn:!SlotStatus}" @click="userSaveBtn" v-else>保存</button>
          </div>

          <ul class="editSize" v-if="sizeDetail">
            <li>
              <p>身高</p>
              <i class="font-l" :class="{infoBg:selectedType == 1}" @click="showPicker(1)">{{ sizeDetail.userSize.height!=0 ? sizeDetail.userSize.height :'-'}}</i>
            </li>
            <li>
              <p>体重</p>
              <i class="font-l" :class="{infoBg:selectedType == 2}" @click="showPicker(2)"> {{ sizeDetail.userSize.weight!=0 ? sizeDetail.userSize.weight :'-'}}</i>
            </li>
            <li>
              <p>胸围</p>
              <i class="font-l" :class="{infoBg:selectedType == 3}" @click="showPicker(3)">{{ sizeDetail.userSize.acrossChest!=0 ? sizeDetail.userSize.acrossChest :'-'}}</i>
            </li>
            <li>
              <p>腰围</p>
              <i class="font-l" :class="{infoBg:selectedType == 4}" @click="showPicker(4)">{{ sizeDetail.userSize.waist!=0 ? sizeDetail.userSize.waist :'-'}}</i>
            </li>
            <li>
              <p>臀围</p>
              <i class="font-l" :class="{infoBg:selectedType == 5}" @click="showPicker(5)">{{ sizeDetail.userSize.hipline!=0 ? sizeDetail.userSize.hipline :'-'}}</i>
            </li>

          </ul>
          <div class="Dw-b font-l">单位：厘米 / 公斤</div>
          <div class="Tp-b font-l"><i>*</i>Tips：推荐仅供参考，填写越准确，推荐越准确。</div>
        </div>

        <div class="gownSizeInfo" v-if="sizeList">
          <div class="Top_Title">
            <h2>商品尺码表</h2>
          </div>
          <div class="gownSizeInfoCont" v-if="sizeDetail">
            <div class="infoContLeft">
              <ul class="infoContLeftList">
                <li v-for="(item,index) in sizeDetail.productSize">{{index=='title'?'尺码':index}}</li>
              </ul>
            </div>
            <div class="infoContRight">
              <ul class="infoContRightList">
                <template v-for="(item,index) in sizeDetail.productSize">
                  <li>
                    <p :class="{'borAction-1':isrecommendSize(index3,sizeItem,index)}" v-for="(sizeItem,index3) in item"><i></i>{{sizeItem}}</p>
                  </li>
                </template>
              </ul>
            </div>
            <div class="Dw-my-b font-l">单位：厘米</div>
          </div>
        </div>

        <div class="sizeDemo"  v-show="sizeList" v-if="sizeDetail.modelSize && sizeDetail.modelSize.feeling != 0 ">
          <!--<div class="sizeDemo" v-show="sizeList" v-if="sizeList">-->
          <div class="Top_Title">
            <h2>尺码图示</h2>
          </div>
          <div class="sizeInfoIMG">
            <img :src="sizeDetail.imgUrl" alt="">
          </div>
        </div>


        <div class="modelDemo"   v-show="sizeList" v-if="sizeDetail.modelSize && sizeDetail.modelSize.feeling != 0 ">
          <div class="Top_Title">
            <h2>模特试穿体验</h2>
          </div>
          <div class="modelDemoCont">
            <div class="modelDemoContLeft">
              <img :src="sizeDetail.modelSize.imgUrl" alt="">
            </div>
            <div class="modelDemoContRight">
              <h2>{{sizeDetail.modelSize.modelName}}</h2>
              <p>胸围{{sizeDetail.modelSize.acrossChest}}／腰围{{sizeDetail.modelSize.waist}}／臀围{{sizeDetail.modelSize.hipline}}／常用尺码{{sizeDetail.modelSize.modelSize}}<br> 试穿尺码{{sizeDetail.modelSize.modelSize}}／试穿体验：适中</p>
            </div>
          </div>
        </div>

        <div>
          <!--<div class="gownSizeInfo">-->
          <!--<div class="Top_Title">-->
          <!--<h2>商品尺码表</h2>-->
          <!--</div>-->
          <!--<div class="gownSizeInfoCont">-->
          <!--<div class="infoContLeft">-->
          <!--<ul class="infoContLeftList">-->
          <!--<li>尺码</li>-->
          <!--<li>1.肩宽</li>-->
          <!--<li>2.胸围</li>-->
          <!--<li>3.腰围</li>-->
          <!--<li>4.臀围</li>-->
          <!--</ul>-->
          <!--</div>-->
          <!--<div class="infoContRight">-->
          <!--<ul class="infoContRightList">-->
          <!--<li>-->
          <!--<p>均码</p>-->
          <!--<p>XXX</p>-->
          <!--<p>3</p>-->
          <!--<p>4</p>-->
          <!--<p>5</p>-->
          <!--</li>-->

          <!--<li>-->
          <!--<p>均码1</p>-->
          <!--<p>2</p>-->
          <!--<p>3</p>-->
          <!--<p>4</p>-->
          <!--<p>5</p>-->
          <!--</li>-->

          <!--<li>-->
          <!--<p>均码1</p>-->
          <!--<p>2</p>-->
          <!--<p>3</p>-->
          <!--<p>4</p>-->
          <!--<p>5</p>-->
          <!--</li>-->

          <!--<li>-->
          <!--<p>均码1</p>-->
          <!--<p>2</p>-->
          <!--<p>3</p>-->
          <!--<p>4</p>-->
          <!--<p>5</p>-->
          <!--</li>-->

          <!--<li>-->
          <!--<p>均码1</p>-->
          <!--<p>2</p>-->
          <!--<p>3</p>-->
          <!--<p>4</p>-->
          <!--<p>5</p>-->
          <!--</li>-->

          <!--</ul>-->
          <!--</div>-->
          <!--<div class="Dw-my-b font-l">单位：厘米</div>-->
          <!--</div>-->
          <!--</div>-->
        </div>
      </div>
    </div>

    <div class="page-picker-wrapper">
      <mt-picker :slots="pcikerData" valueKey="text" v-model="SlotStatus"  :visible-item-count="5"  @doConfirm="doSelect">
      </mt-picker>
    </div>
    <yi23Toast v-model="errorMsg"></yi23Toast>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import { sizeDetail } from 'api/subscribe'
  import { updateBaseInfo } from 'api/user'
  import XCell from '@/components/lib/cell/Cell';
  import MtPicker from '@/components/lib/picker/picker';
  import { mapGetters } from 'vuex'

  export default {
    data() {
      return {
        sizeDetail: null,
        editBtn:true,
        saveBtn:false,
        sizeList:true,
        SlotStatus:false,
        selectedType:null,
        errorMsg:'',
        pcikerData:null,
        sizeSelectData:{
          height:'',
          weight:'',
          acrossChest:'',
          waist:'',
          hipline:'',
        },
      }
    },
    components: {
      goBack,
      XCell,
      MtPicker,
    },
    methods:{
      isrecommendSize(index,val,root_index){
        let detail = this.sizeDetail;
        let index2 = detail.productSize.title.indexOf(this.sizeDetail.recommendSize);
        if(index == index2 ){
          console.log(root_index+'----'+val)
          if(root_index!='title' && val=='-'){
            this.sizeDetail.recommendSize = ''
            return false
          }
          return true
        }
        return false;
      },
      //编辑
      userEditBtn:function () {
        this.userSignIn()
        this.editBtn = false
        this.userEditSize()
      },

      //保存
      userSaveBtn:function () {
        this. saveInfo()
        this.getSizeDetail()
      },

      saveInfo:function () {
        let options = {
          height:this.sizeDetail.userSize.height,
          weight:this.sizeDetail.userSize.weight,
          acrossChest:this.sizeDetail.userSize.acrossChest,
          waist:this.sizeDetail.userSize.waist,
          hipline:this.sizeDetail.userSize.hipline,
        }
        updateBaseInfo(options).then((res)=>{
          console.log(res);
          this.editBtn=true
          this.sizeList=true
          this.selectedType = -1

          if(res.code==200){
            console.log('添加成功')
            this.getSizeDetail()
          }
          this.errorMsg = res.msg;


        });

      },
      doSelect(values) {
        console.log(values[0].value)
        switch (this.selectedType){
          case 1:
            this.sizeDetail.userSize.height=values[0].value
            break;
          case 2:
            this.sizeDetail.userSize.weight=values[0].value
            break;
          case 3:
            this.sizeDetail.userSize.acrossChest=values[0].value
            break;
          case 4:
            this.sizeDetail.userSize.waist=values[0].value
            break;
          case 5:
            this.sizeDetail.userSize.hipline=values[0].value
            break;
        }

      },
      doInitSelctData:function () {
        let _t=this;
        _t.sizeSelectData.height=_t.initSelectData(120,1,16,'cm');//身高
        _t.sizeSelectData.weight=_t.initSelectData(36,1,26,'kg');//体重
        _t.sizeSelectData.acrossChest=_t.initSelectData(69,1,35,'cm');//胸围数据
        _t.sizeSelectData.waist=_t.initSelectData(52,1,38,'cm');//腰围
        _t.sizeSelectData.hipline=_t.initSelectData(56,1,52,'cm');//臀围数据
      },
      initSelectData:function (start,step,number,unit) {//初始化 下拉数据
        var ary=[{text:start+unit,value:start}],curNum;
        for(var i=1;i<number;i++){
          curNum=start+step;
          ary.push({text:curNum+unit,value:curNum});
          start=curNum;
        }
        return ary;
      },

      //登录
      userSignIn:function () {
        if( !this.authorization){
          this.$router.push({
            path:'/loginPage',
            query: {redirect: this.$route.fullPath}
          })
          return false
        }
      },

      //修改尺码
      showPicker:function (type) {
        if( this.editBtn ){
          return false
        }
        switch (type){
          case 1:
            this.pickerDataAction(this.sizeSelectData.height);
            this.selectedType=1;
            this.sizeList = false;
            break;
          case 2:
            this.pickerDataAction(this.sizeSelectData.weight);
            this.selectedType=2;
            this.sizeList = false;
            break;
          case 3:
            this.pickerDataAction(this.sizeSelectData.acrossChest);
            this.selectedType=3;
            this.sizeList = false;
            break;
          case 4:
            this.pickerDataAction(this.sizeSelectData.waist);
            this.selectedType=4;
            this.sizeList = false;
            break;
          case 5:
            this.pickerDataAction(this.sizeSelectData.hipline);
            this.selectedType=5;
            this.sizeList = false;
            break;
        }
      },
      pickerDataAction(data) {
        this.pcikerData=[{
          flex: 1,
          defaultIndex:1,
          values:data,
          className: 'slot1'
        }];
        this.SlotStatus=true;
      },

      //用户编辑尺码
      userEditSize:function () {
        this.showPicker(1)
      },
      //获取数据
      getSizeDetail:function (isFirst) {
        let id= this.$route.query.productId
        sizeDetail(id).then((res)=>{
          if(res.code == 105){
            console.log(res.msg)
            this.errorMsg = res.msg;
          }
          this.sizeDetail = res.data;
          if(!isFirst){
            if(this.sizeDetail.productSize.title.indexOf(this.sizeDetail.recommendSize) == -1){
              this.errorMsg='抱歉，此商品没有适合您的尺码'
            }
          }
        });
      }
    },

    created () {
      this.doInitSelctData();
      this.getSizeDetail(true)
    },
    computed: {
      ...mapGetters({
        authorization: 'authorization'
      })
    },
  }

</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  .yclosetShade{
    z-index: 3;
  }
  .yclosetHeader{
    height: auto;
  }
  .gownSize{
    padding:0 15px;
    display: flex;
    display: inline-block;
    flex-wrap: wrap;
  }
  .gownSize, .gownSizeTop{
    display: flex;
    width:100%;
  }
  .gownSizeTop{
    flex-wrap: wrap;
  }

  .Top_Title{
    display: flex;
    justify-content:space-between;
    width:100%;
    .padding(14,0,14,0);

    h2{
      color: #333;
      .line-height(30);
      .font-size(20);
    }
    button{
      .width(80);
      .height(28);
      background: #ccc;
      color:#fff;
    }
    .activeBtn{
      background: #ff544b;
    }

  }

  ul.editSize{
    display: flex;
    width:100%;
    li{
      width: 20%;
      background: #FAFAFA;
      text-align: center;
      .font-size(12);
      p{
        .height(30);
        .line-height(30);
        background: #333;
        color: #fff;
      }
      i{
        .height(40);
        .line-height(40);
        display: block;
        /*width:100%;*/
      }

    }
    li:nth-of-type(even){
      background: #fff;
    }
    li:first-of-type{
      border-left: 1px #f3f3f3 solid;
    }
    li:last-of-type {
      border-right: 1px #f3f3f3 solid;
    }
  }

  .Dw-b{
    background: #FAFAFA;
    .height(30);
    .line-height(30);
    .padding(0,12,0,0);
    .font-size(12);
    width: 100%;
    display: block;
    border: 1px #F3F3F3 solid;
    color: #999;
    text-align: right;
  }
  .Tp-b{
    display: block;
    font-size: 0.533333rem;
    line-height: 2.133333rem;
    color: #333;

    i{
      color: #ff544b;
      top: -0.213333rem;
      right: 0.106667rem;
    }
  }
  .gownSizeInfo{
    display: flex;
    flex-wrap: wrap;
    width:100%;
  }
  .gownSizeInfoCont{
    display: flex;
    flex-wrap: wrap;
    position: relative;
    .top(-20);
    .infoContLeft{
      //.width(100);
      width:5.866667rem;
      height: auto;

    }
    .infoContRight{
      /*float: left;*/
      //.width(230);
      overflow-x:scroll;
      overflow-y:hidden;
      -webkit-overflow-scrolling:touch;
      white-space:nowrap;
      background: #fff;
      //0627
      flex:1;
    }
  }

  ul.infoContLeftList{
    width: 100%;
    .height(44);
    .line-height(44);
    .font-size(14);
    padding-top: 30px;

    li{
      display: block;
      .height(44);
      .line-height(44);
      color: #333;
      .font-size(12);
      border-bottom: 0.053333rem #eee solid;
      background: #f5f5f5;
      overflow:hidden; display:block;white-space:nowrap; text-overflow:ellipsis;
      .padding(0,0,0,12);
    }
    li:first-of-type{
      padding-left: 0px;
      text-align: center;
    }

    li:first-of-type{
      border-bottom: #ccc 0.053333rem solid;
    }

    li:nth-of-type(1){
      font-size: 0.746667rem;
    }
  }


  ul.infoContRightList{
    overflow-x:scroll;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
    width:auto;
    white-space:nowrap;
    padding-top: 30px;

    li{
      width:auto;
      .minW(235);
      float: left;
      .height(44);
      .line-height(44);
      text-align: center;
      border-bottom: 0.053333rem #eee solid;
      display: flex;
      flex-wrap: nowrap;
      flex-direction: row;
      justify-content: flex-end;
      p{
        display:inline-block;
        .width(50);
        height:auto;
        .height(44);
        .line-height(44);
        .font-size(12);
        display: flex;
        justify-content:center;
      }

    }

    .borAction-1{
      border-left: 0.053333rem #C7C7C7 solid;
      border-right: 0.053333rem #C7C7C7 solid;
      color: red;
      .height(44);
      .line-height(44);
      position: relative;
    }



    li:nth-of-type(odd){
      background: #FAFAFA;
    }
    li:first-of-type .borAction-1{
      border-bottom: #ccc 0.053333rem solid;
      background: #333;
      color: #fff;

      i:first-of-type{
        position: absolute;
        /*width:40px;*/
        /*height: 30px;*/
        /*top: -30px;*/
        .top(-30);
        .width(40);
        .height(30);
        left:5px;
        background: url("https://yimg.yi23.net/webimg/web/images/2018/0531/sub-tip-size.png") 50% 50% no-repeat;
        background-size: 30px;
        /*content: "推荐";*/
      }

    }

    li:last-of-type .borAction-1{
      border-bottom: 0.053333rem #C7C7C7 solid;
      .height(44);
      .line-height(44);
    }


  }

  .Dw-my-b{
    .font-size(12);
    display: block;
    width:100%;
    .height(30);
    .line-height(30);
    .padding(0,12,0,0);
    color: #999;
    text-align: right;
  }
  .infoBg{
    background:rgba(255,84,70,.1);
  }


  .sizeDemo{
    width:100%;
  }

  .modelDemo{
    width:100%;
    &Cont{
      width:100%;
      height:auto;
      display: flex;
      .margin(0,0,40,0);
      &Left{
        .width(50);
        .height(50);
        border-radius: 50%;
        border:1px rgba(0,0,0,.1) solid;
        img{
          width:100%;
          border-radius: 50%;
        }
      }
      &Right{
        .margin(0,0,0,20);
        h2{
          .font-size(14);
        }
        p{
          .font-size(12);
          .margin(5,0,0,0);
          .line-height(19);
        }
      }
    }
  }

  .sizeInfoIMG img{
    width: 100%;
  }

</style>
