<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
      <section>
        <yi23-radiolist-btn :options="customizedFilter.dataList"></yi23-radiolist-btn>
        <yi23-checklist-btn :options="productTypeFilter" v-model="select.productTypeList" title="品类"></yi23-checklist-btn>
        <yi23-checklist-btn :options="sceneFilter.dataList" v-model="select.sceneFilter" title="场景"></yi23-checklist-btn>
      </section>
    </div>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import config from '@/api/config'
  import yi23ChecklistBtn from '@/components/lib/form/checkListBtn'
  import Yi23RadiolistBtn from "@/components/lib/form/radioListBtn"
  export default {
    data () {
      return{
        select:{
          productTypeList:[],
          sceneFilter:[]
        },
        customizedFilter: {
          "dataList": [
            {
              "filterId": 2,
              "filterName": "7天上新"
            },
            {
              "filterId": 3,
              "filterName": "30天上新"
            }
          ],
          "searchName": "filterId"
        },
        sceneFilter: {
          "dataList": [
            {
              "filterId": 6,
              "filterName": "职场"
            },
            {
              "filterId": 7,
              "filterName": "生活"
            },
            {
              "filterId": 8,
              "filterName": "社交"
            }
          ],
          "searchName": "scene"
        },
        productTypeFilter:[
          {
          "filterId": 12,
          "filterName": "连衣裙",
          "tagCategories": [
            2,
            18,
            13,
            5
          ]
        },
          {
            "filterId": 11,
            "filterName": "半裙",
            "tagCategories": [
              2,
              18,
              5
            ]
          },
          {
            "filterId": 6,
            "filterName": "毛衣/针织衫",
            "tagCategories": [
              13,
              5,
              45
            ]
          },
          {
            "filterId": 20,
            "filterName": "长裤",
            "tagCategories": [
              4,
              21,
              5
            ]
          },
          {
            "filterId": 7,
            "filterName": "大衣/披肩",
            "tagCategories": [
              5,
              48
            ]
          },
          {
            "filterId": 8,
            "filterName": "夹克/外套",
            "tagCategories": [
              5
            ]
          },
          {
            "filterId": 2,
            "filterName": "上衣",
            "tagCategories": [
              13,
              5
            ]
          },
          {
            "filterId": 21,
            "filterName": "配饰",
            "tagCategories": [
              44
            ]
          },
          {
            "filterId": 4,
            "filterName": "衬衫",
            "tagCategories": [
              13,
              5
            ]
          },
          {
            "filterId": 14,
            "filterName": "套装",
            "tagCategories": [
              5
            ]
          },
          {
            "filterId": 5,
            "filterName": "卫衣",
            "tagCategories": [
              13,
              5
            ]
          },
          {
            "filterId": 9,
            "filterName": "西服",
            "tagCategories": [
              5
            ]
          },
          {
            "filterId": 17,
            "filterName": "风衣",
            "tagCategories": [
              5
            ]
          },
          {
            "filterId": 16,
            "filterName": "羽绒服/棉服",
            "tagCategories": [
              5
            ]
          },
          {
            "filterId": 10,
            "filterName": "中裤/短裤",
            "tagCategories": [
              4,
              21,
              5
            ]
          },
          {
            "filterId": 3,
            "filterName": "T恤",
            "tagCategories": [
              13,
              5
            ]
          },
          {
            "filterId": 13,
            "filterName": "连体裤",
            "tagCategories": [
              21,
              5
            ]
          },
          {
            "filterId": 18,
            "filterName": "背心/马甲",
            "tagCategories": [
              5
            ]
          }]
      }
    },
    components:{
      Yi23RadiolistBtn,
      yi23ChecklistBtn,
      goBack
    },
    watch:{
    },
    computed: {

    },
    created () {
      this.axios.get(config.categoryPage).then((res)=>{
            if(res.data.code==200){
              console.log(res.data.data)

            }
          })
    },
    methods: {

    },
  }
</script>
<style scoped lang="less">



</style>
