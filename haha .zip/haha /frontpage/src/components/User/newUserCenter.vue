<template>
  <div class="yclosetContainer"><!--userCenterPage-->
    <div class="header">
      <go-back></go-back>
    </div>
    <div class="yclosetCon"><!--核心内容部分-->
      <div class="userCenterPage">
        <div class="memberWrap">
          <template v-if="useStatus">
            <div class="memberGrade"  v-if='memberData'>
              <div class="currentGrade">
                <div class="currentGrade-left">
                  <span>当前等级</span>
                  <span class="font-roboto-r">{{memberData.currentLevel}}</span>
                </div>
                <div class="currentGrade-right" @click="skipMemberCenter()">
                  <div>会员中心</div>
                  <i class="footer-triangle"></i>
                </div>
              </div>
              <div class="gradeInfo" v-if="memberData.memberBenefits">
                <div>
                  <div class="font-roboto-r">{{memberData.memberBenefits.userBoxSlotCount}}</div>
                  <p>个衣位</p>
                </div>
                <div >
                  <div class="font-roboto-r">{{memberData.totalPoint}}</div>
                  <p class="integral-arrow">总积分</p>
                </div>
                <div>
                  <div class="font-roboto-r" :class="{'font-roboto-r-text':memberData.memberBenefits.saleDiscount=='限时'}">{{memberData.memberBenefits.saleDiscount}}</div>
                  <p>购衣折扣</p>
                </div>
              </div>
            </div>
            <div class="residueDay" v-if='memberData'>
              <div class="residueDay-left"><span class="font-roboto-r">{{remainDays}}</span>天剩余有效期</div>
              <div class="residueDay-right" @click="buyCard">立即续费</div>
            </div>
          </template>
          <template v-else>
            <div class="memberGrade">
              <div class="currentGrade">
                <div class="currentGrade-left">
                  <span class="notMember">开通会员，尊享5大权益</span>
                </div>
                <div class="currentGrade-right" @click="skipMemberCenter()">
                  <div>查看权益</div>
                  <i class="footer-triangle"></i>
                </div>
              </div>
              <div class="gradeInfo bitmapList">
                <div>
                  <img src="https://yimg.yi23.net/webimg/web/images/20181009/bitmap1.png" alt="">
                </div>
                <div>
                  <img src="https://yimg.yi23.net/webimg/web/images/20181009/bitmap2.png" alt="">
                </div>
                <div>
                  <img src="https://yimg.yi23.net/webimg/web/images/20181009/bitmap3.png" alt="">
                </div>
                <div>
                  <img src="https://yimg.yi23.net/webimg/web/images/20181009/bitmap4.png" alt="">
                </div>
                <div>
                  <img src="https://yimg.yi23.net/webimg/web/images/20181009/bitmap5.png" alt="">
                </div>
              </div>
            </div>
            <div class="residueDay">
              <div class="residueDay-left"><span class="font-roboto-r">{{remainDays}}</span>天剩余有效期</div>
              <div class="residueDay-right" @click="buyCard">成为会员</div>
            </div>
          </template>
        </div>

        <!--功能列表-->
        <ul class="userFunctionList">
          <router-link to="/Event/rewardList" tag="li">
            <div class="ph2">
              <i class="icon yi23iconfont icon-gift-9"></i>
              <p>邀请有奖</p>
            </div>
          </router-link>

          <router-link to="/User/profile" tag="li" >
            <div class="ph2">
              <i class="icon yi23iconfont icon-profile-9"></i>
              <p>我的资料</p>
            </div>
          </router-link>

          <router-link to="/User/couponPage" tag="li">
            <div class="ph2">
              <i class="icon yi23iconfont icon-coupon-9"></i>
              <p>优惠券</p>
            </div>
          </router-link>

          <router-link to="/User/payRecordPage" tag="li" >
            <div class="ph2">
              <i class="icon yi23iconfont icon-orderlist-9"></i>
              <p>支付记录</p>
            </div>
          </router-link>

          <!--<router-link to="/Others/qna" tag="li">-->
          <li @click="urlFAQ">
            <div class="ph2">
              <i class="icon yi23iconfont icon-question-9"></i>
              <p>常见问题</p>
            </div>
          </li>
          <!--</router-link>-->

          <router-link to="/Index/configPage" tag="li">
            <div class="ph2">
              <i class="icon yi23iconfont icon-setting-9"></i>
              <p>设置</p>
            </div>
          </router-link>

          <li>
            <a href="tel://4006504580">
              <div class="ph2">
                <i class="icon yi23iconfont icon-call-9"></i>
                <p>客服电话</p>
              </div>
            </a>
          </li>

          <!--<router-link to="/Others/ntalkerService" tag="li" >-->
          <li @click="urlNtalkerService">
            <div class="ph2">
              <i class="icon yi23iconfont icon-service-copy"></i>
              <p>在线客服</p>
            </div>
          </li>
          <!--</router-link>-->
        </ul>
      </div>
      <!--等级升级提示-->
      <div v-show="iconClose">
        <div class="HVcenter" v-if="userCenterPage" >
          <div class="userCenterPageGradeImg image-ratio">
            <img :src="userCenterPage.card_img" alt="">
          </div>
          <div class="userCenterPageGradeInfo">
            <p class="GradeInfo">亲爱的女神，恭喜您已获得{{ userCenterPage.pointAvailable }}积分，<br>积分已达到{{userCenterPage.levelName}}。更多会员权益等你来赢。</p>
            <router-link to="/User/userRightsPage" tag="p" class="look">
              查看会员权益
            </router-link>
          </div>
          <div class="yclosetCenterClose">
            <i class="yi23iconfont icon-closex" @click="iconClose=false"></i>
          </div>
        </div>
        <div class="yclosetShade" @click="iconClose=false"></div>
      </div>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar :pageNumber="4"></bottom-Bar>
    </div>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import bottomBar from 'base/BottomBar'
  import common from 'common/js/common';
  import { member, userInfoForToken } from 'api/user';
  export default {
    data(){
      return{
        userCenterPage: null,
        iconClose:false,
//        ppa:true,
        useStatus:1,
        memberData:null,
        remainDays:0
      }
    },
    components:{
      goBack,
      bottomBar
    },
    created () {
      // userCenterPage().then((res)=>{
      //   this.userCenterPage = res.data.uinfo;
      //   // 上一版 星级展示的
      //   // this.$nextTick(function () {
      //   //   this.setWidth(res.data.uinfo.pointTotal, res.data.uinfo.nextLevel);
      //   // })
      // });
      this.getMember();
    },
    methods:{
      //qna
      urlFAQ:function () {
        window.location.href = '/architecture/QnA'
      },

      //ntalkerService
      urlNtalkerService:function () {
        window.location.href = '/architecture/customerService'
      },

      setWidth (pointTotal,nextLevel){
        let percent = (parseFloat(pointTotal)/parseFloat(nextLevel))*100 + '%';
        this.$refs.ProgressBg.style.width = percent;
        this.$refs.bar.style.left = percent;
      },
      buyCard(){
        window.location.href="/yi23/Home/Member/payPage"
      },

      getMember(){
        let params = {}
        if(this.version){
          params.version = this.version;
        }
        member(params).then((res)=>{
          let that = this;
          if(res && res.code == 200){
            if (res.data.user && res.data.user.memberStatus == 1) {
              that.useStatus = res.data.user.memberStatus;
              that.remainDays = res.data.user.remainDays;
            } else {
              that.useStatus = 0;
            }
            this.memberData = res.data
          }
        });
      },
      skipMemberCenter(){
        this.$router.push({
          name:'memberCenter',
          query:{ needRefreshView:1}
        })
      },
    },
    watch:{
      // userCenterPage:function (newVal, oldVal) {
      //   if ( typeof(newVal) == 'object' && !!newVal.level)
      //   {
      //     let levelUp = common.getCookie('levelUp' + newVal.level)
      //     if( typeof (levelUp) == 'undefined' || levelUp == 0)
      //     {
      //       this.iconClose = true;
      //       common.setCookie('levelUp' + newVal.level, newVal.level)
      //     }
      //   }
      // }
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";

  .HVcenter{
    /*background: #fff;*/
    height:auto;
    width:80%;
  }

  .yclosetFooter{
    .height(45);
  }
  .yclosetCon{
    background: #f7f7f7;
  }
  .userCenterPage{
    display: flex;
    justify-content:center;
    align-items: center;
    flex-wrap: wrap;
    width:100%;
    .userCard{
      background: #f7f7f7;
      .padding(10,10,10,10);
      display: block;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      width:100%;
    }


    /*会员按钮*/
    .userBtn{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      .padding(10,10,10,10);
      justify-content: space-between;
      background: #fff;

      span{
        width:47%;
        button{
          width:100%;
          .height(36);
          background: #ff544b;
          color: #fff;
          .font-size(14);
          border-radius: 0.106667rem;
        }
      }
      span:first-of-type{
        width:47%;
        border-right: .5px rgba(0,0,0,.1) solid;
        .padding(0,10,0,0);
        button{
          width:100%;
          background: #fff;
          border:.5px rgba(0,0,0,.1) solid;
          color:#666
        }
      }
    }
    /*功能列表*/
    ul.userFunctionList{
      width:100%;
      .padding(20,10,20,10);
      height: auto;
      display: flex;
      flex-wrap: wrap;
      background: @color-background;
      border-top:10px #f7f7f7 solid;
      border-bottom: 10px #f7f7f7 solid;
      li{
        display: flex;
        flex-wrap: wrap;
        justify-content:center;
        align-items:center;
        width:33%;
        .height(100);
        border-right: .5px #e6e6e6 solid;
        border-bottom: .5px #e6e6e6 solid;
        .ph2{
          display: flex;
          flex-wrap: wrap;
          justify-content:center;
          align-items: center;
          width: 100%;
          .height(60);
        }
        i,p{
          display: flex;
          justify-content:center;
          align-items: center;
          width: 100%;
        }
        p{
          .font-size(13);
        }
        i{
          .font-size(30)
        }
      }

      li:nth-child(3n){
        border-right: none;
      }
      li:nth-child(7),li:nth-child(8),li:nth-child(9){
        border-bottom: none;
      }
      li a, li a:hover{
        color: #000;

      }
    }
  }

  /*等级升级提示*/
  .userCenterPageGradeInfo{
    background: #fff;
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    p{
      .font-size(13);
      line-height:2;
      text-align: center;
      width:100%;
    }
    p.GradeInfo{
      .padding(40,20,40,20);
      letter-spacing: -1px;
    }
    p.look{
      .font-size(14);
      .padding(0,0,20,0);
      color: #cdab6a;
      text-align: center;
    }
  }
  .userCenterPageGradeImg{
    width:100%;
    height: 0;
    overflow: hidden;
    padding-bottom: 73.5294%;
    position: relative;
    img{
      width: 100%;
      position: absolute;
    }
  }
  .image-ratio{
    /*background: #fff;*/
  }
  .icon-closex{
    .font-size(40);
    color:@color-background;
  }


  /*用户等级*/
  .userCardY,.userCardJ,.userCardZ{
    width:100%;
    .height(200);
    position: relative;
    display: flex;
    justify-content: center;
    align-items:center;
  }
  .userCardYIMG,.userCardJIMG,.userCardZIMG{
    width:100%;
    height: 0;
    padding-bottom: 54.6742%;
    overflow: hidden;
    position: relative;
    /*background: #999;*/
    border-radius: 0.32rem;
    img{
      width:100%;
      position: absolute;
      top:0;
      left:0;
    }
  }
  .userCardYCon,.userCardJCon,.userCardZCon{
    position: absolute;
    top:0;
    left:0;
    width: 100%;
    .height(200);
    text-align: center;
    .font-size(18);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
  }

  .YConTop,.JConTop,.ZConTop{
    display: flex;
    flex-wrap: wrap;
    width:100%;
    .height(40);

    h2,p{
      flex-wrap: wrap;
      width:100%;
      display: flex;
      .padding(0,15,0,15);
    }
    h2{
      .font-size(24);
      .height(30);
      .margin(0,0,10,0);
      .padding(15,15,0,15);
      color: #666;
      a{
        color: #000;
      }
      i{
        .font-size(10);
        display: flex;
        justify-content: center;
        align-items: flex-end;
        .padding(0,0,0,10);
        .height(29);
      }
    }
    p{
      .font-size(10);
      color: #666;
      line-height: 1.5;
      text-align: left;
    }
    p.expiryTime{
      .font-size(14)
    }
  }
  .JConTop,.ZConTop{
    h2,p{
      color: @color-background;
    }
    h2{
      i{
        color: #666;
      }
    }
  }
  .YConBottom,.JConBottom,.ZConBottom{
    display: flex;
    flex-wrap: wrap;
    width:100%;
    .height(40);

    .integral{
      flex-wrap: wrap;
      width:100%;
      .height(20);
      display: flex;
      .padding(0,15,0,15);
      justify-content: space-between;
      p{
        display: flex;
        color: #666;
        .font-size(12);
      }
    }
    .userScore{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      .height(20);
      .padding(0,15,0,15);
      .Progress{
        display: flex;
        width:100%;
        .height(4);
        border-radius: 0.213333rem;
        background: rgba(0, 0, 0, 0.1);
        position: relative;
        z-index: 2;
        .ProgressBg{
          position: absolute;
          top:px;
          left:0;
          z-index: 3;
          width:0%;
          .height(4);
          border-radius: 0.213333rem;
          transition: width 4s;
          background: #7b7b7b; /* Old browsers */
          background: -moz-linear-gradient(left,  #7b7b7b 0%, #eff8fe 100%); /* FF3.6-15 */
          background: -webkit-linear-gradient(left,  #7b7b7b 0%,#eff8fe 100%); /* Chrome10-25,Safari5.1-6 */
          background: linear-gradient(to right,  #7b7b7b 0%,#eff8fe 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#7b7b7b', endColorstr='#eff8fe',GradientType=1 ); /* IE6-9 */
        }
        .bar{
          position: absolute;
          .top(-2);
          left:0%;
          z-index: 3;
          .width(8);
          .height(8);
          border-radius: 0.213333rem;
          background: @color-background;
          box-shadow: 0 0 1.066667rem #fff;
          transition: left 4s;

        }
      }
    }
  }
  .JConBottom{
    .integral{
      p{
        color: @color-background;
      }
    }
    .userScore{
      .Progress{
        background: rgba(255, 255, 255, 0.3);
        .ProgressBg{
          width:0%;
          background: #e37962; /* Old browsers */
          background: -moz-linear-gradient(left,  #e37962 0%, #ffcbd8 100%); /* FF3.6-15 */
          background: -webkit-linear-gradient(left,  #e37962 0%,#ffcbd8 100%); /* Chrome10-25,Safari5.1-6 */
          background: linear-gradient(to right,  #e37962 0%,#ffcbd8 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e37962', endColorstr='#ffcbd8',GradientType=1 ); /* IE6-9 */
        }
        .bar{
          left:0%;
        }
      }
    }
  }
  .ZConBottom{
    .integral{
      p{
        color: #999;
      }
    }
    .userScore{
      .Progress{
        background: rgba(255, 255, 255, 0.3);
        .ProgressBg{
          width:99%;
          background: #262626; /* Old browsers */
          background: -moz-linear-gradient(left,  #262626 0%, #cecece 100%); /* FF3.6-15 */
          background: -webkit-linear-gradient(left,  #262626 0%,#cecece 100%); /* Chrome10-25,Safari5.1-6 */
          background: linear-gradient(to right,  #262626 0%,#cecece 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#262626', endColorstr='#cecece',GradientType=1 )
        }
        .bar{
          left:98%;
        }
      }
    }
  }
  .memberWrap{
    background:#ffffff;
    .memberGrade{
      width:329 * @unit;
      height: 178.1 * @unit;
      background-color:red;
      margin:10 * @unit 23 * @unit 25 * @unit 23 * @unit;
      border-radius: 12 * @unit;
      background: url("https://yimg.yi23.net/webimg/web/images/20180918/card-bg.png?11") 0 0 no-repeat;
      background-size:100% 100%;
      box-shadow: 0 11px 39px -17px #ff7878;
      .font-roboto-r{
        font-weight: 600;
      }
      .currentGrade{
        display:flex;
        flex-direction:row;
        justify-content: space-between;
        padding:27 * @unit 26 * @unit 0  26 * @unit ;
        .currentGrade-left{
          font-size:16 * @unit;
          font-weight:500;
          color:#ffffff;
          :nth-child(2){
            font-size:18 * @unit;
          }
          .notMember{
            font-size:14 * @unit;
            color:#ffffff;
          }
        }
        .currentGrade-right{
          display:flex;
          font-size:13 * @unit;
          color:#ffffff;
          margin-top:2 * @unit;
          .footer-triangle{
            display:block;
            width: 12 * @unit;
            height:12 * @unit;
            background:url(https://yimg.yi23.net/webimg/web/xy/Image/20180906/xyTriangle.png) 50% 50% no-repeat;
            background-size:12 * @unit 12 * @unit;
          }
        }
      }
      .gradeInfo{
        margin:52 * @unit 95 * @unit 0 26 * @unit;
        display:flex;
        flex-direction:row;
        justify-content: space-between;
        color:#ffffff;
        & > div > div{
          font-size:22 * @unit;
          height:28 * @unit;
          line-height:28 * @unit;
        }
        & > div > p{
          font-size:11 * @unit;
          height:16 * @unit;
          line-height:16 * @unit;
        }
        .integral-arrow{
          position:relative;
          display: table;
          font-size:11 * @unit;
          /* &:after{
             position:absolute;
             top:12%;
             right:-11px;
             content:'';
             overflow:hidden;
             display:block;
             width: 12 * @unit;
             height:12 * @unit;
             background:url(https://yimg.yi23.net/webimg/web/xy/Image/20180906/xyTriangle.png) 50% 50% no-repeat;
             background-size:12 * @unit 12 * @unit;
           }*/
        }
        .font-roboto-r-text{
          font-size: 20 * @unit;
        }
      }
    }
    .residueDay{
      width:329 * @unit;
      height:28 * @unit;
      margin:0 0 25 * @unit 23 * @unit;
      display:flex;
      justify-content: space-between;
      line-height: 28 * @unit;
      .residueDay-left{
        font-size: 14 * @unit;
        font-weight: 300;
        letter-spacing: 0.1px;
        text-align: center;
        color: #666666;
        span{
          font-size: 24 * @unit;
          color: #333333;
          margin-right:4 * @unit;
        }
      }
      .residueDay-right{
        width: 77 * @unit;
        height: 26 * @unit;
        border-radius: 100 * @unit;
        border: solid 1px #ff544b;
        font-size: 11 * @unit;
        line-height: 26 * @unit;
        letter-spacing: 0.4px;
        text-align: center;
        color: #ff544b;
      }
    }
    .bitmapList{
      width:auto;
      height:34 * @unit;
      margin-top:62 * @unit !important;
      div,div img{
        width:34 * @unit;
        height:34 * @unit;
      }
    }
  }

</style>

