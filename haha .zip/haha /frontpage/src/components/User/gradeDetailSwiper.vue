<template>

    <div class="shareConStepTitle" v-if="list">
      <div class="stepList">
        <template v-for="(items,indexs) in list">
          <div class="stepListCom">
            <li @click="liClick(item,index,indexs)" v-for="(item,index) in items">
              <div class="stepICON-box">
                <div class="stepICON" :class="{'stepICONAct':indexs==idx&&index==idxs}"><img :src="item.memberBenefitImage" alt=""></div>
                <p class="P1">{{item.memberBenefitName}}</p>
              </div>
            </li>
            <transition
              name="accordion"
              v-on:enter="enter(indexs)"
              v-on:after-enter="afterEnter(indexs)"
              v-on:leave="leave(indexs)"
              v-on:after-leave="afterLeave(indexs)">

              <!--<div class="stepBox" :class="['stepBox accordion-enter'+idxs,{'accordion-enter-active':idx==indexs},{'accordion-leave-to':idx!=indexs}]">-->
              <div class="stepBox" :class="['stepBox'+idxs]" v-show="idx==indexs" ref="stepBox">
                <h2 v-html="stringFilter(memberBenefitTitle)"></h2>
                <p v-html="stringFilter(memberBenefitDescription)"></p>
              </div>
            </transition>
          </div>
        </template>
      </div>
    </div>


</template>

<script>
  export default {
    name: "list-swiper",
    data () {
      return {
        vip:1,
        list:'',
        idx:0,//行
        idxs:0,//列
        memberBenefitTitle:'',
        memberBenefitDescription:'',
      }
    },
    props:[
      'rewardList',
      'member',
      'type'
    ],
    watch:{
    },
    created(){
      let val = this.rewardList;
      let list = {}
      let arr = [];
      let totalSize=val.length
      val.forEach((t,v)=>{
        let intP = (v+1)%4;
        let key=parseInt(v/4)
        arr.push(t)
        if(intP==0){
          list[key]=arr;
          arr=[]
        }else if(v==totalSize-1){
          list[key]=arr;
          arr=[]
        }
      })
      this.list = list;
      this.memberBenefitDescription = list[0][0].memberBenefitDescription
      this.memberBenefitTitle = list[0][0].memberBenefitTitle

      let query =  this.$route.query;
      if(query && query.type && this.type){
        for ( var key in list) {
          list[key].some((t,v)=>{
            if(t.memberBenefit==query.type){
              this.idx = key//行
              this.idxs = v//列
              this.memberBenefitDescription = list[key][v].memberBenefitDescription
              this.memberBenefitTitle = list[key][v].memberBenefitTitle
            }
          })
        }

      }


    },
    methods:{
      liClick(val,index,indexs){
        if(+this.idx===+indexs && +this.idxs ===+index){
          this.idx = -1
        }else{
          this.idx = +indexs
          this.idxs = +index
          this.memberBenefitDescription = val.memberBenefitDescription
          this.memberBenefitTitle = val.memberBenefitTitle
        }

      },
      stringFilter(value){
        if(typeof(value) === 'string'){
          value = value.split('#');
          value.forEach((v,t)=>{
            if((t+1) % 2 === 0){
              if(value[t].indexOf('-') === -1){
                value[t] = '<span style="color:#ff544b"> '+value[t]+' </span>'
              }else{
                value[t] = '<span style="color:#afafaf"> '+value[t]+' </span>'
              }
            }
          })
          return value.join('')
        }else {
          return value
        }
      },
      enter (indexs) {
        this.$refs.stepBox[indexs].style.height = 'auto'
        let endWidth = this.$refs.stepBox[indexs].scrollHeight + 'px'
        this.$refs.stepBox[indexs].style.height = '0px'
        this.$refs.stepBox[indexs].offsetHeight // force repaint
        // noinspection JSSuspiciousNameCombination
        this.$refs.stepBox[indexs].style.height = endWidth

      },
      afterEnter (indexs) {
        this.$refs.stepBox[indexs].style.height = null
      },
      leave (indexs) {
        this.$refs.stepBox[indexs].style.height = window.getComputedStyle(this.$refs.stepBox[indexs]).height
        this.$refs.stepBox[indexs].offsetHeight // force repaint
        this.$refs.stepBox[indexs].style.height = '0px'
      },
      afterLeave (indexs) {
        this.$refs.stepBox[indexs].style.height = null
      }

    }

  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";


  .card-content {
    background-color: rgba(255,255,255,0.8);
    border-radius: 6px;
    box-shadow: 0 0 50px 0 rgba(229, 184, 109, 0.3);
    min-height: 61vh;
    padding: 35*@unit;
    text-align: left;
    margin-bottom: 30*@unit;
    .card-tit{
      font-size: 11*@unit;
      line-height: 16*@unit;
      letter-spacing: 0.2px;
      color: #333333;
    }
    h1{
      margin-top: 8*@unit;
      font-size: 35*@unit;
      font-weight: bold;
      font-stretch: condensed;
      line-height: 41*@unit;
      color: #333333;
      span{
        font-size: 11*@unit;
        font-weight: normal;
        letter-spacing: 0.2px;
      }
    }
    /*p {*/
    /*font-size: 20px;*/
    /*line-height: 30px;*/
    /*font-weight: 600;*/
    /*i {*/
    /*font-style: normal;*/
    /*}*/
    /*}*/
    span {
      font-size: @font-size-small;
    }

  }


  //
  .accordion-enter-active,
  .accordion-leave-active {
    /*will-change: height, opacity;*/
    transition: height .3s;
    /*max-height:100px;*/
    overflow: hidden;
  }

  .accordion-enter,
  .accordion-leave-to {
    height: 0 !important;
    max-height:0;
    /*opacity: 0;*/
  }

  .stepICONAct{
    border-radius: 100%;
    background: rgba(247,247,247,1);

  }

  /*.stepICONAct img{*/
    /*position: relative;*/
    /*border-radius: 100%;*/
  /*}*/
  .stepICONAct img{
    /*content: 'these are the zoom buttons';*/
    /*display: block;*/
    /*width: 100%;*/
    /*height: 100%;*/

    /*position: absolute;*/
    /*top:0;*/
    /*left: 0;*/
    /*border:3px solid #6F7D4C;*/
    /*box-shadow: 0px 0px 12px #999999;*/
  }
  .shareConStepTitle {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;

    .stepList{
      width: 100%;
      /*margin: 1.066667rem 0 .533333rem 0;*/

      .stepListCom{
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        /*justify-content: space-between;*/
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
      }

      .stepBox{
        display: block;
        width: 100%;
        border-radius: 6*@unit;
        background-color: #fafafa;
        position: relative;
        max-height: 20vh;
        //margin-top: 16*@unit;
        //margin-bottom: 25*@unit;

        h2{
          font-size: 11*@unit;
          line-height: 16*@unit;
          letter-spacing: 0.3px;
          color: #111111;
          margin:12*@unit;
          margin-bottom: 0;
        }
        p{
          font-size: 10*@unit;
          font-weight: 300;
          line-height: 1.5;
          color: #666666;
          margin:12*@unit;
          margin-top: 2*@unit;
        }
      }
      .stepBox:after{
        content: '';
        /*width: 10px;*/
        /*height: 8px;*/
        display: block;
        position: absolute;
        width:0;
        height:0;
        border-width: 10px;
        border-style:solid dashed dashed dashed;
        border-color: transparent transparent #fafafa transparent;
        top:-18px;

      }
      .stepBox0:after{
        left:5%;
      }
      .stepBox1:after{
        left:32%;
      }
      .stepBox2:after{
        left:61%;
      }
      .stepBox3:after{
        left:89%;
      }

      li {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        /*width: 4.533333rem;*/
        //width: 34*@unit;
        /*height: 70px;*/
        /*padding: .533333rem 0;*/
        margin-bottom: 18*@unit;
        position: relative;
        width: 25%;

        .stepICON-box{
          width: 66*@unit;
        }

        .stepICON {
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -webkit-box-pack: center;
          -ms-flex-pack: center;
          justify-content: center;
          width: 100%;
          height: 66*@unit;
          /*height: 1.28rem;*/
          //margin-bottom: 8*@unit;
          justify-content:center;
          align-items: center;
          img{
            /*width: 1.386667rem;*/
            width: 54*@unit;
            height: 54*@unit;
            display: block;
          }
        }
        p{
          display: block;
        }

        .P1 {
          font-size: 12*@unit;
          /*font-weight: 600;*/
          line-height: 17*@unit;
          text-align: center;
          color: #111111;
          margin-top: 3*@unit;
        }

        .P2 {
          font-size: .533333rem;
          color: #999;
          width: 100%;
          text-align: center;
        }
      }
      li:nth-child(4n+1){
        justify-content: flex-start;
        position: relative;
        left:-5*@unit;
        .stepICON-box{
          position: relative;
        }
      }
      li:nth-child(4n+2){
        left:-6*@unit;
        .stepICON-box{
          position: relative;
        }
      }
      li:nth-child(4n+3){
        /*justify-content: flex-end;*/
        position: relative;
        right:-6*@unit;
        .stepICON-box{
          position: relative;
        }
      }
      li:nth-child(4n+4){
        justify-content: flex-end;
        position: relative;
        right:-6*@unit;
        .stepICON-box{
          position: relative;
        }
      }
    }
  }

</style>
