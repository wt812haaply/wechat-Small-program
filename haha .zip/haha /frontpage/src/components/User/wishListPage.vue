<template>
  <div class="wishListContainer">
    <div class="wishListHeader">
      <goBack></goBack>
    </div>
    <div class="wishListConten" v-if="wishListPage && wishListPage.product != null">
      <list :prodList="wishListPage.product" @delSuccess="delSuccess" :tipsStatus="true"></list>
      <div v-if="wishListPage.product ==0">
          <div class="new_tips">
              <div>IT’S EMPTY HERE</div>
              <div>心愿单中还没有衣物</div>
              <div class="new_tipsBut" @click="listLink()">
                <button>挑选时装加入心愿单</button>
              </div>
          </div>
      </div>
    </div>
    <div class="wishListFooter">
      <bottom-Bar :pageNumber="2"></bottom-Bar>
    </div>
  </div>
</template>

<script>
   import goBack from 'base/GoBack'
   import list from 'base/List'
   import { addWishList,delWishList,wishListPage } from 'api/subscribe'
   import bottomBar from 'base/BottomBar'
export default {
    data () {
      return{
        wishListPage:null
      }
    },
    components:{
      list,
      goBack,
      bottomBar
    },

    computed: {

    },
    created () {
      this.init();
    },
    methods: {
      init:function () {
        wishListPage().then((res)=>{
          res.data.product.map(function(el){
//            console.log(el)
            for(var k in el){
              el['favor'] =1;
            }
          })
//          console.log(res.data)
          this.wishListPage = res.data;

        });
      },
      delSuccess:function () {
        this.init();
      },
      listLink:function(){
        this.$router.push({
          path:'/Subscribe/pdtListPage',
        })
      },
    },
}
</script>

<style scoped lang="less">

    .wishListContainer{
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      -ms-flex-direction: column;
      flex-direction: column;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
      height: 100%;
      width: 100%;
      background: #fff;
    }
    .wishListConten{
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -ms-flex-wrap: wrap;
      flex-wrap: wrap;
      -webkit-box-align: start;
      -ms-flex-align: start;
      align-items: flex-start;
      -webkit-box-flex: 1;
      -ms-flex: 1;
      flex: 1;
      width: 100%;
      height: 100%;
      overflow: scroll;
      background: white;
      .new_tips{
        position:fixed;
        /*padding: 40px 0 0 0;*/
        -webkit-transform: translateX(-50%) translateY(-50%);
        -moz-transform: translateX(-50%) translateY(-50%);
        -ms-transform: translateX(-50%) translateY(-50%);
        transform: translateX(-50%) translateY(-50%);
        width:70%;
        top:50%;
        left:50%;
        text-align:center;
        :nth-child(1){
          font-family: "Futura";
          font-weight:300;
          font-size:20px;
          text-align: center;
          padding-bottom:5px;
        }
        :nth-child(2){
          font-size:12px;
        }
        .new_tipsBut{
          background:#000;
          width:60%;
          hieght:40px;
          margin:100px auto 0;
          button{
            height:40px;
            font-size:12px;
            font-weight:700;
            background:#000;
            color:white;
          }
        }
      }
    }
</style>
