<template>
  <div class="yclosetContainer"><!--couponPage-->
    <div class="yclosetHeader">
      <go-back></go-back>
      <div class="pageTop"><!--顶部输入券码-->
        <input type="text" v-model="changeCode" class="topInput" placeholder="请输入券码">
        <button class="topBtn font-m" type="submit" @click="_couponExchange">兑换</button>
      </div>
    </div>
    <!--
      norec == 1 有
      norec == 0 没有
    -->
    <div class="yclosetCon" v-if="userCoupon && userCoupon.norec == 1"><!--核心内容部分-->
      <div class="couponPage">
        <!--优惠券列表-->
        <div class="conList">
          <ul class="couponCon">
            <li v-for="(item) in userCoupon.list"><!--A-->
              <div class="Left">
                <p class="eventName font-m">{{ item.couponTitle }}</p>
                <p class="eventTime font-r">有效期{{ item.start_date }}-{{ item.exp_date}}</p>
                <p class="eventTime font-r">{{ item.desc }}</p>
              </div>
              <div class="Right">
                <div class="RightIMG image-ratio" v-if="item.status === 0">
                  <img src="//tu.95vintage.com/web_source/Home/Common/images/disable.png" alt="">
                </div>
                <div class="RightIMG image-ratio" v-else-if="item.status === 1">
                  <img src="//tu.95vintage.com/web_source/Home/Common/images/disable.png" alt="">
                </div>

                <div class="RightIMG image-ratio" v-else-if="item.status === 2">
                  <img src="//tu.95vintage.com/web_source/Home/Common/images/active.png" alt="">
                </div>

                <div class="RightIMG image-ratio" v-else-if="item.status === 3">
                  <img src="//tu.95vintage.com/web_source/Home/Common/images/active.png" alt="">
                </div>


                <!--status==0 已使用-->
                <!--status==1 已过期-->
                <!--status==2 未生效-->
                <!--status==3 未使用-->

                <div class="RightCon">
                  <p class="eventZT font-m" >{{item.status | statusCon}}</p>
                  <p class="eventZK font-m" v-if="item.valueType === 0">
                    {{ item.value }}
                    <i>件</i>
                  </p>
                  <p class="eventZK font-m" v-else-if="item.valueType === 1">
                    <i>￥</i>{{ item.value }}

                  </p>
                  <p class="eventZK font-m" v-else-if="item.valueType === 2">
                    {{ item.value*10 }}
                    <i>折</i>
                  </p>
                </div>
              </div>
            </li>
          </ul>
        </div>


      </div>
    </div>
    <!--null-->
    <div class="yclosetCenter" v-if="(userCoupon && userCoupon.norec == 0)">
      <div class="RecordPageCon">
        <h2 class="fontUbuntu">NO RECORD (YET)</h2>
        <p>暂无支付记录</p>
      </div>
    </div>

    <yi23Toast :open="toastOpen"  @toastColse="toastColse">
      {{ errorMsg }}
    </yi23Toast>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import { couponPage, couponExchange } from 'api/user'
  import yi23Toast from '../lib/Toast.vue'
  export default {
    data(){
      return{
        userCoupon: null,
        changeCode:'',
        toastOpen:false,
      }
    },
    filters: {
      statusCon: function (status) {
        let res='';
        switch (status){
          case  0:
            res='已使用';
            break;
          case  1:
            res='已过期';
            break;
          case  2:
            res='未生效';
            break;
          case  3:
            res='未使用';
            break;
        }
        return res;
      }
    },
    components:{
      goBack,
      yi23Toast
    },
    created () {
      this._couponPage();
      this.errorMsg = '信息为空';
    },
    methods:{
      _couponPage(){
        couponPage().then((res)=>{
//          console.log(res);
          this.userCoupon = res.data;
        });
      },
      _couponExchange(){
        let changeCode = this.changeCode;
        if( changeCode !='' )
        {
          this.changeCode = '';
          couponExchange(changeCode).then((res)=>{
            if (res.code !=200 )
            {
              this.errorMsg = res.msg;
              this.toastOpen = true;
            }else{
              this._couponPage()
            }
          })

        }
        else {
          this.toastOpen=true

        }

      },
      toastColse()
      {
        this.toastOpen=false
      }
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  /*.yclosetHeader{*/
    /*height:auto;*/
  /*}*/
  .yclosetCenter{
    z-index: 1;
    .top(125);
  }
  .yclosetCon{
    .padding(20,0,0,0);
    background: #f7f7f7;
  }
  .pageTop{
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    align-items:center;
    width:100%;
    .height(80);
    background: @color-background;
    border-bottom: 1px #e6e6e6 solid;
    input.topInput{
      .line-height(20);
      .height(20);
      .padding(10,0,10,12);
      border-bottom:.5px rgba(0,0,0,.1) solid;
      background:@color-background;
      flex: 1;
      .margin(0,0,0,10);
      .font-size(14);
    }
    button.topBtn{
      .width(70);
      .height(40);
      background-color: #eee;
      .margin(0,10,0,10);
      background: #000;
      color:#fff;
    }
  }
  .couponPage{
    padding-top:0;
    .conList{
      margin-top: 0;
    }
  }
  ul.couponCon{
    display: flex;
    display: block;
    .padding(0,20,0,20);

  }
  li{
    background: @color-background;
    .height(80);
    width:100%;
    position: relative;
    top:0;
    display: flex;
    align-items:center;
    box-shadow: 0 0 0.32rem rgba(0,0,0,.02);
    .margin(0,0,10,0);
    .Left{
      .margin(0,110,0,0);
      display: flex;
      align-items:center;
      flex-wrap: wrap;
      p{
        width:100%;
        .padding(0,0,0,12);
        text-align: left;
        line-height: 1.5;
      }
      P.eventName{
        .font-size(18);
        color:#333;
      }
      P.eventTime{
        .font-size(12);
        color:#999;
      }
    }
    .Right{
      .width(101);
      .height(80);
      float:right;
      position: absolute;
      top:0;
      right:0;
      display: flex;
      align-items:center;
      flex-wrap: wrap;
      .RightIMG{
        .width(101);
        .height(80);
        display: flex;
        img{
          width:100%;
        }
      }
      .RightCon{
        position: absolute;
        top:0;
        left:0;
        display: flex;
        align-items:center;
        .height(60);
        .padding(10,0,10,0);
        width:100%;
        flex-wrap: wrap;
        p{
          width:100%;
          display: flex;
          justify-content:center;
          align-items:center;
          flex-wrap: wrap;
          color:#fff;
        }
        p.eventZT{
          .font-size(12);
          .padding(0,10,0,0);
          justify-content: flex-end;
        }
        p.eventZK{
          .font-size(30);
          .height(24);
          letter-spacing: -.5px;
          i{
            .font-size(12);
            display: flex;
            align-self:flex-end;
            .padding(0,0,0,2);
          }
        }
      }
    }
  }
  li:last-child{
    .margin(0,0,30,0);
  }
</style>
