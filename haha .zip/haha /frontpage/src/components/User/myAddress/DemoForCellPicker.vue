<template>
  <section class="testss">
    <x-cell v-bind="info" :isLink="true">33</x-cell>
    <cell-swiper :right="rightButtons" selectId="9">
      swipe me</cell-swiper>
    <cell-swiper :right="rightButtons" selectId="10">
      swipe 22</cell-swiper>
    <yi23-field label="地址" v-model="test" placeholder="请输入密码"></yi23-field>
    <div class="flex">
      <div class="flex-item">
        <div class="btn btn-defult" @click="showDemo(1)">城市列表</div>
      </div>
      <div class="flex-item">
        <div class="btn btn-defult" @click="showDemo(2)">年份</div>
      </div>
      <div class="flex-item">
        <div class="btn btn-defult" @click="showDemo(3)">其他</div>
      </div>
    </div>
    <div class="page-picker-wrapper">
      <mt-picker :slots="addressSlots"  valueKey="name" v-model="showCity" @doConfirm="doSelect" @change="onAddressChange" :visible-item-count="5">
      </mt-picker>
    </div>
    <div class="page-picker-wrapper">
      <mt-picker :slots="yearSlot" v-model="yearSlotStatus"  :visible-item-count="5"  @doConfirm="doSelect">
      </mt-picker>
    </div>
    <div class="page-picker-wrapper">
      <mt-picker :slots="others" v-model="testSlotStatus"  valueKey="val" :visible-item-count="5" @change="onOthersChange"  @doConfirm="doSelect">
      </mt-picker>
    </div>
    <p class="page-picker-desc">地址: {{ addressProvince }} {{ addressCity }}</p>
  </section>
</template>

<script>

  /*
  * v-bind info  等价react ...info 解构赋值
  * */
  import XCell from '@/components/lib/cell/Cell';
  import Yi23Field from '@/components/lib/field/Field';
  import CellSwiper from '@/components/lib/cell/CellSwiper';
  import MtPicker from '@/components/lib/picker/picker';
  const addresTest=[
    {
      "id": 1,
      "name": "北京",
      "child": [
        {
          "name": "北京市",
          "id": "30000",
          "child": [
            {
              "id": "512",
              "name": "昌平区"
            },
            {
              "id": "503",
              "name": "朝阳区"
            },
            {
              "id": "504",
              "name": "崇文区"
            },
            {
              "id": "515",
              "name": "大兴区"
            },
            {
              "id": "500",
              "name": "东城区"
            },
            {
              "id": "508",
              "name": "房山区"
            },
            {
              "id": "506",
              "name": "丰台区"
            },
            {
              "id": "502",
              "name": "海淀区"
            },
            {
              "id": "513",
              "name": "怀柔区"
            },
            {
              "id": "509",
              "name": "门头沟区"
            },
            {
              "id": "516",
              "name": "密云县"
            },
            {
              "id": "514",
              "name": "平谷区"
            },
            {
              "id": "507",
              "name": "石景山区"
            },
            {
              "id": "511",
              "name": "顺义区"
            },
            {
              "id": "510",
              "name": "通州区"
            },
            {
              "id": "501",
              "name": "西城区"
            },
            {
              "id": "505",
              "name": "宣武区"
            },
            {
              "id": "517",
              "name": "延庆县"
            }
          ]
        }
      ]
    },
    {
      "id": 2,
      "name": "上海",
      "child": [
        {
          "name": "上海市",
          "id": "30000",
          "child": [
            {
              "id": "2717",
              "name": "宝山区"
            },
            {
              "id": "2703",
              "name": "长宁区"
            },
            {
              "id": "2721",
              "name": "崇明县"
            },
            {
              "id": "3426",
              "name": "川沙区"
            },
            {
              "id": "2720",
              "name": "奉贤区"
            },
            {
              "id": "2712",
              "name": "虹口区"
            },
            {
              "id": "2713",
              "name": "黄浦区"
            },
            {
              "id": "2716",
              "name": "嘉定区"
            },
            {
              "id": "2710",
              "name": "静安区"
            },
            {
              "id": "2719",
              "name": "金山区"
            },
            {
              "id": "2711",
              "name": "卢湾区"
            },
            {
              "id": "2705",
              "name": "闵行区"
            },
            {
              "id": "2714",
              "name": "南汇区"
            },
            {
              "id": "2707",
              "name": "浦东新区"
            },
            {
              "id": "2709",
              "name": "普陀区"
            },
            {
              "id": "2718",
              "name": "青浦区"
            },
            {
              "id": "2715",
              "name": "松江区"
            },
            {
              "id": "2706",
              "name": "徐汇区"
            },
            {
              "id": "2708",
              "name": "杨浦区"
            },
            {
              "id": "2704",
              "name": "闸北区"
            }
          ]
        }
      ]
    },
    {
      "id": 5,
      "name": "广东省",
      "child": [
        {
          "name": "广州市",
          "id": "30000",
          "child": [
            {
              "id": "695",
              "name": "白云区"
            },
            {
              "id": "703",
              "name": "从化区"
            },
            {
              "id": "692",
              "name": "从化市"
            },
            {
              "id": "694",
              "name": "东山区"
            },
            {
              "id": "700",
              "name": "番禺区"
            },
            {
              "id": "696",
              "name": "海珠区"
            },
            {
              "id": "701",
              "name": "花都区"
            },
            {
              "id": "699",
              "name": "黄埔区"
            },
            {
              "id": "697",
              "name": "荔湾区"
            },
            {
              "id": "3409",
              "name": "萝岗区"
            },
            {
              "id": "3410",
              "name": "南沙区"
            },
            {
              "id": "693",
              "name": "天河区"
            },
            {
              "id": "698",
              "name": "越秀区"
            },
            {
              "id": "702",
              "name": "增城市"
            }
          ]
        },
        {
          "name": "潮州市",
          "id": "30001",
          "child": [
            {
              "id": "712",
              "name": "潮安县"
            },
            {
              "id": "3437",
              "name": "枫溪区"
            },
            {
              "id": "713",
              "name": "饶平县"
            },
            {
              "id": "711",
              "name": "湘桥区"
            }
          ]
        },
        {
          "name": "东莞市",
          "id": "30002",
          "child": [
            {
              "id": "743",
              "name": "长安镇"
            },
            {
              "id": "737",
              "name": "常平镇"
            },
            {
              "id": "726",
              "name": "茶山镇"
            },
            {
              "id": "729",
              "name": "大朗镇"
            },
            {
              "id": "728",
              "name": "大岭山镇"
            },
            {
              "id": "721",
              "name": "道滘镇"
            },
            {
              "id": "715",
              "name": "东城区"
            },
            {
              "id": "740",
              "name": "东坑镇"
            },
            {
              "id": "732",
              "name": "凤岗镇"
            },
            {
              "id": "745",
              "name": "高埗镇"
            },
            {
              "id": "717",
              "name": "莞城街道"
            },
            {
              "id": "739",
              "name": "横沥镇"
            },
            {
              "id": "725",
              "name": "洪梅镇"
            },
            {
              "id": "735",
              "name": "厚街镇"
            },
            {
              "id": "730",
              "name": "黄江镇"
            },
            {
              "id": "719",
              "name": "虎门镇"
            },
            {
              "id": "727",
              "name": "寮步镇"
            },
            {
              "id": "720",
              "name": "麻涌镇"
            },
            {
              "id": "714",
              "name": "南城区"
            },
            {
              "id": "738",
              "name": "桥头镇"
            },
            {
              "id": "736",
              "name": "清溪镇"
            },
            {
              "id": "741",
              "name": "企石镇"
            },
            {
              "id": "723",
              "name": "沙田镇"
            },
            {
              "id": "722",
              "name": "石碣镇"
            },
            {
              "id": "718",
              "name": "石龙镇"
            },
            {
              "id": "742",
              "name": "石排镇"
            },
            {
              "id": "3892",
              "name": "松山湖"
            },
            {
              "id": "733",
              "name": "塘厦镇"
            },
            {
              "id": "724",
              "name": "望牛墩镇"
            },
            {
              "id": "716",
              "name": "万江区"
            },
            {
              "id": "734",
              "name": "谢岗镇"
            },
            {
              "id": "731",
              "name": "樟木头镇"
            },
            {
              "id": "744",
              "name": "中堂镇"
            }
          ]
        },
        {
          "name": "佛山市",
          "id": "30003",
          "child": [
            {
              "id": "746",
              "name": "禅城区"
            },
            {
              "id": "750",
              "name": "高明区"
            },
            {
              "id": "747",
              "name": "南海区"
            },
            {
              "id": "749",
              "name": "三水区"
            },
            {
              "id": "748",
              "name": "顺德区"
            }
          ]
        },
        {
          "name": "河源市",
          "id": "30004",
          "child": [
            {
              "id": "751",
              "name": "东源县"
            },
            {
              "id": "752",
              "name": "和平县"
            },
            {
              "id": "754",
              "name": "连平县"
            },
            {
              "id": "755",
              "name": "龙川县"
            },
            {
              "id": "753",
              "name": "源城区"
            },
            {
              "id": "756",
              "name": "紫金县"
            }
          ]
        },
        {
          "name": "惠州市",
          "id": "30005",
          "child": [
            {
              "id": "760",
              "name": "博罗县"
            },
            {
              "id": "759",
              "name": "大亚湾"
            },
            {
              "id": "758",
              "name": "惠城区"
            },
            {
              "id": "761",
              "name": "惠东县"
            },
            {
              "id": "757",
              "name": "惠阳区"
            },
            {
              "id": "762",
              "name": "龙门县"
            }
          ]
        },
        {
          "name": "江门市",
          "id": "30006",
          "child": [
            {
              "id": "769",
              "name": "恩平市"
            },
            {
              "id": "768",
              "name": "鹤山市"
            },
            {
              "id": "763",
              "name": "江海区"
            },
            {
              "id": "767",
              "name": "开平市"
            },
            {
              "id": "764",
              "name": "蓬江区"
            },
            {
              "id": "766",
              "name": "台山市"
            },
            {
              "id": "765",
              "name": "新会区"
            }
          ]
        },
        {
          "name": "揭阳市",
          "id": "30007",
          "child": [
            {
              "id": "3685",
              "name": "东山区"
            },
            {
              "id": "774",
              "name": "惠来县"
            },
            {
              "id": "772",
              "name": "揭东县"
            },
            {
              "id": "773",
              "name": "揭西县"
            },
            {
              "id": "771",
              "name": "普宁市"
            },
            {
              "id": "770",
              "name": "榕城区"
            }
          ]
        },
        {
          "name": "茂名市",
          "id": "30008",
          "child": [
            {
              "id": "780",
              "name": "电白县"
            },
            {
              "id": "777",
              "name": "高州市"
            },
            {
              "id": "778",
              "name": "化州市"
            },
            {
              "id": "776",
              "name": "茂港区"
            },
            {
              "id": "775",
              "name": "茂南区"
            },
            {
              "id": "779",
              "name": "信宜市"
            }
          ]
        },
        {
          "name": "梅州市",
          "id": "30009",
          "child": [
            {
              "id": "784",
              "name": "大埔县"
            },
            {
              "id": "785",
              "name": "丰顺县"
            },
            {
              "id": "788",
              "name": "蕉岭县"
            },
            {
              "id": "782",
              "name": "梅江区"
            },
            {
              "id": "781",
              "name": "梅县"
            },
            {
              "id": "787",
              "name": "平远县"
            },
            {
              "id": "786",
              "name": "五华县"
            },
            {
              "id": "783",
              "name": "兴宁市"
            }
          ]
        },
        {
          "name": "清远市",
          "id": "300010",
          "child": [
            {
              "id": "792",
              "name": "佛冈县"
            },
            {
              "id": "796",
              "name": "连南"
            },
            {
              "id": "795",
              "name": "连山"
            },
            {
              "id": "791",
              "name": "连州市"
            },
            {
              "id": "789",
              "name": "清城区"
            },
            {
              "id": "794",
              "name": "清新县"
            },
            {
              "id": "793",
              "name": "阳山县"
            },
            {
              "id": "790",
              "name": "英德市"
            }
          ]
        },
        {
          "name": "汕头市",
          "id": "300011",
          "child": [
            {
              "id": "803",
              "name": "潮南区"
            },
            {
              "id": "798",
              "name": "潮阳区"
            },
            {
              "id": "799",
              "name": "澄海区"
            },
            {
              "id": "802",
              "name": "濠江区"
            },
            {
              "id": "801",
              "name": "金平区"
            },
            {
              "id": "800",
              "name": "龙湖区"
            },
            {
              "id": "797",
              "name": "南澳县"
            }
          ]
        },
        {
          "name": "汕尾市",
          "id": "300012",
          "child": [
            {
              "id": "3996",
              "name": "城区"
            },
            {
              "id": "806",
              "name": "海丰县"
            },
            {
              "id": "805",
              "name": "陆丰市"
            },
            {
              "id": "807",
              "name": "陆河县"
            }
          ]
        },
        {
          "name": "韶关市",
          "id": "300013",
          "child": [
            {
              "id": "809",
              "name": "浈江区"
            },
            {
              "id": "812",
              "name": "乐昌市"
            },
            {
              "id": "813",
              "name": "南雄市"
            },
            {
              "id": "811",
              "name": "曲江区"
            },
            {
              "id": "808",
              "name": "曲江县"
            },
            {
              "id": "815",
              "name": "仁化县"
            },
            {
              "id": "818",
              "name": "乳源"
            },
            {
              "id": "814",
              "name": "始兴县"
            },
            {
              "id": "816",
              "name": "翁源县"
            },
            {
              "id": "810",
              "name": "武江区"
            },
            {
              "id": "817",
              "name": "新丰县"
            }
          ]
        },
        {
          "name": "深圳市",
          "id": "300014",
          "child": [
            {
              "id": "708",
              "name": "宝安区"
            },
            {
              "id": "705",
              "name": "福田区"
            },
            {
              "id": "3923",
              "name": "光明新区"
            },
            {
              "id": "709",
              "name": "龙岗区"
            },
            {
              "id": "3922",
              "name": "龙华区"
            },
            {
              "id": "706",
              "name": "罗湖区"
            },
            {
              "id": "707",
              "name": "南山区"
            },
            {
              "id": "3877",
              "name": "坪山区"
            },
            {
              "id": "710",
              "name": "盐田区"
            }
          ]
        },
        {
          "name": "兴宁市",
          "id": "300015",
          "child": [
            {
              "id": "3889",
              "name": "水口镇"
            }
          ]
        },
        {
          "name": "阳江市",
          "id": "300016",
          "child": [
            {
              "id": "819",
              "name": "江城区"
            },
            {
              "id": "820",
              "name": "阳春市"
            },
            {
              "id": "822",
              "name": "阳东县"
            },
            {
              "id": "821",
              "name": "阳西县"
            }
          ]
        },
        {
          "name": "云浮市",
          "id": "300017",
          "child": [
            {
              "id": "824",
              "name": "罗定市"
            },
            {
              "id": "825",
              "name": "新兴县"
            },
            {
              "id": "826",
              "name": "郁南县"
            },
            {
              "id": "827",
              "name": "云安县"
            },
            {
              "id": "823",
              "name": "云城区"
            }
          ]
        },
        {
          "name": "湛江市",
          "id": "300018",
          "child": [
            {
              "id": "828",
              "name": "赤坎区"
            },
            {
              "id": "833",
              "name": "雷州市"
            },
            {
              "id": "832",
              "name": "廉江市"
            },
            {
              "id": "831",
              "name": "麻章区"
            },
            {
              "id": "830",
              "name": "坡头区"
            },
            {
              "id": "835",
              "name": "遂溪县"
            },
            {
              "id": "834",
              "name": "吴川市"
            },
            {
              "id": "829",
              "name": "霞山区"
            },
            {
              "id": "836",
              "name": "徐闻县"
            }
          ]
        },
        {
          "name": "肇庆市",
          "id": "300019",
          "child": [
            {
              "id": "843",
              "name": "德庆县"
            },
            {
              "id": "3436",
              "name": "鼎湖区"
            },
            {
              "id": "3435",
              "name": "端州区"
            },
            {
              "id": "842",
              "name": "封开县"
            },
            {
              "id": "838",
              "name": "高要市"
            },
            {
              "id": "840",
              "name": "广宁县"
            },
            {
              "id": "841",
              "name": "怀集县"
            },
            {
              "id": "839",
              "name": "四会市"
            },
            {
              "id": "837",
              "name": "肇庆市"
            }
          ]
        },
        {
          "name": "中山市",
          "id": "300020",
          "child": [
            {
              "id": "3994",
              "name": "板芙镇"
            },
            {
              "id": "3883",
              "name": "东凤镇"
            },
            {
              "id": "845",
              "name": "东区街道"
            },
            {
              "id": "3878",
              "name": "东升镇"
            },
            {
              "id": "3836",
              "name": "阜沙镇"
            },
            {
              "id": "3879",
              "name": "古镇镇"
            },
            {
              "id": "847",
              "name": "环城街道"
            },
            {
              "id": "3813",
              "name": "黄圃镇"
            },
            {
              "id": "3826",
              "name": "火炬开发区"
            },
            {
              "id": "3876",
              "name": "南朗镇"
            },
            {
              "id": "3875",
              "name": "南头镇"
            },
            {
              "id": "3851",
              "name": "三角镇"
            },
            {
              "id": "3852",
              "name": "三乡镇"
            },
            {
              "id": "3850",
              "name": "沙溪镇"
            },
            {
              "id": "844",
              "name": "石岐街道"
            },
            {
              "id": "3821",
              "name": "坦洲镇"
            },
            {
              "id": "849",
              "name": "五桂山街道"
            },
            {
              "id": "3418",
              "name": "小榄镇"
            },
            {
              "id": "846",
              "name": "西区街道"
            },
            {
              "id": "848",
              "name": "中山港街道"
            }
          ]
        },
        {
          "name": "珠海市",
          "id": "300021",
          "child": [
            {
              "id": "851",
              "name": "斗门区"
            },
            {
              "id": "3414",
              "name": "金唐区"
            },
            {
              "id": "852",
              "name": "金湾区"
            },
            {
              "id": "3434",
              "name": "南湾区"
            },
            {
              "id": "850",
              "name": "香洲区"
            }
          ]
        }
      ]
    },
  ]
  const others=[
    {
      id:"2",
      val:'李四',
      Age:[
        {
          val:'22'
        },
        {
          val:'23'
        },
        {
          val:'24'
        },
        {
          val:'25'
        }
      ]
    }
  ]
  export default {
    name: "addresslist",
    data () {
      return {
        test:'2',
        showCity:false,
        testSlotStatus:false,
        yearSlotStatus:false,
        info:{
          // isLink:true,
          title:'测试',
          to:{name:'Index'},
          // lable:'山东省 淄博市',
          // detail:'ww'
        },
        yearSlot:[{
          flex: 1,
          defaultIndex:1,
          values: ['1984', '1985', '1986', '1987', '1988', '1989', '1990', '1991', '1992', '1993', '1994', '1995'],
          className: 'slot1'
        }],
        testSlot:[{
          flex: 1,
          values: [{id:1,text:'测试'},{id:2,text:'你好'},{id:3,text:'不好'},{id:4,text:'很差'}],
          className: 'slot1'
        }],
        others:[
          {
            flex:1,
            // defaultIndex:1,
            values:others
          },
          {
            divider: true,
            content: '-',
            className: 'slot2'
          },
          {
            flex: 1,
            // defaultIndex:2,
            // values: others[1].Age,
            values: others[0].Age,
            className: 'slot3',
            textAlign: 'center'
          }
        ],
        addressSlots: [
          {
            flex: 1,
            values: addresTest,
            className: 'slot1',
            textAlign: 'center'
          }, {
            divider: true,
            content: '-',
            className: 'slot2'
          }, {
            flex: 1,
            values: addresTest[0].child,
            className: 'slot3',
            textAlign: 'center'
          },
          {
            divider: true,
            content: '-',
            className: 'slot2'
          },{
            flex: 1,
            values: addresTest[0].child[0].child,
            className: 'slot3',
            textAlign: 'center'
          }
        ],
        addressProvince: '北京',
        addressCity: '北京'
      }
    },
    methods:{
      onAddressChange(picker, values) {
        picker.setSlotValues(1, values[0].child);
        picker.setSlotValues(2, values[1].child);
        this.addressProvince=values[0].name
        this.addressCity=values[1].name+ ' / '+values[2].name
      },
      doSelect(values) {
        console.log(values)
      },
      onOthersChange(picker, values) {
        console.log(values)
        picker.setSlotValues(1, values[0].Age);
      },
      showDemo(val) {
        console.log(val)
        switch (val) {
          case 1:
            this.showCity=true
            break;
          case 2:
            this.yearSlotStatus=true
            break;
          case 3:
            this.testSlotStatus=true
            break;
        }
      }
    },
    components: {
      XCell,
      CellSwiper,
      Yi23Field,
      MtPicker,
    },
    created (){
      this.rightButtons = [
        {
          content: 'Mark as Unread',
          style: { background: 'lightgray', color: '#fff' }
        },
        {
          content: 'Delete',
          style: { background: 'red', color: '#fff' },
          handler: (e) => {
            console.log(e)
          }
        }
      ];
    },
  }
</script>

<style scoped lang="less">

</style>
