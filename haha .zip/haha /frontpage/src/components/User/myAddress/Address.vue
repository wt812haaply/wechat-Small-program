<template>
  <section class="address">
    <div>
      <yi23-field label="收货人" v-model="consignee" placeholder="请输入收货人姓名"></yi23-field>
      <yi23-field label="手机号" v-model="mobile" placeholder="请输入手机号"></yi23-field>
      <x-cell label="所在城市" :is-link="true"><span @click="showCityPicker">{{citys}}</span></x-cell>
      <yi23-field label="详细地址" v-model="address" placeholder="请填写详细地址"></yi23-field>
    </div>
    <mt-picker :slots="addressSlots"  valueKey="name" v-model="showCity" @doConfirm="doSelect" @change="onAddressChange">
    </mt-picker>
    <yi23Toast v-model="toastMsg"></yi23Toast>
    <div class="addBtn" @click="saveAddress">保存并使用</div>
  </section>
</template>

<script>
  /*
  * v-bind info  等价react ...info 解构赋值
  * */
    import XCell from '@/components/lib/cell/Cell';
    import Yi23Field from '@/components/lib/field/Field';
    import MtPicker from '@/components/lib/picker/picker';
    import Validator from 'common/js/class/validator';
    import address from 'api/address';
    import { mapGetters } from 'vuex';
    export default {
      name: "addressComponent",
      data () {
        return {
          consignee:'',
          mobile:'',
          address:'',
          rgn:'',
          toastMsg:'',
          citys:'请选择城市',
          showCity:false,
          addressSlots: [
            {
              flex: 1,
              values: [],
              className: 'slot1',
              textAlign: 'center'
            },{
              divider: true,
              content: '-',
              className: 'slot2'
            },{
              flex: 1,
              values: [],
              className: 'slot3',
              textAlign: 'center'
            },{
              divider: true,
              content: '-',
              className: 'slot2'
            },{
              flex: 1,
              values: [],
              className: 'slot3',
              textAlign: 'center'
            }
          ],
        }
      },
      computed:{
        ...mapGetters({
          cityList: 'getAreaList'
        })
      },
      watch:{
        cityList(val) {
          this.addressSlots=[{
            flex: 1,
            values: val,
            className: 'slot1',
            textAlign: 'center'
          }, {
            divider: true,
            content: '-',
            className: 'slot2'
          }, {
            flex: 1,
            values: val[0].child,
            className: 'slot3',
            textAlign: 'center'
          },
            {
              divider: true,
              content: '-',
              className: 'slot2'
            },{
              flex: 1,
              values: val[0].child[0].child,
              className: 'slot3',
              textAlign: 'center'
            }]
        }
      },
      methods:{
        onAddressChange(picker, values) {
          if(values[0] && values[0].child ){
            picker.setSlotValues(1, values[0].child);
            picker.setSlotValues(2, values[1].child);
          }
        },
        doSelect(values) {
          console.log(values)
          this.citys=`${values[0].name} ${values[1].name} ${values[2].name}`;
          this.rgn=values[2].id
        },
        showCityPicker() {
          this.showCity = true
        },
        saveAddress() {
         let msg=this.validataFunc();
         this.toastMsg=msg;
         if(!msg){
           let info={consignee:this.consignee,
             mobile:this.mobile,
             address:this.address,
             rgn:this.rgn}
            address.addNewAddress(info).then((res)=>{
                if(res.data.code==200){
                  this.$router.go(-1)
                }else{
                  this.toastMsg=res.data.msg
                }
            })
         }
        },
        validataFunc(){
          let validator = new Validator();
          //nickname
          validator.add(this.consignee,[{
            strategy:'isNoEmpty',
            errorMsg:'用户名不能为空'
          }]);

          //phone
          validator.add(this.mobile,[{
            strategy:'isNoEmpty',
            errorMsg:'手机号不能为空'
          },{
            strategy:'isMobile',
            errorMsg:'请正确输入手机号'
          }]);

          //city
          validator.add(this.rgn,[{
            strategy:'isNoEmpty',
            errorMsg:'所在城市不能为空'
          }]);
          validator.add(this.address,[{
            strategy:'isNoEmpty',
            errorMsg:'详细地址不能为空'
          }]);
          return validator.start();
        },
      },
      components: {
        XCell,
        Yi23Field,
        MtPicker,
      },
      created (){
        this.$store.dispatch('getAreaList')
      },
    }
</script>

<style scoped lang="less">
  .addBtn{
    width: 100%;
    position: fixed;
    bottom: 0;
    left: 0;
    font-size: 14px;
    line-height: 40px;
    background: #000;
    color: #ffffff;
    text-align: center;
    margin-top: 30px;
  }

  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .addBtn{
      bottom:34px;
    }
  }
</style>
