<template>
  <section class="addressList">
      <div v-for="item in addressList" @click="doSelect(item)">
        <cell-swiper  :title="item.consignee" :label="item.city+' '+item.country" :detail="item.address" :right="rightButtons" :to="createdUrlJson(item)" :options="item" :key='item.addrId' :isLink="true" >
          {{item.mobile}}
        </cell-swiper>
      </div>
    <router-link :to="{ path: '/User/address' }"><div class="addBtn">+ 新增地址</div></router-link>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </section>
</template>

<script>
  /*
  * v-bind info  等价react ...info 解构赋值
  * */
    import XCell from '@/components/lib/cell/Cell';
    import CellSwiper from '@/components/lib/cell/CellSwiper';
    import address from 'api/address'
    import { mapGetters } from 'vuex'
    export default {
      name: "addresslist",
      data () {
        return {
          toastOpen:false,
          rightButtons: [
            {
              content: '删除',
              style: { background: 'red', color: '#fff' },
              handler: (e) => {
                this.deleteAddress(e)
              }
            }
          ]
        }
      },
      computed:{
        ...mapGetters({
          addressList: 'listInfo',
          toastMsg:'errorMsg'
        }),
      },
      methods:{
        deleteAddress(info) {
          address.deleteAddress({addrId:info.addrId}).then((res)=>{
            if(res.data.code==200){
              this.initList()
            }else{
              this.toastMsg=res.data.msg;
            }
          })
        },
        initList() {
          this.$store.dispatch('getAddressList')
        },
        doSelect(info) {
          this.$store.commit('setAddressInfo',info);
          // let redirect = decodeURIComponent(this.$route.query.redirect || '/');
          // this.$router.replace({
          //   path: redirect
          // })
        },
        createdUrlJson(info){
          let redirect = decodeURIComponent(this.$route.query.redirect || '/');
          return {
            path: redirect
          }
        },
        editAddress(info) {

        }
      },
      components: {
        XCell,
        CellSwiper,
      },
      created (){
        this.initList()
      },
    }
</script>

<style scoped lang="less">
  .addressList{
    padding-bottom:60px;
  }
.addBtn{
  width: 100%;
  position: fixed;
  bottom: 0;
  left: 0;
  font-size: 14px;
  line-height: 40px;
  background: #000;
  color: #ffffff;
  text-align: center;
  margin-top: 30px;
}


  /* Iphone X*/
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .addBtn{
      bottom: 34px;
    }
  }

</style>
