<template>

    <div class="shareConStepTitle" v-if="rewardList">
        <ul class='benefitList' v-for='(item, $index) in rewardList.memberBenefitVOList' :key="$index">
          <li>
            <div class="benefitList-img">
              <img :src="item.memberBenefitImage" alt="">
            </div>
            <div class="benefitList-content">
              <div class="benefitList-content__title">{{item.memberBenefitTitle}}</div>
              <div class="benefitList-content__description">{{item.memberBenefitDescription}}</div>
            </div>
          </li>
        </ul>
    </div>
</template>

<script>
  export default {
    name: "list-swiper",
    data () {
      return {
        vip:1,
        list:'',
        idx:0,//行
        idxs:0,//列
        memberBenefitTitle:'',
        memberBenefitDescription:'',
      }
    },
    props:[
      'rewardList',
      'member',
      'type'
    ],
    watch:{
    },
    created(){
    },
    methods:{
      liClick(val,index,indexs){
        if(+this.idx===+indexs && +this.idxs ===+index){
          this.idx = -1
        }else{
          this.idx = +indexs
          this.idxs = +index
          this.memberBenefitDescription = val.memberBenefitDescription
          this.memberBenefitTitle = val.memberBenefitTitle
        }

      },
      stringFilter(value){
        if(typeof(value) === 'string'){
          value = value.split('#');
          value.forEach((v,t)=>{
            if((t+1) % 2 === 0){
              if(value[t].indexOf('-') === -1){
                value[t] = '<span style="color:#ff544b"> '+value[t]+' </span>'
              }else{
                value[t] = '<span style="color:#afafaf"> '+value[t]+' </span>'
              }
            }
          })
          return value.join('')
        }else {
          return value
        }
      },
      enter (indexs) {
        this.$refs.stepBox[indexs].style.height = 'auto'
        let endWidth = this.$refs.stepBox[indexs].scrollHeight + 'px'
        this.$refs.stepBox[indexs].style.height = '0px'
        this.$refs.stepBox[indexs].offsetHeight // force repaint
        // noinspection JSSuspiciousNameCombination
        this.$refs.stepBox[indexs].style.height = endWidth

      },
      afterEnter (indexs) {
        this.$refs.stepBox[indexs].style.height = null
      },
      leave (indexs) {
        this.$refs.stepBox[indexs].style.height = window.getComputedStyle(this.$refs.stepBox[indexs]).height
        this.$refs.stepBox[indexs].offsetHeight // force repaint
        this.$refs.stepBox[indexs].style.height = '0px'
      },
      afterLeave (indexs) {
        this.$refs.stepBox[indexs].style.height = null
      }

    }

  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";
  .benefitList{
    display:flex;
    width: 100%;
  }
  .benefitList li{
    display: flex;
    flex-direction:row;
    margin-bottom:25 * @unit;
  }
  .shareConStepTitle>div:last-child :last-child li{
    margin-bottom:0;
  }
  .benefitList-img{
    width: 40 * @unit;
    height: 40 * @unit;
    overflow: hidden;
    img{
      width: 100%;
      /*height: 100%;*/
    }
  }
  .benefitList-content{
    width: 216 * @unit;
    margin-left: 14 * @unit;
  }
  .benefitList-content__title{
    font-size: 11 * @unit;
    letter-spacing: 0.3px;
  }
  .benefitList-content__description{
    font-size: 10 * @unit;
    font-weight: 300;
    line-height: 1.5;
    color: #afafaf;
    margin-top: 4 * @unit;
    text-align: justify;
  }


</style>
