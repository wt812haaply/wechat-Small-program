<template>

  <div class="integral_V">

    <div class="barS">
      <div class="progressBar"></div>
      <div class="activeBar" ref="activeBar">
      <span class="font-roboto-r"  ref="activeTips" :class="{exceeding:(currentLevelPoint <=1000),exceMax:(currentLevelPoint >=4500)}" style="min-width:100px;" v-if="currentLevelPoint||currentLevelPoint===0">本季度已积分{{currentLevelPoint}}</span>
      </div>
    </div>
    <!---->
    <div class="kpp">
      <div class="V1" :class="{isActive:vip>=1}">
        <div class="V_bar"></div>
        <div class="VCont">
          <p class="font-roboto-r Vstar">V1</p>
          <p class="font-roboto-r">1</p>
        </div>
      </div>

      <div class="V2" :class="{isActive:vip>=2}">
        <div class="V_bar"></div>
        <div class="VCont">
          <p class="font-roboto-r Vstar">V2</p>
          <p class="font-roboto-r">500</p>
        </div>
      </div>

      <div class="V3" :class="{isActive:vip>=3}">
        <div class="V_bar"></div>
        <div class="VCont">
          <p class="font-roboto-r Vstar">V3</p>
          <p class="font-roboto-r">1000</p>
        </div>
      </div>

      <div class="V4" :class="{isActive:vip>=4}">
        <div class="V_bar"></div>
        <div class="VCont">
          <p class="font-roboto-r Vstar">V4</p>
          <p class="font-roboto-r">2000</p>
        </div>
      </div>

      <div class="V5" :class="{isActive:vip>=5}">
        <div class="V_bar"></div>
        <div class="VCont">
          <p class="font-roboto-r Vstar">V5</p>
          <p class="font-roboto-r">3000</p>
        </div>
      </div>

      <div class="V6" :class="{isActive:vip>=6}">
        <div class="V_bar"></div>
        <div class="VCont">
          <p class="font-roboto-r Vstar">V6</p>
          <p class="font-roboto-r">5000</p>
        </div>
      </div>
    </div>
  </div>


</template>

<script>

  export default {
    name: "member-bar",
    data () {
      return {
        vip:0,
        V6Point:5000,
      }
    },
    props:[
      'predictLevel',
      'currentQuarterLevelPoint',
      'currentLevelPoint',
    ],
    watch:{},
    created(){
      console.log(this.currentQuarterLevelPoint)
      this.$nextTick( () =>{
        this.setWidth(this.currentQuarterLevelPoint,this.predictLevel)
      })
    },
    methods:{
      setWidth (currentQuarterLevelPoint,level){
        currentQuarterLevelPoint = currentQuarterLevelPoint>0 ? currentQuarterLevelPoint : 0;
        let percent = currentQuarterLevelPoint/this.V6Point*1*100;
        percent = percent>100 ? 100 : percent;
        // if (currentQuarterLevelPoint <= 1000) {
        //   // this.$refs.activeTips.style.left = 160 + "%"
        //   // console.log(this.$refs.activeTips.style.left)
        // }
        this.$refs.activeBar.style.width = percent+'%';
        let vip=level.replace(/[^\d]/g,'')
        if(vip){
          this.vip=Number(vip)
        }else{
          this.vip=0
        }
      },
    }

  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";

  .integral_V{
    height:42 * @unit;
    margin-bottom: 38 * @unit;
    //padding:0 0 0 10 * @unit;
  }

  .progressBar,.activeBar{
    width:100%;
    height:3 * @unit;
    background: #eee;
    border-radius: 1.5 * @unit;
    position: relative;
    transition: all 1s ease;
  }
  .activeBar span{
    position: absolute;
    /*right: 0px;*/
    left: 100%;
    transform: translateX(-50%);
    top:-16*@unit;
    font-size: 10 * @unit;
    text-align: center;
    color: #ff544b;
  }
  .activeBar .exceeding{
    position: absolute;
    left: 0;
    transform: translateX(0%);
    top:-16*@unit;
    font-size: 10 * @unit;
    text-align: left;
    color: #ff544b;
  }
  .activeBar .exceMax{
    position: absolute;
    right: 0px;
    transform: translateX(-97%);
    top:-16*@unit;
    font-size: 10 * @unit;
    text-align: right;
    color: #ff544b;
  }
  .progressBar{
    height:1 * @unit;
    position: relative;
    top:-1 * @unit;
  }
  .activeBar{
    width:0%;
    background: #ff544b;
    /*background: rgb(253,125,125);*/
    /*background: -moz-linear-gradient(left, rgba(253,125,125,1) 0%, rgba(223,66,112,1) 100%);*/
    /*background: -webkit-linear-gradient(left, rgba(253,125,125,1) 0%,rgba(223,66,112,1) 100%);*/
    /*background: linear-gradient(to right, rgba(253,125,125,1) 0%,rgba(223,66,112,1) 100%);*/
    /*filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#fd7d7d', endColorstr='#df4270',GradientType=1 );*/
    position: relative;
    top:-3 * @unit;
    /*overflow: hidden;*/
  }

  .V1,.V2,.V3,.V4,.V5,.V6{
    position: absolute;
    top:-2.8 * @unit;
    text-align: center;
    font-size: 10 * @unit;
    display: flex;
    justify-content:center;
    flex-wrap: wrap;

    .V_bar{
      display: block;
      width: .4rem;
      height: .4rem;
      border:.1rem #ffffff solid;
      background: #ddd;
      border-radius: 50%;
      -webkit-border-radius:50%;
      overflow: hidden;
    }

    .VCont{
      margin-top:15 * @unit;
      padding:0 3px;
      text-align: center;
      position: absolute;
      left: 50%;
      width: 26 * @unit;
      margin-left: -15 * @unit;
      color: rgba(51,51,51,.7);
      p.Vstar{
        margin-bottom: 3 * @unit;
        font-weight: bold;
        font-size: 10 * @unit;
      }
      p{
        font-size:  9 * @unit;
        letter-spacing: -0.1px;
      }
    }
  }

  .V1{
    left:@v1/@total*@scale;
  }
  .V2{
    left:@v2/@total*@scale;
  }
  .V3{
    left:@v3/@total*@scale;
  }
  .V4{
    left:@v4/@total*@scale;
  }
  .V5{
    left:@v5/@total*@scale;
  }
  .V6{
    left:@v6/@total*@scale;
  }

  .activeRed{
    color:#ff544b;
  }

  .barS{
    position: relative;
    width:100%;
    /*overflow: hidden;*/
  }

  .kpp{
    position: relative;
    top:-0.37rem;
  }

  .isActive{
    //top:-.2rem;
    .V_bar{
      /*width: .3rem;*/
      /*height: .3rem;*/
      /*border:.2rem #ffffff solid;*/
      background: #ff544b;
      /*border-radius: 50%;*/
      /*-webkit-border-radius:50%;*/
      /*overflow: hidden;*/

    }
    .VCont{
      color:rgba(255,84,75,.7);

    }
  }
  .kpp .isActive:last-child .VCont{
    color: rgba(255, 84, 75, 1);
  }

</style>
