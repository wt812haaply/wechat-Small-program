<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader">
      <go-back></go-back>
    </div>
    <!--核心内容部分-->
      <div class="yclosetCon" v-if="payRecordPage && payRecordPage.norec == 0"><!--支付列表-->
      <div class="payRecordPage" >
        <h2 class="fontUbuntu">TRANSACTIONS</h2>
        <em class="font-f">支付记录</em>
        <dl class="payRecordPageList">
          <dd>
            <span class="Time">时间</span>
            <span class="Project">项目</span>
            <span class="Total">总价</span>
            <span class="Paid">实付</span>
          </dd>
          <dt v-for="(item) in payRecordPage.paylog">
            <span class="Time">{{ item.payDay }}</span>
            <span class="Project">{{ item.payName }}</span>
            <span class="Total">￥{{ item.shouldPay }}</span>
            <span class="Paid">￥{{ item.realPay }}</span>
          </dt>
        </dl>
      </div>
      </div>
    <!--暂无支付-->
    <div class="yclosetCenter" v-else>
      <div class="payRecordPageNo">
        <h2 class="fontUbuntu">NO RECORD (YET)</h2>
        <p>暂无支付记录</p>
      </div>
    </div>

  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import { payRecordPage } from 'api/user'

  export default {
    data(){
      return{
        payRecordPage: null
      }
    },
    methods:{
    },
    components:{
      goBack,
    },
    created () {
      payRecordPage().then((res)=>{
//        console.log(res);
        this.payRecordPage = res.data;
      });
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";

  .active{
    display: none;
  }


  .payRecordPageNo{
    height: auto;
    justify-content: center;
    align-items:center;
    h2,p{
      display: flex;
      flex-wrap: wrap;
      justify-content:center;
      align-items:center;
      width:100%;
    }
    h2{
      .font-size(20);
    }
    p{
      .font-size(12);
      line-height: 2;
    }
  }
  .payRecordPage{
    .padding(35,23,35,23);
    text-align: left;
    display: flex;
    flex-wrap: wrap;
    h2,em{
      display: flex;
      width:100%;
    }
    h2{
      .font-size(28);
      .line-height(30);
      color: #333;
    }
    em{
      .font-size(14);
      .line-height(30);
      color: #999;
      font-style: normal;
    }

  }
  dl.payRecordPageList{
    .margin(40,0,0,0);
    display: flex;
    flex-wrap: wrap;
    width:100%;
    dd,dt{
      display: flex;
      justify-content:space-between;
      align-items: center;
      width:100%;
      .height(60);
      border-bottom: 1px #eee solid;
      .font-size(12);
      color: #333;

      span.Time,
      span.Project,
      span.Total,
      span.Paid{
        display:flex;
        justify-content: center;
        align-items:center;
        flex: 1;
      }
      span.Time{
        display: flex;
        justify-content: flex-start;
      }
    }
    dd{
      border-bottom: 0.106667rem #eee solid;
    }
  }
</style>
