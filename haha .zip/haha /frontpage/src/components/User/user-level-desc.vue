<template lang="html">
  <div class="leveldesc">
    <go-back></go-back>
    <div class="wrapper">
      <div class="level-nav">
        <template v-for="(item,index) of level">
          <span
            :style="{width:navListItemWidth+'%'}"
            :class="{active:(currentIndex == index)}"
            @click="navClick(index)"
            >{{item.nav}}
          </span>
        </template>
      </div>
      <template v-for="(item,index) of level">
        <div class="level-content" v-if="currentIndex==index">
          <div class="card">

            <div class="imgbox image-normal">
              <img :src="item.banner">
            </div>
          </div>
          <div class="card-process">
            <div class="title">{{item.nav}}</div>
            <p>{{item.title_dec}}</p>
            <img class="progress-bar" width="100%" :src="item.progress">
          </div>
          <div class="tab">
            <div class="tab-nav" style="margin-top:20px;">
              <template v-for="(tab, index) of item.tab">

                <span v-if="tab.desc != ''" :style="{width: (100/item.tab.length) + '%'}" @click="tabClick(index)">
                  <!--<i class="yi23_icon font_36 color_333" :class="tab.icon"></i>-->
                  <img :src="tab.iconImg" alt="" style="width: 36px;">
                  <p>{{tab.n_title}}</p>
                </span>
                <span v-else :style="{width: (100/item.tab.length) + '%'}">
                  <!--<i class="yi23_icon font_36 color_c8c8c8" :class="tab.icon"></i>-->
                  <img :src="tab.noiconImg" alt="" style="width: 36px;">
                  <p>{{tab.n_title}}</p>
                </span>

              </template>
            </div>
            <div class="tab-content">
              <template v-if="currentIndex != 2">
                <div class="item" v-for="(tab, index) of item.tab" v-if="index == tabIndex">
                  <i class="yi23_icon font_48 color_333" :class="tab.icon"></i>
                  <img :src="tab.noiconImg" alt="" style="width: 48px;">
                  <div class="right">
                    <div class="title">{{tab.d_title}}</div>
                    <p>
                      {{tab.desc}}
                    </p>
                    <a :href="tab.href[1]" v-if="tab.href" style="color:#d2d2d2;font-size: 14px; text-decoration: underline">{{tab.href[0]}}</a>
                  </div>
                </div>
              </template>
              <template v-else>
                <div class="item l-3" v-for="(tab, index) of item.tab" v-if="index == tabIndex">
                  <div class="right">
                    <div class="title">{{tab.d_title}}</div>
                    <p>{{tab.desc}}</p>
                    <a :href="tab.href[1]" v-if="tab.href" style="color:#d2d2d2;font-size: 14px; text-decoration: underline">{{tab.href[0]}}</a>
                  </div>
                </div>
              </template>

            </div>
          </div>
          <div class="explain">
            <div class="item">
              <h6>保级规定</h6>
              </br>
              </br>
              <p>积分达到钻星级后的连续12个月内，积分累计达到3500分，即可保级钻星级，如不满足则根据积分积累分值，降级为相应权益等级（2000-3499分为金星级，2000分以下为银星级）</p>
              </br>
              <p>积分达到金星级后的连续12个月内，积分累计达到2000分，即可保级金星级，如不满足则降为银星级。</p>
            </div>
            <div class="item">
              <h6>特别说明</h6>
              </br>
              </br>
              <p>积分达到钻星级或金星级后，该等级有效期12个月。在12个月中，您将享受各等级对应的各种特权及服务。有效期内，您可以尽情使用积分，积分余额将不会影响您的等级身份。举例，积分达到钻星级，消费积分后，积分余额不足3500分，但有效期内仍享有钻星级权益。</p>
              </br>
              </br>
              <p>积分可以无限累计，积分无有效期，不清零，您可随时根据您的需要使用积分。</p>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import GoBack from 'base/GoBack';

export default {
  data(){
    return {
      currentIndex: 0,
      tabIndex:0,
      level:[
        {
          nav: '钻星级',
          index: '1',
          banner:'https://tu.95vintage.com/web_source/Home/Common/images/qy_zuan_bkg.png',
          title_dec: '12个月内累计积分达3500分及以上',
          progress: 'https://tu.95vintage.com/web_source/Home/Common/images/qy_zuan_jd.jpg',
          tab:[{
              n_title:'积分加倍',
              icon:'icon-new_20',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_A1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_A1.svg',
              d_title:'积分2倍奖励',
              desc:'积分达到钻星级，您的积分系数为2，即每次购买会员卡或单品时获得积分，都可获得2倍奖励。'
            },
            {
              n_title:'购衣折扣',
              icon:'icon-new_15',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_B1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_B1.svg',
              d_title:'购衣折上8折',
              desc:'钻星级权益有效期内，每次购衣付款时，无需其他操作，即可直接享受原有折扣之上再打8折的优惠权益。'
            },
            {
              n_title:'保留衣箱',
              icon:'icon-new_17',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_C1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_C1.svg',
              d_title:'衣箱保留十分钟',
              desc:'积分达到钻星级，您加入衣箱中的衣服将被特别保留10分钟，不会被抢走。特权每天只能使用一次哦！',
            },
            {
              n_title:'生日福利',
              icon:'icon-new_16',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_D1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_D1.svg',
              d_title:'生日月免费礼服使用',
              desc:'积分达到钻星级，在生日当月，即可获得500元礼服专享优惠券，限当月使用。',
              href:['点击查看礼服列表','http://www.95vintage.com/yi23/Home/Index/index?jumpNativeType=26'],
            },
            {
            n_title:'专属客服',
            icon:'icon-new_21',
            iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_E1.svg',
            noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_E1.svg',
            d_title:'专属客服',
            desc:'积分达到钻星级，您可享受专属客服服务，拨打客服电话将被优先接待，同时有专属微信客服账号，及时处理您的任何需求。积分达到钻星级后，专属客服会致电告知具体权益使用方式。'
          }],

        },
        {
          nav: '金星级',
          index: '2',
          banner:'https://tu.95vintage.com/web_source/Home/Common/images/qy_jin_bkg.png',
          title_dec: '12个月内累计积分达2000分-3499分',
          progress: 'https://tu.95vintage.com/web_source/Home/Common/images/qy_jin_jd.png',
          tab:[{
              n_title:'积分加倍',
              icon:'icon-new_18',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_F1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_F1.svg',
              d_title:'积分1.5倍奖励',
              desc:'积分达到金星级，您的积分系数为1.5，即每次购买会员卡或单品时获得积分，都可获得1.5倍奖励。'
            },
            {
              n_title:'购衣折扣',
              icon:'icon-new_22',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_G1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_G1.svg',
              d_title:'购衣折上9折',
              desc:'金星级权益有效期内，每次购衣付款时，无需其他操作，即可直接享受原有折扣之上再打9折的优惠权益'
            },
            {
              n_title:'保留衣箱',
              icon:'icon-new_17',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_C2.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_C2.svg',
              d_title:'衣箱保留十分钟',
              desc:'',
            },
            {
              n_title:'生日福利',
              icon:'icon-new_16',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_D2.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_D2.svg',
              d_title:'生日月免费礼服使用',
              desc:'',
              href:[{'点击查看礼服列表':'http://www.95vintage.com/yi23/Dress/Gown/gownOrderListPage?jumpNativeType=26'}]
            },
            {
            n_title:'专属客服',
            icon:'icon-new_21',
            iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_E2.svg',
            noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_E2.svg',
            d_title:'专属客服',
            desc:''
          }]
        },
        {
          nav: '银星级',
          index: '3',
          banner:'https://tu.95vintage.com/web_source/Home/Common/images/qy_yin_bkg.png',
          title_dec: '12个月内累计积分达1999分及以下',
          progress: 'https://tu.95vintage.com/web_source/Home/Common/images/qy_yin_jd.jpg',

          tab:[{
              n_title:'积分加倍',
              icon:'icon-new_19',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_H1.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_H1.svg',
              d_title:'12个月内累计积分达到金星级或钻星级后，即可享有对应的会员权益。',
              desc:'在此期间，您通过在衣二三消费及其他多种方式，可以获得积分，积分达到相应要求后，即刻完成升级。升级后的12个月内，您均可享用金星级及钻星级的专属权益。'
            },
            {
              n_title:'购衣折扣',
              icon:'icon-new_22',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_B2.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_B2.svg',
              d_title:'购衣折上9折',
              desc:''
            },
            {
              n_title:'保留衣箱',
              icon:'icon-new_17',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_C2.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_C2.svg',
              d_title:'',
              desc:'',
            },
            {
              n_title:'生日福利',
              icon:'icon-new_16',
              iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_D2.svg',
              noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_D2.svg',
              d_title:'生日月免费礼服使用',
              desc:'',
              href:[{'点击查看礼服列表':'http://www.95vintage.com/yi23/Dress/Gown/gownOrderListPage?jumpNativeType=26'}]
            },
            {
            n_title:'专属客服',
            icon:'icon-new_21',
            iconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_E2.svg',
            noiconImg:'https://yimg.yi23.net/webimg/web/images/2018/0516/rightsIcon_E2.svg',
            d_title:'专属客服',
            desc:''
          }]
        }
      ]
    }
  },
  computed:{
    navListItemWidth:function(){
      var length = this.level.length;
      return length ? (100/length) : 0
    }
  },
  methods:{
    tabClick:function(index){
      this.tabIndex = index;
    },
    navClick:function(index){
      this.currentIndex = index;
      this.initTabIndex(0);
    },
    initTabIndex:function(){
      this.tabClick(0);
    }
  },
  components:{
    GoBack
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";
  .font_36{
    font-size: 36px;
  }
  .font_48{
    font-size: 48px;
  }
  .color_333{
    color: #333;
  }
  .color_c8c8c8{
    color: #c8c8c8;
  }
  .leveldesc{
    display: flex;
    flex-direction: column;
    -webkit-font-smoothing: antialiased;
    background: #fff;
    height: 100%;
    font-weight: @font-weight;
    .an-slider(10%);
    .wrapper{
      flex:1;
      overflow-y: auto;
      .level-nav{
        width: 100%;
        height: 44px;
        line-height: 44px;
        background: #333;
        color: #fff;
        font-size: 0;
        span{
          display: inline-block;
          font-size: 12px;
          color: @color-user-level-nav;
          text-align: center;
          box-sizing: border-box;
          height: 44px;
          &.active{
            font-size: 14px;
            color: #fff;
            border-bottom: 3px solid @color-text;
            font-weight: 500;
          }
        }
      }
      .level-content{
        .card{
          padding: 15px 10px;
          .imgbox{
            width: 100%;
            height: 0;
            padding-bottom: 10.27027rem /* 190/18.5 */;
            overflow: hidden;
            position: relative;
          }
          img{

            position: absolute;
            left: 0;
            top:0;
            width: 100%;
            height: 100%;
          }
        }
        .card-process{
          padding: 0 10px;
          .title{
            font-size: 18px;
            line-height: 24px;
          }
          p{
            font-size: 12px;
            color: @color-dec-m;
            line-height: 24px;
          }
        }
        .tab{
          padding: 0 10px;
          .tab-nav{
            display: flex;
            font-size: @font-size-small;
            color:@color-dec-m;
            text-align: center;
            color: #949694;
            background: #fafafa;
            padding: 10px 0;
            p{
              line-height: 28px;
            }
          }
          .tab-content{
            width: 100%;
            padding: 30px 0 10px 0;
            .px-bottom();
            .item{
              display: flex;
              .an-opcity();
              &.l-3{
                .right{
                  .title{
                    font-size: 14px;
                    font-weight: 500;
                  }
                }

              }
              img{
                display: block;
                width: 48px;
                height: 48px;
              }
              .right{
                flex:1;
                padding-left: 10px;
                .title{
                  font-size: @font-size-large-s;
                  line-height: 24px;
                }
                p{
                  font-size: @font-size-medium;
                  line-height: 21px;
                  margin-top: 10px;
                }
              }

            }
          }
        }
        .explain{
          .item{
            padding: 40px 10px 40px 10px;
            .px-bottom();
          }
          h6{
            font-size: 17px;
          }
          p{
            font-size: 14px;
            line-height: 20px;
            color:@color-dec-m;
          }
        }
      }
    }
  }
  .title a {
    color: #999;
  }
</style>
