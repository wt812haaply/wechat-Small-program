<template>
  <div class="yclosetContainer"><!--userCenterPage-->
    <div class="header">
      <go-back></go-back>
    </div>
    <div class="yclosetCon"><!--核心内容部分-->
      <div class="userCenterPage">
        <div class="userCard">
          <!--用户等级-->
          <div class="userCardY">
            <template v-if="userCenterPage == null">
              <div class="image-ratio"></div>
            </template>

            <template v-else>
              <div class="userCardYIMG image-ratio">
                <img :src="userCenterPage.card_bkg">
              </div>
              <div class="userCardYCon">
                <div class="YConTop" v-if="userCenterPage.level === 1">
                  <h2 class="font-m">{{ userCenterPage.levelName }}<router-link to="/User/userRightsPage" tag="div"><i class="font-r">权益说明</i></router-link></h2>
                  <p v-if="userCenterPage.memberType == 0 || userCenterPage.remainDays <= 0">您还不是会员<br>快成为会员开始随心换穿吧</p>
                  <p class="expiryTime" v-if="userCenterPage.remainDays > 0">还有{{ userCenterPage.remainDays }}天过期</p>
                </div>

                <div class="JConTop" v-else-if="userCenterPage.level === 2">
                  <h2 class="font-m">{{ userCenterPage.levelName }}<router-link to="/User/userRightsPage" tag="div"><i class="font-r">权益说明</i></router-link></h2>
                  <p v-if="userCenterPage.memberType == 0 || userCenterPage.remainDays <= 0">您还不是会员<br>快成为会员开始随心换穿吧</p>
                  <p class="expiryTime" v-if="userCenterPage.remainDays > 0">还有{{ userCenterPage.remainDays }}天过期</p>
                </div>

                <div class="ZConTop" v-else-if="userCenterPage.level === 3">
                  <h2 class="font-m">{{ userCenterPage.levelName }}<router-link to="/User/userRightsPage" tag="div"><i class="font-r">权益说明</i></router-link></h2>
                  <p v-if="userCenterPage.memberType == 0 || userCenterPage.remainDays <= 0">您还不是会员<br>快成为会员开始随心换穿吧</p>
                  <p class="expiryTime" v-if="userCenterPage.remainDays > 0">还有{{ userCenterPage.remainDays }}天过期</p>
                </div>

                <div class="YConBottom" v-if="userCenterPage.level === 1">
                  <div class="integral">
                    <p>可用积分 {{ userCenterPage.pointAvailable }}分</p>
                    <p>升级还需 {{ userCenterPage.nextLevel - userCenterPage.pointTotal}}分</p>
                  </div>
                <div class="userScore">
                <div class="Progress">
                  <div class="ProgressBg" ref="ProgressBg"></div>
                  <div class="bar" ref="bar"></div>
                </div>
                </div>
                </div>
                <div class="JConBottom" v-else-if="userCenterPage.level === 2">
                  <div class="integral">
                    <p>可用积分 {{ userCenterPage.pointAvailable }}分</p>
                    <p>升级还需 {{ userCenterPage.nextLevel - userCenterPage.pointTotal}}分</p>
                  </div>
                  <div class="userScore">
                    <div class="Progress">
                      <div class="ProgressBg" ref="ProgressBg"></div>
                      <div class="bar" ref="bar"></div>
                    </div>
                  </div>
                </div>

                <div class="ZConBottom" v-else-if="userCenterPage.level === 3">
                  <div class="integral">
                    <p>可用积分 {{ userCenterPage.pointAvailable }}分</p>
                    <p v-if="userCenterPage.memberType == 3 || userCenterPage.memberType >= 3">升级还需 {{ userCenterPage.nextLevel - userCenterPage.pointTotal}}分</p>
                  </div>

                  <div class="userScore">
                    <div class="Progress">
                      <div class="ProgressBg" ref="ProgressBg"></div>
                      <div class="bar" ref="bar"></div>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </div>

        </div>
        <!--会员按钮-->
        <div class="userBtn" v-if="userCenterPage">
              <router-link to="/Buy/mallPage" tag="span">
              <button class="font-m">会员中心</button>
              </router-link>
              <template v-if="userCenterPage.memberType == 2 ">
                <!-- <router-link to="/Member/payPage" tag="span" > -->
                <span @click="buyCard">
                  <button class="font-m" >去续费</button>
                </span>
                <!-- </router-link> -->
              </template>
              <template v-else>
                <!-- <router-link to="/Member/payPage" tag="span"> -->
                <span @click="buyCard">
                  <button class="font-m">成为会员</button>
                </span>
                <!-- </router-link> -->
              </template>
        </div>

        <!--功能列表-->
        <ul class="userFunctionList">
            <router-link to="/Event/rewardList" tag="li">
              <div class="ph2">
                <i class="icon yi23iconfont icon-gift-9"></i>
                <p>邀请有奖</p>
              </div>
            </router-link>

            <router-link to="/User/profile" tag="li" >
              <div class="ph2">
                <i class="icon yi23iconfont icon-profile-9"></i>
                <p>我的资料</p>
              </div>
            </router-link>

            <router-link to="/User/couponPage" tag="li">
              <div class="ph2">
                <i class="icon yi23iconfont icon-coupon-9"></i>
                <p>优惠券</p>
              </div>
            </router-link>

            <router-link to="/User/payRecordPage" tag="li" >
              <div class="ph2">
                <i class="icon yi23iconfont icon-orderlist-9"></i>
                <p>支付记录</p>
              </div>
            </router-link>

          <!--<router-link to="/Others/qna" tag="li">-->
            <li @click="urlFAQ">
              <div class="ph2">
                <i class="icon yi23iconfont icon-question-9"></i>
                <p>常见问题</p>
              </div>
            </li>
            <!--</router-link>-->

            <router-link to="/Index/configPage" tag="li">
              <div class="ph2">
                <i class="icon yi23iconfont icon-setting-9"></i>
                <p>设置</p>
              </div>
            </router-link>

            <li>
              <a href="tel://4006504580">
                <div class="ph2">
                  <i class="icon yi23iconfont icon-call-9"></i>
                  <p>客服电话</p>
                </div>
              </a>
            </li>

            <router-link to="/Others/ntalkerService" tag="li" >
              <div class="ph2">
                <i class="icon yi23iconfont icon-service-copy"></i>
                <p>在线客服</p>
              </div>
            </router-link>

        </ul>
      </div>
      <!--等级升级提示-->
      <div v-show="iconClose">
      <div class="HVcenter" v-if="userCenterPage" >
        <div class="userCenterPageGradeImg image-ratio">
          <img :src="userCenterPage.card_img" alt="">
        </div>
        <div class="userCenterPageGradeInfo">
          <p class="GradeInfo">亲爱的女神，恭喜您已获得{{ userCenterPage.pointAvailable }}积分，<br>积分已达到{{userCenterPage.levelName}}。更多会员权益等你来赢。</p>
          <router-link to="/User/userRightsPage" tag="p" class="look">
          查看会员权益
          </router-link>
        </div>
        <div class="yclosetCenterClose">
          <i class="yi23iconfont icon-closex" @click="iconClose=false"></i>
        </div>
      </div>
      <div class="yclosetShade" @click="iconClose=false"></div>
      </div>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar :pageNumber="4"></bottom-Bar>
    </div>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import bottomBar from 'base/BottomBar'
  import { userCenterPage } from 'api/user'
  import common from 'common/js/common';

  export default {
    data(){
      return{
        userCenterPage: null,
        iconClose:false
//        ppa:true,
      }
    },
    components:{
      goBack,
      bottomBar
    },
    created () {
      userCenterPage().then((res)=>{
         this.userCenterPage = res.data.uinfo;
         this.$nextTick(function () {
           this.setWidth(res.data.uinfo.pointTotal, res.data.uinfo.nextLevel);
         })
      });
    },
    methods:{
      urlFAQ:function () {
        if(this.$clientType == 4){
          window.location.href='/yi23/Home/Others/qnaAlipay'
        }
        else {
          window.location.href='/yi23/Home/Others/qna'

        }

      },
      setWidth (pointTotal,nextLevel){
        let percent = (parseFloat(pointTotal)/parseFloat(nextLevel))*100 + '%';
//        console.log(percent);
        this.$refs.ProgressBg.style.width = percent;
//        console.log(this.$refs.ProgressBg)
        this.$refs.bar.style.left = percent;
//        console.log(this.$refs.bar)
      },
      buyCard(){
        window.location.href="/yi23/Home/Member/payPage"
      }
    },
    watch:{
      userCenterPage:function (newVal, oldVal) {
//        console.log(typeof(newVal))
        if ( typeof(newVal) == 'object' && !!newVal.level)
        {
          let levelUp = common.getCookie('levelUp' + newVal.level)
          if( typeof (levelUp) == 'undefined' || levelUp == 0)
          {
            this.iconClose = true;
            common.setCookie('levelUp' + newVal.level, newVal.level)

          }
        }

        }
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";

  .HVcenter{
    /*background: #fff;*/
    height:auto;
    width:80%;
  }

  .yclosetFooter{
    .height(45);
  }
  .yclosetCon{
    background: #f7f7f7;
  }
  .userCenterPage{
    display: flex;
    justify-content:center;
    align-items: center;
    flex-wrap: wrap;
    width:100%;
    .userCard{
      background: #f7f7f7;
      .padding(10,10,10,10);
      display: block;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      width:100%;
    }


    /*会员按钮*/
    .userBtn{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      .padding(10,10,10,10);
      justify-content: space-between;
      background: #fff;

      span{
        width:47%;
        button{
          width:100%;
          .height(36);
          background: #ff544b;
          color: #fff;
          .font-size(14);
          border-radius: 0.106667rem;
        }
      }
      span:first-of-type{
        width:47%;
        border-right: .5px rgba(0,0,0,.1) solid;
        .padding(0,10,0,0);
        button{
          width:100%;
          background: #fff;
          border:.5px rgba(0,0,0,.1) solid;
          color:#666
        }
      }
    }
    /*功能列表*/
    ul.userFunctionList{
      width:100%;
      .padding(20,10,20,10);
      height: auto;
      display: flex;
      flex-wrap: wrap;
      background: @color-background;
      border-top:10px #f7f7f7 solid;
      border-bottom: 10px #f7f7f7 solid;
      li{
        display: flex;
        flex-wrap: wrap;
        justify-content:center;
        align-items:center;
        width:33%;
        .height(100);
        border-right: .5px #e6e6e6 solid;
        border-bottom: .5px #e6e6e6 solid;
        .ph2{
          display: flex;
          flex-wrap: wrap;
          justify-content:center;
          align-items: center;
          width: 100%;
          .height(60);
        }
        i,p{
          display: flex;
          justify-content:center;
          align-items: center;
          width: 100%;
        }
        p{
          .font-size(13);
        }
        i{
          .font-size(30)
        }
      }

      li:nth-child(3n){
        border-right: none;
      }
      li:nth-child(7),li:nth-child(8),li:nth-child(9){
        border-bottom: none;
      }
      li a, li a:hover{
        color: #000;

      }
    }
  }

  /*等级升级提示*/
  .userCenterPageGradeInfo{
    background: #fff;
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    p{
      .font-size(13);
      line-height:2;
      text-align: center;
      width:100%;
    }
    p.GradeInfo{
      .padding(40,20,40,20);
      letter-spacing: -1px;
    }
    p.look{
      .font-size(14);
      .padding(0,0,20,0);
      color: #cdab6a;
      text-align: center;
    }
  }
  .userCenterPageGradeImg{
    width:100%;
    height: 0;
    overflow: hidden;
    padding-bottom: 73.5294%;
    position: relative;
    img{
      width: 100%;
      position: absolute;
    }
  }
  .image-ratio{
    /*background: #fff;*/
  }
  .icon-closex{
    .font-size(40);
    color:@color-background;
  }


  /*用户等级*/
  .userCardY,.userCardJ,.userCardZ{
    width:100%;
    .height(200);
    position: relative;
    display: flex;
    justify-content: center;
    align-items:center;
  }
  .userCardYIMG,.userCardJIMG,.userCardZIMG{
    width:100%;
    height: 0;
    padding-bottom: 54.6742%;
    overflow: hidden;
    position: relative;
    /*background: #999;*/
    border-radius: 0.32rem;
    img{
      width:100%;
      position: absolute;
      top:0;
      left:0;
    }
  }
  .userCardYCon,.userCardJCon,.userCardZCon{
    position: absolute;
    top:0;
    left:0;
    width: 100%;
    .height(200);
    text-align: center;
    .font-size(18);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
  }

  .YConTop,.JConTop,.ZConTop{
    display: flex;
    flex-wrap: wrap;
    width:100%;
    .height(40);

    h2,p{
      flex-wrap: wrap;
      width:100%;
      display: flex;
      .padding(0,15,0,15);
    }
    h2{
      .font-size(24);
      .height(30);
      .margin(0,0,10,0);
      .padding(15,15,0,15);
      color: #666;
      a{
        color: #000;
      }
      i{
        .font-size(10);
        display: flex;
        justify-content: center;
        align-items: flex-end;
        .padding(0,0,0,10);
        .height(29);
      }
    }
    p{
      .font-size(10);
      color: #666;
      line-height: 1.5;
      text-align: left;
    }
    p.expiryTime{
      .font-size(14)
    }
  }
  .JConTop,.ZConTop{
    h2,p{
      color: @color-background;
    }
    h2{
      i{
        color: #666;
      }
    }
  }
  .YConBottom,.JConBottom,.ZConBottom{
    display: flex;
    flex-wrap: wrap;
    width:100%;
    .height(40);

    .integral{
      flex-wrap: wrap;
      width:100%;
      .height(20);
      display: flex;
      .padding(0,15,0,15);
      justify-content: space-between;
      p{
        display: flex;
        color: #666;
        .font-size(12);
      }
    }
    .userScore{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      .height(20);
      .padding(0,15,0,15);
      .Progress{
        display: flex;
        width:100%;
        .height(4);
        border-radius: 0.213333rem;
        background: rgba(0, 0, 0, 0.1);
        position: relative;
        z-index: 2;
        .ProgressBg{
          position: absolute;
          top:px;
          left:0;
          z-index: 3;
          width:0%;
          .height(4);
          border-radius: 0.213333rem;
          transition: width 4s;
          background: #7b7b7b; /* Old browsers */
          background: -moz-linear-gradient(left,  #7b7b7b 0%, #eff8fe 100%); /* FF3.6-15 */
          background: -webkit-linear-gradient(left,  #7b7b7b 0%,#eff8fe 100%); /* Chrome10-25,Safari5.1-6 */
          background: linear-gradient(to right,  #7b7b7b 0%,#eff8fe 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#7b7b7b', endColorstr='#eff8fe',GradientType=1 ); /* IE6-9 */
        }
        .bar{
          position: absolute;
          .top(-2);
          left:0%;
          z-index: 3;
          .width(8);
          .height(8);
          border-radius: 0.213333rem;
          background: @color-background;
          box-shadow: 0 0 1.066667rem #fff;
          transition: left 4s;

        }
      }
    }
  }
  .JConBottom{
    .integral{
      p{
        color: @color-background;
      }
    }
    .userScore{
      .Progress{
        background: rgba(255, 255, 255, 0.3);
        .ProgressBg{
          width:0%;
          background: #e37962; /* Old browsers */
          background: -moz-linear-gradient(left,  #e37962 0%, #ffcbd8 100%); /* FF3.6-15 */
          background: -webkit-linear-gradient(left,  #e37962 0%,#ffcbd8 100%); /* Chrome10-25,Safari5.1-6 */
          background: linear-gradient(to right,  #e37962 0%,#ffcbd8 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e37962', endColorstr='#ffcbd8',GradientType=1 ); /* IE6-9 */
        }
        .bar{
          left:0%;
        }
      }
    }
  }
  .ZConBottom{
    .integral{
      p{
        color: #999;
      }
    }
    .userScore{
      .Progress{
        background: rgba(255, 255, 255, 0.3);
        .ProgressBg{
          width:99%;
          background: #262626; /* Old browsers */
          background: -moz-linear-gradient(left,  #262626 0%, #cecece 100%); /* FF3.6-15 */
          background: -webkit-linear-gradient(left,  #262626 0%,#cecece 100%); /* Chrome10-25,Safari5.1-6 */
          background: linear-gradient(to right,  #262626 0%,#cecece 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#262626', endColorstr='#cecece',GradientType=1 )
        }
        .bar{
          left:98%;
        }
      }
    }
  }
</style>
