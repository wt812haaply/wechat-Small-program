<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="comments yi23ConTitle">
        <h2 class="fontUbuntu">FEEDBACK</h2>
        <em class="font-f">意见反馈</em>
        <div class="textareaCon">
          <textarea class="font-r" v-model="message" placeholder="请留下你的吐槽或者建议，我们每天都在改进"></textarea>
        </div>
        <button class="textareaBtn font-m" type="submit" @click="userSubmit">提交反馈</button>
      </div>
    </div>
    <yi23Toast :open="toastOpen" @toastColse="toastColse">
      {{ errorMsg }}
    </yi23Toast>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import { comments } from 'api/user'
  import yi23Toast from '../lib/Toast.vue'
  export default {
    data(){
        return{
          message:'',
          toastOpen:false,
          errorMsg:'请填写您的宝贵意见！',
          comments:null,
          msg:'erer'
        }
    },
    components:{
      goBack,
      yi23Toast
    },
    methods: {
      toastColse(){
        this.toastOpen=false
      },
      userSubmit: function () {
        let message = this.message;
        if(this.message != ''){
          this.message = '';
          comments(message).then((res)=>{
            if(res.code == 100){
              this.openToast(res.msg);
            }
//            console.log(res);
          })

        }
        else {
          this.toastOpen=true
        }
      },
      openToast(msg){
        this.errorMsg = msg;
        this.toastOpen = true;
      }
    },
    created () {
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  .textareaCon{
    .margin(40,0,0,0);
    textarea{
      width:100%;
      .width(309);
      .padding(10,10,10,10,);
      .height(235);
      .font-size(14);
      //font-size: 14 * @unit;
      color: #111;
      border-radius: 0;
      outline: none;
      background: #f7f7f7;
      display: block;
    }
  }
  button.textareaBtn{
    .height(42);
    width: 100%;
    background:@color-bz-red;
    .margin(23,0,0,0);
    color:@color-background;
    .font-size(14);
  }
</style>
