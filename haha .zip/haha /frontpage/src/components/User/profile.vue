<template>
  <div class="yclosetContainer"> <!--profile-->
    <div class="yclosetHeader">
        <go-back></go-back>
    </div>
    <div class="yclosetCon"><!--核心内容部分-->
      <div class="profileCon" v-if="profile">
        <ul class="ConList">
          <li>
            <div class="Left">默认尺码</div>
            <div class="Right">
              <select v-model="profile.uInfo.default_size">
                <option :value="item"  v-for="item in profile.sizeList">{{item + "码"}}</option>
              </select>
              <i class="yi23iconfont icon-arrowdown"></i>
            </div>
          </li>
          <li>
            <div class="Left">我的体重</div>
            <div class="Right">
              <select v-model="profile.uInfo.heavy">
                <option :value="item" v-for="item in profile.heavyList">{{item + "kg"}}</option>
              </select>
              <i class="yi23iconfont icon-arrowdown"></i>
            </div>
          </li>
          <li>
            <div class="Left">我的身高</div>
            <div class="Right">
              <select v-model="profile.uInfo.tall">
                <option :value="item" v-for="item in profile.tallList">{{item + "cm"}}</option>
              </select>
              <i class="yi23iconfont icon-arrowdown"></i>
            </div>
          </li>
        </ul>
        <!---->
        <ul class="ConList">
          <li>
            <div class="Left">行业</div>
            <div class="Right">
              <select v-model="profile.uInfo.profession">
                <option :value="item" v-for="item in profile.jobList">{{item}}</option>
              </select>
              <i class="yi23iconfont icon-arrowdown"></i>
            </div>
          </li>
          <li>
            <div class="Left">出生年月</div>
            <div class="Right">
              <input class="years" style="width:auto;" type="date" v-model="profile.uInfo.birthday" >
            </div>
          </li>
          <li>
            <div class="Left">手机号</div>
            <div class="Right">{{profile.uInfo.mobile}}</div>
          </li>
          <li  @click="myAddrClick">
            <div class="Left">收货地址</div>
            <div class="Right">
              <i class="yi23iconfont icon-right"></i>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="yclosetFooter">
      <div class="configPageFooterBtn">
        <button class="font-m btn btn-defult" @click="submit">保存</button>
      </div>
    </div>
    <yi23Toast :open="toastOpen" @toastColse="toastColse">
      {{ errorMsg }}
    </yi23Toast>
  </div>
</template>
<script>
import goBack from 'base/GoBack'
import { profile,changeUserInfo } from 'api/user'
import yi23Toast from '../lib/Toast.vue'
  export default {
    data(){
      return{
        profile: null,
        toastOpen:false,
        errorMsg:'保存成功！',
        msg:'erer',
      }
    },
    components:{
      goBack,
      yi23Toast
    },
    methods:{
      toastColse(){
        this.toastOpen=false
      },
      submit:function(){
        let options = {
          sizeList:this.profile.uInfo.default_size,
          jobList:this.profile.uInfo.profession,
          tallList:this.profile.uInfo.tall,
          heavyList:this.profile.uInfo.heavy,
          birthday:this.profile.uInfo.birthday
        }
        changeUserInfo(options).then((res)=>{
//        console.log(res);
          this.changeUserInfo = res.data;
          if(res.code == 200){
            this.openToast(res.msg);
          }
          else {
            this.toastOpen=true
          }
        });
      },

      openToast(msg){
        this.errorMsg = msg;
        this.toastOpen = true;
      },
      //收货地址
      myAddrClick:function(){
        let urls=this.$route.fullPath;
        this.$router.push({
          path:'/User/myAddress',
          query:{ redirect:encodeURIComponent(urls)}
        })
      },


    },
    created () {
      profile().then((res)=>{
        console.log(res);
        this.profile = res.data;
      });
//      changeUserInfo().then((res)=>{
//        console.log(res);
//        this.changeUserInfo = res.data;
//      });
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  .yclosetCon{
    background: #f7f7f7;
  }
  .yclosetFooter{
    .height(75);
    display: flex;
    justify-content:center;
    align-items: center;
  }
  .profileCon{
    ul.ConList{
      display: flex;
      justify-content:center;
      align-items:center;
      flex-wrap: wrap;
      width:100%;
      border-bottom: 10px #f7f7f7 solid;
      background: @color-background;
      li{
        display: flex;
        width:100%;
        justify-content:space-between;
        align-items:center;
        flex-wrap:wrap;
        .height(50);
        .margin(0,20,0,20);
        color:#333;
        .font-size(12);
        border-bottom: .5px rgba(0,0,0,.1) solid;
        .Left{
          display: flex;
          justify-content:flex-start;
        }
        a{
          width:50%;
        }
        .Right{
          display: flex;
          justify-content:flex-end;
          .font-size(12);
          select{
            border-radius:none;
            text-align: right;
            appearance: none;
            background: none;
            border: none;
            height: auto;
            direction: rtl;
            .font-size(12);
            color: #000;
            .margin(0,4,0,0);
          }
          input.years{
            .width(200);
            .height(30);
            text-align: right;
            color: #000;
            .font-size(12);
          }
          .icon-arrowdown{
            .font-size(8);
            color:rgba(0,0,0,.3);
            display: flex;
            justify-content:center;
            align-items:center;
            position: relative;
            .top(3);
          }
        }
        .icon-right{
          .font-size(12);
          color: rgba(0,0,0,.2);
        }
      }
      li:last-child{
        border-bottom:none;
      }
    }
  }
  .configPageFooterBtn{
    width:100%;
    background: @color-background;
    padding:0 10px;
    button.btn{
      width:100%;
      .height(44);
    }
  }
</style>
