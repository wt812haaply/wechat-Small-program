<template>
  <div class="yclosetContainer" v-if="showStatus"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="loginPageCon yi23ConTitle">
        <h2 class="fontUbuntu">SIGN IN</h2>
        <em class="font-f">请登录</em>
        <ul class="loginConList">
          <li>
            <input type="tel" name="tel" placeholder="请输入手机号" v-model="mobile">
          </li>
          <li>
            <input type="text" name="tel" placeholder="请输入右边数字后发送验证码" v-model="imgCode">
            <div class="loginPageVerification"><div class="VerificationImg"><img :src="codeImgUrl" @click="checkImg"></div></div>
          </li>

          <li>
            <input type="tel" name="tel" placeholder="请输入验证码" v-model='code'>
            <div class="VerificationBtn"><button type="submit" class="Btn btn" @click="getCode">{{btnMsg}}</button></div>
          </li>
        </ul>
        <div class="loginPageBtn">
          <button class="btn btn-defult btn-black" @click="doLogin">登录</button>
        </div>
      </div>
    </div>
    <yi23-toast v-model="msg">
    </yi23-toast>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import login from '@/api/login'
  import loginLocal from '@/common/js/login'
  import { mapGetters } from 'vuex'
  export default {
    data () {
      return {
        mobile: '',
        imgCode: '',
        showStatus:false,
        codeImgUrl:'',
        btnMsg: '发送验证码',
        sendingCode:false,
        timerNumber:60,
        msg: '',
        code: ''
      }
    },
    components:{
      goBack,
    },
    watch:{
      loginRes (newStatus,oldStatus){
        this.msg=newStatus.msg
        if(newStatus.status){
          let redirect = decodeURIComponent(this.$route.query.redirect || '/');
          this.$router.replace({
            path: redirect
          })
        }
      },
      '$route':'aliPayLogin'
    },
    computed: {
      ...mapGetters({
        loginRes: 'loginRes'
      })
    },
    methods: {
      dataRequired (options) {
        for (var k in options){
          if(this[options[k].name] == ''){
            this.msg= options[k].msg
            this.toastOpen = true;
            return false;
            break;
          }
        }
        return true
      },
      checkImg(){
        this.codeImgUrl=this.codeImgUrl+1
      },
      doLogin () {
        if(this.dataRequired([{name:'mobile',msg:'手机号不能为空'},{name:'imgCode',msg:'图形验证码不能为空'},{name:'code',msg:'短信验证码不能为空'}])){
          this.$store.dispatch('getUserInfo',{mobile:this.mobile,code:this.code})
        }
      },
      timerAction(){
          let timers=setInterval( () =>{
            if(this.timerNumber>0){
              this.timerNumber= this.timerNumber-1
              this.btnMsg=this.timerNumber+'s后获取！'
              // console.log(this.btnMsg)
            }else{
              clearInterval(timers)
              this.sendingCode=false
              this.btnMsg='发送验证码'
            }
          },1000)
      },
      getCode () {
        if(!this.sendingCode && this.dataRequired([{name:'mobile',msg:'手机号不能为空'},{name:'imgCode',msg:'图形验证码不能为空'}])){
          this.timerAction();
          this.sendingCode=true
          login.getVerifyCode({mobile:this.mobile,code:this.imgCode}).then((res)=>{
            if(res.data.code == 200){

            }else {
              this.msg= res.data.msg
            }
          }).catch((error)=>{
              console.log('error'+ error)
          })
        }
      },
      aliPayLogin(){
        // console.log(this.$route)
        if(this.$clientType==4){
          let autoCode=this.$route.query.auth_code
          if(autoCode){
            //通过autoCode  获取登陆信息
            login.getAliUserInfo({code:autoCode}).then((res)=>{
              if(res.data.code==200){
                loginLocal.setUserInfo(res.data.data.user)
                let redirect = decodeURIComponent(this.$route.query.redirect || '/');
                this.$router.replace({
                  path: redirect
                })
              }else {//没有手机号
                  this.showStatus=true;
              }
            })

          }else{
            let urls='/yi23/Home'+this.$route.fullPath;
            login.getaliAuthLink({url:urls}).then((res)=>{
              if(res.data.code==200){
                window.location.href=res.data.data;
              }else{
                this.msg= res.data.msg
              }
            })
          }
        }else {
          this.showStatus=true;
        }
      },
    },
    created (){
      let redirectUrl=this.$route.query.redirect
      // if(redirectUrl){
      //   if(decodeURIComponent(redirectUrl)=='/Event/rewardList'){
      //     window.location.href=window.location.href+encodeURIComponent('?t=1')+"&loginRedirectUrl="+encodeURIComponent('/yi23/Home/Event/rewardList')+'&back='+encodeURIComponent('/yi23/Home/Event/rewardList')
      //     return;
      //   }
      // }
      this.aliPayLogin()
      this.codeImgUrl=login.codeImgUrl()
      // this.$store.dispatch('getUserInfo')
    }
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";
  .yclosetContainer{
    background: #fafafa;
  }
  .loginPageCon{
    width:100%;
    ul.loginConList{
      .margin(68,0,0,0);
      li{
        width: 100%;
        .height(58);
        & input{
          border-bottom: 1px #e6e6e6 solid;
          width: 100%;
          height: 58px;
          color: #000;
          text-align: left;
          font-size: 12px;
          border-radius: 0;
        }
        & .loginPageVerification, & .VerificationBtn{
          position: relative;
          top:-44px;
          right: 0;
         .VerificationImg,button.Btn{
           position: absolute;
           top:0px;
           right: 0;
           img{
             width:100%;
           }
          }
          button.Btn{
            width:100px;
            height: 30px;
            color: #333;
            background: #fff;
          }
          button.Btn:after{
            content: " ";
            width:200%;
            height:200%;
            position: absolute;
            top: 0;
            left: 0;
            border: 1px solid rgba(0,0,0,.8);
            transform: scale(.5);
            transform-origin: 0 0;
            box-sizing: border-box;
          }
        }
      }

    }
    .loginPageBtn{
      width:100%;
      .margin(35,0,0,0);
      button{
        width:100%;
        .height(40);
      }
    }

  }
</style>
