<template>
  <div class="yclosetContainer"><!--privacy-->
    <div class="yclosetHeader">
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="privacy">
        <div class="topInformation">
          <p class="font-r">
            衣二三非常重视对用户信息的保护，用户在本站进行浏览、下单购物等活动时，涉及用户真实姓名/名称、通信地址、联系电话、电子邮箱、支付账号等隐私信息的，衣二三将予以严格保密；
          </p>
          <p class="font-r">除非得到用户的授权或法律另有规定，</p>
          <p class="font-r">不会向外界披露用户隐私信息。</p>
        </div>
        <ul class="ConList">
          <li v-for="item in items">
            <span class="Left"></span>
            <span class="Right">{{ item.message }}</span>
          </li>
        </ul>
      </div>
    </div>

  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  export default {
    data(){
      return {
        items: [
          { message: '用户注册成功后，将产生用户名和密码等账户信息，用户可以根据本站规定随时改变密码；' },
          { message: '用户应谨慎合理的保存、使用其用户名和密码；' },
          { message: '用户若发现任何他人非法使用用户账号或存在安全漏洞的情况，请立即通知本站，并严重时，应向公安机关报案；' },
          { message: '用户不得将在本站注册获得的账户借给他人使用，否则用户应承担由此产生的全部责任，并与实际使用人承担连带责任；' },
          { message: '如果发现任何非法使用等可能危及账户安全的情形时，用户应当立即以有效方式通知衣二三，要求衣二三暂停相关服务，并向公安机关报案。' },
          { message: '用户理解衣二三对用户的请求采取行动需要合理时间，衣二三对在采取行动前已经产生的后果（包括但不限于用户的任何损失）不承担责任。' },
        ]
      }
    },
      components:{
        goBack
      }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  .privacy{
    background-color: @color-background;
    display: flex;
    flex-direction: column;
    width:100%;
  }
  .topInformation{
    .padding(20,30,40,30);

    p{
      .font-size(14);
      .line-height(24);
      color: #D56E6E;
      text-align: center;
    }
    p:first-of-type {
      .margin(20,0,20,0);
    }
  }
  ul.ConList{
    .margin(0,0,40,0);
    li{
      .font-size(12);
      text-align: left;
      span.Left{
        float: left;
        .width(3);
        .height(15);
        background: #f9516c;
        position: relative;
        .top(18);
        left:0;
      }
      span.Right{
        .margin(0,0,0,12);
        display: block;
        .line-height(24);
        .font-size(14);
        border-bottom: 1px #ededed solid;
        .padding(15,0,15,0);
      }
    }
    li:last-child{
      span.Right{
        border:none
      }
    }
  }
</style>
