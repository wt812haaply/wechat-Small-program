<template>
  <div class=""><!--about-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="wrapper bG">
      <h1>联系我们获得支持</h1>
      <p>如需咨询衣二三产品、技术与业务，请于周一至五10:00-19:00致电<a href="tel:4006504580">400-650-4580</a>联系我们获得帮助。您也可以选择发送邮件获取支持</p>
      <p>技术与产品咨询：<a href="mailto:cs@yi23.net">cs@yi23.net</a></p>
      <p>商务合作咨询：<a href="mailto:flora.he@yi23.net">flora.he@yi23.net</a></p>

    </div>
  </div>

</template>

<script>
  import goBack from 'base/GoBack'
  export default {
    components:{
      goBack
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  .wrapper{
    width: 100%;
    margin: 0;
    font-family: 'PingFang SC', 'Helvetica Neue', 'DroidSansFallback';
    padding: 10px 24px;
    box-sizing: border-box;
  }

  h1{
    font-family: PingFangSC-Light;
    font-size: 22px;
    color: #000000;
    letter-spacing: 0.5px;
    font-weight: 200;
    margin: 40px 0;
  }

  p{
    font-family: PingFangSC-Light;
    font-size: 14px;
    color: #333333;
    letter-spacing: 0.5px;
    line-height: 26px;
    font-weight: 200;
    margin-bottom: 20px;
  }

  a{
    font-weight: 300;
    text-decoration: none;
    color: #cdab6a;

  }
</style>
