<template>
  <div class="yclosetContainer"><!--about-->
    <div class="yclosetHeader"><!--Header-->
        <go-back></go-back>
    </div>

    <div class="yclosetCon"><!--核心内容部分-->
      <div class="aboutCon">
        <div class="aboutConImg about_01">
          <img src="//tu.95vintage.com/web_source/Home/Common/images/about_01.png" alt="">
        </div>
        <div class="aboutConImg about_02">
          <img src="//tu.95vintage.com/web_source/Home/Common/images/about_02.png" alt="">
        </div>
        <div class="aboutConImg about_03">
          <img src="//tu.95vintage.com/web_source/Home/Common/images/about_03.png" alt="">
        </div>
      </div>
    </div>
    <!--<div class="yclosetFooter">111</div>&lt;!&ndash;Footer&ndash;&gt;-->
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  export default {
    components:{
      goBack
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  .aboutCon{
    display: flex;
    flex-wrap: wrap;
    width:100%;
  }
  .aboutConImg,.about_01,.about_02,.about_03
  {
    width:100%;
    height:0;
    padding-bottom:50.6666%;
    position: relative;
    overflow: hidden;
  }
  .aboutConImg img{
    width:100%;
    position: absolute;
  }
  .about_02{
    padding-bottom: 53.3333%;
  }
  .about_03{
    padding-bottom: 65.0666%;
  }
</style>
