<template>
  <div class="jumpNativePageDown">
    <div class="jumpNativePageDownCon font-r">
      <h2>衣二三<br>创新女装租衣共享平台</h2>
      <p class="font-l">每月¥299起，随心换穿全球时装<br>点击立即下载APP</p>
      <button class="btn" @click="downApp()">立即下载</button>
    </div>
    <div class="jumpNativePageFooter font-l">www.yi23.net</div>
  </div>
</template>

<script>
  export default {
    methods:{
      downApp:function () {
        window.location.href='http://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan'
      }
    },
    created() {
      let urls=this.$route.params;
      let query=this.$route.query;
      let reloadUrl='',nativeStatus='?v=1.1'
      reloadUrl=query.cs3?query.cs3:'www.95vintage.com/yi23/Home/Index/index';
      if(query.cs4){
        nativeStatus=nativeStatus+'&jumpNativeStatus='+query.cs4
      }
      if(urls && urls[0]){
        nativeStatus=nativeStatus+'&'+urls[0].replace('cs1/','jumpNativeType=').replace('cs2/','jumpNativeId=').replace('/','&')
      }else{
        if(query.cs1){
          nativeStatus=nativeStatus+'&jumpNativeType='+query.cs1
        }
        if(query.cs2){
          nativeStatus=nativeStatus+'&jumpNativeId='+query.cs2
        }
      }
      let endUrl=reloadUrl+nativeStatus
      if(navigator.userAgent.match(/(iPhone|iPod|iPad);?/i)){
        window.location.href = "yi23app://"+endUrl;
      }else if(navigator.userAgent.match(/android/i)){
        window.location.href = "yi23app://"+endUrl;
      };
    }
  }
</script>

<style lang="less" scoped>
  @import '~common/less/mixin.less';
  @import '~common/less/variable.less';
  .jumpNativePageDown{
    background: #fff url('https://tu.95vintage.com/web_source/Home/Common/images/not-member-bj.jpg') 0 0 no-repeat ;
    background-size: 100%;
    height:100vh;
    display: flex;
    &Con{
      position: fixed;
      top: 50%;
      left: 50%;
      width: 70%;
      transform: translateX(-50%) translateY(-50%);
      z-index: 2;
    }
  }
  .jumpNativePageDownCon{
    text-align: center;
    h2{
      line-height: 31px;
    }
    p{
      margin: 20px 0 40px 0;
      padding: 0px;
      color: #666;
      display: block;
      line-height: 21px;
      font-size: 14px;
    }
    button{
      width:100%;
      height:44px;
      font-size: 14px;
      background: #CDAB6A;
      color: #fff;
    }
  }
  .jumpNativePageFooter{
    position: fixed;
    bottom:14px;
    left:0;
    width:100%;
    font-size: 12px;
    text-align: center;
    color: rgba(0,0,0,.3);
    letter-spacing: .5px;
  }
  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .jumpNativePageFooter{
      .bottom(54);
    }
  }
</style>
