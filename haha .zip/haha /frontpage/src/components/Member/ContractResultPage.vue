<template>
  <div class="contractpay">
    <template v-if="is_success == 'T'">
      <div class="banner">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/contractResultPage/success-banner.png">
      </div>
      <div class="new-payment-success">
          <h2><i><img src="https://yimg.yi23.net/webimg/20180420/frontpage/success-icon.png"></i>连续包月开通成功</h2>
          <p>快去挑选百万美衣吧，最快次日即可送达哦~</p>
          <div class="btn">
            <span @click="linkUrl">立即去选衣</span>
          </div>
      </div>
    </template>

    <template v-if="is_success == 'F'">

      <div>
        <div class="iete" style="padding-bottom: 3rem;">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/20180505Banner.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050501.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050502.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050503.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050504.png" alt="">
        </div>
        <div class="footerBtn">
          <div class="new_btn_gudi_a" style="">
            <ul class="new_btn_1">
              <li><button type="submit" class="new_btn_width_a new_btn_background_e new_btn_border_f new_btn_height_b "  @click="openSDK();">咨询人工客服</button></li>
              <li><button type="submit" class="new_btn_width_a new_btn_background_f new_btn_border_f new_btn_height_b "  style="background-color: #ff544b" @click="goPay">继续开通支付</button></li>
            </ul>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script>
export default {
  data(){
    return {
      is_success: true
    }
  },
  created(){

    let query = this.$route.query;
    let is_success;
    if(query.is_success){
      is_success = query.is_success;
    }else{
      is_success = 'F';
    }

    this.checkIsSuccess(is_success);
  },
  methods:{
    checkIsSuccess(is_success){
      this.is_success = is_success;
    },
    openSDK: function(){
      window.location.href = ysf.url();
    },
    linkUrl:function(){
      window.location.href ="/yi23/Home/Subscribe/pdtListPage?jumpNativeType=7"
    },
    goPay(){
      window.location.href ="/yi23/Home/Member/payPage?jumpNativeType=4"
    }
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .contractpay{
    position:relative;
    z-index:10;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    height: 100%;
    background: #fff;
    .banner{
      width: 100%;
      img{
        display: block;
        width: 100%;
      }
    }
    .new-payment-success{
      padding-top: 80px;
      h2{
        font-size: 20px;
        vertical-align: baseline;
        text-align: center;
        i{
          display: inline-block;
          width: 26px;
          height: 26px;
          vertical-align: top;
          margin-right: 5px;
          img{
            width: 100%;
          }
        }
      }
      p{
        font-size: 14px;
        line-height: 21px;
        color: #666;
        margin-top: 30px;
        text-align: center;
      }
      .btn{
        font-size: 0;
        span{
          display: inline-block;
          text-align: center;
          width: 190px;
          height: 38px;
          line-height: 38px;
          color:#fff;
          font-size: 14px;
          margin-top: 52px;
          font-weight: 500;
          background: #FF544B;
        }
      }
      footer{
        position: fixed;
        bottom: 30px;
        width: 100%;
        text-align: center;
        font-size: 14px;
        color:#111;
      }
    }
    .iete img{
      width:100%;
    }
    .footerBtn{
      margin: 0;
      padding: 0;
      outline: none;
      border: none;
      box-sizing: border-box;
      .new_btn_gudi_a{
        padding: 8px;
        /*padding: 8px 12px 12px 12px;*/
        box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.05);
        position: fixed;
        bottom: 0px;
        width: 96%;
        height: auto;
        z-index: 999;
        /*border-top: 1px #eee solid;*/
        background: rgba(255,255,255,0.9);
        .new_btn_1{
          margin-left: -2%;
          display: flex;
          li{
            flex:1;
            margin: 0 0 0 2%;
            font-size: 14px;
            color: #3d3d3d;
            button{
              border: 1px #d7d7d7 solid;
              .font-size(12);
              font-weight: 800;
            }
            .new_btn_height_b{
              height: 40px;
              width: 100%;
            }
            .new_btn_background_e {
              background: #fff;
            }
            .new_btn_background_f{
              color:white;
            }
          }
        }
      }
    }
  }
</style>
