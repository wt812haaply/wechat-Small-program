<template>
  <div class="huabeipay" v-if="cardDetailList">
    <go-back></go-back>
    <div class="wrapper">

      <div class="swiper-box" v-if="cardDetailList">
        <swiper :options="swiperOption" ref="mySwiper" @slideChangeTransitionEnd="getSwiperIndex">
          <swiper-slide v-for="(slider,index) of cardDetailList" :key="index">
            <div class="card-content">
              <img :src="slider.cardImage">
            </div>
          </swiper-slide>
        </swiper>
      </div>

      <div class="content" v-if="cardDetailList">
        <div class="message">
          <div class="item">
            <p>{{ cardDetailList[currentIndex].payName }}</p>
            <span>¥{{ Number(cardDetailList[currentIndex].payOriginal)}}</span>
          </div>
          <div class="item" v-for="(item,index) of cardDetailList[currentIndex].payReductionInfos">
            <p>{{item.reductionName}}</p>
            <span class="add">-¥{{item.reductionAmount}}</span>
          </div>

          <div class="item" @click="couponsLayerOpen">
            <p>优惠券</p>
            <span class="add gray coupon" v-if="(JSON.stringify(couponsActive) == '[]' || !couponsActive) && !nocoupons">没有可用优惠券哦<i class="icon yi23iconfont icon-right"></i></span>
            <span class="gray" v-if="nocoupons">不使用优惠券</span>
            <template v-if="couponsActive != null && JSON.stringify(couponsActive) != '[]' && !nocoupons">
              <span class="coupon" v-if="couponType(couponsActive.couponType)">-¥{{couponsActive.value}}</span>
              <span class="coupon" v-else>{{couponsActive.value * 10}}折</span>
            </template>
          </div>

          <div class="item cash">
            <p>实际支付</p>
            <span class="cash-text cash-color">¥{{total}}</span>
          </div>

        </div>
        <div class="deposit">
          <h6>用芝麻信用，有机会免交¥300押金</h6>
        </div>
        <div class="description">
          <div class="item" v-for="(item,index) of decImage">
            <img :src="item">
          </div>
        </div>
      </div>

    </div>

    <div class="footer" @click="_zhimaPay()" v-if="cardDetailList">
      <div class="btn">立即成为会员</div>
    </div>

    <pop-up-layer v-if="couponsLayerShow">
      <Coupons
        @btnClick="unUseCoupons"
        @closedPopLayer="couponsLayerClosed"
        :data="couponsList"
        >
        <ul class="coupons-wrapper">
          <li class="coupons-item" v-for="(item, index) of couponsList" @click="choiceCoupon(item)">
            <div class="dec">
              <p>{{item.couponTitle}}</p>
              <span>{{item.startDate | YYYY_MM_DD }}-{{item.expDate | YYYY_MM_DD }}</span>
            </div>

            <div class="money type_a" v-if="couponType(item.couponType)">
              <p><i>¥</i>{{item.value}}</p>
            </div>
            <div class="money type_b" v-else>
              <p>{{item.value * 10}}<i>折</i></p>
            </div>
          </li>
        </ul>
      </Coupons>
    </pop-up-layer>

    <yi23Toast v-model="toastMsg"></yi23Toast>

  </div>
</template>

<script type="text/ecmascript-6">
import GoBack from 'base/GoBack';
import PopUpLayer from 'base/PopUpLayer';
import Coupons from 'components/Member/_coupons';
import { ERR_OK } from 'api/const';
import { zhima } from 'api/member';
import { getCreditLink } from 'api/buy';
import { toastMixin,couponMixin } from 'common/js/mixin';

export default {
  mixins: [toastMixin,couponMixin],
  data(){
    return {
      swiperOption: {
        effect: 'coverflow',
        slidesPerView: '1.2',
        centeredSlides: true,
        spaceBetween: 10,
        coverflowEffect:{
          rotate: 0,
          stretch: 0,
          depth: 50,
          modifier: -5,
          slideShadows: false
        }
      },
      cardDetailList: null,
      iscoupon: null,
      currentIndex: 0,
      decImage:[
        'https://tu.95vintage.com/web_source/Home/Common/images/zhimapay_v1.png',
        'https://tu.95vintage.com/web_source/Home/Common/images/zhimapay2.png?v1123'
      ]
    }
  },
  created(){
    this._zhima();
  },
  computed:{
    total(){
      let slider = this.cardDetailList;
      let [ paycost,total = paycost ] = [ slider[this.currentIndex].payOriginal ];
      let extraReduce = 0; //减免
      let payReductionInfos = slider[this.currentIndex].payReductionInfos;

      if(payReductionInfos.length > 0){
        for(let i = 0, item; item = payReductionInfos[i++];){
          extraReduce += item.reductionAmount
        }
      }

      let couponsActive = this.couponsActive;
      if(this.nocoupons == false &&  couponsActive != null && JSON.stringify(couponsActive) != '{}'){
        if(couponsActive.couponType == 1){
          total = paycost - couponsActive.value;
        }else if(couponsActive.couponType == 2){
          total = paycost * couponsActive.value;
        }
      }

      total = parseInt(total - extraReduce);

      return total >= 0 ? total : 0;

    },
    swiper() {
      return this.$refs.mySwiper.swiper
    }
  },
  methods:{
    _zhima(){
      zhima().then((res)=>{
        if(res.code == ERR_OK){
          let data = res.data;
          this.cardDetailList = data.paydetail;
          this.couponsList = data.couponlist;
          this.couponsActive = data.activecoupon;
          this.iscoupon = data.iscoupon;
        }else{
          this.setToastMsg(res.msg);
        }
      })
    },
    getSwiperIndex() {
      this.currentIndex = this.swiper.activeIndex;
    },
    _zhimaPay(){

      let cardTemplateId = this.cardDetailList[this.currentIndex].templateId;
      let couponId = (this.couponsActive && this.couponsActive.couponId) || 0;
      let payType = 'ALI_CREDIT_LIFE';

      let params = {cardTemplateId,couponId,payType};
      let success = 'MemberPaySuccess';

      window.location.href = `/yi23/Home/Pay/payment?params=${encodeURIComponent(JSON.stringify(params))}&success=${success}&redirect=${encodeURIComponent(this.$route.fullPath)}`;

    }
  },
  components:{
    GoBack,
    PopUpLayer,
    Coupons
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .gray{
    color: #ccc;
  }
  .cash-color{
    color: #FF544B;
  }
  .huabeipay{
    display: flex;
    flex-direction: column;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    font-family: "PingFang SC";
    font-weight: 500;
    height: 100%;
    background: #fafafa;
    .wrapper{
      flex: 1;
      overflow-y: auto;
      .swiper-box{
        .card-content{
          width: 100%;
          padding: 30px 0 30px 0;
          img{
            display: block;
            width: 100%;
          }
        }
      }
      .content{
        position: relative;
        z-index: 5;
        width: 100%;
        box-sizing: border-box;
        padding: 16px;
        margin-top: -30px;
        .message{
          width: 100%;
          background: #fff;
          box-sizing: border-box;
          padding: 20px;
          .item{
            .box();
            .box-center();
            font-weight: 500;
            color: #111;
            font-size: 14px;
            &.cash{
              box-sizing: border-box;
              height: 34px;
              padding-top: 10px;
              .px-top();
              margin-top: 10px;
            }
            .coupon{
              vertical-align: middle;
            }
            p{
              -webkit-box-flex:1;
              height: 34px;
              line-height: 34px;
              font-weight: 300;
            }
            span{
              display: block;
              line-height: 34px;
              i{
                font-size: 13px;
                font-weight: 600;
              }
              &.cash-text{
                font-size: 17px;
                font-weight: 500;
              }
            }
          }
        }
        .deposit{
          background: #fff;
          padding: 16px 20px;
          margin-top: 10px;
          h6{
            line-height: 31px;
            font-weight: 300;
            color: #333;
          }
          p{
            color: #999;
            line-height: 21px;
            font-size: 10px;
            font-weight: 300;
            strong{
              color: #000;
              font-weight: 600;
            }
          }
        }
        .description{
          margin-top: 30px;
          .item{
            width: 100%;
            img{
              display: block;
              width: 100%;
            }
          }
        }
      }
    }
    .footer{
      padding: 20px 17px;
      background: #fafafa;
      .btn{
        width: 100%;
        height: 48px;
        line-height: 48px;
        color: #fff;
        background: #FF544B;
        font-size: 14px;
        font-weight: 700;
      }
    }
  }
  .couponsShow();
</style>
