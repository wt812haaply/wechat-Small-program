<template>
  <div class="contractpay">
    <template v-if="is_success == 'T' && successInfo != null">
      <div class="banner">
          <img :src="successInfo.successImgUrl">
      </div>
      <div class="new-payment-success">
          <h2><i><img src="https://yimg.yi23.net/webimg/20180420/frontpage/success-icon.png"></i>会员开通成功</h2>
          <p v-html="successInfo.message"></p>
          <div class="btn">
            <span @click="linkUrl(successInfo.url)">{{successInfo.buttonMessage}}</span>
          </div>
      </div>
    </template>
    <template v-if="is_success == 'F'">

      <div>
        <div class="iete" style="padding-bottom: 3rem; ">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/20180505Banner.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050501.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050502.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050503.png" alt="">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/contractResultPage/2018050504.png" alt="">
          <!-- <p style="width:100%; word-wrap: break-word; word-break: normal;">{{fullPath}}</p> -->
        </div>
        <div class="footerBtn">
          <div class="new_btn_gudi_a" style="">
            <ul class="new_btn_1">
              <li><button type="submit" class="new_btn_width_a new_btn_background_e new_btn_border_f new_btn_height_b "  @click="openSDK();">咨询人工客服</button></li>
              <li><button type="submit" class="new_btn_width_a new_btn_background_f new_btn_border_f new_btn_height_b "  style="background-color: #ff544b" @click="goPay">继续开通支付</button></li>
            </ul>
          </div>
        </div>

      </div>
    </template>
  </div>
</template>

<script>
export default {
  data(){
    return {
      is_success: true,
      successInfo:null
      // fullPath:null
    }
  },
  created(){

    /**
     * 支付结果页面两种接受参数的方式
     * 第一种is_success=T/F
     * 第二种
     * http://testwx.95vintage.com/yi23/Home/Member/normalResultPage?FromPageId=UNKNOWN
     * &biz_content={"admit_state":"Y","invoke_type":"WINDOWS","order_no":"233888389","out_order_no":"1535003915154610","success":"true","user_id":"2088102184711920"}
     * &readTitle=true&defaultTitle=true
     * &showLoading=NO&showProgress=YES
     * &canPullDown=NO
     * &showOptionMenu=NO
     * */

    let is_success;
    let query = this.$route.query;

    if(query && query.is_success){
      is_success = query.is_success;
    }else if(query && query.biz_content){
      let content = JSON.parse(decodeURIComponent(query.biz_content));
      if(content.success == 'true'){
        is_success = 'T'
      }else{
        is_success = 'F'
      }
    }else{
      is_success = 'F'
    }

    this.checkIsSuccess(is_success);

  },
  methods:{
    checkIsSuccess(is_success){

      //获取来自localStorage存入的成功页面数据
      if(is_success === 'T'){
        let successInfo = JSON.parse(localStorage.getItem('paySuccessInfo'));
        this.successInfo = successInfo;
      }

      this.is_success = is_success;
    },
    openSDK: function(){
      window.location.href = ysf.url();
    },
    linkUrl:function(url){
      window.location.href = url;
    },
    goPay(){
      window.location.href ="/yi23/Home/Member/payPage?jumpNativeType=4"
    }

  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .contractpay{
    position:relative;
    z-index:10;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    height: 100%;
    background: #fff;
    .banner{
      width: 100%;
      img{
        display: block;
        width: 100%;
      }
    }
    .new-payment-success{
      padding-top: 80 * @unit;
      h2{
        font-size: 20 * @unit;
        vertical-align: baseline;
        text-align: center;
        i{
          display: inline-block;
          width: 26 * @unit;
          height: 26 * @unit;
          vertical-align: top;
          margin-right: 5 * @unit;
          img{
            width: 100%;
          }
        }
      }
      p{
        font-size: 14 * @unit;
        line-height: 21 * @unit;
        color: #666;
        margin-top: 30 * @unit;
        text-align: center;
        padding: 0 50 * @unit;
      }
      .btn{
        font-size: 0;
        span{
          display: inline-block;
          text-align: center;
          width: 190 * @unit;
          height: 38 * @unit;
          line-height: 38 * @unit;
          color:#fff;
          font-size: 14 * @unit;
          margin-top: 52 * @unit;
          font-weight: 500;
          background: #FF544B;
        }
      }
      footer{
        position: fixed;
        bottom: 30 * @unit;
        width: 100%;
        text-align: center;
        font-size: 14 * @unit;
        color:#111;
      }
    }
    .iete img{
      width:100%;
    }
    .footerBtn{
      margin: 0;
      padding: 0;
      outline: none;
      border: none;
      box-sizing: border-box;
      .new_btn_gudi_a{
        padding: 8 * @unit;
        /*padding: 8px 12px 12px 12px;*/
        box-shadow: 0 0 6 * @unit 0 rgba(0, 0, 0, 0.05);
        position: fixed;
        bottom: 0px;
        width: 96%;
        height: auto;
        z-index: 999;
        /*border-top: 1px #eee solid;*/
        background: rgba(255,255,255,0.9);
        .new_btn_1{
          margin-left: -2%;
          display: flex;
          li{
            flex:1;
            margin: 0 0 0 2%;
            font-size: 14 * @unit;
            color: #3d3d3d;
            button{
              border: 1px #d7d7d7 solid;
              .font-size(12);
              font-weight: 800;
            }
            .new_btn_height_b{
              height: 40 * @unit;
              width: 100%;
            }
            .new_btn_background_e {
              background: #fff;
            }
            .new_btn_background_f{
              color:white;
            }
          }
        }
      }
    }
  }
</style>
