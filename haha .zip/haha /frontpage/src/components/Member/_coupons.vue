<template lang="html">
  <div class="coupons">
    <div class="title">{{title}}</div>
    <div class="coupons-box">
      <slot v-if="!!data"></slot>
    </div>
    <div class="nouse">
      <div class="btn" @click="btnClick">{{btnTitle}}</div>
    </div>
  </div>
</template>

<script>
export default {
  props:{
    title:{
      type: String,
      default: '可用优惠券'
    },
    btnTitle:{
      type: String,
      default: '不使用优惠券'
    },
    data:{
      type: Array,
      default: null
    }
  },
  methods:{
    closed(){
      this.$emit('closedPopLayer');
    },
    btnClick(){
      this.$emit('btnClick');
      this.closed();
    }
  }
}
</script>

<style lang="less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.coupons{
  background: #fafafa;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: @z-1000;
  width: 90%;
  border-radius: 5px;
  overflow: hidden;
  font-size: 14px;
  .title{
    background: #fff;
    line-height: 45px;
    text-align: center;
    font-size: 14px;
  }
  .coupons-box{
    min-height: 130px;
    max-height: 220px;
    overflow-y: auto;
    box-sizing: border-box;
    padding: 0 10px;
  }
  .nouse{
    padding: 10px;
    background: #fff;
    .px-top();
    .btn{
      display: block;
      width: 100%;
      border: 1px solid #000;
      line-height: 40px;
      font-size: 12px;
      font-weight: 500;
    }
  }
}

</style>
