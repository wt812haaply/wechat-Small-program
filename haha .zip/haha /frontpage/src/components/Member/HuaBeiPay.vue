<template>
  <div class="huabeipay">
    <go-back></go-back>
    <div class="wrapper">
      <div class="swiper-box" v-if="cardDetailList">
        <swiper :options="swiperOption" ref="mySwiper" @slideChangeTransitionEnd="getSwiperIndex">
          <swiper-slide v-for="(slider, index) of cardDetailList" :key="index">
            <div class="card-content">
              <img :src="slider.cardImage">
            </div>
          </swiper-slide>
        </swiper>
      </div>
      <div class="content" v-if="cardDetailList">
        <div class="message">
          <div class="item">
            <p>{{ cardDetailList[currentIndex].payName }}</p>
            <span>¥{{ Number(cardDetailList[currentIndex].payOriginal)}}</span>
          </div>

          <div class="item" v-for="(item,index) of cardDetailList[currentIndex].payReductionInfos">
            <p>{{item.reductionName}}</p>
            <span class="add">-¥{{item.reductionAmount}}</span>
          </div>

          <div class="item" @click="couponsLayerOpen">
            <p>优惠券</p>
            <span class="add gray coupon" v-if="JSON.stringify(couponsActive) == '[]'">没有可用优惠券哦<i class="icon yi23iconfont icon-right"></i></span>
            <span class="gray" v-if="nocoupons">不使用优惠券</span>
            <template v-if="couponsActive != null && JSON.stringify(couponsActive) != '[]' && !nocoupons">
              <span class="coupon" v-if="couponType(couponsActive.couponType)">-¥{{couponsActive.value}}</span>
              <span class="coupon" v-else>{{couponsActive.value * 10}}折</span>
            </template>
          </div>

          <div class="item cash">
            <p>实际支付</p>
            <span class="cash-text cash-color">¥{{total}}</span>
          </div>
        </div>

        <div class="deposit">
          <h6>¥300押金(仅冻结花呗额度，无须支付)</h6>
          <p v-for="item of (cardDetailList[currentIndex].cardDesc && cardDetailList[currentIndex].cardDesc.split('\n'))">{{item}}</p >
          <p>购买即视为已阅读并同意<span @click="toAgreen" style="text-decoration:underline">《用户服务协议》</span></p>
        </div>

      </div>
    </div>

    <div class="footer" @click="createdPay" v-if="cardDetailList">
      <div class="btn">立即成为会员</div>
    </div>

    <pop-up-layer v-if="couponsLayerShow">
      <Coupons
        @btnClick="unUseCoupons"
        @closedPopLayer="couponsLayerClosed"
        :data="couponsList"
        >
        <ul class="coupons-wrapper">
          <li class="coupons-item" v-for="(item, index) of couponsList" @click="choiceCoupon(item)">
            <div class="dec">
              <p>{{item.couponTitle}}</p>
              <span>{{item.startDate | YYYY_MM_DD }}-{{item.expDate | YYYY_MM_DD }}</span>
            </div>

            <div class="money type_a" v-if="couponType(item.couponType)">
              <p><i>¥</i>{{item.value}}</p>
            </div>
            <div class="money type_b" v-else>
              <p>{{item.value * 10}}<i>折</i></p>
            </div>
          </li>
        </ul>
      </Coupons>
    </pop-up-layer>

    <yi23Toast v-model="toastMsg"></yi23Toast>

  </div>
</template>

<script type="text/ecmascript-6">
import GoBack from "base/GoBack";
import PopUpLayer from "base/PopUpLayer";
import Coupons from "components/Member/_coupons";
import {
  subscribePayment,
  subHuabei,
  subSubscribe,
  paymentOrder
} from "api/member";
import { ERR_OK, COUPON_TYPE_JE } from "api/const";
import { toastMixin, couponMixin } from "common/js/mixin";

export default {
  mixins: [toastMixin, couponMixin],
  data() {
    return {
      swiperOption: {
        effect: "coverflow",
        slidesPerView: "1.2",
        centeredSlides: true,
        spaceBetween: 10,
        coverflowEffect: {
          rotate: 0,
          stretch: 0,
          depth: 50,
          modifier: -5,
          slideShadows: false
        }
      },
      cardDetailList: null,
      currentIndex: 0,
      iscoupon: null,
      decImage: [
        "https://tu.95vintage.com/web_source/Home/Common/images/subscribePaymentHB/baoyue-2.jpg?0919",
        "https://tu.95vintage.com/web_source/Home/Common/images/subscribePaymentHB/baoyue-1.jpg?0919"
      ],
    };
  },
  created() {
    let _t = this;
    _t._subscribePayment();
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.swiper;
    },
    total() {
      let slider = this.cardDetailList;
      let [paycost, total = paycost] = [slider[this.currentIndex].payOriginal];
      let extraReduce = 0; //减免
      let payReductionInfos = slider[this.currentIndex].payReductionInfos;

      if (payReductionInfos.length > 0) {
        for (let i = 0, item; (item = payReductionInfos[i++]); ) {
          extraReduce += item.reductionAmount;
        }
      }

      let couponsActive = this.couponsActive;
      if (
        this.nocoupons == false &&
        couponsActive != null &&
        JSON.stringify(couponsActive) != "{}"
      ) {
        if (couponsActive.couponType == 1) {
          total = paycost - couponsActive.value;
        } else if (couponsActive.couponType == 2) {
          total = paycost * couponsActive.value;
        }
      }

      total = parseInt(total - extraReduce);

      return total >= 0 ? total : 0;
    },

  },
  methods: {
    toAgreen() {
      this.$router.push({
        path: "/Others/payment_huabei_agree"
      });
    },
    createdPay(){
      try{
        adhoc('track', 'BecomeMember_Click', 1)
      }catch (e){
        console.log(e)
      }
      let depositWaived = this.cardDetailList[this.currentIndex].depositWaived;
      if(depositWaived){
        this.paySwitch();
      }else{
        this._subHuabei();
      }
    },
    _subHuabei() {
      //花呗预授权 => code:200 链接跳转授权或者JSBridge授权 => 发起支付,判断是否为连续包月
      let _t = this;
      let couponId = this.couponsActiveId || 0;
      let payType = "ALI_AUTH_FREEZE";
      let cardTemplateId = this.cardDetailList[this.currentIndex].templateId;
      let depositWaived = this.cardDetailList[this.currentIndex].depositWaived;
      console.log(this.cardDetailList);
      let subType = 2;

      paymentOrder({ couponId, payType, cardTemplateId, subType }).then(res => {
        console.log(res);
        if (res.code == 102) {
          //102
          window.location.href = res.data.freezeLink;
        } else if (res.code == 103) {
          //103
          AlipayJSBridge.call("tradePay", { orderStr: res.data }, function(
            result
          ) {
            if (result.resultCode == "9000" || result.resultCode == 9000) {
              //正常发起支付
              _t.paySwitch();
            }else{
              console.log(result);
            }
          });
        } else if (res.code == 110) {
          //正常发起支付
          this.paySwitch();
        } else {
          this.setToastMsg(res.msg);
        }
      });
    },
    paySwitch() {
      let params = this.getParams();

      let cardTemplateId = this.cardDetailList[this.currentIndex].templateId;

      if (cardTemplateId != 4) {
        let success = "MemberPaySuccess";
        //发起常规支付
        window.location.href = `/yi23/Home/Pay/payment?params=${encodeURIComponent(
          JSON.stringify(params)
        )}&success=${success}&redirect=${encodeURIComponent(
          this.$route.fullPath
        )}`;
      } else {
        params["payType"] = "ALI_CONTRACT_BINDING"; //发起连续包月
        let success = "ContractResultSuccess";

        window.location.href = `/yi23/Home/Pay/payment?params=${encodeURIComponent(
          JSON.stringify(params)
        )}&success=${success}&redirect=${encodeURIComponent(
          this.$route.fullPath
        )}`;
      }
    },
    getParams() {
      let cardTemplateId = this.cardDetailList[this.currentIndex].templateId;
      let couponId = this.couponsActiveId || 0;
      const params = {
        couponId,
        cardTemplateId
      };
      return params;
    },
    getSwiperIndex() {
      this.currentIndex = this.swiper.activeIndex;
    },
    _subscribePayment() {
      subscribePayment().then(res => {
        if (res.code == ERR_OK) {
          let data = res.data;
          this.cardDetailList = data.paydetail;
          this.couponsList = data.couponlist;
          this.couponsActive = data.activecoupon;
          this.iscoupon = data.iscoupon;
        } else {
          this.setToastMsg(res.msg);
        }
      });
    },

  },
  components: {
    GoBack,
    PopUpLayer,
    Coupons
  }
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.gray {
  color: #ccc;
}
.cash-color {
  color: #ff544b;
}
.huabeipay {
  display: flex;
  flex-direction: column;
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  font-family: "PingFang SC";
  font-weight: 500;
  height: 100%;
  background: #fafafa;
  .wrapper {
    flex: 1;
    overflow-y: auto;
    .swiper-box {
      .card-content {
        width: 100%;
        padding: 30px 0 30px 0;
        img {
          display: block;
          width: 100%;
        }
      }
    }
    .content {
      position: relative;
      z-index: 5;
      width: 100%;
      box-sizing: border-box;
      padding: 16px;
      margin-top: -30px;
      .message {
        width: 100%;
        background: #fff;
        box-sizing: border-box;
        padding: 20px;
        .item {
          .box();
          .box-center();
          font-weight: 500;
          color: #111;
          font-size: 14px;
          &.cash {
            box-sizing: border-box;
            height: 34px;
            padding-top: 10px;
            .px-top();
            margin-top: 10px;
          }
          .coupon {
            vertical-align: middle;
          }
          p {
            -webkit-box-flex: 1;
            height: 34px;
            line-height: 34px;
            font-weight: 300;
          }
          span {
            display: block;
            line-height: 34px;
            i {
              font-size: 13px;
              font-weight: 600;
            }
            &.cash-text {
              font-size: 17px;
              font-weight: 500;
            }
          }
        }
      }
      .deposit {
        background: #fff;
        padding: 16px 20px;
        margin-top: 10px;
        h6 {
          line-height: 31px;
          font-weight: 300;
          color: #333;
        }
        p {
          color: #999;
          line-height: 21px;
          font-size: 10px;
          strong {
            color: #000;
          }
        }
      }
      .description {
        margin-top: 30px;
        .item {
          width: 100%;
          img {
            display: block;
            width: 100%;
          }
        }
      }
    }
  }
  .footer {
    padding: 20px 17px;
    background: #fafafa;
    .btn {
      width: 100%;
      height: 48px;
      line-height: 48px;
      color: #fff;
      background: #ff544b;
      font-size: 14px;
      font-weight: 700;
    }
  }
}
.couponsShow();
</style>
