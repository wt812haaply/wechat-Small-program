<template>
  <div class="paySuccess">
    <div class="success"  v-if="status == 'T'">
      <img src="https://yimg.yi23.net/webimg/20180420/frontpage/suceed.png" alt="">
      <h2>支付成功!</h2>
      <p>会员期可<i>随时暂停</i>,你的会员期你做主</p>
      <div class="btn" @click="toProduct">立即开启新衣箱</div>
    </div>
    <div class="fail" v-if="status == 'F'">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0516/paycancel.png">
      <h2>支付取消</h2>
      <p>出于某些原因，支付未能完成。请稍候再次尝试</p>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return{
      status: null,
    }
  },
  created(){
    this.setStatus();
  },
  methods:{
    setStatus(){
      this.status = this.$route.query.is_success || this.$route.params.is_success
    },
    toProduct(){
      this.$router.replace({
        path:'/Subscribe/pdtListPage'
      })
    }
  }
}
</script>

<style lang="less" scoped>
@import '~common/less/mixin.less';
@import '~common/less/variable.less';
.paySuccess{
    width: 100%;
    height: 100%;
    background: #fff;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    .success,.fail{
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 30%;
    }
    .success,.fail{
      img{
        width: 40%;
      }
      h2{
        font-size: 20px;
        margin-bottom: 14px;
      }
      p{
        margin-bottom:21px;
        line-height: 21px;
        font-size: 14px;
        color:#666;
        i{
          font-style: normal;
          color:@color-text;
        }
      }
      .btn{
        width: 60%;
        height: 44px;
        line-height: 44px;
        padding: 0;
        background: @color-text;
        font-size: 14px;
        font-weight: @font-weight-m;
        color: #fff;
      }
    }
    .fail{
      padding-top: 0;
      img{
        width: 100%;
      }
      h2{
        margin-top: 36px;
      }
      p{
        width: 70%;
        text-align: center;
      }
    }
  }
</style>
