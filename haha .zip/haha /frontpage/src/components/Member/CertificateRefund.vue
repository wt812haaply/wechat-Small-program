<template>
  <div class="certificate">
    <go-back></go-back>
    <div class="wrapper">
      <div class="inner-box">
        <div class="inner">
          <h2>会员到期后可取消信用免押借还特权</h2>
          <p>衣二三会员期内，只需要归还手中衣箱，你就可以下单一个新的衣箱哦。下单随心换穿。如有疑问，请致电<i>400-650-4580</i></p>
          <button type="submit" class="btn">没有进行的借还信息</button>
        </div>
      </div>
      <div class="footer"><p>www.yi23.net</p></div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import GoBack from 'base/GoBack';

export default {

  components:{
    GoBack
  }

}

</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.certificate {
  display: flex;
  flex-direction: column;
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  background: #fff;
  min-height: 100%;
  .wrapper{
    flex: 1;
    background: #fff url(https://tu.95vintage.com/web_source/Home/Common/images/activity-end-bj.jpg) 0 -44px no-repeat;
    background-size: cover;
    display: flex;
    flex-direction: column;
    .inner-box{
      flex:1;
      position: relative;
      .inner{
        width: 70%;
        position: absolute;
        left: 50%;
        top:50%;
        transform: translate(-50%,-50%);
        h2{
          font-size: 16px;
          line-height: 24px;
          padding: 20px 0 10px 0;
          text-align: center;
          font-weight: 600;
        }
        p{
          text-align: left;
          margin-top: 20px;
          padding: 0px;
          color: #666;
          display: block;
          line-height: 21px;
          font-size: 14px;
          i{
            font-style: normal;
            color:@color-text;
            font-size: 14px;
            font-family: "PingFangSC";
          }
        }
        .btn{
          width: 100%;
          height: 44px;
          font-size: 14px;
          margin-top: 50px;
          color: #fff;
        }
      }
    }
    .footer{
      padding-bottom: 10px;
      text-align: center;
      color: rgba(0,0,0,.3);
      font-size: 12px;
    }
  }
}
</style>
