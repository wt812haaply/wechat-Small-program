<template lang="html">

  <pop-up-layer v-if="cancelLayerShow">
    <div class="cancel-pannel">
       <div class="zmxy-logo"><img src="https://yimg.yi23.net/webimg/20180420/frontpage//zmxy-logo.png"></div>
       <h3>取消开通芝麻信用免押借还吗？</h3>
       <p class="quxiao-zmxy-p1">取消开通芝麻信用免押借还服务后，你在<br>购买包月会员时需要支付¥300押金。</p>
       <div class="button-group">
         <span class="tip_btn_no" @click="closed">暂时不用</span>
         <span class="tip_btn_yes" @click="_postcancelZMXY">立即取消</span>
       </div>
    </div>
  </pop-up-layer>

</template>

<script>
import PopUpLayer from 'base/PopUpLayer';
import { cancelCreditLife } from 'api/member';

export default {
  props:{
    cancelLayerShow:{
      type: Boolean,
      default: false
    }
  },
  methods:{
    closed(){
      this.$emit('cancelLayerClosed');
    },
    open(){
      this.$emit('cancelLayerOpen');
    },
    _postcancelZMXY(){
      cancelCreditLife().then((res)=>{
        let code = res.code;
        if(code == 200){
          window.location.reload();
        }else{
          this.closed();
          alert(res.msg);
        }
      })
    }
  },
  components:{
    PopUpLayer
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";

.cancel-pannel{
  background: #fff;
  width: 85%;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: @z-1000;
  border-radius: 2px;
  overflow: hidden;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  padding: 30px 0;
  .zmxy-logo{
    width: 60px;
    margin-bottom: 24px;
    img{
      display: block;
      width: 100%;
    }
  }
  h3{
    font-size: 16px;
    margin-bottom: 3.1%;
    color: #333;
    font-weight: 600;
  }
  p{
    font-size: 12px;
    margin-top: 10px;
    margin-bottom: 24px;
    color: #666;
    line-height: 21px;
    letter-spacing: 0.3px;
    text-align: center;
  }
  .button-group{
    width: 100%;
    display: flex;
    span{
      display: block;
      width: 50%;
      text-align: center;
      font-size: 14px;
      color: #999999;
      &:nth-child(1){
        border-right: 1px solid #ccc;
      }
    }
    .tip_btn_yes {
      color: #CDAB6A;
    }
  }
}

</style>
