<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>

    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="postDeposit">
        <div class="postDepositTitle" v-if="box && box.depositInfo ">
          <h2 class="font-m font-roboto-b">衣物贵重, 需交纳¥300押金哦</h2>
          <p class="font-r">{{ box.depositInfo.contractDepositTopTile}}</p>
        </div>

        <div class="lastTime">
          <div class="lastTimeCont">
            <span class="lastTimeSemicircle"></span>
            <div class="let">
              <div class="CountDown" >
                <div class="timer font-roboto-b">{{minute}}:{{second}}</div>
                <svg class="mSVG"  style="transform:rotate(90deg) rotateY(180deg);" ref="widthA">
                  <circle cx="50%" cy="50%" r="45%" stroke-width="5%" stroke="#f7f7f7" fill="none"></circle>
                  <circle cx="50%" cy="50%" r="45%" stroke-width="5%" stroke="#ff544b" fill="none" :stroke-dasharray="dasharray"></circle>
                </svg>
              </div>
              <div class="letCon">
                <ul class="proList" v-if="box && box.cart && box.cart.length > 3">
                  <li v-for="item in box.cart" :key="item.boxId">
                    <img :src="item.thumbPic" alt="">
                  </li>
                </ul>
                <ul class="proList cen"  v-else-if="box && box.cart">
                  <li v-for="item in box.cart" :key="item.boxId">
                    <img :src="item.thumbPic" alt="">
                  </li>
                </ul>
                <div class="TotalPrice" v-if="box">衣箱总价值<i class="font-roboto-b">￥{{box.allPrice}}</i> ,请在<i style="color: #afafaf" class="font-roboto-b">5</i>分钟内交纳押金</div>
              </div>
            </div>
          </div>
        </div>
      <!--
      continuityPay:'连续包月',
      DepositPay:'使用花呗额度免押',
      huabeiPay:'使用花呗额度免押',
      aliPay:'去支付',
      wechatPay:'去支付',

      1 ios,
      2 android,
      3 wechart,
      4 alipay,
      0 其他,默认返回web
      -->
        <div class="postDepositPayList">
          <h2 class="font-m">选择押金方式</h2>
          <div class="DepositPayList" v-if="box && box.depositInfo && box.depositInfo.ableContractDeposit && box.depositInfo.ableContractDeposit == '1' ">
            <input id="radio0" name="radio" type="radio" :value="continuityPay" v-model="DepositPay" />
            <label for="radio0">
              <div class="dIiem">
                <div class="payLogo posiUpgrade">
                  <img src="https://yimg.yi23.net/webimg/web/images/2018/0813/upgradeLogo.png" alt="">
                </div>
                <div class="payDesc">
                  <p class="p1 font-m" v-if="box && box.depositInfo.contractDepositPopContent">{{ box.depositInfo.contractDepositName}} <i class="queryDe" @click="openContinuityContent">{{ box.depositInfo.contractDepositTips}}</i></p>
                  <p class="p1 font-m" v-else>{{ box.depositInfo.contractDepositName}} <i>{{ box.depositInfo.contractDepositTips}}</i></p>
                  <p class="p2">{{box.depositInfo.contractDepositDesc}}</p>
                </div>
              </div>
            </label>
          </div>

          <div class="DepositPayList" v-if="this.huabeiPay">
            <input id="radio1" name="radio" type="radio" :value="huabeiPay" v-model="DepositPay" />
            <label for="radio1">
              <div class="dIiem">
                <div class="payLogo posiHuabei">
                  <img src="https://yimg.yi23.net/webimg/web/images/2018/0813/huabeiLogo.png" alt="">
                </div>
                <div class="payDesc" v-if="box && box.depositInfo">
                  <p class="p1 font-m">花呗额度当押金
                    <template v-if="box && box.depositInfo.contractDepositTips"></template>
                    <i v-else>推荐</i>
                  </p>
                  <p class="p2">¥300预授权 (仅冻结花呗额度，无需现金支付）</p>
                </div>
              </div>
            </label>
          </div>


          <div class="DepositPayList" v-if="this.aliPay">
            <input id="radio2" name="radio" type="radio" :value="aliPay" v-model="DepositPay" />
            <label for="radio2">
              <div class="dIiem">
                <div class="payLogo">
                  <img src="https://yimg.yi23.net/webimg/web/images/2018/0813/alipayLogo.png" alt="">
                </div>
                <div class="payDesc">
                  <p class="p1 font-m">现金押金¥300</p>
                </div>
              </div>
            </label>
          </div>

          <!--微信支付-->
          <!--<div class="DepositPayList" v-if="clientType > 0 && clientType < 4">-->
            <!--<input id="radio3" name="radio" type="radio" :value="wechatPay" v-model="DepositPay"/>-->
            <!--<label for="radio3">-->
              <!--<div class="dIiem">-->
                <!--<div class="payLogo">-->
                  <!--<img src="https://yimg.yi23.net/webimg/web/images/2018/0813/wechatLogo.png" alt="">-->
                <!--</div>-->
                <!--<div class="payDesc">-->
                  <!--<p class="p1 font-r">微信现金¥300</p>-->
                  <!--<p class="p2">会员期后随时退</p>-->
                <!--</div>-->
              <!--</div>-->
            <!--</label>-->
          <!--</div>-->
        </div>
      </div>
    </div>

    <!--放弃支付-->
    <yi23Dialog :open="abjurationOpen" :dialogSm='dialogSm' :hasCannel="true" >
      <div slot="header" class="yu"><i>放弃交纳押金？</i></div>
      <div slot="body">
        <div class="yi23-dialog__bd" style="padding:0 12px 0">放弃后衣物不再为您保留哦。会员期内押金仅需交一次，会员到期后随时可申请退还。</div>
      </div>
      <div slot="btnCannel" @click="abjurationPay">放弃交纳</div>
      <div slot="btnOk" @click="_pay">继续交纳</div>
    </yi23Dialog>

    <!--超时提示-->
    <yi23Dialog :open="overtimeOpen" :dialogSm='dialogSm' :hasCannel="false" >
      <div slot="header" class="yu"><i>已超时，请重新提交</i></div>
      <div slot="body">
        <div class="yi23-dialog__bd" style="padding:0 12px 0">喜欢的衣服就要被抢走了，赶紧重新提交吧。</div>
      </div>
      <div slot="btnOk" @click="overtimeClose">好的</div>
    </yi23Dialog>

    <!--卡信息描述-->
    <yi23Dialog @dialogClose="dialogOneHundredClose" :open="continuity"  v-if="box && box.depositInfo && box.depositInfo.contractDepositPopContent">
      <div slot="header" style="color: #222;">连续包月续费优惠</div>
      <div slot="body">
        <div class="yi23-dialog__bd" style="padding:0">{{ box.depositInfo.contractDepositPopContent}}</div>
      </div>
      <div slot="btnOk">知道了</div>
    </yi23Dialog>

    <yi23Toast v-model="toastMsg"></yi23Toast>

    <!-- 判断非支付宝环境 提示去app下单 -->
    <yi23Dialog @dialogClose="dialogDownAppClose" :open="dialogDownAppOpen" >
      <div slot="header" style="color: #222;">押金提示</div>
      <div slot="body">
        <div class="yi23-dialog__bd" style="padding:0"> 小仙女，衣物贵重需要交纳押金，APP下单可以申请免押哦 </div>
      </div>
      <div slot="btnOk">知道了</div>
    </yi23Dialog>

    <div class="yclosetFooter">
      <div class="DepositFooterBtn">
        <div class="btnA" @click="abjuration">放弃交纳</div>
        <div class="btnB" @click="goDepositPay">{{ DepositPay }}</div>
      </div>
    </div>
  </div>
</template>
<script>
  import payCash from '@/mixins/payCash';
  import { mapGetters } from 'vuex'
  import goBack from 'base/GoBack'
  import box from '@/api/box'
  import region from '@/common/js/region';

    export default {
    name:'',
    mixins: [payCash],
      data () {
      return{
        toastMsg:'',
        dasharray:'',
        abjurationOpen: false,
        overtimeOpen: false,
        dialogSm: true,
        hasCannel: true,
        continuityPay:'去免押',
        DepositPay:'连续包月',
        huabeiPay:'使用花呗额度免押',
        aliPay:'去支付',
        wechatPay:'去支付',
        clientType : this.$clientType,
        stopTimer:true,
        countdown:'',
        minutes:0,
        seconds:0,
        continuity:false,
        dialogDownAppOpen:false
      }
    },

    // 组件
    components:{
      goBack
    },

    // 组件传值
    props:[],

    // 事件方法
    methods: {
      dialogDownAppClose() {
        this.dialogDownAppOpen = false
      },
      openContinuityContent() {
        this.continuity = true
      },
      dialogOneHundredClose() {
        this.continuity = false
      },
      getLockStock() {
        let regionId = region.getLocalRegion().regionId || 52;
        box.lockStock(regionId).then((res)=>{
          if( res.code == 200 ){

            this.doCountdown(res)
          } else {
            this.toastMsg=res.msg
          }
        })
      },
      unlockStock(){
        box.unlockStock().then((res)=>{
          //console.log(res.code)
        })
      },

      doCountdown(res){
        let servcerTime = res.data.servcerTime
        let stockLockExpTime = res.data.stockLockExpTime
        //console.log(servcerTime + '1111')
        //console.log(stockLockExpTime + '1111')
        let countdown = parseInt((stockLockExpTime - servcerTime)/1000);
        let seconds= countdown%60;
        let minutes=(countdown-countdown%60)/60
        this.seconds=seconds
        this.minutes=minutes
        this.numberTime()
        this.dasharrayChange( 332,  332 - countdown);
      },

      num(n){
        return n<10 ? "0" + n : "" + n
      },
      numberTime(){
        this.$nextTick(()=>{
          let _this = this;
          let time = setInterval(() => {
            if (_this.seconds == 0 && _this.minutes != 0) {
              _this.seconds = 59;
              _this.minutes -= 1;
            }else if(_this.minutes == 0 && _this.seconds == 0){
              _this.seconds = 0;
              clearInterval(time);
            }else{
              _this.seconds -= 1
            }
          },1000);
        })
      },


      // 倒计时进度条
      dasharrayChange(time,thistime){
        let _t = this;
        this.$nextTick(()=>{
          let _l = _t.$refs.widthA.clientWidth * Math.PI;
          let pice = _l / time;
          let thistimetest = time - thistime;
          let thisTimeL = thistime*_l/time;
            let timers = setInterval( () =>{
              if(thistimetest > 0){
                thisTimeL += pice;
                _t.dasharray = `${_l - thisTimeL} ${thisTimeL} `;
                thistimetest--
                if(!this.stopTimer){
                  clearInterval(timers)
                }
              }else{
                clearInterval(timers)
                this.overtime()
            }
          },1000)

        })
      },
      timer(){

      },

      goBackBox(){
        this.$router.push({
          path:'/ClothBox/box',
        })
      },
      goDepositPay(){
        //'1': 'ALI_WEB',
        // '2': 'WECHAT_WEB',
        // '3': 'ALI_AUTH_FREEZE'
        //  DepositPay:'使用花呗额度免押',
        //  huabeiPay:'使用花呗额度免押',
        // aliPay:'使用支付宝支付',
        // wechatPay:'使用微信支付',

        /*
        continuityPay:'连续包月',
        DepositPay:'使用花呗额度免押',
        huabeiPay:'使用花呗额度免押',
        aliPay:'去支付',
        wechatPay:'去支付',
        */
        // 1 ios, 2 android, 3 wechart, 4 alipay, 0 web
        let clientType = this.$clientType;
        if(clientType != 4){
            this.dialogDownAppOpen = true
        } else{
          if( this.DepositPay == this.continuityPay){
            this._creatDepositPayment({params:{ payType:'ALI_CONTRACT_BINDING'},success:'/ClothBox/box'})
            //alert('连续包月')
          } else if(this.DepositPay == this.huabeiPay){
            this._creatDepositPayment({params:{ payType:'ALI_AUTH_FREEZE'},success:'/ClothBox/box'})
          //alert('花呗')
          } else if(this.DepositPay == this.aliPay ){
            this._creatDepositPayment({params:{ payType:'ALI_WEB'},success:'/ClothBox/box'})
          //alert('支付宝')
          }
        }
      },

      /*
      continuityPay:'连续包月',
      DepositPay:'使用花呗额度免押',
      huabeiPay:'使用花呗额度免押',
      aliPay:'去支付',
      wechatPay:'去支付',

      1 ios,
      2 android,
      3 wechart,
      4 alipay,
      0 其他,默认返回web
      */
      DepositPayList(){
        let clientType = this.$clientType;
        let ableContractDeposit = this.box.depositInfo.ableContractDeposit
        if(clientType == 4){
          if(ableContractDeposit == '1') {
            this.DepositPay = this.continuityPay
            console.log(this.DepositPay,'?')
          } else{
            this.DepositPay = this.huabeiPay
          }
        } else{
          this.dialogDownAppOpen = true
          this.DepositPay = this.aliPay
        }
      },

      abjuration(){
        this.abjurationOpen = true
      },

      // 放弃支付
      abjurationPay(){
        this.abjurationOpen = false
        this.stopTimer = false
        this.unlockStock()
        this.goBackBox()
      },
      _pay(){
        this.abjurationOpen = false
      },

      // 超时
      overtime(){
        this.overtimeOpen = true
      },
      overtimeClose(){
        this.overtimeOpen = false
        this.goBackBox()
      },
    },

    // 计算属性
    computed: {
      ...mapGetters({
        box:'box'
      }),
      second(){
        return this.num(this.seconds)
      },
      minute(){
        return this.num(this.minutes)
      }
    },

    // 侦听属性
    watch:{
      box(){
        this.DepositPayList()
      },
      second:{
        handler(newVal){
          this.num(newVal)
        }
      },
      minute:{
        handler(newVal){
          this.num(newVal)
        }
      },

    },

    //一进页面先执行
    mounted(){
    },

    // 接口数据
    created(){
      this.getLockStock()
      this.$store.dispatch('getClothes')
    },
  }
</script>

<style scoped lang="less">
.posiUpgrade,.posiHuabei{
  position: relative;
  top: -12 * @unit;
}
.posiHuabei{
  top: -3px;
}
.queryDe{
  width: 12 * @unit;
  height: 12 * @unit;
  position:relative;
  padding-right: 18 * @unit !important;
  &:after{
    content: '';
    width: 12 * @unit;
    height: 12 * @unit;
    position:absolute;
    border-radius: 50%;
    top: 50%;
    right: 4 * @unit;
    transform: translateY(-50%);
    background:url("//yimg.yi23.net/webimg/web/images/2018/0813/queryDeposit.png");
    background-size: 100% 100%;
  }
}

  .yclosetHeader{
    height: auto;
  }

  .yclosetFooter{
    height: 48 * @unit;
    display: flex;
    justify-content:center;
    align-items:center;
    border-top:1px #eee solid;
    z-index: 3;
    position: relative;
  }

  .yclosetContainer{
    background: #fafafa;
  }

  .postDeposit{
    display: flex;
    justify-content:center;
    width:100%;
    flex-wrap: wrap;
  }
  .postDepositTitle{
    padding:24 * @unit 0 0 0;
    text-align: center;
    flex-wrap: wrap;
    width:100%;
    h2{
      font-size: 18 * @unit;
      color:rgb(17, 17, 17);
      margin-bottom: 10 * @unit;
    }
    p{
      font-size: 12 * @unit;
      line-height: 1.58;
      color:rgb(153,153,153);
      padding: 0 35 * @unit
    }
  }
  .postDepositPayList{
    margin:0 20 * @unit;
    width:100%;
    h2{
      font-size: 16 * @unit;
      color:rgb(17,17,17);
      margin-bottom: 15 * @unit;

    }
  }

  .DepositPayList {
    background-color: #fff;
    display: block;
    position: relative;
    z-index: 0;
    padding-bottom:5px;
    border-bottom: solid 1px rgba(0, 0, 0, 0.04);
  }

  .DepositPayList:last-of-type{
    border-bottom:none;
  }
  .DepositPayList label{
    /*padding: 10px 0;*/
    width: 100%;
    display: block;
    text-align: left;
    color: #3C454C;
    cursor: pointer;
    position: relative;
    z-index: 1;
    /*-webkit-transition: color 200ms ease-in;*/
    /*transition: color 200ms ease-in;*/
    overflow: hidden;
  }
  .DepositPayList label:before {
    width: 10 * @unit;
    height: 10 * @unit;
    border-radius: 50%;
    content: '';
    /*background-color: #5562eb;*/
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%) scale3d(1, 1, 1);
    transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
    opacity: 0;
    z-index: -1;
  }
  .DepositPayList label:after {
    width: 22 * @unit;
    height: 22 * @unit;
    content: '';
    border: solid 1px rgba(0, 0, 0, 0.1);
    background-color:transparent;
    background-repeat: no-repeat;
    /*background-position: 2px 3px;*/
    border-radius: 50%;
    z-index: 1;
    position: absolute;
    right: 0px;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    cursor: pointer;
    /*-webkit-transition: all 200ms ease-in;*/
    /*transition: all 200ms ease-in;*/
  }

  .DepositPayList input:checked ~ label:before {
    -webkit-transform: translate(-50%, -50%) scale3d(56, 56, 1);
    transform: translate(-50%, -50%) scale3d(56, 56, 1);
    opacity: 1;
  }
  .DepositPayList input:checked ~ label:after {
    background: #ff544b url("//yimg.yi23.net/webimg/web/images/2018/0817/dui.svg" ) 0 50% no-repeat;
    background-size: 100%;
    border-color: #ff544b;
  }
  .DepositPayList input {
    width: 22 * @unit;
    height:  22 * @unit;
    -webkit-box-ordinal-group: 2;
    -ms-flex-order: 1;
    order: 1;
    z-index: 1;
    position: absolute;
    right: 30 * @unit;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    cursor: pointer;
    visibility: hidden;
  }


  .dIiem{
    display: flex;
    width:100%;
    height: 72 * @unit;
    align-items: center;
    font-size:  12 * @unit;
    font-weight: 300;
    position: relative;
    top: 0;
  }

  .payLogo{
    width: 28 * @unit;
    height: 28 * @unit;
    margin-right: 12 * @unit;
    /*align-self:flex-start;*/
    /*align-items: center;*/
    /*margin-top: 17px;*/
    img{
      width:100%;
    }
  }

  .payDesc{
    height:auto;
    flex:1;
    /*background: #eee;*/
    padding-right: 35 * @unit;
    p{
      font-size: 12 * @unit;
    }
    p.p1{
      color:#111;
      line-height: 1.4;
      font-size: 14 * @unit;
      i{
        padding:2 * @unit 4 * @unit;
        background:#ffeceb;
        color:#ff544b;
        font-weight: 700;
        font-size: 11 * @unit;
        border-radius: 2 * @unit;
      }
    }
    p.p2{
      color:#afafaf;
      line-height: 1.4;
      font-weight: 400;
      margin-top: 6 * @unit;
    }
  }
  .DepositFooterBtn{
    width:100%;
    display: flex;
    height:48 * @unit;
    div.btnA{
      width:128 * @unit;
      line-height: 48 * @unit;
      text-align: center;
      background-color:#fff;
      font-size: 12 * @unit;
      font-weight: 400;
      color: #999;
    }
    div.btnB{
      flex:1;
      line-height: 48 * @unit;
      text-align: center;
      background-color:#ff544b;
      font-size: 14 * @unit;
      font-weight: 600;
      color: #fff;
    }
  }
  .lastTime{
    margin:50 * @unit 14 * @unit 40 * @unit 14 * @unit;
    width: 100%;
  }

  .lastTimeCont{
    width: 100%;
    background: #fff;
    position: relative;
    z-index: 1;
    border-radius: 5 * @unit;
    filter: drop-shadow(0 0 3px #efefef);
    display: flex;
    justify-content:center;
    align-items: center;
    flex-wrap: wrap;
  }
  .lastTimeSemicircle{
    width:91 * @unit;
    height:50 * @unit;
    background-color:#fff;
    display: flex;
    border-radius:50 * @unit 50 * @unit 0 0; /* 左上、右上、右下、左下 */
    position: relative;
    top: -35 * @unit;
  }
  .let{
    width: 100%;
    display:flex;
    justify-content:center;
    align-items:center;
  }
  .CountDown{
    width:73 * @unit;
    height:73 * @unit;
    border-radius: 50%;
    position: absolute;
    top:-25 * @unit;
    font-size:  18 * @unit;
    text-align: center;
    line-height: 73 * @unit;

    .timer{
      position: absolute;
      top: 0px;
      left: 0px;
      float: left;
      width:73 * @unit;
      height:73 * @unit;
      line-height: 73 * @unit;
      font-size: 18 * @unit;
    }
  }

  .letCon{
    width:300 * @unit;
    font-size: 12 * @unit;
  }

  .cen{
    justify-content:center;
  }
  ul.proList{
    overflow-x: scroll;
    overflow-y: hidden;
    display: flex;
    width: 300 * @unit;
    margin-top: 15 * @unit;
    > li{
      min-width:80 * @unit;
      height:96.8 * @unit;
      margin-right: 8 * @unit;
      display: flex;
      border:1px rgba(0,0,0,.05) solid;
      border-radius: 5 * @unit;

      img{
        width:80 * @unit;
      }
    }
    > li:last-of-type{
      margin-right: 0;
    }
  }

  .TotalPrice{
    text-align: center;
    padding:15 * @unit 0 30 * @unit 0;
    font-size: 12 * @unit;
    /*font-weight: 400;*/
    letter-spacing: 0.3px;
    color: #afafaf;
    i{
      color:#ff544b;
      font-size: 13 * @unit;
      font-weight: 500;
      letter-spacing: 0;
    }
  }
  .yu{
    text-align: left;
    padding:0 12 * @unit 0;
  }
  .yi23-dialog__sm .yi23-dialog__bd{
    padding:0;
    text-align: left;
    height: 44 * @unit;
    font-size: 12 * @unit;
    line-height: 1.83;
    letter-spacing: 0.2px;
    color: #666;
  }
  circle {
    transition: stroke-dasharray 1s;
  }
  .mSVG{
    width:100%;
    height:100%;
  }
  .dialog-slide-enter-active {
    animation: zoomIn1 0s;
  }
  .dialog-slide-leave-active {
    animation: zoomIn1 0s reverse;
  }
  .dialog-slide-enter-active .yi23-dialog {
    animation: zoomIn 0s;
  }
  .dialog-slide-leave-active .yi23-dialog{
    animation: zoomIn 0s reverse;
  }
</style>
