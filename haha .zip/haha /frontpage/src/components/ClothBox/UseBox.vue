<template>
  <section v-if="box">
      <div class="boxContent" >
        <div class="yclosetShade" v-show="tips.open" >
          <div class="boxTip" @click="closeTip">
            <i class="icon yi23iconfont icon-close"></i>
            <p class="cssarrow" v-html="tips.text"></p>
          </div>
        </div>
        <div class="tips">待发送</div>
        <div class="box hasClothes" v-if="box.cart" v-for="item in box.cart" :key="item.skuId">
            <div class="left" @click="toDetail(item.productId,item.path)">
                <div class="noneBox" v-if="item.stockNum==0">
                  <img src="https://tu.95vintage.com/web_source/Home/Common/images/que.svg">
                </div>
                <img :src="item.thumbPic">
            </div>
            <dl class="right">
              <dt class="blackColor">{{item.productName}}</dt>
              <dd>{{item.brandName}}</dd>
              <dd class="blackColor">{{item.size}}</dd>
              <i class="yi23iconfont icon-close" @click="delClothes(item.skuId,item.path)"></i>
            </dl>
        </div>
        <div class="box" v-if="emptyBoxNum" v-for="n in  emptyBoxNum"  @click="doSelect">
          +添加一件单品至衣箱
        </div>

    </div>
    <div class="btnBox">
      <div class="btn addBtn"  v-if="hasCoupone" @click="addBoxBtn" >
        新增一个衣位
      </div>
      <div class="btn" :class="{gray:box.cart.length==0}" v-if="box.cart.length!=0" @click="doSubmit">
        寄这个衣箱给我（{{box.cart.length}}/{{box.allNum}}）
      </div>

      <div class="btn" :class="{gray:box.cart.length==0}" v-else>
        寄这个衣箱给我（{{box.cart.length}}/{{box.allNum}}）
      </div>
    </div>
    <div class="boxList" v-if="box.boxesInUse">
      <div v-for="item in box.boxesInUse" :key="item.orderInfoId">
        <div class="cell-groups">
          <x-cell :label="item.addTime | YYYY_MM_DD" ><span>{{item.statusDesc}}</span></x-cell>
          <x-cell :is-link="true" v-if="item.courierInfo.acceptTime" :to="{ name:'expressInfoPage', query:{id:item.mailNo}}"><span >查看物流状态</span></x-cell>
        </div>
        <div class="box noneborder" v-for="info in item.detailInfo">
          <div class="left" >
            <img :src="info.thumbPic">
          </div>
          <dl class="right">
            <dt class="blackColor">{{info.productName}}</dt>
            <dd>{{info.brandName}}</dd>
            <dd class="blackColor">{{info.size}}</dd>

            <i class="yi23iconfont buybtn" v-if="info.isCanBuy==1" @click="buyClothes(info)">
              我要买
            </i>
            <i class="yi23iconfont buybtn" v-if="info.isCanBuy==0">
              已购买
            </i>
          </dl>
        </div>
        <div class="btnBox" v-if="item.appointmentStatus==0">
          <div class="btn" @click="linkUrl(0,item.orderInfoId)">
            送还这个衣箱
          </div>
        </div>
        <div class="btnBox" v-if="item.appointmentStatus==2">
          <div class="btn" @click="confirmBox(item.orderInfoId)">
            确认收货
          </div>
        </div>
        <div class="btnBox" v-if="item.appointmentStatus==1">
          <div class="btn" @click="linkUrl(1,item.orderInfoId)">
            查看预约
          </div>
        </div>
      </div>

    </div>
    <yi23Toast v-model="toastMsg"></yi23Toast>


    <yi23Dialog @dialogOk="dialogOk" @dialogClose="dialogClose" :open="dialogOpen"  :hasCannel="!!dialogInfo.btnCannel">
      <div slot="header" style="text-align: center">{{dialogInfo.title}}</div>
      <div slot="body">
        <div class="yi23-dialog__bd" style="text-align: center"> {{dialogInfo.msg}} </div>
      </div>
      <div slot="btnCannel">{{dialogInfo.btnCannel}}</div>
      <div slot="btnOk">{{dialogInfo.btnOk}}</div>
    </yi23Dialog>


    <!-- 判断非支付宝环境 提示去app下单 -->
    <yi23Dialog @dialogClose="dialogDownAppClose" :open="dialogDownAppOpen" >
      <div slot="header" style="color: #222;">押金提示</div>
      <div slot="body">
        <div class="yi23-dialog__bd" style="padding:0"> 小仙女，衣物贵重需要交纳押金，APP下单可以申请免押哦 </div>
      </div>
      <div slot="btnOk">知道了</div>
    </yi23Dialog>



    <div class="couponBox" v-if="showCoupon">
      <div class="content">
        <header>可用优惠券</header>
        <div class="couponList">
          <ul>
            <li v-for="item in box.coupon" :key="item.couponId" @click="useCoupon(item.couponId)">
              <div class="leftBox">
                <p class="title">{{item.couponTitle}}</p>
                <p>{{item.startDate}}-{{item.expDate}}</p>
              </div>
              <div class="rightBox">
                +<span>{{item.value}}</span>件
              </div>
            </li>
          </ul>

        </div>
        <div class="closeBtnBox">
          <div class="closeBtn" @click="closeBtn">不使用优惠券</div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
  import { mapGetters } from 'vuex'
  import XCell from '@/components/lib/cell/Cell';
  import box from '@/api/box'
  import store from "@/store"

  import region from '@/common/js/region';
  export default {
    name: "useBox",
    data () {
      return {
        isUseDeposit:'',
        toastMsg:'',
        // emptyBoxNum:'',
        showCoupon:false,
        tips:{
          open:'',
          text:'会员每次可以租1个衣箱 <br> 每箱至少有3个衣位',
        },
        dialogInfo:{
          title:'',
          btnCannel:'',
          msg:'',
          btnOk:''
        },
        dialogOpen:false,
        dialogDownAppOpen:false
      }
    },
    computed:{
      ...mapGetters({
        box:'box'
      }),
      emptyBoxNum () {
        let num = 0;
        if(this.box && this.box.cart){
          for(var k in this.box.cart){
            num += this.box.cart[k].boxSlot
          }
        }
        return this.box.allNum-num;
      },
      hasCoupone () {
//        if(this.box && this.box.boxMeta.extra_field==0 && this.box.boxComplete.list.length > 0){
          if(this.box && this.box.boxMeta.extraField==0 && this.box.boxMeta.addClothesCouponValue ){
            return true
          }else{
            return false
          }
      },
//      showAddBtn (){
//        if(this.box.box_status!= 1 && this.box.box_status!= 2){
//          return true
//        }else{
//          return false
//        }
//      }
    },
    methods:{
      dialogClose(){
        this.dialogOpen=false
      },
      dialogDownAppClose() {
        this.dialogDownAppOpen = false
      },
      dialogOk(){
        if(this.box.canUserOrder.reasonType==2){
          loadJs.init(function () {
            window.location.href = ysf.url();
          });
        }
      },

      getUseBoxLocalStorage(){
        let once = localStorage.getItem("userBoxTips")
        if(!once){
          localStorage.setItem("userBoxTips",1)
          this.tips.open = false
        }
        else {
          this.tips.open = true
        }
      },
      closeTip(){
        this.tips.open = false
        this.getUseBoxLocalStorage()
      },

      doSelect () {
        this.$router.push({
          name:'pdtListPage',
        })
      },
      buyClothes (info) {
        this.$router.push({
          name:'BuyPage',
          query:{
            skuId:info.skuId,
            detailId:info.detailId
          }
        })
      },
      addBoxBtn () {
        this.showCoupon=true;
      },
      useCoupon (couponId) {
        box.useCouponForAddClothes({cid:couponId}).then((res)=>{
          // console.log(res)
          if(res.data.code==200){
              this.$store.dispatch('getClothes')
          }else{
            this.toastMsg=res.data.msg
          }
          this.closeBtn()
        })
      },
      closeBtn () {
        this.showCoupon=false;
      },
      delClothes (skuId,path) {
        let query = {}
        if(path){
          query.path = path
        }
        box.newRemoveFromBox(skuId,query).then((res)=>{
          if(res.data.code==200){
            this.showCoupon=false;
            this.$store.dispatch('getClothes')
          }else {
            this.toastMsg=res.data.msg
          }
        })
      },
      toDetail (pid,path) {
        if(!pid){
          return;
        }
        let query = {pid:pid};
        if(path){
          query.path = path
        }
        this.$router.push({
          name:'pdtDetailPage',
          query:query
        })
      },

      goPostDeposit(){
        this.$router.push({
          name:'PostDeposit',
        })
      },


      sellOut(){
        let sellOut=[]
        sellOut= this.box.cart.filter(function (res) {
          if(res.stockNum==0){
            return res
          }
        })
        if(sellOut.length>0){
          return true
        }else{
          return false
        }
      },


      getLockStock() {
//        let regionObj = region.getLocalRegion();
//        let regionId = '52';
//        if( !regionObj ){
//          regionId = regionObj.regionId
//        }
        let regionId = region.getLocalRegion().regionId || 52;
        box.lockStock(regionId).then((res)=>{
          if( res.code == 200 ){
            this.goPostDeposit()
          } else {
            this.toastMsg=res.msg
          }
        })
      },


      notAvailable(){
        if(this.sellOut()){
          this.dialogInfo.title='衣箱包含不在架单品，无法下单'
          this.dialogInfo.btnCannel=''
          this.dialogInfo.btnOk='我知道了'
          this.dialogOpen=true
          return false
        }
        if(this.box.canUserOrder && this.box.canUserOrder.canUserOrder != 1){
          this.dialogInfo.msg = this.box.canUserOrder.reasonMessage
          this.dialogOpen=true
          if(this.box.canUserOrder.reasonType==2){
            this.dialogInfo.title='订单异常!'
            this.dialogInfo.btnCannel='我知道了'
            this.dialogInfo.btnOk='联系客服'
          }else{
            this.dialogInfo.title='暂时无法下单'
            this.dialogInfo.btnCannel=''
            this.dialogInfo.btnOk='我知道了'
          }
          return false
        }
        if(this.box.isValidUser==0 ){
          this.$router.push({
            path:'/Member/payPage',
          })
          return false;
        }

        else if( this.box.depositInfo.isUseDeposit == 1){
          if( this.$clientType == 4 ){
            this.getLockStock()
          } else {
            this.dialogDownAppOpen = true
          }
        }
        else if(this.box && this.box.cart.length>0){
          let items=this.box.cart.map(function (el) {
            return el.boxId
          })
          let isUseDeposit=this.box.depositInfo.isUseDeposit
          this.$router.push({
            name:'completeOrderInfo',
            query:{items:items.join(','),isUseDeposit:isUseDeposit}
          })
        }
      },

//
//      getUserInfoForToken(){
//        userInfoForToken().then((res)=>{
//          if(res.code==200){
//            if(res.data.isValidUser==0 ){
//              this.$router.push({
//                path:'/Member/payPage',
//              })
//              return false;
//            }
            // isUseDeposit int 0不需要交押金、 1需要交押金
//            else if( this.box.depositInfo.isUseDeposit == 1){
//              if( this.$clientType == 4 ){
//                this.getLockStock()
//              } else {
//                this.dialogDownAppOpen = true
//              }
//            }
//            else if(this.box && this.box.cart.length>0){
//              let items=this.box.cart.map(function (el) {
//                return el.boxId
//              })
//              let isUseDeposit=this.box.depositInfo.isUseDeposit
//              this.$router.push({
//                name:'completeOrderInfo',
//                query:{items:items.join(','),isUseDeposit:isUseDeposit}
//              })
//            }
//          }else{
//            this.toastMsg=res.msg
//          }
//        })
//      },

      doSubmit() {
        let is_success = this.$route.query.is_success
        if(is_success == 'T'){
          //console.log('T 下单地址页面')
          if(this.box && this.box.cart.length>0){
            let items=this.box.cart.map(function (el) {
              return el.boxId
            })
            let isUseDeposit=this.box.depositInfo.isUseDeposit
            this.$router.push({
              name:'completeOrderInfo',
              query:{items:items.join(','),isUseDeposit:isUseDeposit}
            })
          }
        } else if (is_success == 'F') {
          //console.log('F')
          this.notAvailable()
        } else {
          //console.log('T跟F都没有')
          this.notAvailable()
        }

      },
      confirmBox(oid){
        box.confirmBox({orderId:oid}).then((res)=>{
          if(res.data.code==200){
            this.$store.dispatch('getClothes')
          }else {
            this.toastMsg=res.data.msg
          }
        })
      },
      linkUrl(type,id){
        if(type==0){
          this.$router.push({
            name:'bookExpressPage',
            query:{oid:id}
          })
        }else{
          this.$router.push({
            name:'bookInfoPage',
            query:{oid:id}
          })
        }
      }
    },
    watch:{
    },
    components:{
      XCell
    },
    mounted(){
      let is_success = this.$route.query.is_success
      if (is_success == 'F') {
        this.toastMsg="很抱歉，押金交纳失败，请再试一次吧"
      } else if( is_success == 'T') {
        this.toastMsg="押金交纳成功，立即去下单吧"
      }
    },
    created() {
      this.$store.dispatch('getClothes')
      let once = localStorage.getItem("userBoxTips")
      if(once){
        this.tips.open = false;
      }else {
        this.tips.open = true;
      }
    }

  }
</script>

<style scoped lang="less">
  .boxContent{
    padding: 0 10px;
    /*position: relative;*/
  }
  .boxList{
    background-color: rgb(250, 250, 250);
    .cell /deep/ .cell-wrapper{
      min-height: 40px;
      background-color: #ffffff;
      background-position: bottom left;
      background-origin: border-box;
    }
    .cell-groups{
      margin: 10px 0;
    }
    .cell-label{
      color: #333333;
    }
    .cell-value{
      font-weight: 300;
    }
    .cell /deep/ .is-link{
      margin-right: 15px;
      color: #111111;
    }
    .cell /deep/ .cell-allow-right::after{
      right: 5px;
    }
  }
  section{
    width: 100%;
    min-height: 100%;
    padding: 5px 0;
    box-sizing: border-box;
    font-size: 12 * @unit;
    background-color: rgb(250, 250, 250);
    color: #999;

    .tips{
      width: 100%;
      line-height: 3;
      text-align: right;
    }
    .btnBox{
      width: 100%;
      overflow: hidden;
      box-sizing: border-box;
      /*padding: 0 10px;*/
      background: #ffffff;
      display: flex;
    }
    .btn{
      font-size: 12 * @unit;
      color: #ffffff;
      background: #ff544b;
      line-height: 3.5;
      margin: 10px 5px;
      padding:0 5px;
      flex: 1;
    }
    .gray{
      background: #d7d7d7;
    }
    .btn.addBtn{
      background: none;
      color: #3d3d3d;
      border: 1px solid #3d3d3d;
    }
    .buybtn{
      font-size: 12px;
      border: 1px solid rgba(0, 0, 0, 0.11);
      padding: 5px;
      color: #3d3d3d;
    }
  }
  .box{
    &.hasClothes{
      border:1px #d2d2d2 solid;
      background: #ffffff;
    }
    &.noneborder{
      border: 0;
      background: #ffffff;
    }
    .blackColor{
      color: #333;
    }
    width: 100%;
    border:1px #d2d2d2 dashed;
    display: flex;
    align-items: center;
    justify-content: center;


    margin-bottom: 5px;
    height: 100px;

    .left{
      width: 80px;
      position: relative;
      .noneBox{
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        img{
          width: 100%;
          height: 100%;
        }
      }
      img{
        border: 0;
        font-size: 0;
        line-height: 0;
        width: 100%;
        height: 100%;
        display: block;
      }
    }
    .right{
      flex: 1;
      position: relative;
      box-sizing: border-box;
      padding:0 10px ;
      font-size: 14px;
      dt{
        line-height: 2;
        padding-bottom: 5px;
      }
      dd{
        font-size: 12px;
        line-height: 1.5;
      }
      i{
        position: absolute;
        right: 5px;
        top: -10px;
      }
    }
  }
  .couponBox{
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    top: 0;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    .content{
      width: 90%;
      background: #ffffff;
      overflow: hidden;
      header{
        width: 100%;
        text-align: center;
        font-size: 14px;
        color: #666;
        line-height: 3;
      }
    }
    .couponList{
      min-height: 130px;
      max-height: 220px;
      overflow-y: scroll;
      background: #fafafa;
      li{
        display: flex;
        height: 76px;
        margin: 10px;
        background-color: #ffffff;
        align-items: center;
        justify-content: center;
        .leftBox{
          flex: 1;
          padding-left: 10px;
          text-align: left;
          p{
            color: #999;
            font-size: 12px;
            line-height: 1.5;
          }
          .title{
            color: #333;
            font-size: 15px;
            line-height: 1.8;
          }
        }
        .rightBox{
          position: relative;
          width: 96px;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: url("//yimg.yi23.net/webimg/web/images/2018/0418/active2018.png");
          background-size: 100%;
          background-repeat: no-repeat;
          color: #ffffff;
          font-size: 12px;
          font-weight: 300;
          span{
            font-size: 28px;
            padding: 0 1px;

          }
        }

      }
    }
    .closeBtnBox{
      background: #ffffff;
      padding: 10px 10px;
      width: 100%;
      font-size: 14px;
      color: #666;
      line-height: 3;
      box-sizing: border-box;
      text-align: center;
      .closeBtn{
        border: 1px solid #666;
        width: 100%;
      }
    }


  }

  /*0808*/
  .yclosetShade{
    /*position: relative;*/
    background: transparent;
  }
  .boxTip{
    position:absolute;
    top: 110 * @unit;
    left: 50%;
    background: transparent;
    padding: 0;
    display: flex;
    flex-wrap: wrap;
    /*justify-content: center;*/
    /*align-items: center;*/
    width:200 * @unit;
    transform: translateX(-50%) translateY(-50%);
    z-index:11;
    border-radius: 4 * @unit;
    box-shadow:0px 2px 20px #999;
  }

.boxTip > i{
  position: absolute;
  top:16 * @unit;
  right:10 * @unit;
  float:right;
  z-index: 12;
  color:#fff;
  font-size: 10 * @unit;
}

  .cssarrow {
    position: relative;
    width:100%;
    height:auto;
    padding:14 * @unit 20 * @unit;
    background: #000;
    font-size: 12 * @unit;
    line-height: 1.5;
    letter-spacing: 0.4px;
    color: #ffffff;
    border-radius: 4 * @unit;
  }
  .cssarrow:after,
  .cssarrow:before {
    top: 100%;
    left: 50%;
    border: solid transparent;
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
  }
  .cssarrow:after {
    border-color: rgba(0,0,0,0);
    border-top-color: #000;
    border-width: 10 * @unit;
    margin-left: -10 * @unit;
  }
  .cssarrow:before {
    border-color: rgba(194, 225, 245, 0);
    border-top-color: #c20e1f5;
    border-width: 10 * @unit;
    margin-left: -10 * @unit;
  }
.yi23-toast{
 margin-bottom: 44 * @unit;
}
</style>
