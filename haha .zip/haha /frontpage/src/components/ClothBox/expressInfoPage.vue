<template>
  <div class="yclosetContainer" v-if="expressInfoPage"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG" ><!--核心内容部分-->
      <div class="expressInfoPage">
        <div class="Title">订单编号：{{expressInfoPage.express.mailNo}}</div>
        <ul class="expressInfoPageList">
          <li v-for="(item) in expressInfoPage.express.courierRoutes">
            <div class="listLeft"></div>
            <div class="listRight">
              <p class="P1">{{item.acceptAddress}}</p>
              <p class="P2">{{item.acceptTime}}</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
  import goBack from 'base/GoBack'
  import { expressInfoPage } from 'api/clothBox'
  export default {
    data () {
      return{
        expressInfoPage: null,
      }
    },
    props:[

    ],
    components:{
      goBack,
    },
    watch:{
    },
    computed: {
    },
    methods: {
    },
    created () {
     let id = this.$route.query.id
      console.log(id)
      expressInfoPage(id).then((res)=>{
        console.log(res);
        this.expressInfoPage = res.data;
      });
    }
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";

  .image-ratio:after{
    padding-top: 100%;
  }

  .yclosetContainer{
    background: #fafafa;
  }
  .expressInfoPage{
    display:flex;
    flex-wrap: wrap;
    width:100%;
    .Title{
      display: flex;
      width:100%;
      .height(44);
      .line-height(44);
      .font-size(14);
      color: #000;
      .padding(0,0,0,12);
      border-bottom: rgba(0,0,0,.1) 1px solid;
    }

    ul.expressInfoPageList{
      display:flex;
      width:100%;
      flex-wrap: wrap;
      li{
        display: flex;
        width: 100%;
        height:auto;
        background:#fff;

        .listLeft{
          /*flex:1;*/
          display: flex;
          width:10%;
          background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/lushang1.svg") 50% 0 no-repeat;
          background-size: 22px;
        }
        .listRight{
          /*flex:8;*/
          border-bottom: 1px rgba(0,0,0,.05) solid;
          .padding(12,0,12,0);
          .margin(0,12,0,0);
          display: flex;
          flex-wrap: wrap;
          width:90%;
          p{
            color: #000;
            .line-height(16);
            .font-size(12);
            display: flex;
            width:100%;
          }
          .P1{}
          .P2{
            .margin(5,0,0,0)
          }

        }
      }

      li:last-of-type{
        .listLeft{
          background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/lushang3.svg") 50% 0 no-repeat;
          background-size: 22px;
        }
        .listRight{
          border:none;
          .P1{
            /*color:pink;*/
          }
        }
      }

      li:first-of-type{
        .listLeft{
          background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/lushang2.svg") 50% 0 no-repeat;
          background-size: 22px;
        }
        .listRight{
          .P1{
            color: #ff544b;
            .font-size(13);
          }
        }
      }

      li:only-child{
        .listLeft{
          background: url("https://yimg.yi23.net/webimg/web_source/Home/Common/images/lushang2.svg") 50% 0 no-repeat;
          background-size: 22px;
        }
        .listRight{
          border-bottom: 1px rgba(0,0,0,.05) solid;
          .P1{
            color: red;
            .font-size(13);
          }
        }
      }
    }
  }
</style>
