<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader">
      <p>您已预约上门取件，请耐心等待。如需帮助，请联系客服，4006504580</p>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <ul class="takeliveryDWrap">
        <li class="takeDate">
          <div class="takeDateLeft">取件日期</div>
          <div class="takeDateRight">{{fetchTime}}</div>
        </li>

      </ul>
      <div class="addAdress" v-if="addressInfo">
        <div class="addAdresTop">
          <div >{{addressInfo.consignee}}</div>
          <div>{{addressInfo.mobile}}</div>
        </div>
        <div class="addAdresCon">{{addressInfo.city}}&nbsp;{{addressInfo.country}}</div>
        <div class="addAdresBot">{{addressInfo.address}}</div>
      </div>
    </div>
    <div class="yclosetFooter">
      <div class="onlineServices">
        <button @click="openSDK()">在线客服</button>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { bookInfoPage } from 'api/subscribe'
  export default {
    data () {
      return {
        fetchTime:null,
      }
    },
    components:{
    },
    watch:{

    },
    computed: {
      ...mapGetters({
        addressInfo:'addressInfo'
      })
    },
    methods: {
      openSDK: function(){
        window.location.href = ysf.url();
      }
    },
    created () {
      let oid= this.$route.query.oid
      this.$store.dispatch('getAddressInfo')
      bookInfoPage(oid).then((res)=>{
        console.log(res)
        console.log(res.data.bookInfo.timeSlot)
        this.fetchTime = res.data.bookInfo.timeSlot
      });
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .yclosetContainer{
    height: 100%;
    width: 100%;
    display: block;
    background:#f4f8fb;
  }
  .yclosetHeader{
    display: block;
    .margin(0,0,10,0);
    p{
      .line-height(21);
      .padding(10,10,10,10);
      color: #fff;
      background: #333;
      .font-size(12);
    }
  }
  .yclosetCon{
    width: 100%;
    display: block;
    overflow: scroll;
    background:#f4f8fb;
    .takeliveryDWrap{
      .height(45);
      .margin(0,0,10,0);
      .padding(0,10,0,10);
      .font-size(12);
      background:#fff;
      .takeDate,.takeTime{
        display:flex;
        justify-content:space-between;
        .line-height(43);
      }
    }
    .addAdress{
      .height(50);
      .padding(10,10,10,10);
      background:#fff;
      position:relative;
      .addAdresTop{
        display:flex;
        justify-content: space-between;
        .padding(0,45,0,0);
        .font-size(12);
        color:#333;
        .line-height(18);
      }
      .addAdresCon,.addAdresBot{
        .font-size(12);
        .line-height(18);
        color:#999;
      }
    }
  }
  .yclosetFooter{
    position:fixed;
    bottom:0;
    width:100%;
    display: block;
    background:white;
    .padding(10,0,0,0);
    .height(50);
    .onlineServices{
      .padding(0,10,20,10);
      .font-size(14);
      button{
        width:100%;
        .height(44);
        background:white;

        color:#000;
        border: 1px #d7d7d7 solid;
      }
    }
  }
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .yclosetFooter{
      .bottom(34)
    }
  }
</style>
