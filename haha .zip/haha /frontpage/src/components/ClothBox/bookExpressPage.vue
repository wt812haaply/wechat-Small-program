<template>
    <div class="yclosetContainer"><!--comments-->
      <div class="yclosetHeader">
        <p>温馨提示：请您务必在新衣箱发货后的第二天将上一个衣箱寄出。若超时未寄出，您的会员期将被双倍扣除。</p>
      </div>
      <!--<div  v-model="addressInfo" style="display">{{addressInfo.addrId}}</div>-->
      <div class="yclosetCon bG"><!--核心内容部分-->
        <ul class="takeliveryDWrap">
          <li class="takeDate">
            <div class="takeDateLeft">取件日期</div>
            <div class="takeDateRight">
              <span @click="showDemo(3)" v-model="selDate">{{selDate}}</span>
              <i class="yi23iconfont icon-arrowdown"></i>
            </div>
          </li>
          <li class="takeTime">
            <div class="takeTimeLeft">取件时间</div>
            <div class="takeTimeRight">
                <span @click="showDemo(2)" v-model="selTime">{{selTime}}</span>
                <i class="yi23iconfont icon-arrowdown"></i>
            </div>
          </li>
        </ul>
        <div class="addAdress" @click="listLink()" v-if="addressInfo" v-model="addressInfo">
          <div class="addAdresTop">
            <div>{{addressInfo.consignee}}</div>
            <div>{{addressInfo.mobile}}</div>
          </div>
          <div class="addAdresCon">{{addressInfo.city}}&nbsp;{{addressInfo.country}}</div>
          <div class="addAdresBot">{{addressInfo.address}}</div>
          <div class="arrows"></div>
        </div>
      </div>
      <div class="yclosetFooter">
        <div class="affirm">
          <button @click="affirm">确认还衣</button>
        </div>
        <div class="onlineServices">
          <button @click="openSDK()">在线客服</button>
        </div>
      </div>
      <yi23-toast :open="toastOpen" @toastColse="toastColse">
        {{ msg }}
      </yi23-toast>

      <div class="page-picker-wrapper">
        <mt-picker :slots="yearSlot" v-model="timeSlotStatus"  :visible-item-count="5"  @doConfirm="doSelect">
        </mt-picker>
      </div>
      <div class="page-picker-wrapper">
        <mt-picker :slots="testSlot" v-model="dateSlotStatus" valueKey="text" :visible-item-count="5"  @doConfirm="doSelDate">
        </mt-picker>
      </div>
  </div>

</template>

<script>
  import MtPicker from '@/components/lib/picker/picker';
  import { mapGetters } from 'vuex'
  import { bookExpressPage } from 'api/subscribe'
  import yi23Toast from '@/components/lib/Toast.vue'
  import { bookExpress } from 'api/user'
  export default {
    data () {
      return {
        toastOpen: '',
        msg: '',
        selTime:'请选择时间',
        selDate:'请选择日期',
        dateSlotStatus:false,
        timeSlotStatus:false,
        periodData:null,
        yearSlot:[{
          values: [],
          className: 'slot1'
        }],

        testSlot:[{
          values: [],
          className: 'slot1'
        }],
      }
    },
    components:{
      yi23Toast,
      MtPicker,
    },
    watch:{

    },
    computed: {
      ...mapGetters({
        addressInfo:'addressInfo'
      })
    },
    methods: {
      dataRequired (options) {
        console.log(options)
        for(var k in options){
          console.log(this[options[k].name])
          if(this[options[k].name] == "请选择日期" || this[options[k].name] == "请选择时间"){
            this.msg=options[k].msg
            this.toastOpen = true;
            return false;
            break;
          }
        }
        return true
      },
      toastColse () {
        this.toastOpen = false;
      },
      listLink:function(){
        let oid = this.$route.query.oid;
        this.$router.push({
          path:'/User/myAddress',
          query:{ redirect:"/ClothBox/bookExpressPage?oid="+oid}
        })
      },
      doSelect(values) {
         console.log(values[0])
         // this.selTime= values[0]
        sessionStorage.setItem("selTime",values[0]);
        this.selTime= sessionStorage.getItem("selTime")
      },
      doSelDate(values){
        console.log(values)
        sessionStorage.setItem("selDate",values[0]);
        this.selDate= sessionStorage.getItem("selDate")
      },
      showDemo(val) {
        console.log(val)
        switch (val) {
          case 3:
            this.dateSlotStatus=true
            break;
          case 2:
            this.timeSlotStatus=true
            break;
        }
      },
      affirm:function(){
        let oid= this.$route.query.oid
        // console.log(oid)
        if(this.dataRequired([{name:'selDate',msg:'请选择日期'},{name:'selTime',msg:'请选择时间段'}])){
          let options = {
            addrId:this.addressInfo.addrId,
            date:this.selDate,
            peroid:this.selTime,
            oid:oid
          }
          // console.log(options)
          bookExpress(options).then((res)=>{
            if (res.code == 200) {
              sessionStorage.removeItem('selDate');
              sessionStorage.removeItem('selTime');
              window.location = "/yi23/Home/ClothBox/box";
            } else {
              this.toastOpen = true;
              this.msg = res.msg
            }
          });
        }
      },
      openSDK: function(){
        window.location.href = ysf.url();
      }
    },
    created () {
      let oid= this.$route.query.oid
      // console.log(oid)
      let sessionSelDate  =sessionStorage.getItem("selDate")
      let sessionSelTime  =sessionStorage.getItem("selTime")
      if(sessionSelDate || sessionSelTime){
        this.selDate= sessionStorage.getItem("selDate")
        this.selTime= sessionStorage.getItem("selTime")
      }
      this.$store.dispatch('getAddressInfo');
      bookExpressPage(oid).then((res)=>{
          // console.log(res)
          let timeData = null;
          let dateData = res.data.reserve_time_list;
          dateData.map(function(el){
            // console.log(el)
            timeData =el
          })
        this.yearSlot[0].values = timeData.period.split("|");
        this.testSlot[0].values = [timeData.date]
        // console.log(this.testSlot[0].values);
      });
    }
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .yclosetContainer{
    height: 100%;
    width: 100%;
    display: block;
    background:#f4f8fb;
  }
  .yclosetHeader{
    .margin(0,0,10,0);
    p{
      .line-height(21);
      .padding(10,10,10,10);
      color: #fff;
      background: #333;
      .font-size(12);
    }
  }
  .yclosetCon{
    width: 100%;
    overflow: scroll;
    display: block;
    background:#f4f8fb;
    .takeliveryDWrap{
      .height(88);
      .margin(0,0,45,0);
      .padding(0,10,0,10);
      .font-size(12);
      background:#fff;
      .takeDate,.takeTime{
        display:flex;
        justify-content:space-between;
        .line-height(43);
        border-bottom: rgb(230,230,230) 1px solid;
        .yi23iconfont{
          .font-size(12)
        }
      }
    }
    .addAdress{
      .height(50);
      .padding(10,10,10,10);
      background:#fff;
      position:relative;
      .addAdresTop{
        display:flex;
        justify-content: space-between;
        .padding(0,45,0,0);
        .font-size(12);
        color:#333;
        .line-height(18);
      }
      .addAdresCon,.addAdresBot{
        .font-size(12);
        .line-height(18);
        color:#999;
      }
      .arrows{
        .width(8);
        .height(8);
        border-right:solid #999 1px;
        border-bottom:solid #999 1px;
        transform:rotate(-45deg);
        -ms-transform:rotate(-45deg);
        -moz-transform:rotate(-45deg);
        -webkit-transform:rotate(-45deg);
        -o-transform:rotate(-45deg);
        position:absolute;
        .right(21);
        .top(31);
      }
    }
  }
  .yclosetFooter{
    position:fixed;
    display: block;
    bottom:0;
    width:100%;
    .height(100);
    .onlineServices{
      .padding(0,10,20,10);
      .font-size(14);
      button{
        width:100%;
        .height(38);
        background:white;
        color:#000;
        border: 1px #d7d7d7 solid;
      }
    }
    .affirm{
      .padding(0,10,20,10);
      .font-size(14);
      button{
        width:100%;
        .height(38);
        background:#000;
        color:white;
        border: 1px #d7d7d7 solid;
      }
    }
  }


  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .yclosetFooter{
      .bottom(34)
    }
  }
</style>
