<template>
  <!--<div class="container">-->
      <section>
        <div>
          <div class="emptyBox"  v-if="boxlist == null || boxlist.length ==  0 ">
            <h3>CHECK BACK LATER</h3>
            <em>归还后的衣箱会出现在这里</em>
          </div>

          <div class="tabBodyItem_box" v-else>
            <div class="orderItem" v-for="item in boxlist">

              <div class="expressNumber">{{item.oid}}</div>
              <div class="expressTime">
                <div class="ordersDate">{{item.addTime | YYYY_MM_DD}}下单</div>
                <div class="deliveryDate">{{item.revDate | YYYY_MM_DD}}送达</div>
              </div>
              <ul>
                <li v-for="items in item.detailInfo" @click="linkUrl(items.productId,items.path)">
                  <div class="clotheImg"><img :src="items.thumbPic"></div>
                  <div class="clotheDetail">
                    <div class="clotheName">{{items.productName}}</div>
                    <div class="clotheBrand">{{items.brandName}}</div>
                    <div class="clotheSize">{{items.size}}</div>
                  </div>
                </li>
              </ul>
              <div class="fault"></div>
            </div>
          </div>
        </div>
      </section>

  <!--</div>-->
</template>

<script>
  import box from 'api/box'
  import store from "@/store"
  export default {
    name: "boxNotes",
    data () {
      return {
        boxlist:null,
      }
    },
    components:{

    },

    created(){
      let that = this;
      box.boxV2().then((res)=>{
         console.log(res)
        that.boxlist = res.data.data.boxComplete.list
        store.commit('bigLoading', false)
      })
    },
    methods: {
      linkUrl:function(pid,path){
        if(!pid){
          return;
        }
        let query = {pid:pid};
        if(path){
          query.path = path
        }
        this.$router.push({
          name:'pdtDetailPage',
          query:query
        })
      },

    },
  }
</script>

<style scoped lang="less">
  @import "~common/less/variable";

  .container{
    width: 100%;
    background:#fafafa;
    background:blue !important;
  }

  section{
    width: 100%;
    height: 100%;
    padding: 10px 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-size: 12px;
    /*background-color: #fafafa;*/
    background-color: white;
    color: #999;
    .font-size(12);
    .tabBodyItem_box{
      .padding(0,0,0,0);
      width: 100%;
      height: auto;
      top:95.5px;
      border-bottom: 1px rgba(0,0,0,.05) solid;
      .fault{
        .height(30);
        background:#fafafa;
      }
      .expressNumber{
        .height(40);
        .line-height(40);
        text-align:right;
        .padding(0,12,0,0);
        .font-size(12);
        color:#999;
        border-bottom: 1px rgba(0,0,0,.05) solid;
        background:white;
      }
      .expressTime{
        display:flex;
        flex-direction:row;
        justify-content: space-between;
        .height(28);
        .line-height(28);
        .font-size(12);
        color:#999;
        background:white;
        .ordersDate{
          .padding(0,0,0,12)
        }
        .deliveryDate{
          .padding(0,12,0,0)
        }
      }
      ul{
        background: #fff;
        width: 100%;
        height: auto;
        .padding(10,0,12,0);
        li{
          display:flex;
          flex-direction:row ;
          .height(108);
          .clotheImg{
            .width(80);
            .height(100);
            .margin(0,0,0,12);
            img{
              width:100%;
              height:100%;
            }
          }
          .clotheDetail{
            .width(255);
            .height(100);
            .margin(0,0,0,20);
            border-bottom: 1px #e6e6e6 solid;
            .clotheName{
              color:#333;
              .font-size(13);
              .line-height(21);
              .margin(0,0,10,0);
              .padding(10,0,0,0);
            }
            .clotheBrand{
              .height(21);
              color:#999;
              .font-size(12);
              .line-height(21);
            }
            .clotheSize{
              .height(21);
              color:#333;
              .font-size(12);
              .line-height(21);
            }
          }
        }
      }
    }
    .emptyBox{
      position:absolute;
      -webkit-transform: translateX(-50%) translateY(-50%);
      -moz-transform: translateX(-50%) translateY(-50%);
      -ms-transform: translateX(-50%) translateY(-50%);
      transform: translateX(-50%) translateY(-50%);
      width:70%;
      top:50%;
      left:50%;
      text-align:center;
      h3{
        font-family: "Futura";
        font-weight: 300;
        font-size: 20px;
        text-align: center;
        line-height: 25px;
        color: #3d3d3d;
        padding: 5px 0;

      }
      em{
        margin: 0px;
        padding: 0px;
        display: block;
        line-height: 17px;
        font-style: normal;
        text-align: center;
        line-height: 17px;
      }
    }
    .gif{
      position:absolute;
      -webkit-transform: translateX(-50%) translateY(-50%);
      -moz-transform: translateX(-50%) translateY(-50%);
      -ms-transform: translateX(-50%) translateY(-50%);
      transform: translateX(-50%) translateY(-50%);
      width:50%;
      height:50px;
      top:50%;
      left:50%;
      text-align:center;
      img{
        width:50px;
        height:50px;
      }
    }
  }

</style>
