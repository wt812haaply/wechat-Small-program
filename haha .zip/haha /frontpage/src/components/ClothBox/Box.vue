<template>
<section class="yclosetContainer">
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <nav class="nav">
        <ul>
          <router-link :to="{path:'/ClothBox/box'}" >
            <li :class="{active:currentNav==0}">
              使用中衣箱
            </li>
          </router-link>
          <router-link :to="{path:'/ClothBox/box/boxNotes'}" >
            <li :class="{active:currentNav==1}">
              换衣记录
            </li>
          </router-link>
          <router-link :to="{path:'/ClothBox/box/gownOrderListPage'}" >
            <li :class="{active:currentNav==2}">
              礼服列表
            </li>
          </router-link>
        </ul>
      </nav>
      <router-view></router-view>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar :pageNumber="3"></bottom-Bar>
    </div>
</section>
</template>

<script>
  import goBack from 'base/GoBack'
  import bottomBar from 'base/BottomBar'
    export default {
      name: "box",
      data () {
        return {
          isFatherRouter:true,
          currentNav:0
        }
      },
      watch:{

      },
      components:{
        goBack,
        bottomBar,
      },
      beforeRouteUpdate (to, from, next) {
        if(to.path=='/ClothBox/box'){
            this.currentNav=0
        }else if(to.path=='/ClothBox/box/boxNotes'){
            this.currentNav=1
        }else{
            this.currentNav=2
        }
        next()
      },
      created(){
        if(this.$route.path=='/ClothBox/box'){
          this.currentNav=0
        }else if(this.$route.path=='/ClothBox/box/boxNotes'){
          this.currentNav=1
        }else{
          this.currentNav=2
        }
      }

    }
</script>

<style scoped lang="less">
  @import "~common/less/variable";
  /*;*/
  //
  .nav{
    width: 100%;
    ul{
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      line-height: 3.5;
      box-sizing: border-box;
      background-image:linear-gradient(180deg, #e7e7e7, #e7e7e7 50%, transparent 50%);
      background-size: 120% 1px;
      background-repeat: no-repeat;
      background-position: bottom left;
      background-origin: border-box;
    }
    li{
      display: inline-block;
      text-align: center;
      box-sizing: border-box;
      color: #333;
      margin: 0 15px;
      border-bottom: 2px solid rgba(255, 84, 75, 0);
      &.active{
        color: #ff544b;
        border-bottom: 2px solid #ff544b;
      }
    }


  }
</style>
