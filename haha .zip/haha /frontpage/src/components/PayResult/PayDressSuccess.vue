<template>
  <div>
    <div class="paySuccess">

      <div class="success"  v-if="status == 'T'">
        <img src="https://yimg.yi23.net/webimg/20180420/frontpage/suceed.png">
        <h2>支付成功!</h2>
        <p>已预约回程物流，请在还衣日保持手机畅通，等待快递员与你联系</p>
        <div class="btn" @click="toGownOrderList">返回列表</div>
        <div class="footer" @click="toIndex"><p>返回首页</p></div>
      </div>

      <div class="fail" v-if="status == 'F'">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/0516/paycancel.png">
        <h2>支付取消</h2>
        <p>出于某些原因支付未能完成，请重新下单</p>
        <div class="btn" @click="toGownOrderList">返回列表</div>
        <div class="footer" @click="toIndex"><p>返回首页</p></div>
      </div>

    </div>

  </div>

</template>

<script>
  export default {
    data(){
      return{
        status:null,
      }
    },
    created(){
      this.setStatus();
    },
    methods:{
      setStatus(){
        this.status = this.$route.query.is_success || this.$route.params.is_success
      },
      toGownOrderList(){
        window.location.href='/yi23/Home/ClothBox/box/gownOrderListPage?jumpNativeType=3&jumpNativeId=4'
      },
      toIndex:function () {
        window.location.href='/yi23/Home/Index/index?jumpNativeType=2'
      }
    }
  }
</script>

<style lang="less" scoped>
  @import '~common/less/mixin.less';
  @import '~common/less/variable.less';
  .paySuccess{
    width: 100%;
    height: 100%;
    background: #fff;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    .success,.fail{
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 30%;
    }
    .success,.fail{
      img{
        width: 40%;
      }
      h2{
        font-size: 20px;
        margin-bottom: 14px;
      }
      p{
        width:70%;
        margin:0 auto;
        text-align: center;
        margin-bottom:21px;
        line-height: 21px;
        font-size: 14px;
        color:#666;
        i{
          font-style: normal;
          color:@color-text;
        }
      }
      .btn{
        width: 60%;
        height: 44px;
        line-height: 44px;
        padding: 0;
        background: @color-text;
        font-size: 14px;
        font-weight: @font-weight-m;
        color: #fff;
      }
    }
    .fail{
      padding-top: 0;
      img{
        width: 100%;
      }
      h2{
        margin-top: 36px;
      }
      p{
        width: 70%;
        text-align: center;
      }
    }

  }
  .footer{
    width:100%;
    position:fixed;
    .bottom(40);
    text-align: center;
    p{
      margin-bottom:0 !important;
      color:#CDAB6A !important;
      .font-size(15) !important;
    }
  }

</style>
