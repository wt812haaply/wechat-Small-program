<template>
  <div class="paySuccess">

    <div class="success"  v-if="status == 'T'">
      <img src="https://tu.95vintage.com/web_source/Home/Common/images/paysuccess.png">
      <h2>支付成功!</h2>
      <p>请前往“我的优惠券”查看新入手的卡券，或等待客服与你联系</p>
      <router-link class="btn red" :to="{path: '/Subscribe/pdtListPage', query: { jumpNativeType : 7}}">
        去挑选美衣
      </router-link>
    </div>

    <div class="fail" v-if="status == 'F'">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0516/paycancel.png">
      <h2>支付取消</h2>
      <p>出于某些原因，支付未能完成。请稍候再次尝试</p>
      <router-link class="btn red" :to="{path: '/Subscribe/pdtListPage', query: { jumpNativeType : 7}}">
        去挑选美衣
      </router-link>
    </div>

  </div>
</template>

<script>
export default {
  data(){
    return {
      status: null,
    }
  },
  created(){
    this.setStatus();
  },
  methods:{
    setStatus(){
      this.status = this.$route.query.is_success;
    }
  }
}
</script>

<style lang="less" scoped>
@import '~common/less/mixin.less';
@import '~common/less/variable.less';
.paySuccess{
    width: 100%;
    height: 100%;
    background: #fff;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    .success,.fail{
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 0;
    }
    .success,.fail{
      img{
        width: 100%;
      }
      h2{
        font-size: 20px;
        margin-top: 36px;
        margin-bottom: 14px;
        color: #333333;
      }
      p{
        margin-bottom:21px;
        line-height: 21px;
        font-size: 14px;
        color:#666;
        width: 12.972973rem /* 240/18.5 */;
        text-align: center;
        i{
          font-style: normal;
          color:@color-text;
        }
      }
      .btn{
        width: 60%;
        height: 44px;
        line-height: 44px;
        padding: 0;
        font-size: 14px;
        font-weight: @font-weight-m;
        color: #fff;
        &.golden{
          background: @color-text;
        }
        &.red{
          background: @color-background-red;
        }
      }
    }
    .fail{
      padding-top: 0;
      img{
        width: 100%;
      }
      h2{
        margin-top: 36px;
      }
      p{
        width: 70%;
        text-align: center;
      }
    }
}
</style>
