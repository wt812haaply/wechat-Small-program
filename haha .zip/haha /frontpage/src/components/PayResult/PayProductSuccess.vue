<template>
  <div class="paySuccess">

    <div class="success"  v-if="status == 'T'">
      <img src="https://tu.95vintage.com/web_source/Home/Common/images/paysuccess.png">
      <h2>支付成功</h2>
      <p>手中商品直接留下，非手中商品将尽快发货</p>
      <div class="btn red" v-text="setText()" @click="linkTo"></div>
    </div>

    <div class="fail" v-if="status == 'F'">
      <img src="https://yimg.yi23.net/webimg/web/images/2018/0516/paycancel.png">
      <h2>支付失败</h2>
      <p>请您稍后尝试重新支付</p>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return {
      status: null,
    }
  },
  created(){
    this.setStatus();
  },
  methods:{
    setStatus(){
      this.status = this.$route.query.is_success;
    },
    setText(){
      if(this.$clientType == 1 || this.$clientType == 2){
        return '查看已购买订单'
      }else{
        return '继续挑选美衣'
      }
    },
    linkTo(){
      window.location.href="/yi23/Home/Subscribe/pdtListPage?jumpNativeType=3&jumpNativeId=3";
    }
  }
}
</script>

<style lang="less" scoped>
@import '~common/less/mixin.less';
@import '~common/less/variable.less';
.paySuccess{
    width: 100%;
    height: 100%;
    background: #fff;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    .success,.fail{
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 0;
    }
    .success,.fail{
      img{
        width: 100%;
      }
      h2{
        font-size: 20px;
        margin-top: 36px;
        margin-bottom: 14px;
        color: #333333;
      }
      p{
        margin-bottom:21px;
        line-height: 21px;
        font-size: 14 * @unit;
        color:#666;
        width: 295 * @unit;
        text-align: center;
        i{
          font-style: normal;
          color:@color-text;
        }
      }
      .btn{
        width: 60%;
        height: 44px;
        line-height: 44px;
        padding: 0;
        font-size: 14px;
        font-weight: @font-weight-m;
        color: #fff;
        &.golden{
          background: @color-text;
        }
        &.red{
          background: @color-background-red;
        }
      }
    }
    .fail{
      padding-top: 0;
      img{
        width: 100%;
      }
      h2{
        margin-top: 36px;
      }
      p{
        width: 70%;
        text-align: center;
      }
    }
}
</style>
