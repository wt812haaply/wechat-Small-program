<template>

  <div class="clothes">
    <div class="wrapper">
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index01_clothes.png?version=1.4">
      </div>
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index02_clothes.png?version=1.4">
      </div>
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index02_01.jpg">
      </div>
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index02_02.jpg">
      </div>
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index03_01.jpg">
      </div>
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index03_02.jpg">
      </div>

      <!-- 小程序二维码 -->
      <div class="WXSmall">
          <div class="Small_img image-normal">
              <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/SmallPrject-erweima.jpg" alt="">
          </div>
          <p class="Small_title">长按识别进入小程序</p>
      </div>
      <!-- 内容区 -->
      <div class="inner">
        <div class="iconTitle"><p>领取礼包</p></div>
        <div class="iconForm">
          <input class="tel" type="tel" placeholder="请输入您的手机号">
          <button>立即领取</button>
        </div>
      </div>
    </div>

    <transition name="slide-bottom">
      <div class="downApp" v-if="!downApp.closed && downApp.show">
      <div class="downAppFooter">
          <div class="Close" @click="DownAppClosed"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/downClose.svg"></div>
          <div class="ConLeft"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/downApplogo.svg"></div>
          <div class="ConRight">
              <h2 class="font-l">衣二三APP</h2>
              <p class="font-l">下载即得250元新人立减</p>
          </div>
          <button class="FooterBtn"><a style="color:#fff;" href="http://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan">下载APP</a></button>
      </div>
    </div>
    </transition>

  </div>

</template>

<script type="text/ecmascript-6">
export default {
  data(){
    return{
      downApp:{
        show: false,
        closed: false
      }
    }
  },
  mounted(){

    window.addEventListener('scroll', () => {
      var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
      if(scrollTop >= 100){
        this.downApp.show = true;
      }else{
        this.downApp.show = false;
      }
    })

  },
  methods:{
    DownAppClosed(){
      this.downApp.closed = true;
    }
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";

  .clothes{
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    .wrapper{
      position: relative;
      .imgplaceholder{
        width: 100%;
        height: 0;
        padding-bottom: 78%;
        position: relative;
        img{
          display: block;
          width: 100%;
          position: absolute;
          left: 0;
          top: 0;
          height: 100%;
        }
      }
      .inner{
        position: absolute;
        left:0;
        top: 16.533333rem;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        .iconTitle{
          display: flex;
          white-space: nowrap;
          width: 70%;
          font-size: 12px;
          line-height: 1.77;
          letter-spacing: 0.7px;
          color: #ffffff;
          height: 1.6rem;
          p{
            padding: 0 10px;
          }
          &:after,&:before{
            border-top: .026667rem solid rgba(255,255,255,.8);
            content: '';
            display: table-cell;
            position: relative;
            top: 10px;
            top: 0.63rem;
            width: 45%;
            height: 1.066667rem;
          }
        }
        .iconForm{
          width: 84%;
          display: flex;
          flex-direction: column;
          display: relative;
          padding-bottom: 4rem;
          input{
            width: 100%;
            height: 2.666667rem;
            line-height: 20px;
            font-size: 0.96rem;
            background-color: #f9f9f9;
            color: #666;
            border-radius: 2px;
            text-align: center;
          }
          button{
            width: 100%;
            height: 2.666667rem;
            background: #B63A3E;
            border-radius: 2px;
            font-size: 0.853333rem;
            letter-spacing: 0.2px;
            text-align: center;
            color: #fff;
            margin-top: 1.066667rem;
            font-weight: 600;
          }
          &:after{
            content: '';
            background: url('https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/JT.svg') no-repeat;
            background-size: cover;
            display: block;
            width: 1.013333rem;
            height: 1.013333rem;
            position: absolute;
            left: 50%;
            bottom: 0;
            transform: translate(-50%, 0);
            animation: bounce 2s infinite;
          }
        }
      }
    }
    .image-normal{
      background: #fafafa url('../../common/image/data_image_png.png') no-repeat center;
      background-size: 20%;
    }
  }

  .WXSmall{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 50px 0;
    width: 100%;
    background: #fff;
    .Small_img{
      width: 6.933333rem;
      height: 6.933333rem;
      display: block;
      img{
        display: block;
        width: 100%;
        height: 100%;
      }
    }
    .Small_title{
      width: 100%;
      font-size: 13px;
      text-align: center;
      color: #666;
      margin-top: 20px;
    }
  }
  .downApp{
    position: fixed;
    _position: absolute;
    bottom: 0;
    width: 100%;
    height: 50px;
    background: rgba(0,0,0,.6);
    z-index: 3;
    box-sizing: border-box;
    padding: 0 10px 0 3px;
    .downAppFooter{
      display: flex;
      align-items: center;
      height: 100%;
      color: #fff;
      font-weight: 400;
      .Close{
        width: 30px;
        height: 30px;
        line-height: 30px;
        font-size: 0;
        text-align: center;
        img{
          display: inline-block;
          vertical-align: middle;
        }
      }
    }
    .ConLeft{
      font-size: 0;
    }
    .ConRight{
      flex: 1;
      padding-left: 5px;
      padding-right: 5px;
    }
    .FooterBtn{
      width: 83px;
      height: 30px;
      border-radius: 2px;
      color: #fff;
      font-size: 12px;
      background: #ff544b;
      font-weight: 500;
    }
    h2{
      font-size: 14px;
      font-weight: 400;
    }
    p{
      font-size: 10px;
      font-weight: 400;
    }
  }

  @keyframes bounce {
    0%, 20%, 50%, 80%{
      -webkit-transform: translate(-50%, 0);
              transform: translate(-50%, 0);
    }
    40% {
      -webkit-transform: translate(-50%,-10px);
              transform: translate(-50%,-10px);
    }
    60% {
      -webkit-transform: translate(-50%,-5px);
              transform: translate(-50%,-5px);
    }
  }

  .slide-bottom-enter-active,.slide-bottom-leave-active{
    transition: all .3s;
  }

  .slide-bottom-enter,.slide-bottom-leave-to{
    opacity: 0;
    transform: translateY(100%);
  }
</style>
