<template>
  <div class="success">
    <div class="content">
      <div class="banner">
        <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/20180402001/dist/images/RecordBanner.jpg" />
        <div class="banner_text">
          <h2>您已获得奖励总额</h2>
          <h1 v-if="list&&list.total">¥{{number(list.total.totalAmount)}}</h1>
          <h1 v-else>¥{{number(0)}}</h1>
        </div>
      </div>
      <div class="RecordConTitleA">
        <div class="font-m left">邀请记录</div>
        <div class="right" @click="withdrawCash">可去资金账户提现</div>
      </div>
      <div class="listBox" v-if="list.record&&list.record.length>0">
        <ul>
          <li v-for="(item,index) in list.record" :key="item.id" :class="{'hide':index>=moreNum&&more}">
            <div class="listLeft">
              <div class="tCon">
                <p class="hide">{{item.message}} <span v-if="item.sendStatus==0">待生效</span></p>
              </div>
              <div class="bCon">{{item.time}}</div>
            </div>
            <div class="listRight">¥{{number(item.amount)}}</div>
          </li>
        </ul>
        <div class="btnBox" v-if="list.record.length>moreNum">
          <div class="berBtn" v-if="more" @click="moreClick">查看更多<i class="yi23iconfont icon-down"></i></div>
          <div class="berBtn" v-else @click="moreClick">收起</div>
        </div>
      </div>

      <div class="RecordConNull" v-else>
        <span>暂无邀请记录，快去邀请好友吧～</span>
        <div class="shareConStepTitle">
          <ul class="stepList">
            <li>
              <div class="stepICON"><img src="https://yimg.yi23.net/webimg/web/images/2018/0730/icon-1@2x.png" alt=""></div>
              <p class="P1">分享海报</p>
              <p class="P2 font-l">给好友</p>
            </li>
            <li>
              <div class="stepICON"><img src="https://yimg.yi23.net/webimg/web/images/2018/0730/icon-2@2x.png" alt=""></div>
              <p class="P1">好友扫码</p>
              <p class="P2 font-l">完成注册</p>
            </li>
            <li>
              <div class="stepICON"><img src="https://yimg.yi23.net/webimg/web/images/2018/0730/icon-3@2x.png" alt=""></div>
              <p class="P1">好友付费</p>
              <p class="P2 font-l">成为会员</p>
            </li>
            <li>
              <div class="stepICON"><img src="https://yimg.yi23.net/webimg/web/images/2018/0730/icon-4@2x.png" alt=""></div>
              <p class="P1">好友下单</p>
              <p class="P2 font-l">邀请好友成功</p>
            </li>
            <li>
              <div class="stepICON"><img src="https://yimg.yi23.net/webimg/web/images/2018/0730/icon-5@2x.png" alt=""></div>
              <p class="P1">领取红包</p>
              <p class="P2 font-l">下单7天后</p>
            </li>
            <li>
              <div class="stepICON"><img src="https://yimg.yi23.net/webimg/web/images/2018/0730/icon-6@2x.png" alt=""></div>
              <p class="P1">资金账户</p>
              <p class="P2 font-l">提取现金</p>
            </li>
          </ul>
        </div>
      </div>
      <div class="inner">
        <div class="context">
          <div class="text">
            <h6>奖励细则<i>RULES &amp; CONDITIONS</i></h6>
            <div>

              <ol>
                <li>
                  好友通过链接注册成为会员后，邀请人可在APP内领取¥50元现金礼包；领取路径如下：APP【我的】->【资金账户】
                </li>
                <li>
                  红包在被邀请人付费后发送至账户，在被邀请人成功下单借衣且成为会员7天后变为可领。若被邀请人不满足上述条件，或邀请人尚未下单，则双方无法获得相应奖励；
                </li>
                <li>【待生效】的红包在好友付费成功的7天后可在资金账户内领取；</li>
                <li>邀请好友奖励可累计，邀请成功越多，奖励越多；</li>
                <li>红包奖励领取后，不得无理由退费。若执意退费，需扣除相应奖励后，方可退费；</li>
                <li>此活动针对有效会员参加，若好友成功下单借衣7天后，您的会员期已结束，仍可获得相应奖励。</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { redpacketList } from 'api/event';
  import { ERR_OK }from 'api/const';
  import common from 'common/js/common';
export default {
  name: "box",
  data () {
    return {
      list : {},
      more : false,
      moreNum :4,
    }
  },
  watch:{
    more:function (val) {

    }
  },

  created(){
    this.getRedpacketList()

  },
  methods:{
    getRedpacketList:function () {
      let clientKey = common.getCookie('client_key',true);
      let authorization = common.getCookie('authorization');
      if(clientKey || authorization){
        let inputData = {};
        if(clientKey){
          inputData = {'clientKey' : clientKey};
        }
        redpacketList(inputData).then((res)=>{
          if(res.code == ERR_OK){
            this.list = res.data;
            if(this.list.record.length>this.moreNum){
              this.more = true;
            }
          }else{
            this.toastMsg = res.msg;
          }
        })
      }else{
        this.$router.push({
          path: '/User/loginPage',
          query: {
            redirect: this.$route.fullPath
          }
        })
      }


    },
    //秀芳让加链接
    //https://www.95vintage.com/yi23/Home/Others/jumpNativePage.html?jumpNativeType=35
//    withdrawCash() {
//      this.$router.push({
//        path: "/Others/jumpNativePage.html?jumpNativeType=35"
//      });
//    },

    withdrawCash() {
      window.location.href='https://www.95vintage.com/yi23/Home/Index/index?jumpNativeType=35'
    },

    number(value) {
      var toFixedNum = Number(value/100).toFixed(3);
      var realVal = toFixedNum.substring(0, toFixedNum.toString().length - 1);
      return realVal;
    },
    moreClick(){
      this.more = !this.more;
    }
  }
}
</script>

<style scoped lang="less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.success{
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  background: #f7f7f7;
}
.left{
  float: left;
}
.right{
  float: right;
}
.hide{
  display: none;
}
.banner{
  width: 100%;
  box-sizing: border-box;
  font-size: 0;
  height: auto;
  position: relative;
  img{
    width: 100%;
    position: relative;
  }
  .banner_text{
    width: 100%;
    text-align: center;
    position: absolute;
    top:23%;
    color: white;
    h2{
      font-size: .8rem;
      font-weight: 500;
    }
    h1{
      font-size: 1.92rem;
      font-weight: 100;
    }
  }
}
.RecordConTitleA {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  height: 2.666667rem;
  line-height: 2.666667rem;
  border-bottom: 1px rgba(0,0,0,.1) solid;
  padding: 0 1.226667rem;
  background: white;
  .left{
    font-size: 16px;
    color: #111;
  }
  .right{
    font-size: .64rem;
    color: #4a90e2;
  }
}

.listBox{
  background: white;
  width: 100%;
  overflow: hidden;
  ul{
    padding: 0 1.226667rem;
    li{
      width: 100%;
      height: auto;
      border-bottom: 1px rgba(0,0,0,.05) solid;
      padding: .853333rem 0;
      font-size: .64rem;
      .listLeft {
        height: 2.453333rem;
        float: left;
        width: 80%;
        .tCon {
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -webkit-box-align: center;
          -ms-flex-align: center;
          align-items: center;
          width: 100%;
          line-height: 1.226667rem;
          color: #666;
          font-size: .746667rem;
          p {
            color: #666;
            width: auto;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            overflow: hidden;
            span{
              text-align: center;
              padding: 0 2px;
              min-width: 2.133333rem;
              width: auto;
              line-height: .746667rem;
              height: .746667rem;
              background: #ff544b;
              border-radius: 1.6rem;
              font-size: .48rem;
              color: #fff;
              margin-left: .533333rem;
            }
          }
        }
        .bCon {
          color: rgba(0,0,0,.3);
          width: 100%;
          line-height: 1.226667rem;
        }

      }
      .listRight {
        margin-left: 80%;
        text-align: right;
        color: #ff544b;
        line-height: 2.453333rem;
      }
    }
  }

  .berBtn {
    margin: 1.28rem auto;
    width: 7.04rem;
    height: 2.026667rem;
    line-height: 2.026667rem;
    position: relative;
    left: 0;
    text-align: center;
    border-radius: 2.026667rem;
    border: 1px #f5f5f5 solid;
    color: #999;
    font-size: .64rem;

    .icon-down {
      font-size: .48rem;
      padding: 0 .16rem 0 .533333rem;
    }
  }

}

.inner{
  width: 100%;
  box-sizing: border-box;
  .context{
    padding-bottom: 18px;

    .text{
      text-align: center;
      font-size: 13px;
      line-height: 1.54;
      color: #333333;
      padding: 0 1.226667rem 1.226667rem 1.386667rem;
      background: #f7f7f7;
      h6{
        color: #333333;
        text-align: left;
        padding: 1.28rem 0;
        font-size: .853333rem;
        i {
          font-size: .533333rem;
          padding-left: .426667rem;
        }
      }
      div{
        ol{
          font-size: .64rem;
          padding-left: .533333rem;
          li{
            color: #666;
            list-style-type: decimal;
            text-align: left;
            font-size: .64rem;
            line-height: 1.83;
            letter-spacing: .2px;
            margin-bottom: .8rem;
          }
        }
      }
    }
  }
}


  .RecordConNull {
    background: white;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    width: 100%;

    span {
      font-size: .64rem;
      color: #999;
      text-align: center;
      width: 100%;
      margin-top: 35/18.75rem;
      margin-bottom: .86666667rem;
    }

    .shareConStepTitle {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      width: 100%;
      -ms-flex-wrap: wrap;
      flex-wrap: wrap;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      background: #fff;

      ul{
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        width: 100%;
        padding: 0 1.6rem;
        margin: 1.066667rem 0 .533333rem 0;

        li {
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
          -webkit-box-pack: center;
          -ms-flex-pack: center;
          justify-content: center;
          /*width: 4.533333rem;*/
          width: 23vw;
          /*height: 70px;*/
          padding: .533333rem 0;
          margin-bottom: 1.066667rem;
          position: relative;
          border:1px rgba(0,0,0,.1) solid;

          .stepICON {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 100%;
            height: 1.28rem;
            margin-bottom: .373333rem;

            img{
              width: 1.386667rem;
              display: block;
            }
          }
          p{
            display: block;
          }

          .P1 {
            font-size: .64rem;
            line-height: 2;
            color: #333;
          }

          .P2 {
            font-size: .533333rem;
            color: #999;
            width: 100%;
            text-align: center;
          }
        }
        li:nth-child(3n+1):after,li:nth-child(3n+2):after{
          content: '';
          position: absolute;
          width: 3.73vw;
          height:10/18.75rem;
          background-image: url('https://yimg.yi23.net/webimg/web/images/2018/0730/invalid-name@2x.png');
          background-size: contain;
          background-repeat: no-repeat;
          top: 50%;
          right: -5.3vw;
        }
      }
    }
  }

</style>
