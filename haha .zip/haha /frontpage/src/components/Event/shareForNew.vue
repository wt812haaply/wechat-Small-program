<template>
  <div class="yclosetContainer">
    <div class="yclosetHeader">
      <go-back></go-back>
    </div>
    <div class="yclosetCon">
      <!--核心内容部分-->
    <div class="shareForNew" v-if="shareForNew">
      <div class="shareForNewBanner">
        <router-link to="/Event/rewardList" tag="div" class="imgP image-ratio shareForNewBannerIMG">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/reward_pic.jpg?0821" alt="">
        </router-link>
      </div>
      <div class="shareForNewT">
          <div class="kat">
              <p>获得加时</p>
              <h2>{{shareForNew.total.days}}<i>天</i></h2>
          </div>

        <div class="kat">
          <p>获得积分</p>
          <h2>{{shareForNew.total.point}}<i>分</i></h2>
        </div>


        <div class="kat">
          <p>获得现金</p>
          <h2>{{shareForNew.total.cash}}<i>元</i></h2>
        </div>
      </div>
      <div class="shareForNewCon">
          <div v-if="shareForNew && shareForNew.record == 0">暂时没有邀请记录</div>
          <ul class="shareForNewList"  v-else>
            <!--<li v-for="(item) in shareForNew.record" v-if="item.type == 1">-->
              <!--<div class="listLeft">-->
                <!--<p class="hide" v-if="item.number == 1">邀请 {{item.itemName}} 登录成功</p>-->
                <!--<p class="hide" v-else>邀请 {{item.itemName}} 付费成功</p>-->
                <!--<p class="hide">{{item.time}}</p>-->
              <!--</div>-->
              <!--<div class="listRight">{{item.payName}}</div>-->
            <!--</li>-->

            <!--<li v-for="(item) in shareForNew.record" v-if="item.type == 2">-->
              <!--<div class="listLeft">-->
                <!--<p class="hide">邀请 {{item.itemName}} 下单礼服成功</p>-->
                <!--<p class="hide">{{item.time}}</p>-->
              <!--</div>-->
              <!--<div class="listRight">{{item.payName}}</div>-->
            <!--</li>-->

            <!--<li v-for="(item) in shareForNew.record" v-if="item.type == 3">-->
              <!--<div class="listLeft">-->
                <!--<p class="hide">邀请 {{item.itemName}} 支付成功</p>-->
                <!--<p class="hide">{{item.time}}</p>-->
              <!--</div>-->
              <!--<div class="listRight">{{item.payName}}</div>-->
            <!--</li>-->

            <li v-for="(item) in shareForNew.record" v-if="item.type == 4">
              <div class="listLeft">
                <p class="hide">被好友 {{item.itemName}} 邀请成为会员</p>
                <p class="hide">{{item.time}}</p>
              </div>
              <div class="listRight">{{item.payName}}</div>
            </li>
          </ul>
      </div>
    </div>
    </div>
  </div>
</template>
<script>
import goBack from 'base/GoBack'
import { shareForNew } from 'api/event'
export default {
  data() {
    return {
      shareForNew: null,
    }
  },
  components: {
    goBack
  },
  created() {
    shareForNew().then((res) => {
      console.log(res);
      this.shareForNew = res.data;
    });
  }
}

</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
@import "~common/less/variable";
.yclosetCon{
  background: #f7f7f7;
}
.hide {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
  /*1行*/
  overflow: hidden;
}
  .shareForNew{
    width:100%;
    &Banner{
      .padding(10,10,10,10);
      background: #fafafa;
      &IMG{
        padding-bottom: 55.7103%;
      }
    }
    &T{
      display: flex;
      width:100%;
      height:auto;
      .padding(30,0,30,0);
      background: #fff;
      .kat{
        display:flex;
        flex:1;
        flex-wrap: wrap;
        border-right: 1px rgba(0, 0, 0, .05) solid;

        h2,p{
          display: flex;
          justify-content: center;
          width: 100%;
          .height(18);
          .line-height(18);
          text-align: center;
        }
        p{
          .font-size(12);
          color: #666;
        }
        h2{
          .font-size(24);
          color: #CDAB6A;
          i{
            .font-size(9);
            position: relative;
            .top(3);
            height: auto;
            left:0;
            .padding(0,2,0,2);
            /*align-self:flex-end;*/
          }
        }
      }
      .kat:last-of-type{
        border:none;
      }
    }
    &Con{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      min-height:calc(100vw - 16px);
      /*background: #fafafa;*/
      div{
        width:100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #fafafa;
        /*background: blue;*/
      }
      ul.shareForNewList{
        .padding(0,33,0,33);
        display: block;
        display: flex;
        flex-wrap: wrap;
        width:100%;
        background: #fafafa;
        li{
          display: flex;
          justify-content:center;
          align-items:center;
          width:100%;
          .height(55);
          border-bottom: 1px rgba(0,0,0,.05) solid;
          .padding(14,0,14,0);
          .font-size(12);
          .listLeft{
            display: flex;
            width: 100%;
            .height(46);
            flex-wrap: wrap;
            flex:7;
            p{
              width:100%;
              .line-height(22);
              flex-wrap: wrap;
              color: #333;
            }
            p:last-of-type{
              color: rgba(0,0,0,.3)
            }

          }
          .listRight{
            text-align: right;
            flex:2;
            color: #999;
          }
        }
        li:last-of-type{
          border:none;
        }
      }
    }
  }
</style>
