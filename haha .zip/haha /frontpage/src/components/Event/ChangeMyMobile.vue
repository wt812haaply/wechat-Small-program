<template lang="html">
  <div class="changeM">
    <div class="banner image-normal">
      <img src="https://yimg.yi23.net/webimg/20180420/frontpage//ModifyPhoneBanner.jpg">
    </div>
    <div class="userphone">当前领取手机号:<i>15313080725</i></div>
    <input class="tel" type="tel" placeholder="请输入新的的手机号" v-model="userphone">
    <button class="savechange">保存</button>
    <div class="message">
      <p>修改手机后<br>下次将使用新手机号参加领取养成加衣券活动</p>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  data(){
    return{
      userphone:'15313080725'
    }
  }
}
</script>

<style>
  body{
    background: #fff;
  }
</style>

<style lang="less" style="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.changeM{
  font-family: "PingFang SC";
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.banner{
  height: 0;
  width: 100%;
  padding-bottom: 10.27rem;
  position: relative;

  img{
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
  }
}
.userphone{
  text-align: center;
  font-size: 14px;
  color: #9b9b9b;
  margin-top: 50px;
  margin-bottom: 15px;
  i{
    font-style: normal;
  }
}
.tel{
  width: 80%;
  display: block;
  height: 50px;
  line-height: 50px;
  font-size: 18px;
  color: #666;
  text-align: center;
  border-radius: 2px;
  background: #f9f9f9;
  text-align: center;
}
.savechange{
  width: 80%;
  height: 50px;
  background: #b63a3e;
  color: #fff;
  font-size: 16px;
  letter-spacing: 0.2px;
  border-radius: 2px;
  margin-top: 20px;
}
.message{
  text-align: center;
  font-size: 12px;
  line-height: 1.58;
  letter-spacing: 0.3px;
  text-align: center;
  color: #9b9b9b;
  margin-top: 20px;
}
</style>
