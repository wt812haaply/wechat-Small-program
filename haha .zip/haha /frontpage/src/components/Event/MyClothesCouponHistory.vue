<template lang="html">
  <div class="history">
    <div class="coupon">
      <div class="title">我目前拥有<i>1</i>张</div>
      <div class="userConCouponList">
        <ul>
          <li>
            <div class="left">
              <p>加衣券碎片</p>
            </div>
            <div class="right">
              <p>1<i>张</i></p>
            </div>
          </li>
        </ul>
        <div class="info">加衣券尚未养成,再接再厉！</div>
      </div>
    </div>
    <div class="coupon_tab">
      <div class="tab_nav">
        <div class="nav_item"
          :class="{'active': index == currentIndex }"
          v-for="(item,index) of tabNav.data"
          @click="TabClick(index)"
          >
          {{item.title}}
        </div>
      </div>
      <div class="inner" ref="slider">
        <div class="wrapper clearfix" ref="wrapper">
          <div class="inner_item reward">
            <ul>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>
              <li>
                <p>0.5张养成加衣券</p>
                <span>2017/12/23</span>
              </li>

            </ul>
          </div>
          <!-- 加衣券 -->
          <div class="inner_item coupon">
            <ul>
              <li class="unoverdue">
                <div class="left">
                  加衣券碎片
                </div>
                <div class="right">
                  <p>1<i>张</i></p>
                  <span>有效期：2017/12/23 - 2018/01/14</span>
                </div>
              </li>
              <li class="overdue">
                <div class="left">
                  新人立减
                </div>
                <div class="right">
                  <p>50<i>¥</i></p>
                  <span>有效期：2017/12/23 - 2018/01/14</span>
                </div>
              </li>
            </ul>

            <!-- <div class="empty">
              <p>您目前还没有完整的加衣券<br>再接再厉哦！</p>
            </div> -->

          </div>
        </div>
      </div>
      <mini-program-q-r></mini-program-q-r>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import MiniProgramQR from "base/MiniProgramQR";

export default {
  components: {
    MiniProgramQR
  },
  data() {
    return {
      currentIndex: 0,
      tabNav: {
        data: [
          {
            title: "奖励记录"
          },
          {
            title: "已获得加衣券(2)"
          }
        ]
      }
    };
  },
  mounted() {
    setTimeout(() => {
      this._setSliderWidth();
    }, 20);
  },
  methods: {
    TabClick(index) {
      this.currentIndex = index;
    },
    _setSliderWidth() {
      this.children = this.$refs.wrapper.children;
      let width = 0;
      let sliderWidth = this.$refs.slider.clientWidth;
      for (let i = 0; i < this.children.length; i++) {
        let child = this.children[i];
        child.style.width = `${sliderWidth}px`;
        width += sliderWidth;
      }
      this.$refs.wrapper.style.width = `${width}px`;
    }
  },
  watch: {
    currentIndex(newIndex, oldIndex) {
      if (newIndex != oldIndex) {
        setTimeout(() => {
          let clientWidth = this.$refs.slider.clientWidth;
          let transWidth = newIndex * clientWidth;
          let currentItem = this.$refs.wrapper.children[newIndex];
          let itemH = currentItem.clientHeight;
          this.$refs.wrapper.style.webkitTransform = `translate3d(-${transWidth}px, 0px, 0px)`;
          this.$refs.wrapper.style.transform = `translate3d(-${transWidth}px, 0px, 0px)`;
          this.$refs.wrapper.style.height = `${itemH}px`;
          this.$refs.wrapper.style.overflow = "hidden";
        }, 20);
      }
    }
  }
};
</script>

<style>
body {
  background: #fff;
}
</style>
<style lang="less" style="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.history {
  font-family: "PingFang SC";
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  padding-top: 25px;
}
.coupon {
  .title {
    font-size: 13px;
    line-height: 1.19;
    color: #b63a3e;
    text-align: center;
    margin-bottom: 17px;

    i {
      font-style: normal;
      font-size: 25px;
      line-height: 0.87;
      margin-left: 2px;
      margin-right: 2px;
    }
  }
  .userConCouponList {
    width: 100%;
    box-sizing: border-box;
    padding: 0 1.78rem;
    li {
      width: 100%;
      height: 5.19rem;
      line-height: 5.19rem;
      text-align: center;
      display: flex;
      .left {
        width: 10rem;
        height: 5.19rem;
        .bg-image("invalid-name");
        background-size: cover;
        border-radius: 2px 0 0 2px;
        color: #b63a3e;
        font-size: 18px;
      }
      .right {
        width: 6.7rem;
        height: 5.19rem;
        background: url("https://yimg.yi23.net/webimg/20180420/frontpage//spanRight.png")
          no-repeat;
        background-size: cover;
        border-radius: 0 2px 2px 0;
        color: #fff;
        font-size: 18px;
        p {
          font-size: 1.62rem;
        }
        i {
          font-style: normal;
          font-size: 14px;
        }
      }
    }
    .info {
      font-size: 13px;
      color: #666;
      text-align: center;
      margin-top: 15px;
    }
  }
}
.coupon_tab {
  width: 100%;
  margin-top: 2.16rem;
  .tab_nav {
    display: flex;
    .px-bottom();
    .nav_item {
      width: 50%;
      text-align: center;
      height: 49px;
      line-height: 49px;
      font-size: 14px;
      color: #999;
      &.active {
        color: #333;
        position: relative;
        &:after {
          content: "";
          display: block;
          height: 2px;
          width: 4.86rem;
          position: absolute;
          background: #b63a3e;
          left: 2.43rem;
          bottom: 0;
        }
      }
    }
  }
  .inner {
    width: 100%;
    overflow: hidden;
    .wrapper {
      width: 100%;
      transition-property: transform, -webkit-transform;
      transition-duration: 300ms;
      transform: translate3d(0px, 0px, 0px);
      .inner_item {
        width: 100%;
        float: left;
        &.reward {
          li {
            font-size: 14px;
            display: flex;
            height: 3.2rem /* 60/18.75 */;
            line-height: 3.2rem /* 60/18.75 */;
            padding: 0 15px;
            .px-bottom();
            p {
              flex: 1;
              color: #4a4a4a;
            }
            span {
              font-size: 13px;
              color: #9b9b9b;
            }
          }
        }
        &.coupon {
          padding-top: 39px;
          li {
            width: 100%;
            box-sizing: border-box;
            padding: 0 1.81rem /* 34/18.75 */ 0 1.87rem /* 35/18.75 */;
            display: flex;
            margin-bottom: 20px;
            .left {
              width: 1.39rem /* 26/18.75 */;
              height: 4.053333rem /* 76/18.75 */;
              background: url("https://yimg.yi23.net/webimg/20180420/frontpage//newUserLeft.svg")
                no-repeat;
              background-size: cover;
              overflow: hidden;
              color: #fff;
              font-size: 9px;
              text-align: center;
              writing-mode: vertical-lr;
              line-height: 1.39rem /* 26/18.75 */;
            }
            .right {
              width: 14.933333rem /* 280/18.75 */;
              height: 4.053333rem /* 76/18.75 */;
              background: url("https://yimg.yi23.net/webimg/20180420/frontpage//newUserRight.svg")
                no-repeat;
              background-size: cover;
              overflow: hidden;
              display: flex;
              flex-direction: column;
              justify-content: center;
              box-sizing: border-box;
              padding: 0 20px;
              p {
                font-size: 25px;
                color: #b63a3e;
                margin-bottom: 6px;
                i {
                  font-size: 12.6px;
                  font-style: normal;
                  margin-left: 3px;
                }
              }
              span {
                font-size: 10px;
                color: #666666;
              }
            }
            &.overdue {
              .left {
                background: url("https://yimg.yi23.net/webimg/20180420/frontpage//newUserLeft2.svg")
                  no-repeat;
                background-size: cover;
              }
              .right {
                background: url("https://yimg.yi23.net/webimg/20180420/frontpage//newUserRight2.svg")
                  no-repeat;
                background-size: cover;
                position: relative;
                p {
                  color: #b63a3e;
                  color: #fff;
                }
                span {
                  font-size: 10px;
                  color: #fff;
                }
                &:after {
                  content: "";
                  display: block;
                  width: 2.4rem /* 45/18.75 */;
                  height: 2.4rem /* 45/18.75 */;
                  background: url("https://yimg.yi23.net/webimg/20180420/frontpage//newUserZT.svg")
                    no-repeat;
                  background-size: cover;
                  position: absolute;
                  right: 16px;
                  top: 50%;
                  margin-top: -1.2rem;
                }
              }
            }
          }
        }
      }
    }
  }
  .empty {
    text-align: center;
    font-size: 13px;
    color: #999999;
    opacity: 0.5;
    line-height: 1.5;
    padding-top: 3.2rem /* 60/18.75 */;
    padding-bottom: 6.13rem /* 115/18.75 */;
  }
}
</style>
