<template>
  <div class="redpacket">
    <div style="position:absolute; left:0px; width: 100%; height: 29px; background: #EFE8E1; line-height: 29px; text-align: center; color: #333; font-size: 11px;">
      4月1日起现金红包将在APP内领取，<a href="/yi23/Home/Index/postingPage?id=7207" style="color: #4A90E2">点击查看详情</a >
    </div>
    <div class="content" v-if="info" style="padding-top: 30px">
       <!--<div class="date">1月20日-1月30日</div>-->

       <div class="user">
         <img  class="avater" :src="info.headimg">
         <div>
           <div class="name">{{info.nick}}</div>
           <p v-if="info.finishList && info.finishList.length>0">
             邀请好友成功，获得现金奖励！
           </p>
           <p v-else>
             你还没有获得现金奖励哦
           </p>
         </div>
       </div>

       <div class="cash">
         <p class="tit">可提现金额</p>
         <h3><i>¥</i>{{info.remain/100}}</h3>
         <p class="dec">每日只能领取6个红包哟</p>
       </div>
       <div class="shape"></div>
       <!-- 没红包 -->
       <div class="nopacket" v-if="info.finishList.length==0">
         <span class="pic"></span>
         <div class="btn-friend"><a href="https://www.95vintage.com/yi23/Home/Event/rewardList">去邀请好友</a></div>
       </div>
       <!-- 可提现 -->
       <div class="withdraw-cash" v-if="info.havefinish==1">
         <ul>
           <li v-for="(item,index) of info.finishList">
             <div class="left" v-if="item.is_self==0">
                <h6>好友<span>{{item.nickname}}</span>成为会员</h6>
                <p class="date-dec">{{item.time}}</p>
              </div>
             <div class="left" v-else>
               <h6>被好友邀请成为会员</h6>
               <p class="date-dec">{{item.time}}</p>
             </div>
             <div class="middle">
               <p>+¥{{item.amount/100}}元</p>
             </div>
             <template v-if="item.result==0">
               <div class="withdraw-cash-btn" @click="doSubmit(item.id)">提现</div>
             </template>
             <template v-else>
               <div class="withdraw-cash-btn off">已提现</div>
             </template>
           </li>
         </ul>
       </div>
       <!--  未达到提现标准 -->

       <div class="shape" v-if="info.havewaitting==1"></div>
       <div class="withdraw-cash" v-if="info.havewaitting==1">
         <div class="item-title">好友使用不足七天,暂不能提现</div>
         <ul>
           <li v-for="(item,index) of info.waitting">
             <div class="left"  v-if="item.is_self==0">
               <h6>好友<span>{{item.nickname}}</span>成为会员</h6>
               <p class="date-dec">{{item.time}}</p>
             </div>
             <div class="left"  v-else>
               <h6>被好友邀请成为会员</h6>
               <p class="date-dec">{{item.time}}</p>
             </div>
             <div class="middle">
               <p>+¥{{item.amount/100}}元</p>
             </div>
               <div class="withdraw-cash-btn off">未开始</div>
           </li>
         </ul>
       </div>
    </div>
    <yi23Dialog :hasCannel="dialog.hasCannel" :open="dialog.open" @dialogOk="DialogOk" @dialogClose="DialogToggle" :dialogSm='dialog.dialogSm'>
      <div slot="banner">
        <div class="banner-box">
          <img src="https://yimg.yi23.net/webimg/20180420/frontpage/success.jpg" v-if="status">
          <img src="https://yimg.yi23.net/webimg/web_source/Home/Common/images/20161227001/red-packet-warning.png" v-else>
        </div>
      </div>
      <div slot="header" v-if="status">提现成功</div>
      <div slot="header" v-else>提现失败</div>
      <div slot="body">
        <!--<div class="yi23-dialog__bd">出于某种原因，领取不成功哦，请留言联系我们</div>-->
        <!--<div class="yi23-dialog__bd">请返回衣二三公众号领取红包或继续留在此页面</div>-->
        <!--<div class="yi23-dialog__bd">今天已领超过6个红包了，明天再来吧</div>-->
        <div class="yi23-dialog__bd">{{msg}}</div>
      </div>
      <div slot="btnCannel" >继续领取</div>
      <div slot="btnOk" style="color:#cc9e68;">返回公众号</div>
    </yi23Dialog>
    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script type="text/ecmascript-6">
//import PopUpLayer from 'base/PopUpLayer';
//import yi23Dialog from 'components/lib/Dialog.vue';
import { invitationPacket,signStatus} from 'api/user';
export default {
  data(){
    return{
      status:0,
      dialog:{
        open: false,
        dialogSm: true,
        hasCannel: true,
        toastOpen: false
      },
      toastMsg:'',
      info:'',
      msg:'',
    }
  },
  components:{
    //PopUpLayer,
    //yi23Dialog
  },
  methods:{
    DialogOk() {
      this.dialog.open = false;
      try {
        WeixinJSBridge.invoke('closeWindow',{},function(res){});
      }catch (e){
        console.log(e)
      }
    },
    doSubmit(id) {
      signStatus({id:id}).then((res)=>{
        if(res.code==200){
          this.status=1
          this.msg='请返回衣二三公众号领取红包\r\n或继续留在此页面'
          this.dialog.open=true
        }else{
          this.msg=res.msg
          this.status=0
          this.dialog.open=true
        }
      })
    },
    DialogToggle(){
      this.dialog.open = !this.dialog.open;
      this.loadData();
    },
    loadData() {
      invitationPacket().then((res)=>{
        if(res.code==200){
          this.info=res.data
        }else{
          this.toastMsg=res.msg
        }
      })
      // let res={"code":200,"msg":"请求成功","data":{"nick":"虎","headimg":"http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoSicTWia1ELc7l5Cenmf4yzIwEzKsbiclMccJ3vI3Bj69YmWkG5KfichZwKoLmRxeGfUOOVucONwzZGw/132","nodata":0,"havefinish":1,"havewaitting":0,"remain":5000,"waitting":[],"finishList":[{"id":767,"uid":142,"code":null,"openid":"","amount":5000,"result":0,"addTime":1519920000000,"payId":0,"sendTime":1527868800000,"referId":0,"enable":0,"request":null,"response":null,"nickname":"大·怪","mobile":"13641189117","time":"2018/03/02 00:00","is_self":0},{"id":772,"uid":83053,"code":null,"openid":"","amount":5000,"result":1,"addTime":1519920000000,"payId":0,"sendTime":1527868800000,"referId":0,"enable":0,"request":null,"response":null,"nickname":"虎","mobile":"18600958531","time":"2018/03/02 00:00","is_self":1}]}}
      // this.info=res.data
    }
  },
  created () {
    this.loadData()
    let res=''
  },
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .banner-box{
    padding-top: 57px;
    img{
      width: auto;
    }
  }
  .redpacket{
    width: 100%;
    min-height: 100%;
    display: flex;
    flex-direction: column;
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    background: #55555C url(https://tu.95vintage.com/web_source/Home/Common/images/20161227001/red-packet-bg.jpg) no-repeat;
    background-size: cover;
    border: 6px #3A4C57 solid;
    box-sizing: border-box;
    padding:28px 18px 50px 18px;
    .content{
      flex: 1;
      display: flex;
      flex-direction: column;
      background: #fff;
      box-shadow: 0px 15px 20px rgba(0,0,0,.3);
      border-radius: 2px;
      .date{
        text-align: center;
        height: 29px;
        line-height: 29px;
        border-radius: 2px;
	      background-color: #be9565;
        font-size: @font-size-small;
        font-weight: @font-weight-m;
        color: #fff;
      }
      .user{
        width: 100%;
        .box();
        box-sizing: border-box;
        padding: 0 20px;
        background-color: #fafafa;
        height: 55px;
        align-items: center;
        font-size: 12px;
        img{
          display: block;
          width: 36px;
          height: 36px;
        }
        & > div{
          flex: 1;
          margin-left: 10px;
          .name{
            width: 100%;
            .no-wrap();
            height: 17px;
            line-height: 17px;
          }
          p{
            color: #999999;
            font-weight: 300;
            .no-wrap();
          }
        }
      }
      .cash{
        padding-top: 24px;
        padding-bottom: 30px;
        text-align: center;
        font-size: 12px;
        .tit{
          font-size: 14px;
          color: #c3935c;
        }
        .dec{
        	letter-spacing: 0.2px;
          color: #999999;
        }
        h3{
          font-size: 72px;
          color: #cc9e68;
          font-weight: 200;
          line-height: .9em;
          margin-top: 5px;
          margin-bottom: -2px;
          i{
            font-style: normal;
            font-size: 24px;
            letter-spacing: 0.5px;
            font-weight: 400;
            font-family: PingFangSC;
          }
        }
      }
      .shape{
        width: 100%;
        height: 32px;
        background: url('https://yimg.yi23.net/webimg/20180420/frontpage/red-packet-section.png') no-repeat;
        background-size: 100%;
      }
      .nopacket{
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        .pic{
          display: inline-block;
          width: 112px;
          height: 110px;
          .bg-image('empty-state');
          background-size: 100%;
          margin-bottom: 35px;
        }
        .btn-friend{
          width: 80%;
          max-width: 267px;
          height: 44px;
          line-height: 44px;
          text-align: center;
          background-color: #cc9e68;
          color: #fff;
          font-size: 14px;
        }
      }
      .withdraw-cash{
        padding: 0 20px;
        .item-title{
          font-size: 14px;
          text-align: center;
          letter-spacing: 0.3px;
          color: rgba(0, 0, 0, 0.2);
          margin-bottom: 23px;
          position: relative;
          &:before{
            content: '';
            display: block;
            width: 0;
            height: 0;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-top: 5px solid rgba(0, 0, 0, 0.1);
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-112px,-50%);
          }
          &:after{
            content: '';
            display: block;
            width: 0;
            height: 0;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-top: 5px solid rgba(0, 0, 0, 0.1);
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(105px,-50%);
          }
        }
        li{
          display: flex;
          align-items: center;
          padding: 20px 0;
          &:first-child{
            padding-top: 0px;
          }
          .px-bottom();
          .left{
            flex: 1;
            overflow: hidden;
            h6{
              font-size: @font-size-medium;
              letter-spacing: 0.3px;
              color: @color-dec;
              padding-right: 10px;
              .no-wrap();
            }
            .date-dec{
              font-size: @font-size-small;
              color:rgba(0, 0, 0, 0.3);
              padding-right: 10px;
              .no-wrap();
            }
          }
          .middle{
            font-size: @font-size-small;
            color:#cc9e68;
            font-weight: 500;
          }
          .withdraw-cash-btn{
            width: 56px;
            height: 28px;
            line-height: 28px;
            text-align: center;
            background-color: #cc9e68;
            letter-spacing: 0.2px;
            border-radius: 2px;
            margin-left: 9px;
            color: #fff;
            font-size: @font-size-small;
            &.off{
              background-color: rgba(0, 0, 0, 0.05);
              color:rgba(0, 0, 0, 0.2);
            }
          }
        }
      }
    }
  }
</style>
