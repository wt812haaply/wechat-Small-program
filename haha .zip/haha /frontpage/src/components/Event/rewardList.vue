<template>
  <div class="yclosetContainer" style="">

    <div class="yclosetHeader">
      <go-back></go-back>
    </div>

    <div class="yclosetCon bG">
      <!--核心内容部分-->
      <div class="Reward">
        <h4 style="font-size: 1.066667rem;">邀请新用户 最少得50元现金</h4>
        <h6 class="font" style="font-size:.64rem; text-align:center;width: 100%;">邀请无上限 邀请成功后双方各得50元</h6>
        <div class="RewardForIMG">
          <swiper :options="swiperOption" ref="mySwiper" @slideChangeTransitionEnd="getSwiperIndex">
            <!-- slides -->
            <swiper-slide v-for="(item,index) of slides" :key="index">
              <div class="swiper-slide image-ratio PlIMG slideIMG">
                <img :src="item">
              </div>
            </swiper-slide>
            <div class="swiper-pagination NE"  slot="pagination"></div>
          </swiper>
        </div>

        <div class="or">
          <div class="Title">
            <p>or</p>
          </div>
        </div>
        <h4>或将你的专属邀请码告知好友</h4>
        <h5 class="font-l">让好友首次付费时输入</h5>
        <div class="sharForMA font-m">
          <span class="Left">你的专属邀请码：</span>
          <span class="Right yi23red" @click="shareForMa=true">{{invitationCode || ''}}<i class="yi23iconfont icon-right yi23gray"></i></span>
        </div>
        <div class="shareConStepTitle">
            <h2 class="Title font-m"><i>邀请好友简6步</i></h2>
            <p class="font-l">6 STEPS</p>
            <ul class="stepList">
                <li>
                    <div class="stepICON"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180402001/dist/images/stepICON01.png" alt=""></div>
                    <p class="P1">分享海报</p>
                    <p class="P2 font-l">给好友</p>
                </li>
                <li>
                    <div class="stepICON"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180402001/dist/images/stepICON02.png" alt=""></div>
                    <p class="P1">好友扫码</p>
                    <p class="P2 font-l">完成注册</p>
                </li>
                <li>
                    <div class="stepICON"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180402001/dist/images/stepICON03.png" alt=""></div>
                    <p class="P1">好友付费</p>
                    <p class="P2 font-l">成为会员</p>
                </li>
                <li>
                    <div class="stepICON"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180402001/dist/images/stepICON04.png" alt=""></div>
                    <p class="P1">好友下单</p>
                    <p class="P2 font-l">邀请好友成功</p>
                </li>
                <li>
                    <div class="stepICON"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180402001/dist/images/stepICON05.png" alt=""></div>
                    <p class="P1">领取红包</p>
                    <p class="P2 font-l">下单7天后</p>
                </li>
                <li>
                    <div class="stepICON"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180402001/dist/images/stepICON06.png" alt=""></div>
                    <p class="P1">资金账户</p>
                    <p class="P2 font-l">提取现金</p>
                </li>
            </ul>
        </div>
      </div>

      <ul class="meunList">
        <li @click="myorderlist">
            <div>我的邀请记录</div>
            <i class="yi23iconfont icon-right"></i>
        </li>
        <li @click="orderTop10">
            <div>拉新排行榜</div>
            <i class="yi23iconfont icon-right"></i>
        </li>
      </ul>

      <div v-show="shareForMa">
        <div class="HVcenter CustomizedMa">
          <h2 class="font-m">定制你的专属邀请码</h2>
          <input type="text" class="ma font-l" v-model="changeCodeInput" placeholder="请定制邀请码">
          <div class="yi23-dialog__ft flex">
            <div class="flex-item yi23-dialog__btn font-r" @click="shareForMa=false">取消</div>
            <div class="flex-item yi23-dialog__btn_primary font-r" @click="changeInvitationCode">确定</div>
          </div>
        </div>
        <div class="yclosetShade"></div>
      </div>

    </div>

    <div class="shareForBtn">
      <button class="btn btn-defult font-m" @click="shareFor">邀请好友</button>
    </div>

    <yi23Toast v-model="toastMsg"></yi23Toast>

    <WXbg v-model="shareForImg"></WXbg>

  </div>
</template>
<script>
import goBack from "base/GoBack";
import { rewardList } from "api/event";
import { getShareForNewUserImage, changeInvitationCode } from "api/share";
import { toastMixin } from "common/js/mixin";
import shareMixin from "@/mixins/share";
import WXbg from "base/WXbg";
import common from "@/common/js/common";

export default {
  mixins: [toastMixin, shareMixin],
  data() {
    return {
      currentIndex: 0,
      shareImageCache: [],
      shareForImg: false,
      shareForMa: false,
      rewardList: null,
      changeCodeInput: "",
      invitationCode: null,
      swiperOption: {
        grabCursor: true,
        loop: true,
        initialSlide: 0,
        slidesPerView: 1,
        paginationClickable: true,
        spaceBetween: 10,
        pagination: {
          el: ".swiper-pagination"
        }
      },
      slides: [
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-51.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-52.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-53.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-54.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-55.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-56.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-57.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-58.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-59.jpg",
        "https://yimg.yi23.net/webimg/web_source/Home/Common/images/shareForNew/20180320-60.jpg"
      ]
    };
  },
  components: {
    goBack,
    WXbg
  },
  created() {
    let _t = this;

    this.checkLogin(this.getShareInfo);
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.swiper;
    }
  },
  methods: {
    checkLogin(callBack) {
      let _t = this;

      let clientKey = common.getCookie("client_key", true);
      let auth = common.getCookie("authorization");

      if (clientKey || auth) {
        callBack && callBack.apply(_t, [0, true]);
      } else {
        window.location.href =
          "/yi23/Home/User/loginPage?redirect=" + this.$route.fullPath;
      }
    },
    getParams() {
      let clientKey = common.getCookie("client_key", true);
      let params = {};
      if (clientKey) {
        params["clientKey"] = clientKey;
      }
      return params;
    },
    myorderlist() {
      this.$router.push({
        path: "/Event/RedPacketList?jumpNativeType=50"
      });
    },
    orderTop10() {
      this.$router.push({
        path: "/Index/postingPage?id=7245&jumpNativeType=20&jumpNativeId=7245"
      });
    },
    initRewardList() {
      rewardList().then(res => {
        console.log(res);
        this.rewardList = res.data.uinfo;
      });
    },
    getSwiperIndex() {
      let index = this.swiper.realIndex;
      this.getShareInfo(parseInt(index));
    },
    getShareInfo(index, initstatus) {
      //************ /

      let params = this.getParams();

      params["index"] = index + 1;

      //************ /

      getShareForNewUserImage(params).then(res => {
        if (res && res.code == 200) {
          if (initstatus) {
            this.invitationCode = res.data.invitationCode;
          }

          let data = {
            title: res.data.title,
            url: res.data.link,
            shareType: "1",
            message: res.data.desc,
            image: res.data.bgImg,
            thumb_pic: res.data.imgUrl
          };

          this.setShareMessage(data);
        }
      });
    },
    shareFor() {
      if (this.$clientType == 1 || this.$clientType == 2) {
        this.doShare();
      } else {
        this.shareForImg = true;
      }
    },
    changeInvitationCode() {
      let params = this.getParams();

      params["code"] = this.changeCodeInput;

      if (params["code"].length < 6) {
        this.setToastMsg("请至少输入6位邀请码");
      } else {
        changeInvitationCode(params).then(res => {
          if (res.code == 200) {
            this.shareForMa = false;
            this.invitationCode = this.changeCodeInput;
            this.changeCodeInput = "";
          } else {
            this.setToastMsg(res.msg);
          }
        });
      }
    }
  }
};
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
@import "~common/less/variable";
.shareForBtn {
  display: block;
  width: 100%;
  button {
    width: 100%;
    .height(44);
    color: #fff;
    .font-size(14);
  }
}
.NE {
  position: absolute;
  width: 100%;
  height: 1.333333rem;
  bottom: -0.4rem;
  left: 0;
  text-align: center;
  z-index: 2;
}

.shareConStepTitle {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  width: 100%;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  background: #fff;
}
.shareConStepTitle h2.Title {
  display: table;
  white-space: nowrap;
  width: 90%;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  line-height: 1.77;
  letter-spacing: 0.037333rem;
  text-align: center;
  color: #000;
  padding-top: 1.6rem;
}

.shareConStepTitle h2.Title i {
  padding: 0 0.533333rem;
  font-style: normal;
  font-size: 0.853333rem;
  color: #000;
}

.shareConStepTitle p {
  width: 100%;
  text-align: center;
  font-size: 0.533333rem;
  color: #999;
}

.shareConStepTitle ul.stepList {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  width: 100%;
  padding: 0 1.6rem;
  margin: 1.066667rem 0 0.533333rem 0;
}

.shareConStepTitle ul.stepList li .stepICON {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  width: 1.386667rem;
  height: 1.28rem;
  margin-bottom: 0.373333rem;
}

.shareConStepTitle ul.stepList li .P1 {
  font-size: 0.64rem;
  line-height: 2;
  color: #333;
}

.shareConStepTitle ul.stepList li .P2 {
  font-size: 0.533333rem;
  color: #999;
}

ul.meunList {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  width: 100%;
  background: #fff;
  // margin-bottom: 2.56rem;
  border-top: 10px #f7f7f7 solid;
  border-bottom: 10px #f7f7f7 solid;
}

ul.meunList li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  height: 3.2rem;
  width: 100%;
  margin: 0 1.333333rem;
  font-size: 0.746667rem;
  border-bottom: 1px rgba(0, 0, 0, 0.1) solid;
}

ul.meunList li .yi23iconfont {
  color: #dedede;
}

ul.meunList li:last-of-type {
  border: none;
}

.shareConStepTitle h2.Title:after,
.shareConStepTitle h2.Title:before {
  border-top: solid 1px rgba(0, 0, 0, 0.04);
  content: "";
  display: table-cell;
  position: relative;
  top: 0.8rem;
  width: 45%;
  height: 1.066667rem;
}

.shareConStepTitle ul.stepList li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  width: 4.533333rem;
  height: 70px;
  padding: 0.533333rem 0;
  margin-bottom: 1.066667rem;
  position: relative;
  border: 1px solid rgba(0, 0, 0, 0.1);
}

img {
  display: block;
  width: 100%;
}

.yi23-dialog__ft {
  display: flex;
  width: 100%;
  .font-size(12);
  .height(70);
}

.yi23-dialog__btn:after {
  .height(14);
  top: 26px;
}

.rewardShare {
  width: 100%;
  img {
    width: 100%;
  }
}

.CustomizedMa {
  height: auto;
  .padding(20, 0, 0, 0);
  width: 80%;
  background-color: #fff;
  h2 {
    .font-size(16);
    color: #666;
    line-height: 4;
    width: 100%;
    text-align: center;
  }
  input.ma {
    .font-size(14);
    .height(60);
    width: 100%;
    .margin(0, 40, 10, 40);
    border-bottom: 1px #e5e5e5 solid;
  }
}
.swiper-container {
  margin: 0 27px;
}
.swiper-button-next,
.swiper-container-rtl .swiper-button-prev {
  background: url(//tu.95vintage.com/web_source/Home/Common/images/shareForNew/20170628-btn-r.svg);
}

.swiper-button-prev,
.swiper-container-rtl .swiper-button-next {
  background: url(//tu.95vintage.com/web_source/Home/Common/images/shareForNew/20170628-btn-l.svg);
}

.swiper-button-next,
.swiper-button-prev {
  height: 29px;
  width: 29px;
}

.swiper-slide {
  // .width(300);
  img {
    .width(300);
    .height(306);
  }
}

.slideIMG {
  // .width(300);
  .height(0);
  padding-bottom: 102.3125%;
  position: relative;
  overflow: hidden;
  img {
    width: 100%;
    position: absolute;
  }
  // padding-bottom: 95.3125%;
}

.image-ratio {
  background-color: transparent;
}

.Reward {
  display: flex;
  width: 100%;
  flex-wrap: wrap;

  .SeeReward {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    width: 100%;
    .padding(0, 12, 0, 0);
    line-height: 4;
    .font-size(12);
    color: #222;
    i {
      .font-size(5);
      .padding(0, 0, 0, 3);
    }
  }
  h2,
  h3,
  h4,
  h5 {
    text-align: center;
    width: 100%;
    line-height: 1.5;
    i {
      color: @color-bz-red;
      font-style: normal;
    }
  }
  h2 {
    .font-size(24);
  }
  h3 {
    color: #999;
    .font-size(12);
  }
  .RewardForIMG {
    width: 100%;
    .height(306);
    .margin(20, 0, 20, 0);
    box-sizing: border-box;
  }
  .shareForBtn {
    display: block;
    width: 100%;
    position: fixed;
    z-index: 10;
    left: 0;
    bottom: 0;
    button {
      width: 100%;
      .height(44);
      color: #fff;
      .font-size(14);
    }
  }
  .or {
    .padding(0, 20, 20, 20);
    width: 100%;
    .Title {
      display: table;
      white-space: nowrap;
      .margin(15, 0, 0, 0);
      p {
        .padding(0, 10, 0, 10);
        .font-size(14);
        color: #ccc;
      }
    }
    & .Title:before,
    & .Title:after {
      border-top: 1px solid rgba(0, 0, 0, 0.1);
      content: "";
      display: table-cell;
      position: relative;
      .top(8);
      width: 50%;
    }
    & .Title:before {
      right: 0.5%;
    }
    & .Title:after {
      left: 0.5%;
    }
  }
  h4 {
    .font-size(18);
    color: #000;
  }
  h5 {
    .font-size(12);
    color: #666;
    .line-height(26);
    font-style: normal;
  }
  .sharForMA {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    .margin(20, 20, 0, 20);
    flex-wrap: wrap;
    background-color: #f7f7f7;
    span {
      display: flex;
      .line-height(56);
      .font-size(12);
      .padding(0, 10, 0, 10);
      display: flex;
      justify-content: center;
      align-items: center;
    }
    span.Left {
      justify-content: flex-start;
      color: #111;
    }
    span.Right {
      justify-content: flex-end;
      i.icon-right {
        .font-size(10);
      }
    }
  }
  .RewardInformation {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    width: 100%;
    .padding(20, 20, 20, 20);
    background: #f7f7f7;
    .InformationTitle {
      width: 100%;
      display: flex;
      align-items: center;
      .font-size(16);
      color: #000;
      .height(40);
      p {
        display: flex;
        align-items: center;
        .font-size(10);
        .padding(0, 0, 0, 10);
      }
    }
    ol.InformationList {
      .font-size(12);
      .margin(10, 0, 0, 0);
      .padding(0, 0, 0, 14);
      li {
        color: #999;
        list-style-type: decimal;
        line-height: 1.6;
        text-align: left;
        .padding(0, 0, 0, 2);
        .margin(0, 0, 15, 0);
      }
    }
    ol.InformationList:last-child {
      li {
        border-bottom: 1px #eee solid;
        .padding(0, 0, 20, 0);
        .liIMG01,
        .liIMG02,
        .liIMG03 {
          width: 100%;
          height: 0;
          position: relative;
          padding-bottom: 141.1311%;
          overflow-y: hidden;
          .margin(10, 0, 0, 0);
          img {
            width: 100%;
            position: absolute;
            display: block;
          }
        }
        .liIMG02 {
          padding-bottom: 172.4%;
        }
        .liIMG03 {
          padding-bottom: 155.4666%;
        }
      }
      li:last-child {
        border-bottom: none;
      }
    }
  }
}
</style>
