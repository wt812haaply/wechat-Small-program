<template>

  <div class="clothes">
    <div class="wrapper">
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index01_clothes.png?version=1.4">
      </div>
      <div class="imgplaceholder image-normal">
        <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/index02_clothes.png?version=1.4">
      </div>
      <div class="inConIMG image-ratio">
          <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/user01_03.jpg">
      </div>

      <!-- 内容区 -->
      <div class="inner">
        <div class="iconTitle"><p>领取礼包</p></div>
        <div class="userConCouponList">
          <ul>
            <!-- 加衣碎片 -->
            <li>
              <div class="left">
                <p>加衣券碎片</p>
              </div>
              <div class="right">
                <p>0.2<i>张</i></p>
              </div>
            </li>
            <!-- 新人立减 -->
            <li>
              <div class="left">
                <p>新人立减</p>
              </div>
              <div class="right">
                <p>200<i>¥</i></p>
              </div>
            </li>
            <!-- 新人优惠券 -->
            <li>
              <div class="left">
                <p>新人优惠券</p>
                <span>2018/1/1 19:00到期</span>
              </div>
              <div class="right">
                <p>50<i>¥</i></p>
              </div>
            </li>
            <li>
              <div class="left">
                <p>续费优惠券</p>
                <span>2018/1/1 19:00到期</span>
              </div>
              <div class="right">
                <p>50<i>¥</i></p>
              </div>
            </li>
          </ul>
          <!-- 活动结束 -->
          <div class="completion">
            Sorry，你来迟了，加衣券已被抢光
          </div>
          <!-- 改变手机号 -->
          <div class="changemobile">
            已放入账号：15313080725<i>修改</i>
          </div>
          <!-- 查看我的碎片 -->
          <div class="clothesbtn">
            查看我的碎片
          </div>
        </div>
        <div class="titleCon what">
          <img src="https://yimg.yi23.net/webimg/20180420/frontpage//TITLE.png">
        </div>
        <div class="what_inner">
          <div class="placeholder">
            <ol type="1" class="rules-con">
                <li>下单成功后分享【礼包】给好友，一起领取加衣券碎片</li>
                <li>加衣券碎片将自动兑换成加衣券，衣箱3件变4件</li>
                <li>礼包被越多人领取，分享者可获得越多额外奖励</li>
            </ol>
          </div>
        </div>
        <div class="titleCon top">
          <img src="https://yimg.yi23.net/webimg/20180420/frontpage//TOP.png">
        </div>
        <div class="top_list">
          <div class="item">
            <img  class="avatar" src="">
            <div class="user">
              <div class="nickname">luna</div>
              <p>何以解忧，唯有美衣</p>
            </div>
            <div class="right">
              <span>12-23 09:00</span>
              <p>0.2<i>张</i></p>
            </div>
          </div>
          <div class="item">
            <img  class="avatar" src="">
            <div class="user">
              <div class="nickname">luna</div>
              <p>何以解忧，唯有美衣</p>
            </div>
            <div class="right">
              <span>12-23 09:00</span>
              <p>0.2<i>张</i></p>
            </div>
          </div>
        </div>
        <div class="titleCon top">
          <img src="../../common/image/GZ.png">
        </div>
        <div class="rules_inner">
          <ol>
            <li>每份礼包中一人只能领取一次，获得的奖励可能为现金券或加衣券碎片，金额随机抽取。</li>
            <li>加衣券碎片需要累积满一张后，才可在衣箱中使用。</li>
            <li>现金券可在支付时抵扣现金，需在有效期内使用。</li>
            <li>领取红包并注册成为会员后，可与分享者各自获得50元现金奖励，现金奖励可在衣二三服务号中领取。</li>
          </ol>
        </div>
        <mini-program-q-r></mini-program-q-r>
      </div>
    </div>
    <down-app
      :show="downApp.show"
      ></down-app>
  </div>

</template>

<script type="text/ecmascript-6">
import MiniProgramQR from 'base/MiniProgramQR';
import DownApp from 'base/DownApp';

export default {
  data(){
    return{
      downApp:{
        show: false
      }
    }
  },
  components:{
    MiniProgramQR,
    DownApp
  },
  mounted(){

    window.addEventListener('scroll', () => {
      var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
      if(scrollTop >= 100){
        this.downApp.show = true;
      }else{
        this.downApp.show = false;
      }
    })

  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .clothes{
    -webkit-font-smoothing: antialiased;
    font-weight: @font-weight;
    min-height: 100%;
    .wrapper{
      position: relative;
      .imgplaceholder{
        width: 100%;
        height: 0;
        padding-bottom: 78%;
        position: relative;
        img{
          display: block;
          width: 100%;
          position: absolute;
          left: 0;
          top: 0;
          height: 100%;
        }
      }
      .inner{
        margin-top: -40rem;
        position: relative;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        .iconTitle{
          display: flex;
          white-space: nowrap;
          width: 70%;
          font-size: 0.693333rem;
          line-height: 1.77;
          letter-spacing: 0.7px;
          color: #ffffff;
          height: 1.6rem;
          p{
            padding: 0 10px;
          }
          &:after,&:before{
            border-top: .026667rem solid rgba(255,255,255,.8);
            content: '';
            display: table-cell;
            position: relative;
            top: 10px;
            top: 0.63rem;
            width: 45%;
            height: 1.066667rem;
          }
        }
        .userConCouponList{
          width: 100%;
          box-sizing: border-box;
          padding: 0 33px;
          .completion{
            width: 100%;
            height: 5.12rem;
            font-size: 0.853333rem;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff;
            color: #b63a3e;
          }
          .changemobile{
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 13px;
            margin: 17px 0 30px 0;
            i{
              font-style: normal;
              width: 52px;
              box-sizing: border-box;
              height: 24px;
              border: 1px solid #fff;
              text-align: center;
              line-height: 24px;
              border-radius: 2px;
              margin-left: 10px;
            }
          }
          .clothesbtn{
            height: 2.666667rem;
            line-height: 2.666667rem;
            width: 100%;
            background: #B63A3E;
            font-size: 0.853333rem;
            color: #fff;
            text-align: center;
            border-radius: 0.106667rem;
          }
          li{
            width: 100%;
            display: flex;
            margin-bottom: 10px;
            .left{
              width: 9.973333rem;
              height: 5.12rem;
              .bg-image('invalid-name');
              background-size: cover;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              color: #b63a3e;
              p{
                font-size: 0.96rem;
              }
              span{
                font-size: 10px;
                margin-top: 5px;
              }
            }
            .right{
              flex:1;
              height: 5.12rem;
              background: url('https://yimg.yi23.net/webimg/20180420/frontpage//spanRight.png') no-repeat;
              background-size: cover;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 1.6rem;
              color: #fff;
              i{
                font-size: 0.746667rem;
                font-style: normal;
                margin-left: 4px;
              }
            }
          }
        }
        .titleCon{
          width: 6.4rem;
          height: 3.2rem;
          padding: 1.6rem 0;
          margin-top: 1.066667rem;
          img{
            display: block;
            width: 100%;
          }
        }
        .what_inner{
          width: 100%;
          padding: 0 15px;
          box-sizing: border-box;
          .placeholder{
            border: 1px solid #fff;
            ol{
              border: 3px solid #e19d60;
              background: #fff;
              padding: 1.066667rem 1.066667rem 1.066667rem 1.6rem;
              font-size: 14px;
            	line-height: 1.64;
            	letter-spacing: 0.2px;
              color:#b63a3e;
              li{
                list-style: decimal;
              }
            }
          }
        }
        .top_list{
          width: 100%;
          box-sizing: border-box;
          padding: 0 20px;
          color: #fff;
          .item{
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            &:last-child{
              margin-bottom: 0;
            }
          }
          img{
            display: block;
            width: 40px;
            height: 40px;
            border-radius: 50%;
          }
          .user{
            flex: 1;
            margin-left: 15px;
            .nickname{
              width: 100%;
              font-size: 15px;
              line-height: 21px;
            }
            p{
              font-size: 13px;
            }
          }
          .right{
            font-size: 11px;
            span{
              line-height: 21px;
            }
            p{
              font-size: 15px;
              text-align: right;
              color: #b63a3e;
              i{
                font-style: normal;
              }
            }
          }
        }
        .rules_inner{
          width: 100%;
          box-sizing: border-box;
          padding: 0 20px 0 33px;
          color: #fff;
          font-size: 12px;
          margin-bottom: 50px;
          li{
            line-height: 1.56;
            list-style: decimal;
          }
        }
      }
    }
  }

  @keyframes bounce {
    0%, 20%, 50%, 80%{
      -webkit-transform: translate(-50%, 0);
              transform: translate(-50%, 0);
    }
    40% {
      -webkit-transform: translate(-50%,-10px);
              transform: translate(-50%,-10px);
    }
    60% {
      -webkit-transform: translate(-50%,-5px);
              transform: translate(-50%,-5px);
    }
  }

  .slide-bottom-enter-active,.slide-bottom-leave-active{
    transition: all .3s;
  }

  .slide-bottom-enter,.slide-bottom-leave-to{
    opacity: 0;
    transform: translateY(100%);
  }
</style>
