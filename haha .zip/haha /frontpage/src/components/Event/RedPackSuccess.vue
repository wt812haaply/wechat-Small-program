<template lang="html">
  <div class="success">
    <div class="paymessage"><i><img src="https://yimg.yi23.net/webimg/20180420/frontpage//okimg.svg"/></i>下单成功!</div>
    <div class="content">
      <div class="banner"><img src="https://tu.95vintage.com/web_source/Home/Common/images/20180110001/images/orderBanner.jpg?version=1.3" /></div>
      <div class="inner">
        <div class="context">
          <div class="sharebtn">
            <button>分享给好友</button>
          </div>
          <div class="text">
            <h6>奖励规则</h6>
            <div>

              <ol>
                <li>将礼包分享给微信好友或分享至朋友圈，和好友一起瓜分礼包，共获奖励。</li>
                <li>每个礼包可由10个领取，每人获得的金额随机。</li>
                <li>根据领取人数的多少，您将额外获得奖励金额，奖励金额在24小时后自动放入您的账户中：<br>a.有X人领取，分享者将会获得X个加衣券;<br>b.有X人领取，分享者将会获得X个加衣券。</li>
                <li>若好友领取红包并成为衣二三会员，您与好友将各自得到50元现金奖励。</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" style="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.success{
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
}
.paymessage{
  font-size: 18px;
  font-weight: 500;
  padding-top: 30px;
  padding-bottom: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  i{
    display: inline-block;
    width: 1.27027rem /* 23.5/18.5 */;
    height: 1.27027rem /* 23.5/18.5 */;
    vertical-align: middle;
    margin-right: 4.5px;
    img{
      width: 100%;
      height: 100%
    }
  }
}
.banner{
  width: 100%;
  box-sizing: border-box;
  padding: 0 .810811rem /* 15/18.5 */;
  font-size: 0;
  img{
    width: 100%;
  }
}
.inner{
  width: 100%;
  box-sizing: border-box;
  padding: 0 .810811rem /* 15/18.5 */;
  .context{
    background: #fff;
    padding-bottom: 18px;
    .sharebtn{
      text-align: center;
      padding-top: 39px;
      padding-bottom: 44px;
      button{
        width: 127px /* 127/18.5 */;
        height: 32px /* 32/18.5 */;
        background: #ff544b;
        font-size: 13px /* 13/18.5 */;
        font-weight: 500;
        color: #ffffff;
      }
    }
    .text{
      text-align: center;
      font-size: 13px;
      line-height: 1.54;
      color: #333333;
      width: 100%;
      h6{
        font-size: 13px;
        color: #333333;
        margin-bottom: 10px;
      }
      div{
        ol{
          padding-left: 26px;
          padding-right: 10px;
          li{
            list-style: decimal;
            font-size: 12px;
            line-height: 1.5;
            text-align: left;
            color: #111111;
	          font-weight: 300;
          }
        }
      }
    }
  }
}
</style>
