<template>
  <div>错误页面（500 等错误）</div>
</template>

<script>
    export default {
        name: "pageError"
    }
</script>

<style scoped>

</style>
