<template>
  <div>404页面</div>
</template>

<script>
    export default {
        name: "page404"
    }
</script>

<style scoped>

</style>
