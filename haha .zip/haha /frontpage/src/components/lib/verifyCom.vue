<template>
  <div>
    <!-- 验证码容器 -->
    <components v-if="componentType"
                :is="componentType"
                :type="verifyType"
                :width="width"
                :height="height"
                :vOffset="vOffset"
                :explain="explain"
                :blockSize="blockSize"
                :barSize="barSize"
    >
    </components>
  </div>
</template>
<script >
  import VerifySlide from './verify/verifySlide'

  export default {
    name: 'Vue2Verify',
    props: {
      type: {
        type: String | Number,
        require: false,
        default: 'picture'
      },
      width: {
        type: String
      },
      height: {
        type: String
      },
      vOffset: {
        type: Number
      },
      explain: {
        type: String
      },
      blockSize: {
        type: Object
      },
      barSize: {
        type: Object
      },
    },
    data() {
      return {
        // 内部类型
        verifyType: undefined,
        // 所用组件类型
        componentType: undefined
      }
    },
    methods: {
    },
    computed: {

    },
    watch: {
      type: {
        immediate: true,
        handler(type) {
          switch (type.toString()) {
            case '3':
              this.verifyType = '1'
              this.componentType = 'VerifySlide'
              break
            default:
              this.verifyType = undefined
              this.componentType = undefined
              console.error('Unsupported Type:' + type)
          }
        }
      }
    },
    components: {
      VerifySlide
    }
  }
</script>
