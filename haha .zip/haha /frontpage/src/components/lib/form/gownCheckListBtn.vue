<template>
  <section class="yi23-checklist checklist-bd" @change="$emit('change', currentValue)">
    <div class="checklist-bd1" ref="checkListBd">
      <label :class="{'yi23-checkList-label':true,size:isSquare}" v-for="option in options" :key="option.filterId">
        <input type="checkbox"
               class="yi23-checkbox-input"
               :value="name?(option[name]=='均码'?'F':option[name]):option.filterId"
               :name="option.filterName?option.filterName:option"
               :disabled="option.disabled"
               v-model="currentValue"
        />
        <div class="yi23-checkbox-core">
          <div class="label-color-box" v-if="rowType || rowType == 1" >
            <div class="label-color" v-bind:style="{background :`rgb(${option.filterRGB})`}">
              <!--{{option.filterRGB}}-->
            </div>
          </div>
          <div class="label" v-else>
            {{option.filterName?option.filterName:option}}
          </div>
        </div>
      </label>
    </div>
  </section>
</template>

<script>
  /**
   * checklist
   * @module components/lib/form/checklist
   *
   * @param {(string[]|object[])} options - 选项数组，可以传入 [{label: 'label', value: 'value', disabled: true}] 或者 ['ab', 'cd', 'ef']
   * @param {string[]} value - 选中值的数组
   * @param {string} title - 标题
   * @param {number} [max] - 最多可选的个数
   *
   *
   * @example
   * <yi23-checkList :v-model="value" :options="['a', 'b', 'c']"></yi23-checkList>
   */
    export default {
        name: "yi23-checklist-btn",
        props:{
          max: Number,
          name:String,
          title: String,
          isSquare:Boolean,
          options: {
            type: Array,
            required: true
          },
          value: Array,
          rowType: String,
        },
        computed:{
          limit () {
              return this.max<this.currentValue.length
          },
          initHide () {
            return this.options.length>8
          },
//          revertFilter () {
//            this.$emit('revertFilter')
//          }
        },
        created(){

        },
        methods:{
          openBox () {
            if(this.isHide){
              this.isHide=false
            }else{
              this.isHide=true
            }
          }
        },
        watch:{
          value (val){
            this.currentValue=val
          },
          currentValue (val){
//            console.log('-------------')
//            console.log(val)
            this.$emit('input',val)
            this.$emit('submitFilter')
          },

        },
        mounted (){
        },
        data () {
          return {
            isHide:true,
            currentValue: this.value
          }
        }

    }
</script>

<style scoped lang="less">
  *{box-sizing: border-box;}
  .checklist-bd::-webkit-scrollbar{ display:none; } .checklist-bd::-webkit-scrollbar-track{ display:none; } .checklist-bd::-webkit-scrollbar-thumb{ display:none; }

  .yi23-checklist{
    header{
      margin-left:2%;
      font-size: 14px;
      line-height: 2.8;
      font-weight: 500;
      display: flex;
      justify-content:space-around;
      div{
        width: 100%;
        flex: 1;
      }
      .rightBox{
        text-align: right;
        i{
          font-size: 12px;
        }
      }
    }
      /*width: 100%;*/
      padding: 10px 0;
      overflow: hidden;
      font-size: 12px;
      color: #000000;
    overflow-x: auto;
    width: auto;
      position: relative;
      border-bottom: 1px solid #fafafa;
      .checklist-bd1.hideBd{
        max-height: 1.4rem;
      }
      .checklist-bd1{
        /*transition: max-height 1s;*/
        max-height: 1.4rem;
        /*overflow:-webkit-paged-x;*/
        width: max-content;
        .yi23-checkList-label.size{
          /*width: 50px;*/
        }
        .yi23-checkList-label{
          /*width:18vw;*/
          margin:0 0px 0 20px;
          border-radius:3px;
          /*padding: 0 10px;*/
          display: inline-block;
          font-size:12px;
          line-height: 2;
          text-align:center;
          /*background:#fafafa;*/
          color:#666;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap;
          word-wrap:normal;
          .yi23-checkbox-core{

          }
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label{
            color: #ffffff;
            background: #000;
            padding: 0 25px 0 10px;
            border-radius: 20px;
            animation-name: zoomIn;
            animation-duration: .3s;
            animation-fill-mode: both;
            position: relative;

          }
          .label-color-box{
            width: 1rem;
            height: 1rem;
            display: flex;
            align-items: center;
            justify-content:center;
          }
          .yi23-checkbox-core .label-color{
            border-radius: 50%;
            border:1px solid #efefef;
            width: .8rem;
            height: .8rem;
          }
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label-color-box{
            background: white;
            border-radius: 55%;
            border: 1px solid #9DBCCA;
          }
          /*.yi23-checkbox-input:checked + .yi23-checkbox-core .label-color{*/
            /*border-radius: 50%;*/
            /*border: 1px solid #9DBCCA;*/
            /*!*padding: 3px;*!*/
            /*box-shadow:0px 0px .4rem  #FFFFFF inset;*/
            /*animation-name: zoomIn;*/
            /*animation-duration: .3s;*/
            /*animation-fill-mode: both;*/
          /*}*/
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label:after,.yi23-checkbox-input:checked + .yi23-checkbox-core .label:before{
            content: '';
            position: absolute;
            width: 2px;
            height:40%;
            background: white;
            top:30%;
            right:18%;
          }
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label:after{
            transform:rotate(45deg);
          }
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label:before{
            transform:rotate(-45deg);
          }
        }
        .yi23-checkbox-input{
          display: none;
        }
      }
  }

  @keyframes zoomIn {
    from {
      opacity: 0;
      transform: scale3d(0.3, 0.3, 0.3);
    }
    50% {
      opacity: 1;
    }
  }


</style>
