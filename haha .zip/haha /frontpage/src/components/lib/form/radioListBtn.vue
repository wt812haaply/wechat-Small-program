<template>
  <section class="yi23-checklist" @change="$emit('change', currentValue)">
    <header>{{title}}</header>
    <div class="checklist-bd">
      <label class="yi23-checkList-label" v-for="option in options" :key="option.filterId">
        <input type="radio"
               class="yi23-checkbox-input"
               :value="option.filterId || option"
               :disabled="option.disabled"
               v-model="currentValue"
        />
        <div class="yi23-checkbox-core">
          <div class="label">
            {{option.filterName?option.filterName:option}}
          </div>
        </div>
      </label>
    </div>
  </section>
</template>

<script>
  /**
   * checklist
   * @module components/lib/form/checklist
   *
   * @param {(string[]|object[])} options - 选项数组，可以传入 [{label: 'label', value: 'value', disabled: true}] 或者 ['ab', 'cd', 'ef']
   * @param {string[]} value - 选中值的数组
   * @param {string} title - 标题
   * @param {number} [max] - 最多可选的个数
   *
   *
   * @example
   * <yi23-checkList :v-model="value" :options="['a', 'b', 'c']"></yi23-checkList>
   */
    export default {
        name: "yi23-radiolist-btn",
        props:{
          title: String,
          options: {
            type: Array,
            required: true
          },
          value: Number
        },
        computed:{
          limit () {
              return this.max<this.currentValue.length
          }
        },
        watch:{
          value (val){
            this.currentValue=val
          },
          currentValue (val){
            this.$emit('input',val)
          },
        },
        data () {
          return {
            currentValue: this.value
          }
        }

    }
</script>

<style scoped lang="less">
  *{box-sizing: border-box;}
  .yi23-checklist{
      header{
        margin-left:2%;
        font-size: 14px;
        line-height: 2.8;
        font-weight: 500;
      }
      width: 100%;
      padding: 0 10px;
      overflow: hidden;
      font-size: 12px;
      color: #111;
      position: relative;
      .checklist-bd{
        overflow: hidden;
        display: flex;

        .yi23-checkList-label{
          width:23%;
          margin:0 0 2% 2%;
          border-radius:3px;
          border: 1px #fafafa solid;
          float:left;
          font-size:12px;
          line-height: 3;
          position:relative;
          text-align:center;
          color:#333;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap;
          word-wrap:normal;
          .yi23-checkbox-core{

          }
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label{
            color: #ff544b;
            border: 1px #ff544b solid;
            animation-name: zoomIn;
            animation-duration: .3s;
            animation-fill-mode: both;
          }
        }
        .yi23-checkbox-input{
          display: none;
        }
      }
  }

  @keyframes zoomIn {
    from {
      opacity: 0;
      transform: scale3d(0.3, 0.3, 0.3);
    }
    50% {
      opacity: 1;
    }
  }


</style>
