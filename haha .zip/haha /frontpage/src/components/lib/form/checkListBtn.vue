<template>
  <section class="yi23-checklist" @change="$emit('change', currentValue)">
    <header @click="openBox"><div>{{title}}</div><div v-show="initHide" class="rightBox"><i class="icon yi23iconfont icon-down"></i></div></header>
    <div :class="{'checklist-bd':true,hideBd:(isHide && initHide)}" ref="checkListBd">
      <label :class="{'yi23-checkList-label':true,size:isSquare}" v-for="(option, index) in options" :key="index">
        <input type="checkbox"
               class="yi23-checkbox-input"
               :value="name?(option[name]=='均码'?'F':option[name]):option.filterId"
               :disabled="option.disabled"
               v-model="currentValue"
        />
        <div class="yi23-checkbox-core">
          <div class="label">
            {{option.filterName?option.filterName:option}}
          </div>
        </div>
      </label>
    </div>
  </section>
</template>

<script>
  /**
   * checklist
   * @module components/lib/form/checklist
   *
   * @param {(string[]|object[])} options - 选项数组，可以传入 [{label: 'label', value: 'value', disabled: true}] 或者 ['ab', 'cd', 'ef']
   * @param {string[]} value - 选中值的数组
   * @param {string} title - 标题
   * @param {number} [max] - 最多可选的个数
   *
   *
   * @example
   * <yi23-checkList :v-model="value" :options="['a', 'b', 'c']"></yi23-checkList>
   */
    export default {
        name: "yi23-checklist-btn",
        props:{
          max: Number,
          name:String,
          title: String,
          isSquare:Boolean,
          options: {
            type: Array,
            required: true
          },
          value: Array
        },
        computed:{
          limit () {
              return this.max<this.currentValue.length
          },
          initHide () {
            return this.options.length>8
          }
        },
        methods:{
          openBox () {
            if(this.isHide){
              this.isHide=false
            }else{
              this.isHide=true
            }
          }
        },
        watch:{
          value (val){
            this.currentValue=val
          },

          currentValue (val){
            this.$emit('input',val)
          },
        },
        mounted (){
        },
        data () {
          return {
            isHide:true,
            currentValue: this.value
          }
        }

    }
</script>

<style scoped lang="less">
  *{box-sizing: border-box;}
  .yi23-checklist{
    header{
      margin-left:2%;
      font-size: 14px;
      line-height: 2.8;
      font-weight: 500;
      display: flex;
      justify-content:space-around;
      div{
        width: 100%;
        flex: 1;
      }
      .rightBox{
        text-align: right;
        i{
          font-size: 12px;
        }
      }
    }
      width: 100%;
      padding: 0 10px;
      overflow: hidden;
      font-size: 12px;
      color: #000000;
      position: relative;
      .checklist-bd.hideBd{
        max-height:85px;
        height: 85px;
      }
      .checklist-bd{
        transition: max-height 1s;
        max-height: 500px;
        overflow: hidden;
        .yi23-checkList-label.size{
          width: 50px;
          line-height: 50px;
        }
        .yi23-checkList-label{
          width:23%;
          margin:0 0 10px 2%;
          border-radius:3px;
          float:left;
          font-size:12px;
          line-height: 3;
          position:relative;
          text-align:center;
          background:#fafafa;
          color:#333;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap;
          word-wrap:normal;
          .yi23-checkbox-core{

          }
          .yi23-checkbox-input:checked + .yi23-checkbox-core .label{
            color: #ffffff;
            background: #ff544b;
            animation-name: zoomIn;
            animation-duration: .3s;
            animation-fill-mode: both;
          }
        }
        .yi23-checkbox-input{
          display: none;
        }
      }
  }

  @keyframes zoomIn {
    from {
      opacity: 0;
      transform: scale3d(0.3, 0.3, 0.3);
    }
    50% {
      opacity: 1;
    }
  }


</style>
