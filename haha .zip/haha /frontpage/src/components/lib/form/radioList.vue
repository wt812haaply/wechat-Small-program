<template>
    <div class="yi23-radiolist" @change="$emit('change', currentValue)">
      <dl>
        <dt v-text="title">{{title}}</dt>
        <dd v-for="option in options" :key="option.value?option.value:option" class="">
          <label class="yi23-radiolist-label">
            <slot name="leftBox" :option="option"> </slot>
            <span class="yi23-checkbox is-right">
              <input type="radio"
                     class="yi23-checkbox-input"
                     :value="option.value || option"
                     :disabled="option.disabled"
                     v-model="currentValue"
              />
              <span class="yi23-checkbox-core"></span>
            </span>
            <slot name="rightBox" :option="option"></slot>
          </label>
        </dd>
      </dl>
    </div>
</template>

<script>
  /**
   * radiolist
   * @module components/lib/form/radiolist
   *
   * @param {(string[]|object[])} options - 选项数组，可以传入 [{label: 'label', value: 'value', disabled: true}] 或者 ['ab', 'cd', 'ef']
   * @param {string[]} value - 选中值的数组
   * @param {string} title - 标题
   *
   *
   * @example
   * <yi23-radiolist :v-model="value" :options="['a', 'b', 'c']"></yi23-radiolist>
   */
    export default {
        name: "yi23-radiolist",
        props:{
          title: String,
          align: String,
          options: {
            type: Array,
            required: true
          },
          value: String
        },
        watch:{
          value (val){
            this.currentValue=val
          },
          currentValue (val){
            this.$emit('input',val)
          },
        },
        data () {
          return {
            currentValue: this.value
          }
        }

    }
</script>

<style scoped lang="less">
  *{box-sizing: border-box;}
  .yi23-radiolist{
    width: 100%;
    font-size: 12px;
    line-height: 1.5;
    position: relative;
    dl{

    }
    dt,.yi23-radiolist-label{
      display: flex;
      align-items: center;
      justify-content: flex-start;
    }
    dt{
      color: #333;
      line-height: 2;
      font-size: 12px;
      background: #f6f6f6;
      &:after{
        content: " ";
        position: absolute;
        left: 0;
        bottom: 0;
        right: 0;
        height: 1px;
        border-bottom: 1px solid #f6f6f6;
        color: #f6f6f6;
        transform-origin: 0 100%;
        transform: scaleY(0.5);
      }
    }
    dd {
      position: relative;
      input{
        display: none
      }
      &:after{
        content: " ";
        position: absolute;
        left: 0;
        bottom: 0;
        right: 0;
        height: 1px;
        border-bottom: 1px solid #f6f6f6;
        color: #f6f6f6;
        transform-origin: 0 100%;
        transform: scaleY(0.5);
      }
      &:last-child:after{

        border: 0;
      }
    }

    .yi23-radiolist-label {
      padding: 0 10px;

      div{flex: 1}
    }
    .yi23-checkbox {}
    .yi23-checkbox.is-right {
      float: right;
    }


    .yi23-checkbox-input:checked + .yi23-checkbox-core {
      background-color: #ff544b;
      border-color: #ff544b;
    }
    .yi23-checkbox-input:checked + .yi23-checkbox-core::after {
      background-color: #fff;
      -webkit-transform: scale(1);
      transform: scale(1);
    }
    .yi23-checkbox-input[disabled] + .yi23-checkbox-core {
      background-color: #d9d9d9;
      border-color: #ccc;
    }
    .yi23-checkbox-core {
      display: inline-block;
      background-color: #fff;
      border-radius: 100%;
      border: 1px solid #ccc;
      position: relative;
      width: 20px;
      height: 20px;
      vertical-align: middle;
    }
    .yi23-checkbox-core::after {
      content: " ";
      border-radius: 100%;
      top: 5px;
      left: 5px;
      position: absolute;
      width: 8px;
      height: 8px;
      -webkit-transition: -webkit-transform .2s;
      transition: -webkit-transform .2s;
      transition: transform .2s;
      transition: transform .2s, -webkit-transform .2s;
      -webkit-transform: scale(0);
      transform: scale(0);
    }
  }

</style>
