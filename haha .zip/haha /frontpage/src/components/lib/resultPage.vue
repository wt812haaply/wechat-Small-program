<template>
  <!--成功-->
  <div class="eventResult" v-if="all">
      <div class="eventResultTitle"  >
        <slot name="eventResultTitle"></slot>
      </div>

      <div class="eventResultBtn" >
        <div class="BtnA"><slot name="BtnA">a1aaaa</slot></div>
        <div class="BtnB"><slot name="BtnB">bbbbbb</slot></div>
        <div class="BtnA"><slot name="BtnA">aaaaaaaa</slot></div>
      </div>

  </div>
</template>




<script>
  export default {
    data () {
      return {
      }
    },
    props: ['all'],
    methods:{
//      closeBox:function () {
//        this.$parent.result = true;
//      }
    },




  }
</script>




<style scoped lang="less">
  @import "~common/less/variable";


  /*兑换状态*/


  .eventResult{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;

    text-align: center;
    padding-top: 7.466667rem;
    width: 100%;

    /*状态抬头*/
    &Title{
      width: 100%;
      font-size: 1.066667rem;
      height: 3.2rem;
      display: flex;
      align-items: center;
      justify-content: center;

      i {
        width: 1.386667rem;
        height: 1.386667rem;
        position: relative;
        top: 0;
        right: 0.266667rem;

        img {
          width: 1.386667rem;
          position: absolute;
          left: 0;
          top: 0;
        }
      }
    }

    /*按钮*/
    &Btn{
      .BtnA{
        background: #ff544b;
        width: 10.773333rem;
        height: 2.133333rem;
        color: #fff;
        font-size: 0.746667rem;
      }
      .BtnB{
        margin-top: 1.066667rem;
        border: 1px #ff544b solid;
        background: transparent;
        color: #ff544b;
        background: #ff544b;
        width: 10.773333rem;
        height: 2.133333rem;
        color: #fff;
        font-size: 0.746667rem;
      }
    }
  }
</style>
