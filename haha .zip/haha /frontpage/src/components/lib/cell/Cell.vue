<template>
  <a :href="href" class="cell">
    <div class="cell-left">
      <slot name="left"></slot>
    </div>
    <div class="cell-wrapper">
      <div class="cell-title">
        <slot name="title">
          <span class="cell-text" :class="{maxFont:detail}" v-text="title"></span>
          <span class="cell-label" v-if="label" v-text="label"></span>
          <span class="cell-detail" v-if="detail" v-text="detail"></span>
        </slot>
      </div>
      <div class="cell-value" :class="{'is-link':isLink}">
        <slot>
            <span v-text="value"></span>
        </slot>
      </div>
      <i class="cell-allow-right" v-if="isLink"></i>
    </div>
    <div class="cell-right">
      <slot name="right"></slot>
    </div>
  </a>
</template>

<script>
    export default {
      name: "cell",
      data () {
        return { }
      },
      computed:{
        href () {
          if (this.to && !this.added && this.$router && typeof this.to == 'object') {
            const resolved = this.$router.match(this.to);
            if (!resolved.matched.length) return this.to;
            this.$nextTick(() => {
              this.added = true;
              this.$el.addEventListener('click', this.handleClick);
            });
            return resolved.fullPath || resolved.path;
          }
          return this.to;
        }
      },
      methods:{
        handleClick (_event) {
          _event.preventDefault();
          this.$router.push(this.href)
        }
      },
      props:{
        to:[String,Object],
        isLink:Boolean,
        title: String,
        label:String,
        detail:String,
        value:{}
      }
    }
</script>
<style scoped lang="less">
  .cell{
    display: block;
    color: #999999;
    width:100%;
    box-sizing: border-box;
    overflow: hidden;
    position: relative;
    text-decoration: none;
    &:first-child{
      .cell-wrapper{
        background-origin: border-box;
      }
    }
    &:last-child{
        background-image:linear-gradient(0, #d2d2d2, #d2d2d2 50%, transparent 50%);
        background-size: 100% 1px;
        background-repeat: no-repeat;
        background-position: bottom;
    }
  }
  .cell-left{
    position: absolute;
    left: 0;
    bottom: 0;
    transform: translate3d(-100%, 0, 0);
    height: 100%;
  }
  .cell /deep/ .cell-wrapper{
    display: flex;
    align-items: center;
    justify-items: self-start;
    box-sizing: border-box;

    width: 100%;

    font-size: 14px;
    line-height: 1.2;

    padding:0px 10px;
    min-height: 60px;
    background-image:linear-gradient(180deg, #d2d2d2, #d2d2d2 50%, transparent 50%);
    background-size: 120% 1px;
    background-repeat: no-repeat;
    background-position: top left;
    background-origin: content-box;
  }
  .cell-right{
    position: absolute;
    height: 100%;
    right: 0;
    top: 0;
    transform: translate3d(100%, 0, 0);
  }
  .cell-title{
    flex:1;
    padding: 10px 0;
    box-sizing: border-box;
    .cell-text{
      vertical-align: middle;
      &.maxFont{
        font-size: 16px;
        color: #111111;
      }
    }
    .cell-label{
      display: block;
      margin-top: 3px;
    }
    .cell-detail{
      margin-top: 3px;
      display: block;
    }
  }
  .cell-value{
    display: flex;
    align-items: center;
  }

  .cell /deep/ .cell-allow-right::after{
    border: solid 1px #999999;
    border-bottom-width: 0;
    border-left-width: 0;
    content: " ";
    position: absolute;
    top: 50%;
    right: 20px;
    width: 5px;
    height: 5px;
    transform: translateY(-50%) rotate(45deg);
  }
  .cell /deep/ .is-link{
    margin-right: 20px;
  }
</style>
