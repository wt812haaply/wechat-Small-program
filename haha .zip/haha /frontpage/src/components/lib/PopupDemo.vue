<template>
  <div >
    <div class="flex">
      <div class="btn btn-sm btn-black" @click="showDialog">展示弹框</div>
      <div class="btn btn-defult" @click="showToast">toast</div>
      <div class="btn btn-defult btn-black" @click="showAlertImg">图片弹框</div>
    </div>
    <div style="width: 100%">
      <img src="//tu.95vintage.com/web/images/activity/201710/lao1_2.jpg?t=1" style="width: 100%">
    </div>
    <div>
      <yi23Dialog @dialogOk="ok" @dialogClose="close" :open="open" :dialogSm='dialogSm' :hasCannel="false" @show="show">

        <div slot="body">
          <div class="yi23-dialog__bd"> 如果买下的时装已在手中，你可以直接将它留下，不必寄回。<span style="color: red">我是红色</span>如果不在，购买后请继续下单，时装将随下一个衣箱寄出 </div>
        </div>
        <div slot="btnCannel">3333</div>
      </yi23Dialog>

      <yi23Toast :open="toastOpen" :step="step" @toastColse="toastColse">
        衣服成功加入衣箱
      </yi23Toast>

      <yi23-alert-img :open="alertImgOpen" @alertImgClose="alertImgClose">
        <img :src="alertImgUrl">
      </yi23-alert-img>
    </div>
    <img v-lazy="banner">
    <img v-lazy="banner">
    <img v-lazy="alertImgUrl">
  </div>

</template>
<script>
  export default {
    name: 'popupDemo',
    data () {
      return {
        open: false,
        banner: '//tu.95vintage.com/web/images/activity/201710/lao1_2.jpg?t=1',
        dialogSm: true,
        hasCannel: true,
        toastOpen: false,
        step: 10000,
        test:{a:1},
        alertImgOpen: false,
        alertImgUrl: '//tu.95vintage.com/web/images/activity/201710/lao1_2.jpg?t=1'
      }
    },
    methods: {
      close () {
        console.log('close')
        this.open = false
      },
      ok () {
        console.log('ok')
      },
      show () {
        console.log('show')
      },
      showDialog () {
        this.open = true
      },
      showToast () {
        this.toastOpen = true
      },
      toastColse () {
        this.toastOpen = false
      },
      showAlertImg () {
        this.alertImgOpen = true
      },
      alertImgClose () {
        this.alertImgOpen = false
      }
    },
    created () {
      console.log('created----')
      // this.$set(this.test, 'b' ,'3')

    },
    components: {
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
  img {width: 100%;}
</style>
