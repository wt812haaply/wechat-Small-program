<template>
  <div style="position: relative;"
       @mouseover="showImage = true"
       @mouseout="showImage = true">

    <!-- 公共部分 -->
    <div class="verify-bar-area" style="width:100%" :style="{
                                              height: barSize.height,
                                              'line-height':barSize.height,'background-color':barBackgroundColor,'color':iconColor}">
      <span class="verify-msg" v-text="text"></span>
      <div class="verify-left-bar"
           :style="{width: (leftBarWidth!==undefined)?leftBarWidth: barSize.height, height: barSize.height, 'border-color': leftBarBorderColor, transaction: transitionWidth}">
        <span class="verify-msg" :style="{color:fontColor}"></span>
        <div class="verify-move-block"
             @touchstart="start"
             @mousedown="start"
             :style="{width: blockSize.width, height: blockSize.height, 'background-color': moveBlockBackgroundColor, left: moveBlockLeft, transition: transitionLeft}">
          <div class="verifyImg">
            <img src="https://yimg.yi23.net/webimg/web/images/icons/superNext.png" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script >
  import { resetSize } from './slide'

  export default {
    name: 'VerifySlide',
    props: {
      type: {
        type: String,
        default: '1'
      },
      vOffset: {
        type: Number,
        default: 5
      },
      explain: {
        type: String,
        default: '向右滑动完成验证'
      },
      blockSize: {
        type: Object,
        default() {
          return {
            width: '46px',
            height: '39px'
          }
        }
      },
      barSize: {
        type: Object,
        default() {
          return {
            width: '',
            height: '40px'
          }
        }
      }
    },
    data() {
      return {
        imgRand: 0,
        text: '',
        setSize: {
          imgHeight: 0,
          imgWidth: 0,
          barHeight: 0,
          barWidth: 0
        },
        top: 0,
        left: 0,
        showImage: true,
        moveBlockLeft: undefined,
        leftBarWidth: undefined,
        // 移动中样式
        moveBlockBackgroundColor: undefined,
        barBackgroundColor: undefined,
        fontColor: undefined,
        leftBarBorderColor: '#ddd',
        iconColor: undefined,
        iconClass: 'icon-right',
        status: false,	//鼠标状态
        isEnd: false,		//是够验证完成
        showRefresh: true,
        transitionLeft: '',
        transitionWidth: ''
      }
    },
    computed: {
      barArea() {
        return this.$el.querySelector('.verify-bar-area')
      },
      resetSize() {
        return resetSize
      }
    },
    methods: {

      init() {
        this.text = this.explain

        this.$nextTick(() => {

          let setSize = this.resetSize(this)	//重新设置宽度高度

          // 监听的问题
          for (let key in setSize) {
            this.$set(this.setSize, key, setSize[key])
          }
        })

        var _this = this

        window.removeEventListener("touchmove", function (e) {
          _this.move(e);
        });
        window.removeEventListener("mousemove", function (e) {
          _this.move(e);
        });

        //鼠标松开
        window.removeEventListener("touchend", function () {
          _this.end();
        });
        window.removeEventListener("mouseup", function () {
          _this.end();
        });

        window.addEventListener("touchmove", function (e) {
          _this.move(e);
        });
        window.addEventListener("mousemove", function (e) {
          _this.move(e);
        });

        //鼠标松开
        window.addEventListener("touchend", function () {
          _this.end();
        });
        window.addEventListener("mouseup", function () {
          _this.end();
        });

      },

      //鼠标按下
      start: function (e) {
        e.preventDefault()
        if (this.isEnd == false) {
          this.text = '向右滑动完成验证'
          e.stopPropagation();
          this.status = true;
        }
      },
      //鼠标移动
      move: function (e) {
        if (this.status && this.isEnd == false) {

          if (!e.touches) {    //兼容移动端
            var x = e.clientX;
          } else {     //兼容PC端
            var x = e.touches[0].pageX;
          }
          var bar_area_left = this.getLeft(this.barArea);
          var move_block_left = x - bar_area_left //小方块相对于父元素的left值

          if (this.type !== '1') {		//图片滑动
            if (move_block_left >= this.barArea.offsetWidth - parseInt(parseInt(this.blockSize.width) / 2) - 2) {
              move_block_left = this.barArea.offsetWidth - parseInt(parseInt(this.blockSize.width) / 2) - 2;
            }

          } else {		//普通滑动
            if (move_block_left >= this.barArea.offsetWidth - parseInt(parseInt(this.barSize.height) / 2) + 3) {
              this.text = '向右滑动完成验证'
              move_block_left = this.barArea.offsetWidth - parseInt(parseInt(this.barSize.height) / 2) + 3;
            } else {
              this.text = '向右滑动完成验证'
            }
          }

          if (move_block_left <= 0) {
            move_block_left = parseInt(parseInt(this.blockSize.width) / 2);
          }

          //拖动后小方块的left值
          if ((move_block_left - parseInt(parseInt(this.blockSize.width) / 2) - 5 ) < 0) {
            return
          }
          this.moveBlockLeft = (move_block_left - parseInt(parseInt(this.blockSize.width) / 2) - 3 ) + "px"
          this.leftBarWidth = (move_block_left - parseInt(parseInt(this.blockSize.width) / 2)) + "px"
        }
      },

      //鼠标松开
      end: function () {
        var _this = this;
        //  判断是否重合
        if (this.status && this.isEnd == false) {

          if (this.type !== '1') {		//图片滑动

            var vOffset = parseInt(this.vOffset)
            if (parseInt(this.left) >= (parseInt((this.moveBlockLeft || '').replace('px', '')) - vOffset) &&
              parseInt(this.left) <= (parseInt((this.moveBlockLeft || '').replace('px', '')) + vOffset)) {
              this.moveBlockBackgroundColor = '#5cb85c'
              this.leftBarBorderColor = '#5cb85c'
              this.iconColor = '#bababa'
              this.iconClass = 'icon-check'
              this.showRefresh = false
              this.isEnd = true;
              this.$parent.$emit('success', this)

            } else {
              this.fontColor = '#bababa'
              setTimeout(function () {
                _this.refresh();
              }, 400);
              this.$parent.$emit('error', this)
            }

          } else {		//普通滑动

            if (parseInt((this.moveBlockLeft || '').replace('px', '')) >= (parseInt(this.setSize.barWidth) - parseInt(this.barSize.height) - parseInt(this.vOffset))) {
              this.iconColor = '#fff'
              this.iconClass = 'icon-check'
              this.moveBlockBackgroundColor = '#ffffff'
              this.barBackgroundColor = '#9ec9ef'
              this.showRefresh = false
              this.text = '验证成功'
              this.isEnd = true;
              this.$parent.$emit('success', this)
            } else {
              this.text = '向右滑动完成验证'
              this.fontColor = '#bababa'
              this.iconClass = 'icon-close'
              this.isEnd = true;

              setTimeout(function () {
                this.text = '向右滑动完成验证'
                this.fontColor = '#bababa'
                _this.refresh()
                _this.isEnd = false
              }, 400);

              this.$parent.$emit('error', this)
            }
          }

          this.status = false;
        }
      },

      refresh: function () {
        this.showRefresh = true
        this.text = '向右滑动完成验证'

        this.transitionLeft = 'left .3s'
        this.moveBlockLeft = 0

        this.leftBarWidth = undefined
        this.transitionWidth = 'width .3s'

        this.leftBarBorderColor = '#ddd'
        this.moveBlockBackgroundColor = '#fff'
        this.iconClass = 'icon-right'
        this.isEnd = false
        setTimeout(() => {

          this.transitionWidth = ''
          this.transitionLeft = ''
          this.text = this.explain
        }, 300)
      },

      //获取left值
      getLeft: function (node) {
        let leftValue = 0;
        while (node) {
          leftValue += node.offsetLeft;
          node = node.offsetParent;
        }
        let finalvalue = leftValue;
        return finalvalue;
      }
    },
    watch: {
      // type变化则全面刷新
      type: {
        immediate: true,
        handler() {
          this.init()
        }
      }
    },
    created(){
      this.init()
    },
    mounted() {
      this.init()
      // 禁止拖拽
      this.$el.onselectstart = function () {
        return false
      }
    }
  }
</script>
<style scoped lang="less">
  .verify-bar-area {
    position: relative;
    background: #efefef;
    text-align: center;
    box-sizing: content-box;
    border-radius:3px;
    margin:0 auto;
    font-size: 14 * @unit;
    color: #bababa;
  }

  .verify-bar-area .verify-move-block {
    position: absolute;
    top: 0px;
    left: 0;
    background: #ffffff;
    cursor: pointer;
    border: solid 1px #cccccc;
    border-radius: 4px;
  }

  .verify-bar-area .verify-left-bar {
    position: absolute;
    top: -1px;
    left: -1px;
    cursor: pointer;
    box-sizing: content-box;
  }

  .verify-bar-area .verify-move-block .verify-sub-block {
    position: absolute;
    text-align: center;
    z-index: 19;
    border: 1px solid #fff;
  }

  .verify-bar-area .verify-msg {
    z-index: 9;
  }
  .verifyImg{
    width: 17 * @unit;
    height:15 * @unit;
    position:absolute;
    top: 26%;
    left: 50%;
    /*border:1px solid red;*/
    transform: translateX(-50%) translateY(-50%);
    img{
      width: 100%;
      height: 100%;
    }
  }
</style>
