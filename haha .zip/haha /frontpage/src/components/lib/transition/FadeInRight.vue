<template>
  <transition name="fadeInRight">
    <slot></slot>
  </transition>
</template>
<style lang="less">
  @keyframes fadeInRight {
    from {
      opacity: 0;
      transform: translate3d(100%, 0, 0);
    }

    to {
      opacity: 1;
      transform: translate3d(0, 0, 0);
    }
  }
  .fadeInRight-enter-active {
    animation: fadeInRight .3s;
  }
  .fadeInRight-leave-active {
    animation: bounceInLeft .1s reverse;
  }
</style>
<script>
export default {
  name: 'BounceInLeft',
  data () {
    return {}
  },
  methods:{
  }
}
</script>
