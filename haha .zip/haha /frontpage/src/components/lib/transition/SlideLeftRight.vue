<template>
  <transition :name="name" @after-enter="show()">
    <slot></slot>
  </transition>
</template>
<style lang="less">
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s ease;
  }
  .fade-enter, .fade-leave-active {
    opacity: 0
  }
  .slide-left-enter-active{
    transition: all .4s cubic-bezier(.55,0,.1,1);
  }
  .slide-right-leave-active{
    transition: all .2s cubic-bezier(.55,0,.1,1);
  }
  .slide-left-enter, .slide-right-leave-active {
    opacity: 0;
    transform: translate(100px, 0);
  }
  .slide-left-leave-active, .slide-right-enter {
    opacity: 0;
    transform: translate(-100px, 0);
  }
</style>
<script>
export default {
  name: 'SlideLeftRight',
  data () {
    return {}
  },
  props: {
    name: {
      type: String
    }
  },
  methods: {
    show (el) {
      console.log(el)
    }
  }
}
</script>
