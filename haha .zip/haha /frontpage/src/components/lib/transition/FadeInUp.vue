<template>
  <transition name="bounceInUp">
    <slot></slot>
  </transition>
</template>

<script>
    export default {
        name: "fade-in-up"
    }
</script>

<style scoped lang="less">


  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translate3d(0, 100%, 0);
    }

    to {
      opacity: 1;
      transform: translate3d(0, 0, 0);
    }
  }

  .bounceInUp-enter-active {
    animation: fadeInUp .5s;
  }
  .bounceInUp-leave-active {
    animation: fadeInUp .5s reverse;
  }


</style>
