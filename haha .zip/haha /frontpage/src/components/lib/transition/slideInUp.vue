<template>
  <transition name="slideInUp">
    <slot></slot>
  </transition>
</template>

<script>
    export default {
        name: "slide-in-up"
    }
</script>

<style scoped lang="less">

  @keyframes slideInUp {
    from {
      transform: translate3d(0, 100%, 0);
      visibility: visible;
    }

    to {
      transform: translate3d(0, 0, 0);
    }
  }

  .slideInUp-enter-active {
    animation: slideInUp .5s;
  }
  .slideInUp-leave-active {
    animation: slideInUp .5s reverse;
  }

</style>
