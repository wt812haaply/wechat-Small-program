<template>
  <transition name="slide-fade-left" mode="out-in">
    <slot></slot>
  </transition>
</template>
<script>
export default {
  name: 'SlideLeftRight',
  data () {
    return {}
  },
  props: {
    name: {
      type: String
    }
  }
}
</script>
<style lang="less" scoped>
  /* 可以设置不同的进入和离开动画 */
/* 设置持续时间和动画函数 */
.slide-fade-left-enter-active {
  transition: all .3s ease;
}
.slide-fade-left-leave-active {
  transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-fade-left-enter, .slide-fade-left-leave-to{
  transform: translate(300px,0);
  opacity: 0;
}
</style>
