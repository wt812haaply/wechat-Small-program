<template>
  <transition name="bounceInUp">
    <slot></slot>
  </transition>
</template>

<script>
    export default {
        name: "fade-in"
    }
</script>

<style scoped lang="less">


  @keyframes fadeInUp {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  .bounceInUp-enter-active {
    animation: fadeInUp .5s;
  }
  .bounceInUp-leave-active {
    animation: fadeInUp .5s reverse;
  }


</style>
