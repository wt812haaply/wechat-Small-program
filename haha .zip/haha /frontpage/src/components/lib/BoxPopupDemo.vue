<template>
  <div>
    <BoxPopup>

    <div slot="Box_InnerTop">
      <div class="Box_InnerTop" style="height: 40px">
        <p>为您绑定到衣二三账户：</p>
        <p id="buy-mobile">11111</p>
      </div>
    </div>


    <div slot="Box_InneBtm">
      <img src="https://tu.95vintage.com/web_source/Home/Common/images/20180312001/dist/images/indexTip05.jpg" alt="">
    </div>


    <div slot="Box_checkbox">
      <p>
        <input type="checkbox" name="">
        <label><i class="font-m">¥300押金预授权(仅冻结花呗额度，无须支付)</i></label>
      </p>
    </div>


    <div slot="Box_p">
      <p>支付成为会员，包月租衣随心换穿</p>
    </div>


    <div slot="Box_Btn">
      <button class="btn font-r">确认支付</button>
    </div>


    </BoxPopup>
  </div>
</template>
<!--<style code>-->
<style scoped lang="less">
  @import "~common/less/variable";
  /*
  .Popup_Box{
    position: fixed;
    top: 50%;
    left: 50%;
    background: transparent;
    .width(320);
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    transform: translateX(-50%) translateY(-50%);
    z-index: 9;
    background: red;
  }
  .Box_Inner{
    background: #fff;
    width: 100%;
    border-radius: 0.16rem;
  }
  .Box_InnerImg{
    padding-bottom: 58.9171%;
    border-top-left-radius: 0.16rem;
    border-top-right-radius: 0.16rem;
  }

  .Box_InnerTop{
    position: absolute;
    margin: 0px;
    top: 50%;
    width: 80%;
    height: 5.333333rem;
    left: 50%;
    display: block;
    z-index: 9;
    transform: translate(-50%, -50%);
    display: flex;
    flex-wrap: wrap;
    justify-content: center;

    p{
      display: flex;
      width: 100%;
      justify-content: center;
      align-items: center;
      text-align: center;
      font-size: 0.853333rem;
      line-height: 1.4;
      letter-spacing: 0.085333rem
    }
  }

  .Box_Form{
    flex-wrap: wrap;
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: center;
    margin-top: 1.6rem;
    p{
      font-size: 0.64rem;
      color: #000;
    }
  }

  .Box_Form p input[type=checkbox]{
    position: absolute;
    opacity: 0;
  }

  .Box_Form p input[type=checkbox] + label:before{
    content: "";
    display: inline-block;
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #cccccc;
    -moz-border-radius: 50%;
    -webkit-border-radius: 50%;
    border-radius: 50%;
    float:left;
    background-color: #fff;
  }
  .Box_Form p input[type=checkbox]:checked + label:before
  {
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #ff544b;
    /*background:#ff544b  url(../images/iconDuihao.svg) 100% 0 no-repeat;*/
    background:#ff544b   100% 0 no-repeat;
    /*background-size:100%;*/
    font-size: 20px;
    content: '✓';
    color: #fff;
    display: flex;
    justify-content:center;
    align-items:center;
    text-align: center;
    font-family: "Pingfang SC";
  }

  .Box_Form p label{
    width: 100%;
  }
  .Box_Form p label i{
    position: relative;
    top: 0.373333rem;
    margin: 0.533333rem 0 0 0.533333rem;
    font-style: normal;
  }


  .Box_Btn{
    padding: 1.386667rem 0;
    display: flex;
    width: 100%;
    justify-content: center;
    align-content: center;
    button{
      width: 8.106667rem;
      height: 2.346667rem;
      border-radius: 2.346667rem;
      background: #ccc;
      color: #fff;
      font-size: 0.746667rem;
    }
    button.btn.active{
      background: #ff544b;
    }
  }

  .Box_close{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 2.346667rem;
    height: 2.346667rem;
    margin-top: 2.133333rem;
    .icon-closex{
      color: #fff;
      font-size: 2.346667rem;
    }
  }

</style>
<script>
import BoxPopup from '../lib/BoxPopup.vue'

  export default {
    data(){
      return{

      }
    },
    components:{
      BoxPopup
    },
    methods: {

    },
    created () {
    }
  }
</script>
</script>
