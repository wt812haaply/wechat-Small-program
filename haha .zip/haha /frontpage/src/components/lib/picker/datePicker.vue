<template>
<div class="pickerBox" v-if="show">
  <fade-in-up>
    <div class="datepickerBox" v-if="show">
      <datepicker :disabledDates="state.disabledDates" maximum-view="day" :open-date="openDate" format="yyyy-MM-dd" :highlighted="state.highlighted" :language="zh" :inline="true"  :value="state.highlightEndDate" @selected="highlightTo"  >
      </datepicker>
      <div class="btn btn-defult datepicker_submit" @click="selectedDate">确认日期选择</div>
    </div>
  </fade-in-up>
  <div class="shade" @click="hide()"></div>
</div>

</template>

<script>
  import {getDays} from '@/common/js/utils'
  import {zh} from 'vuejs-datepicker/dist/locale'
  import Datepicker from 'vuejs-datepicker';
  import FadeInUp from '@/components/lib/transition/FadeInUp'
    export default {
        name: "date-picker-yi23",
        data(){
          return {
            zh:zh,
            startDate:null,
            state:{
              endDate:null,
              highlightEndDate:null,
              backDate:null,
              selectedStartDate:null,
              disabledDates:{
              },
              highlighted:{
                includeDisabled: true
              }
            },
          }
        },
        watch:{
          userableList(val){
            this.dateDataAction()
          }
        },
        computed:{
          openDate(){
            return (this.userableList && this.userableList.length>0)?new Date(this.userableList[0]):new Date()
          }
        },
        props:{
          userableList:{
            type: Array,
            default: null
          },
          step:{
            type:Number,
            default:3
          },
          show:{
            type:Boolean,
            default:false
          }
        },
        components: {
          FadeInUp,
          Datepicker
        },
        created(){
          this.dateDataAction();
        },
        methods:{
          dateDataAction(){
            if(this.userableList && this.userableList.length>1){
              let startDate=this.userableList[0]
              let userableListL=this.userableList.length
              let  lastDate=this.userableList[userableListL-1];
              let allDays=getDays(startDate,lastDate)
              if(allDays.length>userableListL){
                let disabledDate=  this.difference(allDays,this.userableList)
                console.log(disabledDate)
                let dateList=[];
                for (let i=0;i< disabledDate.length;i++){
                  dateList.push(new Date(disabledDate[i]))
                }
                this.state.disabledDates.dates=dateList
              }
              this.state.disabledDates.to=new Date(this.userableList[0]);
              this.state.disabledDates.from=new Date(lastDate);
            }
          },
          difference(all,useable){
            return  all.concat(useable).filter(v=> !useable.includes(v))
          },
          highlightTo(val){
             if(new Date(val).getTime()==this.state.selectedStartDate){
                this.state.selectedStartDate=null;
                this.state.endDate=null;
                this.state.backDate=null;
                delete this.state.highlighted.from
                delete this.state.highlighted.to
             }else{
               this.state.highlighted.from=new Date(val)
               this.state.highlighted.to=new Date(new Date(val).getTime()+(this.step+1)* 24 * 60 * 60 * 1000)

               this.state.highlightEndDate=new Date(val).getTime()+this.step* 24 * 60 * 60 * 1000;
               this.state.selectedStartDate=new Date(val).getTime();
               this.state.endDate=new Date(val).getTime()+(this.step)* 24 * 60 * 60 * 1000;
               this.state.backDate=new Date(val).getTime()+(this.step+1)* 24 * 60 * 60 * 1000;
             }

            return false
          },
          selectedDate(){
            this.$emit('datePickerSelect',{startDate:this.state.selectedStartDate,endDate:this.state.endDate,backDate:this.state.backDate})
          },
          hide() {
            this.$emit('datePickerSelect',false)
          }
        }
    }
</script>

<style scoped lang="less">
  .pickerBox{
    /*height: 100%;*/
    overflow: hidden;
  }
  .shade{
    width: 100%;
    height: 100%;
    position: fixed;
    overflow: hidden;
    top: 0;
    left: 0;
    z-index: 10;
    background: rgba(17, 17, 17, 0.2);
  }
  .datepickerBox{
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #ffffff;
    z-index: 12;
  }
  /deep/ .vdp-datepicker__calendar .cell:not(.blank):not(.disabled).day:hover{
    border: 0;
  }
  /deep/ .vdp-datepicker__calendar .cell{
    position: relative;
    border-radius: 51%;
    padding: 0;
    width: 11vw;
    height: 11vw;
    line-height: 11vw;
    font-size: .7rem;
    margin: 1vw;

  }
  /deep/ .vdp-datepicker__calendar .cell.selected.highlighted{
    background: #adcbd6;
  }
  /deep/ .vdp-datepicker__calendar .cell.highlighted{
    background: #adcbd6;
    color: white;
  }
  /deep/ .vdp-datepicker__calendar .cell.highlight-end{
    color: #CC9E68;
    background: #FAFAFA;
  }
  /deep/ .vdp-datepicker__calendar .cell.highlight-end:after{
    content: '归还';
    font-size: 12px;
    top: 29px;
    left: 0;
    display: inline-block;
    position: absolute;
    width: 100%;
  }
  /deep/ .vdp-datepicker__calendar{
    border: 0;
    width: 96%;
    padding-top: 1rem;
  }
  /deep/ .vdp-datepicker{
    display: flex;
    padding-bottom: 30px;
    justify-content:center;
  }
  /deep/ .vdp-datepicker__calendar .cell.selected:hover{
    background: none;
  }
  /deep/ .vdp-datepicker__calendar .cell.selected.highlighted:hover{
    background: #9FBCC7;
  }
  /deep/ .vdp-datepicker__calendar header .prev, /deep/ .vdp-datepicker__calendar header .next{
    width: 25%;
  }
  /deep/ .vdp-datepicker__calendar header .next:after{
    left: 1rem;
  }
  /deep/ .vdp-datepicker__calendar header .prev:after, /deep/ .vdp-datepicker__calendar header .next:after {
    content: '‹';
    font-size: .9rem;
    font-weight: 700;
    position: absolute;
    color: white;
    text-align: center;
    left: 0;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    /* border: 6px solid transparent; */
    background: black;
    height: 1rem;
    width: 1rem;
    line-height: 1rem;
    border-radius: 1rem;
  }
  /deep/ .vdp-datepicker__calendar header span{
    font-size: .9rem;
  }
  /deep/ .vdp-datepicker__calendar header .prev:after{
    right: -1rem;
    left: inherit;
  }
  /deep/ .vdp-datepicker__calendar header .next:after{
    content: '›';
  }
  /deep/ .vdp-datepicker__calendar header .prev:after,/deep/ .vdp-datepicker__calendar header .next:after{
    border: 0;
    text-indent: 1px;
  }
  /deep/ .vdp-datepicker__calendar header span{
    width: 50%;
  }
  /deep/ .vdp-datepicker__calendar header .prev:not(.disabled):hover,/deep/  .vdp-datepicker__calendar header .next:not(.disabled):hover,/deep/  .vdp-datepicker__calendar header .up:not(.disabled):hover{
    background: white;
  }
  /deep/ .vdp-datepicker__calendar header .prev.disabled:after{
    border: none;
  }
</style>
