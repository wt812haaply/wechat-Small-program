<template>
    <div  class="v-modal" v-show="currentStatus">
      <transition name="slideInUp">
        <div class="upBox" v-show="currentStatus">
          <div class="picker" :class="{ 'picker-3d': rotateEffect }">
            <div class="picker-toolbar" v-if="showToolbar">
              <slot>
                <div @click="doAction(0)">取消</div>
                <div class="submit" @click="doAction(1)">确定</div>
              </slot>
            </div>
            <div class="picker-items">
              <picker-slot v-for="(slot,index) in slots" :key="index" :valueKey="valueKey" :values="slot.values || []" :text-align="slot.textAlign || 'center'" :visible-item-count="visibleItemCount" :class-name="slot.className" :flex="slot.flex" v-model="values[slot.valueIndex]" :rotate-effect="rotateEffect" :divider="slot.divider" :content="slot.content" :itemHeight="itemHeight" :default-index="slot.defaultIndex"></picker-slot>
              <div class="picker-center-highlight" :style="{ height: itemHeight + 'px', marginTop: -itemHeight / 2 + 'px' }"></div>
            </div>
          </div>
        </div>
      </transition>
    </div>
</template>

<style lang="less">
  .picker {
    overflow: hidden;
    font-size: 14px;
  }
  .picker-toolbar{
    color:#999;
    div{
      padding:16px
    }
  }
  .picker .submit{color: #ff5454}
  .picker-toolbar {
    /*height: 35px;*/
    box-sizing: border-box;
    padding: 0 10px;
    display: flex;
    align-items: center;
    justify-content: space-between ;
  }

  .picker-items {
    display: flex;
    justify-content: center;
    padding: 0;
    text-align: right;
    font-size: 24px;
    position: relative;
  }

  .picker-center-highlight {
    box-sizing: border-box;
    position: absolute;
    left: 0;
    width: 100%;
    top: 50%;
    margin-top: -18px;
    pointer-events: none
  }

  .picker-center-highlight:before,
  .picker-center-highlight:after {
    content: '';
    position: absolute;
    height: 1px;
    width: 100%;
    background-color: #eaeaea;
    display: block;
    z-index: 15;
    transform: scaleY(0.5);
  }

  .picker-center-highlight:before {
    left: 0;
    top: 0;
    bottom: auto;
    right: auto;
  }

  .picker-center-highlight:after {
    left: 0;
    bottom: 0;
    right: auto;
    top: auto;
  }
  /*动画*/

  .v-modal{
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 100;
    background: rgba(0, 0, 0, 0.1);
  }
  .upBox{
    position: absolute;
    background: #fff;
    width: 100%;
    bottom: 0;
    opacity: 1;
    left: 0;
    z-index: 11;
  }
  @keyframes slideInUp {
    from {
      transform: translate3d(0, 100%, 0);
      visibility: visible;
    }

    to {
      transform: translate3d(0, 0, 0);
    }
  }
  .slideInUp-enter-active {
    animation: slideInUp .5s;
  }
  .slideInUp-leave-active {
    animation: slideInUp .3s reverse;
  }
  @keyframes fadeIn {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  .fadeIn-enter-active {
    animation: fadeIn .1s;
  }
  .fadeIn-leave-active {
    animation: fadeIn .1s reverse;
  }
</style>

<script type="text/babel">
  import  PickerSlot from './picker-slot.vue'
  import Clickoutside from '@/utils/directive/clickoutside';
  export default {
    name: 'mt-picker',

    componentName: 'picker',
    data () {
      return {
        currentStatus: this.value
      }
    },
    props: {
      value:Boolean,
      slots: {
        type: Array
      },
      showToolbar: {
        type: Boolean,
        default: true
      },
      visibleItemCount: {
        type: Number,
        default: 5
      },
      valueKey: String,
      rotateEffect: {
        type: Boolean,
        default: false
      },
      itemHeight: {
        type: Number,
        default: 36
      }
    },
    directives: { Clickoutside },
    created() {
      this.$on('slotValueChange', this.slotValueChange);
      this.slotValueChange();
    },
    watch:{
      value (val){
        this.currentStatus=val
      },
      currentStatus (val){
        this.$emit('input',val)
      },
    },
    methods: {
      slotValueChange() {
        this.$emit('change', this, this.values);
      },
      doAction(val) {
        if(val==1){
          this.$emit('doConfirm', this.values);
        }
        this.$emit('input',false)
      },
      getSlot(slotIndex) {
        var slots = this.slots || [];
        var count = 0;
        var target;
        var children = this.$children.filter(child => child.$options.name === 'picker-slot');

        slots.forEach(function(slot, index) {
          if (!slot.divider) {
            if (slotIndex === count) {
              target = children[index];
            }
            count++;
          }
        });

        return target;
      },
      getSlotValue(index) {
        var slot = this.getSlot(index);
        if (slot) {
          return slot.currentValue;
        }
        return null;
      },
      setSlotValue(index, value) {
        var slot = this.getSlot(index);
        if (slot) {
          slot.currentValue = value;
        }
      },
      getSlotValues(index) {
        var slot = this.getSlot(index);
        if (slot) {
          return slot.mutatingValues;
        }
        return null;
      },
      setSlotValues(index, values) {
        var slot = this.getSlot(index);
        if (slot) {
          slot.mutatingValues = values;
        }
      },
      getValues() {
        return this.values;
      },
      setValues(values) {
        var slotCount = this.slotCount;
        values = values || [];
        if (slotCount !== values.length) {
          throw new Error('values length is not equal slot count.');
        }
        values.forEach((value, index) => {
          this.setSlotValue(index, value);
        });
      }
    },

    computed: {
      values: {
        get() {
          var slots = this.slots || [];
          var values = [];
          var valueIndexCount = 0;
          slots.forEach(slot => {
            if (!slot.divider) {
              slot.valueIndex = valueIndexCount++;
              values[slot.valueIndex] = (slot.values || [])[slot.defaultIndex || 0];
            }
          });
          return values;
        }
      },
      slotCount() {
        var slots = this.slots || [];
        var result = 0;
        slots.forEach(function(slot) {
          if (!slot.divider) result++;
        });
        return result;
      }
    },
    components: {
      PickerSlot: PickerSlot,
    }
  };
</script>
