<template>
  <div class="collapseItem">
    <div class="title" @click="collapse(id)">
      <slot name="title">
      </slot>
    </div>
    <div class="content" v-show="showStatus && id==$parent.currentActive">
      <slot name="content">
      </slot>
    </div>
  </div>
</template>

<script>
  export default {
    name: "collapseItem",
    props:['id'],
    data(){
      return {
        showStatus:true
      }
    },
    methods:{
      collapse(id){
        if(id==this.$parent.currentActive && this.showStatus){
          this.showStatus=false
        }else{
          this.showStatus=true
        }
        this.$parent.$emit('input',id)

      }
    }
  }
</script>

<style scoped lang="less">
  .collapseItem{
    overflow: hidden;
    width: 100%;
    background-image:linear-gradient(180deg, #d2d2d2, #d2d2d2 50%, transparent 50%);
    background-size: 120% 1px;
    background-repeat: no-repeat;
    background-position: bottom left;
    background-origin: content-box;
  }
  .collapseItem /deep/ .title{
    font-size: 12px;
    font-weight: 500;
    color: #000000;
    line-height: 4;
  }
  .collapseItem /deep/ .content{
    font-size: 12px;
    color: #111;
    padding-bottom: 10px;
    line-height: 1.1;
  }
</style>
