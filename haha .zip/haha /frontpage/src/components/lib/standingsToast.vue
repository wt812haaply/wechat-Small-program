<template>
<div>
  <transition name="pop-img" appear>
    <div class="pop-img-box" v-show="open">
      <h1>+{{title}}</h1>
      <p>
        {{explain}}
        <span>恭喜您获得{{title}}积分</span>
      </p>
    </div>
  </transition>
  <div class="pop-img-box-bg" v-if="open"></div>
</div>
</template>
<style code lang="less">
  .pop-img-box{
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 386/2 * @unit;
    height: 356/2 * @unit;
    background:url("https://yimg.yi23.net/webimg/web/images/20180918/toast@2x.png") no-repeat;
    background-size: cover;
    text-align: center;
    opacity: 0;
    z-index: -1;
    h1{
      color: white;
      line-height: 32 * @unit;
      font-size: 28 * @unit;
      margin-top: 51 * @unit;
    }
    p{
      font-size: 12 * @unit;
      line-height: 17 * @unit;
      margin-top: 25 * @unit;
      span{
        display: block;
        font-size: 10 * @unit;
        line-height: 17 * @unit;
        color: rgb(175,175,175);
      }
    }
  }
  .pop-img-box-bg{
    position: fixed;
    width: 100vw;
    height:100%;
    display: block;
    top:0;
    left:0;
    /*background: rgba(0,0,0,0.1);*/
    z-index: -5;
    animation: pop-img-box-bg-in 3s;
  }
  .pop-img-enter-active{
    animation: pop-img-in 3s;
  }
  .pop-img-bg-enter-active{
    animation: pop-img-in 3s;
  }
  /*.pop-img-enter-to{*/
  /*display: none;*/
  /*}*/
  @keyframes pop-img-box-bg-in{
    0% {
      z-index: 5;
    }
    99%{
      z-index: 5;
    }
    100%{
      z-index: -5;
    }
  }
  @keyframes pop-img-in {
    0% {
      opacity: 1;
      z-index: 5;
      transform: translate(-50%, 260%);
    }
    30% {
      opacity: 1;
      z-index: 5;
      transform: translate(-50%, -50%);
    }
    95% {
      opacity: 1;
      z-index: 5;
      transform: translate(-50%, -50%);
    }
    100%{
      transform: translate(-50%, -50%);
      opacity: 0;
    }
    /*100% {*/
      /*transform: translate(-50%, 260%);*/
      /*opacity: 0;*/
    /*}*/
  }
</style>
<script>
export default {
  name: 'standingsToast',
  data () {
    return {

    }
  },
  props: ['open', 'title', 'explain'],
  computed: {
    getStep () {
      if (this.step) {
        return this.step
      } else {
        return 3000
      }
    }
  },
  watch:{

  },
  methods: {

  }
}
</script>
