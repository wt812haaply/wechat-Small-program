<template>
  <div class="laodingBox">
    <div class="mint-spinner-snake loading">

    </div>
    <slot></slot>
  </div>
</template>

<script>
  export default {
    name: "loading",
    data () {
      return {
        currentNav:0
      }
    },
    props: ['open', 'hasCannel'],
    created(){
    }

  }
</script>

<style scoped>
  .laodingBox{
    display: flex;
    align-items: center;
    justify-content:center;
    width: 100%;
    overflow: hidden;
    font-size: 14px;
  }
  .loading{
    border-top-color: rgb(0, 0, 0) !important;
    border-left-color: rgb(0, 0, 0) !important;
    border-bottom-color: rgb(0, 0, 0) !important;
    height: 10px;
    width: 10px;
    margin-right: 5px;
  }
  .mint-spinner-snake {
    -webkit-animation: mint-spinner-rotate 0.8s infinite linear;
    animation: mint-spinner-rotate 0.8s infinite linear;
    border: 2px solid transparent;
    border-radius: 50%;
  }
  @-webkit-keyframes mint-spinner-rotate {
    0% {
      -webkit-transform: rotate(0deg);
      transform: rotate(0deg);
    }
    100% {
      -webkit-transform: rotate(360deg);
      transform: rotate(360deg);
    }
  }
  @keyframes mint-spinner-rotate {
    0% {
      -webkit-transform: rotate(0deg);
      transform: rotate(0deg);
    }
    100% {
      -webkit-transform: rotate(360deg);
      transform: rotate(360deg);
    }
  }
</style>
