<template>
  <transition name="bigLoading">
  <div class="columns__box__wait" v-if="open">
    <div>
      <div class="img">
        <img src="https://yimg.yi23.net/webimg/web/images/2018/1207/lo.gif" style="width: 100%" alt=""/>
      </div>
      <p class="loading">加载中</p>
    </div>
  </div>
  </transition>
</template>

<script>
  export default {
    name: "bigLoading",
    data () {
      return {

      }
    },
    props: ['open'],
    created(){
      console.log(this.open);
    },
    methods: {
      show: function () {
        this.$emit('show')
      }
    }
  }
</script>

<style scoped lang="less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .columns__box__wait{
    display: flex;
    min-height: 100vh;
    width: 100%;
    flex-direction: column;
    position: fixed;
    z-index: 1000;
    top: 0;
    left: 0;
    background: white;
    justify-content: center;
    align-items: center;
    opacity: .95;
  }
  .loading{
    font-size: 14px;
    padding-left: .7rem;
    margin-top: 10px;
  }
  .loading:after{
    overflow: hidden;
    display: inline-block;
    vertical-align: bottom;
    animation: ellipsis steps(4,end) 1.2s infinite;
    content: "\2026";
    width: 0px;
  }

  @keyframes ellipsis{
    to{
      width: 1.25em;
    }
  }

  .img{
    width: 18.67vw;
    position: relative;
  }

  .lds-heart{
    display: inline-block;
    position: absolute;
    top:51%;
    left: 39%;
    width: 6.53vw;
    height: 6.53vw;
    transform: rotate(59deg);
    -webkit-transform: rotate(59deg);
    transform-origin: 4.26vw 4.26vw;
    -webkit-transform-origin: 4.26vw 4.26vw;
  }
  .lds-heart div {
    position: absolute;
    width: 5.9vw;
    height: 5.9vw;
    background: #ff544b;
    animation: lds-heart 1.2s infinite cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  .lds-heart div:after,
  .lds-heart div:before {
    content: " ";
    position: absolute;
    display: block;
    width: 6.9vw;
    height: 6.9vw;
    background: #ff544b;
  }
  .lds-heart div:before {
    left: -2.6vw;
    top:1.3vw;
    border-radius: 50% 0 50% 50%;
    transform: rotate(59deg);
  }
  .lds-heart div:after {
    top: -3.5vw;
    right: .2vw;
    border-radius: 50% 50% 0% 0%;
    transform: rotate(-2deg);
  }
  @keyframes lds-heart {
    0% {
      transform: scale(0.95);
    }
    5% {
      transform: scale(1.1);
    }
    39% {
      transform: scale(0.85);
    }
    45% {
      transform: scale(1);
    }
    60% {
      transform: scale(0.95);
    }
    100% {
      transform: scale(0.9);
    }
  }
</style>
