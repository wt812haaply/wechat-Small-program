<template>
  <!-- <transition name="dialog-slide" @after-enter="show()" @after-leave="hide()"> -->
    <div class="dialog" v-if="open">
      <div class="yi23-mask" @click="close"></div>
      <div class="yi23-dialog" :class="dialogClassVal">
        <slot name="banner"></slot>
        <div class="yi23-dialog__hd">
          <h4 class="font-m">
            <slot name="header"></slot>
          </h4>
        </div>
        <div class="yi23-dialog__bd">
          <slot name="body"> </slot>
        </div>
        <div class="yi23-dialog__ft flex">
          <div class="flex-item yi23-dialog__btn" v-if="hasCannel" @click="cannel">
            <slot name="btnCannel">
              取消
            </slot>
          </div>
          <div class="flex-item yi23-dialog__btn_primary"  @click="ok">
            <slot name="btnOk">
              确定
            </slot>
          </div>
        </div>
      </div>
    </div>
  <!-- </transition> -->
</template>
<style lang="less" scoped>
  .dialog-slide-enter-active, .dialog-slide-leave-active, .dialog-slide-enter-active .yi23-dialog, .dialog-slide-leave-active .yi23-dialog{
    z-index: 1000;
  }
  .dialog-slide-enter-active {
    animation: zoomIn1 .5s;
  }
  .dialog-slide-leave-active {
    animation: zoomIn1 .5s reverse;
  }
  .dialog-slide-enter-active .yi23-dialog {
    animation: zoomIn .5s;
  }
  .dialog-slide-leave-active .yi23-dialog{
    animation: zoomIn .5s reverse;
  }
  @keyframes zoomIn1 {
    from {
      opacity: 0;
    }

    50% {
      opacity: 1;
    }
  }
  @keyframes zoomIn {
    from {
      transform: translate(-50%,-50%) scale(0);
    }

    50% {
      transform: translate(-50%,-50%) scale(1.1);
    }
  }
</style>
<script>
  export default {
    name: 'yi23Dialog',
    data () {
      return {
      }
    },
    props: ['open', 'dialogSm', 'hasCannel'],
    computed: {
      dialogClassVal () {
        return {
          'yi23-dialog__sm': this.dialogSm
        }
      }
    },
    methods: {
      ok: function () {
        this.$emit('dialogClose')
        this.$emit('dialogOk')
      },
      cannel: function () {
        this.$emit('dialogClose')
      },
      close: function () {
        this.$emit('dialogClose')
      },
      show: function () {
        this.$emit('show')
      },
      hide: function () {
        this.$emit('hide')
      }
    }
  }
</script>
