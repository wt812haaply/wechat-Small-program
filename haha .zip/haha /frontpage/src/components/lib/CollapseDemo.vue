<template>
  <div class="collapseItem">
    <collapse-container v-model="selected">
      <collapse-item :id="1">
        <div slot="title">标题</div>
        <div slot="content">
          内容
          <div>
            ddd
          </div>
        </div>
      </collapse-item>
      <collapse-item :id="2">
        <div slot="title">标题2</div>
        <div slot="content">
          内容2
          <div>
            ddd2222
          </div>
        </div>
      </collapse-item>
      <collapse-item :id="3">
        <div slot="title">标题3</div>
        <div slot="content">
          内容3
          <div>
            ddd3333
          </div>
        </div>
      </collapse-item>
    </collapse-container>
  </div>
</template>

<script>
  import collapseItem from '@/components/lib/CollapseItem'
  import collapseContainer from '@/components/lib/CollapseContainer'
  export default {
    name: "collapseDemo",
    data() {
      return{
        selected:'2'
      }
    },
    methods:{

    },
    components:{
      collapseContainer,
      collapseItem
    }
  }
</script>

<style scoped lang="less">

</style>
