<template>
  <transition name="alertImg-draw" @after-enter="show()" @after-leave="hide()" appear>
    <div class="yi23-imgalert__box" v-if="open || currentStatus">
      <div class="yi23-mask" v-if="open || currentStatus"></div>
      <div class="yi23-imgalert">
        <div class="yi23-imgalert___hd">
          <slot class="ccc"></slot>
        </div>
        <div class="yi23-imgalert__ft" v-if="!hideClose" @click="close">
          <span class="yi23iconfont icon-closex"></span>
        </div>
      </div>
    </div>
  </transition>
</template>
<style lang="less" scoped>
.alertImg-draw-enter-active, .alertImg-draw-leave-active, .alertImg-draw-enter-active .yi23-imgalert, .alertImg-draw-leave-active .yi23-imgalert{
  z-index: 1000;
}

.yi23-imgalert___hd{
  width: 100%;
  border-radius: 2px;
  position: relative;
}
</style>
<script>
export default {
  name: 'yi23AlertImg',
  data () {
    return {
      currentStatus:'',
    }
  },
  props: ['open','value', "hideClose"],
  watch:{
    value:{
      handler:function (val) {
        this.currentStatus=val;
      },
      immediate: true
    },
    currentStatus (val) {
      this.$emit('input',val)
    }
  },
  methods: {
    show: function () {
      this.$emit('show')
    },
    hide: function () {
      this.$emit('hide')
    },
    close: function () {
      this.currentStatus=false
      this.$emit('alertImgClose')
    }
  }
}
</script>
