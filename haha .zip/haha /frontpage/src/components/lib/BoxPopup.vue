<template>

  <transition name="alertImg-slide">
    <div class="yi23-imgalert__box" v-if="open || otherPay">
      <div class="yi23-mask" @click="closeBox()"></div>
      <div class="yi23-imgalert">
        <div class="Box_Inner">


          <div class="imgP1 Box_InnerImg image-ratio1">
            <slot name="Box_InnerTop"></slot>
            <slot name="Box_InneBtm"></slot>
          </div>

          <div class="Box_Form">
            <slot name="Box_checkbox"></slot>
            <slot name="Box_p"></slot>
          </div>

          <!--<div class="Box_Btn">-->
            <!--<slot name="Box_Btn"></slot>-->
          <!--</div>-->

        </div>

        <div class="yi23-imgalert__ft">
          <span class="yi23iconfont icon-closex" @click="closeBox()"></span>
        </div>


      </div>
    </div>
  </transition>



</template>
<!--<style code>-->
<style scoped lang="less">
  @import "~common/less/variable";

  .Box_Inner{
    background: #fff;
    width: 100%;
    border-radius: 0.16rem;
  }
  .Box_InnerImg{
    border-top-left-radius: 0.16rem;
    border-top-right-radius: 0.16rem;
    position: relative;
    overflow-y: hidden;
    /deep/ img{
      width: 100%;
    }
  }

  .Box_Form{
    display: flex;
    justify-content:space-around;
    align-items:center;
    text-align: center;
    flex-wrap: wrap;
    /*min-height: 150px;*/
    height:auto;
    padding:0 0 20px 0;
  }

  /*.Box_Btn{*/
    /*padding:0 0 1.386667rem 0;*/
    /*display: flex;*/
    /*width: 100%;*/
    /*justify-content: center;*/
    /*align-content: center;*/
  /*}*/

  .alertImg-slide-enter-active {
    animation: zoomIn1 1s;
  }
  .alertImg-slide-leave-active {
    animation: zoomIn1 .1s reverse;
  }
  .alertImg-slide-enter-active .yi23-imgalert{
    animation: zoomIn 1s;
  }
  .alertImg-slide-leave-active .yi23-imgalert{
    animation: zoomIn .5s reverse;
  }
  @keyframes zoomIn1 {
    from {
      opacity: 0;
    }

    50% {
      opacity: 1;
    }
  }
  @keyframes zoomIn {
    from {
      transform: translate(-50%,-50%) scale(0);
      opacity: 0;
    }
    50% {
      transform: translate(-50%,-50%) scale(1.1);
      opacity: 1;
    }
  }
</style>
<script>
  export default {
    data () {
      return {
//        open:false
      }
    },
    props: ['open','otherPay'],
    methods:{
      closeBox:function () {
        this.$parent.open = false;
        this.$parent.otherPay = false;
      }
    },




  }
</script>
