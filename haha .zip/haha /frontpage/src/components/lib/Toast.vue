<template>
  <transition name="toast-slide" @after-enter="show()" @after-leave="hide()">
    <div class="yi23-toast" v-if="!!currentMsg  || open">
        <slot>{{currentMsg}}</slot>
    </div>
  </transition>
</template>
<style code lang="less">
  .yi23-toast{
    line-height: 1.5;
    padding: 15px 23px;
    box-sizing: border-box;
  }
  .toast-slide-enter-active {
    animation: slideOutDown 1s;
  }
  .toast-slide-leave-active {
    animation: slideOutDown .5s reverse;
  }
  @keyframes slideOutDown {
    from {
      visibility: hidden;
      transform: translate3d(0, 100%, 0);
    }
    to {
      transform: translate3d(0, 0, 0);
    }
  }
</style>
<script>
export default {
  name: 'yi23Toast',
  data () {
    return {
      timer: '',
      currentMsg:this.value
    }
  },
  props: ['open','value', 'step'],
  computed: {
    getStep () {
      if (this.step) {
        return this.step
      } else {
        return 3000
      }
    }
  },
  watch:{
    currentMsg(val) {
      this.$emit('input',val)
    },
    value(val) {
      this.currentMsg = val
    }
  },
  methods: {
    show: function () {
      console.log('--show000000---')
      this.$emit('show')
      if (this.timer) {
        clearTimeout(this.timer)
      }
      this.timer = setTimeout(() => {
        this.$emit('toastColse')
        this.currentMsg=''
      }, this.getStep)
    },
    hide: function () {
      this.$emit('hide')
    }
  }
}
</script>
