<template>
  <x-cell
    class="field"
    :title="label"
    v-clickoutside="doCloseActive"
    :class="[{
      'is-textarea': type === 'textarea',
      'is-nolabel': !label
    }]">
    <textarea
      @change="$emit('change', currentValue)"
      ref="textarea"
      class="field-core"
      :placeholder="placeholder"
      v-if="type === 'textarea'"
      :rows="rows"
      :disabled="disabled"
      :readonly="readonly"
      v-model="currentValue">
    </textarea>
    <input
      @change="$emit('change', currentValue)"
      ref="input"
      class="field-core"
      :placeholder="placeholder"
      :number="type === 'number'"
      v-else
      :type="type"
      @focus="active = true"
      :disabled="disabled"
      :readonly="readonly"
      :value="currentValue"
      @input="handleInput">
    <div
      @click="handleClear"
      class="field-clear"
      v-if="!disableClear"
      v-show="currentValue && type !== 'textarea' && active">
      <i class="yi23iconfont icon-closex"></i>
    </div>
    <span class="field-state" v-if="state" :class="['is-' + state]">
      <i class="yi23iconfont" :class="['icon-field-' + state]"></i>
    </span>
    <div class="field-other">
      <slot></slot>
    </div>
  </x-cell>
</template>

<script>
  import XCell from '@/components/lib/cell/Cell';
  import Clickoutside from '@/utils/directive/clickoutside';
  /**
   * field
   * @desc 编辑器，依赖 cell
   * @module components/field
   *
   * @param {string} [type=text] - field 类型，接受 text, textarea 等
   * @param {string} [label] - 标签
   * @param {string} [rows] - textarea 的 rows
   * @param {string} [placeholder] - placeholder
   * @param {string} [disabled] - disabled
   * @param {string} [readonly] - readonly
   * @param {string} [state] - 表单校验状态样式，接受 error, warning, success
   *
   * @example
   * <yi23-field v-model="value" label="用户名"></yi23-field>
   * <yi23-field v-model="value" label="密码" placeholder="请输入密码"></yi23-field>
   * <yi23-field v-model="value" label="自我介绍" placeholder="自我介绍" type="textarea" rows="4"></yi23-field>
   * <yi23-field v-model="value" label="邮箱" placeholder="成功状态" state="success"></yi23-field>
   */
  export default {
    name: 'yi23-field',

    data() {
      return {
        active: false,
        currentValue: this.value
      };
    },

    directives: {
      Clickoutside
    },

    props: {
      type: {
        type: String,
        default: 'text'
      },
      rows: String,
      label: String,
      placeholder: String,
      readonly: Boolean,
      disabled: Boolean,
      disableClear: Boolean,
      state: {
        type: String,
        default: 'default'
      },
      value: {},
      attr: Object
    },

    components: { XCell },

    methods: {
      doCloseActive() {
        this.active = false;
      },

      handleInput(evt) {
        this.currentValue = evt.target.value;
      },

      handleClear() {
        if (this.disabled || this.readonly) return;
        this.currentValue = '';
      }
    },

    watch: {
      value(val) {
        this.currentValue = val;
      },

      currentValue(val) {
        this.$emit('input', val);
      },

      attr: {
        immediate: true,
        handler(attrs) {
          this.$nextTick(() => {
            const target = [this.$refs.input, this.$refs.textarea];
            target.forEach(el => {
              if (!el || !attrs) return;
              Object.keys(attrs).map(name => el.setAttribute(name, attrs[name]));
            });
          });
        }
      }
    }
  };
</script>

<style lang="less">
  .field {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    .cell-title {
      width: 105px;
      flex: none;
    }
    .yi23iconfont{
      color: #000000;
    }
    ::-webkit-input-placeholder { /* WebKit browsers */
      color: #cccccc;
    }
    :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
      color:    #cccccc;
    }
    ::-moz-placeholder { /* Mozilla Firefox 19+ */
      color:    #cccccc;
    }
    :-ms-input-placeholder { /* Internet Explorer 10+ */
      color:    #cccccc;
    }

  }

  .field .cell-value {
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1;
    color: inherit;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
  }
  .field.is-nolabel .cell-title {
    display: none;
  }
  .field.is-textarea {
    -webkit-box-align: inherit;
    -ms-flex-align: inherit;
    align-items: inherit;
  }
  .field.is-textarea .cell-title {
    padding: 10px 0;
  }
  .field.is-textarea .cell-value {
    padding: 5px 0;
  }
  .field-core {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0;
    border: 0;
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1;
    outline: 0;
    line-height: 1.6;
    font-size: inherit;
    width: 100%;
  }
  .field-clear {
    opacity: .2;
  }
  .field-state {
    color: inherit;
    margin-left: 20px;
  }
  .field-state .yi23iconfont {
    font-size: 20px;
  }
  .field-state.is-default {
    margin-left: 0;
    color: #d5d5d5;
  }
  .field-state.is-success {
    color: #4caf50;
  }
  .field-state.is-warning {
    color: #ffc107;
  }
  .field-state.is-error {
    color: #f44336;
  }
 .field-other {
    top: 0;
    right: 0;
    position: relative;
  }
</style>
