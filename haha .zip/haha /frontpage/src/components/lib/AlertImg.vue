<template>
  <transition name="alertImg-slide" @after-enter="show()" @after-leave="hide()">
    <div class="yi23-imgalert__box" v-if="open || currentStatus">
      <div class="yi23-mask" v-if="open || currentStatus"></div>
      <div class="yi23-imgalert">
        <div class="yi23-imgalert__hd">
          <slot></slot>
        </div>
        <div class="yi23-imgalert__ft" @click="close">
          <span class="yi23iconfont icon-closex"></span>
        </div>
      </div>
    </div>
  </transition>
</template>
<style code lang="less">

  .alertImg-slide-enter-active {
    animation: zoomIn1 1s;
  }
  .alertImg-slide-leave-active {
    animation: zoomIn1 .1s reverse;
  }
  .alertImg-slide-enter-active .yi23-imgalert{
    animation: zoomIn 1s;
  }
  .alertImg-slide-leave-active .yi23-imgalert{
    animation: zoomIn .5s reverse;
  }
  @keyframes zoomIn1 {
    from {
      opacity: 0;
    }

    50% {
      opacity: 1;
    }
  }
  @keyframes zoomIn {
    from {
      transform: translate(-50%,-50%) scale(0);
      opacity: 0;
    }
    50% {
      transform: translate(-50%,-50%) scale(1.1);
      opacity: 1;
    }
  }
</style>
<script>
export default {
  name: 'yi23AlertImg',
  data () {
    return {
      currentStatus:''
    }
  },
  props: ['open','value'],
  watch:{
    value (val){
      this.currentStatus=val
    },
    currentStatus (val) {
      this.$emit('input',val)
    }
  },
  methods: {
    show: function () {
      this.$emit('show')
    },
    hide: function () {
      this.$emit('hide')
    },
    close: function () {
      this.currentStatus=false
      this.$emit('alertImgClose')
    }
  }
}
</script>
