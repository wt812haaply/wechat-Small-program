<template>
  <div class="laodingBox" v-show="show" @click="stopAction">
    <div class="loadBg"></div>
    <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
  </div>
</template>

<script>
  export default {
    name: "smallLoading",
    data () {
      return {
        show:true
      }
    },
    props: [],
    created(){
    },
    methods:{
      stopAction(){
        event.stopPropagation()
        event.preventDefault()
      }
    }

  }
</script>

<style scoped lang="less">
  .laodingBox{
    display: flex;
    align-items: center;
    justify-content:center;
    width: 100%;
    height:100%;
    overflow: hidden;
    font-size: 14px;
    position: fixed;
    top:0;
    left: 0;
    z-index:999;
  }
  .loadBg{
    width: 100%;
    height:100%;
    background: rgba(0, 0, 0, 0.1);
    position: fixed;
    left: 0;
    top: 0;
  }

  .lds-ellipsis {
    position: relative;
    width: 64px;
    height: 64px;
    z-index: 1;
  }
  .lds-ellipsis div {
    position: absolute;
    width: 11px;
    height: 11px;
    border-radius: 50%;
    background: #ffffff;
    animation-timing-function: cubic-bezier(0, 1, 1, 0);
  }
  .lds-ellipsis div:nth-child(1) {
    left: 6px;
    animation: lds-ellipsis1 0.6s infinite;
  }
  .lds-ellipsis div:nth-child(2) {
    left: 6px;
    animation: lds-ellipsis2 0.6s infinite;
  }
  .lds-ellipsis div:nth-child(3) {
    left: 26px;
    animation: lds-ellipsis2 0.6s infinite;
  }
  .lds-ellipsis div:nth-child(4) {
    left: 45px;
    animation: lds-ellipsis3 0.6s infinite;
  }
  @keyframes lds-ellipsis1 {
    0% {
      transform: scale(0);
    }
    100% {
      transform: scale(1);
    }
  }
  @keyframes lds-ellipsis3 {
    0% {
      transform: scale(1);
    }
    100% {
      transform: scale(0);
    }
  }
  @keyframes lds-ellipsis2 {
    0% {
      transform: translate(0, 0);
    }
    100% {
      transform: translate(19px, 0);
    }
  }


</style>
