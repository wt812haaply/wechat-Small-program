<template>
    <div class="collapse">
      <slot></slot>
    </div>
</template>

<script>
    export default {
      name: "collapseContainer",
        data() {
           return{
             currentActive:this.value
           }
        },
        props:['value'],
        watch:{
          value(val){
              this.currentActive=val
          },
          currentActive(val, oldValue) {
            this.$emit('input', val);
          }
        },
    }
</script>

<style scoped lang="less">
  .collapse{
    overflow: hidden;
    width: 100%;

  }
</style>
