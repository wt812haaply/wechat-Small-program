<template>
  <transition name="toast-up" @after-enter="show()" @after-leave="hide()">
    <div class="yi23-toast" v-if="!!currentMsg">
        {{currentMsg}}
    </div>
  </transition>
</template>
<style lang="less" scoped>
  .yi23-toast{
    line-height: 1.5;
    padding: 15px 23px;
    box-sizing: border-box;
    border-radius: 0;
  }

  .toast-up-enter-active {
    transition: all .5s ease;
  }
  .toast-up-leave-active {
    transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);;
  }

  .toast-up-enter,.toast-up-leave-to{
    transform: translate3d(0, 100%, 0);
    opacity: 0;
  }
</style>
<script>
import {mapGetters,mapActions} from 'vuex'
export default {
  data(){
    return {
      timer:''
    }
  },
  computed: {
    ...mapGetters({
      currentMsg:'errmsg',
      getStep:'step'
    })
  },
  methods: {
    ...mapActions(['setErrorMsg']),
    show: function () {
      if (this.timer) {
        clearTimeout(this.timer)
      }
      this.timer = setTimeout(() => {
        this.setErrorMsg('');
      }, this.getStep)
    },
    hide(){
      console.log('toast closed');
    }
  }
}
</script>
