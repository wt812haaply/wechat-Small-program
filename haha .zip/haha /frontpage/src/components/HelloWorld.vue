<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <!--<datepicker :disabledDates="state.disabledDates" :highlighted="state.highlighted" :language="zh" :value="state.endDate" @selected="highlightTo"  :inline="true" v-if="opened" >-->
      <!--Choose a Date-->
    <!--</datepicker>-->

    <h2 @click="openPicker">open datepicker</h2>
    <router-link to="/Buy/mallPage">mallPage</router-link>
    <br>
    <router-link to="/Member/payPage">PayPage</router-link>
    <br>
    <router-link to="/cityList">cityList</router-link>
    <br>
    <router-link to="popupDemo">popupDemo</router-link>
    <br>
    <br>
    <br><br>
    <br>
    <router-link to="/lib/BoxPopupDemo">BoxPopupDemo</router-link>
    <br>
     <router-link to="cs">cs</router-link>
    <br><br><br><br>
    <br>
    <br/>
    <router-link to="/Index/index">index</router-link>
    <br>
    <br/>
    <router-link to="/Qna/ntalkerService">ntalkerService</router-link>
    <br/>
    <br/>
    <router-link to="/Subscribe/pdtDetailPage">pdtDetailPage</router-link>
    <br/>
    <br/>

    <br/>

    {{addressInfo}}
    <div>
      --------------------
    </div>



    <datepicker  :show="opened"  :userableList="userableList" @datePickerSelect="pickerSelect"></datepicker>
  </div>
</template>

<script>
  // import Datepicker from 'vuejs-datepicker';
  // import {en, zh} from 'vuejs-datepicker/dist/locale'
  import { mapGetters } from 'vuex'
  import Datepicker from '@/components/lib/picker/datePicker'
export default {
  name: 'HelloWorld',
  computed:{
    ...mapGetters({
      addressInfo:'addressInfo'
    })
  },
  methods:{
    openPicker() {
        this.opened=true
    },
    pickerSelect(val) {
      this.opened=false
      console.log(val)
    }
  },
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      datepicker:{
        show:false,
        date:null
      },
      opened:false,
      testdate:0,
      userableList:["2018-05-29","2018-05-30","2018-06-01","2018-06-02","2018-06-03","2018-06-05","2018-06-06","2018-06-07","2018-06-08","2018-06-09","2018-06-10","2018-06-11","2018-06-12","2018-06-13","2018-06-14","2018-06-15","2018-06-16","2018-06-17","2018-06-18","2018-06-19","2018-06-20","2018-06-21","2018-06-22","2018-06-23","2018-06-24","2018-06-25","2018-06-26","2018-06-27","2018-06-28"]
    }
  },
  components: {
    Datepicker
  },
  created(){
    // console.log('--33--')
    // this.$store.commit()

    this.$store.dispatch('getAddressInfo')
    // this.$store.dispatch('getAddressList')

  }
}
  var a = [1, 2, 3],b = [2, 4, 5]
  let difference = a.concat(b).filter(v => !a.includes(v) || !b.includes(v)) // [1,3,4,5]
  let difference1 = a.concat(b).filter(v => !b.includes(v)) // [1,3,4,5]
  console.log(difference)
  console.log(difference1)
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">

  @import "~common/less/variable";

h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  /*margin: 0 10px;*/
}
a {
  color: #42b983;
  line-height: 60px;
}
 .hello{
  }
</style>
