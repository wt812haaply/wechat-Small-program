<template>
  <div class="yclosetContainer"><!--configPage-->
    <div class="yclosetHeader">
        <go-back></go-back>
    </div>

    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="configPage">
        <ul class="ConList">
          <li>
            <router-link to="/Others/aboutyi23">
            <div class="Left">衣二三简介</div>
            <div class="Right"><i class="yi23iconfont icon-right"></i></div>
            </router-link>
          </li>
          <li>
            <router-link to="/Others/pvtSafe">
            <div class="Left">隐私保护</div>
            <div class="Right"><i class="yi23iconfont icon-right"></i></div>
            </router-link>
          </li>
          <li>
            <router-link to="/User/comments">
            <div class="Left">意见反馈</div>
            <div class="Right"><i class="yi23iconfont icon-right"></i></div>
            </router-link>
          </li>
        </ul>
      </div>
    </div>

    <div class="yclosetFooter">
      <div class="configPageFooterBtn">
        <button class="font-m btn btn-defult" @click="loginOutclick">退出登录</button>
      </div>
    </div>
  </div>
</template>
<script>
  import goBack from 'base/GoBack';
  import common from 'common/js/common';
  export default {
    data(){
      return{
      }
    },
    components:{
      goBack
    },
    methods:{
      loginOutclick:function () {
        //删除授权标记
        common.delCookie('wx_flag')
        common.delCookie('wx_flag', '.95vintage.com')
        this.$store.dispatch('loginOut')
        this.$router.replace({name:'index'})
      }
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  @import "~common/less/variable";
  .yclosetFooter{
    .height(75);
    display: flex;
    justify-content:center;
    align-items: center;
  }
  .yclosetCon{
    /*bottom:0;*/
  }
  .configPage{
    .padding(0,15,0,15);
    width:100%;
    display: flex;
    flex-direction: column;
    ul.ConList{
      display: flex;
      justify-content:center;
      align-items: center;
      flex-wrap: wrap;
      width: 100%;
      li{
        width:100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        .height(60);
        border-bottom: .5px rgba(0,0,0,.1) solid;
        color: #333;
        a{
          display: flex;
          justify-content:space-between;
          align-items: center;
          width:100%;
          color: #000;
        }
        .Left{
          display: flex;
          .font-size(14)
        }
        .Right{
          display: flex;
          .icon-right{
            .font-size(12);
            color:rgba(0,0,0,.2)
          }
        }
      }
    }
  }
  .configPageFooterBtn{
    width:100%;
    background: @color-background;
    .padding(0,10,0,10);
    button.btn{
      width:100%;
      .height(44);
    }
  }
</style>
