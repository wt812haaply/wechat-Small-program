<template>
  <div class="yclosetContainer"><!--comments-->
    <!--Header-->
    <!-- <div class="yclosetHeader"> -->
      <!-- <go-back></go-back> -->
    <!-- </div> -->
    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="indexCon">
        <!--定位-->
          <div class="inTopLocation">
            <!--成功 success-->
              <div class="locationSuccess font-l">
                <img src="https://tu.95vintage.com/web_source/Home/Common/images/2017122501/map.svg" alt="">
                <a href=""></a>
                <i v-if="regionInfo.status==0">定位中</i>
                <i v-else-if="regionInfo.status==1 || regionInfo.status==3" @click="toCityList">{{ regionInfo.info?regionInfo.info.cityName:'' }}</i>
                <i v-else-if="regionInfo.status==2" @click="toCityList"> 单击选择城市</i>
              </div>
          </div>

        <component :is="item.componetName" v-for="item in index.content" :info="item" :key="item.id + item.addTime">
          <!-- 组件在 vm.currentview 变化时改变！ -->
        </component>

        <div class="vipUser" v-if="hoverItem">
          <a :href="hoverItem.redirectUrl">
            <img :src="hoverItem.imageUrl">
          </a>
        </div>
      </div>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar></bottom-Bar>
    </div>
    <bounce-in-up>
        <div class="successTipCon" v-show="(regionInfo.status != 3 && regionInfo.status != 0 && showRegionTip)" @click="toCityList">
                        <span class="left">
                          <img src="https://yimg.yi23.net/webimg/web/images/2018/0515/in-location-b-con-city.svg">
                        </span>
          <span class="content">
                          <h2>点击选择你的收件城市 <i class="icon yi23iconfont icon-arrow"></i></h2>
                          <p>{{ regionInfo.info?regionInfo.info.cityName:regionInfo.msg }}</p>
                        </span>
          <span class="right">
                          <img src="https://yimg.yi23.net/webimg/web/images/2018/0515/in-location-b-con-zq.svg">
                        </span>
        </div>
    </bounce-in-up>

    <div class="yclosetShade" v-if="step.mask">
      <div class="stepOne" v-if="step.one" @click="oneStep">
        <div class="stepOneImg">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0808/indexStepOne.png" alt="">
        </div>
      </div>
      <div class="stepTwo" v-if="step.two" @click="twoStep">
        <div class="stepTwoImg">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0808/indexStepTwo.png" alt="">
        </div>
      </div>
      <div class="stepThree" v-if="step.three" @click="threeStep">
        <div class="stepThreeImg">
          <img src="https://yimg.yi23.net/webimg/web/images/2018/0808/indexStepThree.png?!" alt="">
        </div>
      </div>
    </div>

    <yi23-alert-img v-model="popViewDialog.isShow">
      <img class="imgalert___hd-img" :src="popViewDialog.data.img" @click="popViewJump(popViewDialog.data.url)" v-if="popViewDialog.data">
    </yi23-alert-img>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import goBack from 'base/GoBack';
import yi23Toast from '@/components/lib/Toast.vue';
import yi23AlertImg from '@/components/lib/AlertImg_m.vue';
import { getPreloadImgAttr,toLocaleDateStringFormat}from 'common/js/utils';
import BounceInUp from '@/components/lib/transition/BounceInUp.vue';
import bottomBar from 'base/BottomBar';
import smallList from './smallList';
import bigList from './bigList';
import Banner from './Banner';
import inSearch from './inSearch';
import Special from './Special';
import { index, getPopView } from 'api/index';
import loadAreaJs from '@/utils/loadAreaJs';
import  shareMixin  from '@/mixins/share';
import _track from '@/common/js/track'
export default {
  mixins:[ shareMixin ],
  data() {
    return {
      showRegionTip: true,
      none: false,
      showRegionRes: true,
      hoverItem: null,
      index: {
        content: null
      },
      getCityForIP: {},
      getCityStatus: true,
      step: {
        one:true,
        two:false,
        three:false,
        mask:'',
      },
      listenerNum:0,
      listenerTimer:null,
      popViewDialog:{
        isShow:false,
        data:null
      }
    };
  },
  props: [],
  components: {
    BounceInUp,
    goBack,
    yi23Toast,
    bottomBar,
    smallList,
    bigList,
    Banner,
    inSearch,
    Special,
    yi23AlertImg
  },
  watch: {},
  computed: {
    regionInfo() {
      let regionInfo = this.$store.getters.regionInfo;
      if (regionInfo.status == 3 || regionInfo.status == 0) {
        setTimeout(() => {
          this.showRegionTip = false;
        }, 3000);
      }
      return regionInfo;
    }
  },
  methods: {
    toCityList: function() {
      this.$router.push({
        path: '/cityList'
      });
    },

    oneStep(){
      this.step.one = false
      this.step.two = true
    },
    twoStep(){
      this.step.three = true
      this.step.two = false
    },
    threeStep(){
      this.step.three = false
      this.step.mask = false
      this.getLocalStorage()
    },

    getLocalStorage(){
      let once = localStorage.getItem("indexTips")
      if(!once){
        localStorage.setItem("indexTips",1)
        this.step.mask = false;
      }
      else {
        this.step.mask = true;
      }
    },
    aMapListener() {
      if(window.AMap && window.AMap.Map){
        this.$store.dispatch('getRegion')
        return false
      }else if(this.listenerNum<10){
        this.listenerTimer=setTimeout(()=>{
          clearTimeout(this.listenerTimer)
          this.listenerNum++
          this.aMapListener()
        },100)
      }
    },
    setLocalStorageNow(name,value){

      if(localStorage.getItem(name)){
        localStorage.removeItem(name);
      }
      localStorage.setItem(name,JSON.stringify({value:`${value}`,timer: toLocaleDateStringFormat(new Date().getTime())}));

    },
    isExpiresLocalStorage(name){
      let timer = localStorage.getItem(name) && JSON.parse(localStorage.getItem(name)).timer;
      let now = toLocaleDateStringFormat(new Date().getTime());

      if(!timer || Number(now)>Number(timer)){
        return true
      }
      return false
    },
    popView(){
      let _t = this;
      //获取cookie中首页弹窗key
      let popCookie = this.isExpiresLocalStorage('ali_popViewIndex');
      if(popCookie){
        //当前首页弹窗已过期，或者cookie中没有popViewIndex
        getPopView({id:2}).then((res)=>{
          console.log(res);
          if(res.code == 200 && res.data != '' && JSON.stringify(res.data) != '{}'){

            getPreloadImgAttr(res.data.img,function(){
              _t.popViewDialog.data = res.data;
              _t.popViewDialog.isShow = true;

              _track.popViewVisit({'popupViewId':res.data.id});
              _t.setLocalStorageNow('ali_popViewIndex',1);
            })
          }
        })
      }
    },
    popViewJump(url){
      _track.popviewTapCount({'popupViewId':this.popViewDialog.data.id});
      window.location.href=url;
    },
  },
  created() {
    if (this.$clientType == 4) {
      this.popView()
    }
    // this.$store.dispatch('getRegion');
    index().then(res => {
      this.index.content = res.data.itemList.map(function(el) {
        if (el.itemType == 2) {
          el.componetName = 'smallList';
        } else if (el.itemType == 4) {
          el.componetName = 'bigList';
        } else if (el.itemType == 12) {
          el.componetName = 'Banner';
        } else if (el.itemType == 5) {
          el.componetName = 'inSearch';
        } else if (el.itemType == 3) {
          el.componetName = 'Special';
        }
        return el;
      });
      this.hoverItem = res.data.hoverItem;
      this.$store.commit('bigLoading', false)
      let once = localStorage.getItem("indexTips")
      if(once){
      this.step.mask = false;
      }else {
        this.step.mask = true;
      }
    });

    //高德地图 后续加载处理
    loadAreaJs.init(()=>{
      this.aMapListener()
    })
  },
  mounted () {
    let params = {
      title: "衣二三",
      url: window.location.href,
      shareType: 0,
    }

    this.setShareMessage(params);
  }
};
</script>
<style scoped lang="less">
@import '~common/less/variable';
.image-ratio:after {
  padding-top: 100%;
}
.imgalert___hd-img{
  display: block;
  width: 100%;
}
.yclosetContainer {
  background: #fafafa;
}

.indexCon {
  display: flex;
  flex-wrap: wrap;
  width: 100%;
  .inTopLocation {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    .locationSuccess,
    .locationFailure {
      display: flex;
      width: 100%;
      justify-content: center;
      align-items: center;
      line-height: 40px;
      .font-size(12);
      img {
        width: auto;
      }
      i {
        color: #000;
        .font-size(12);
      }
    }
    .locationFailure {
      i {
        color: #000;
        .font-size(12);
      }
      i.iA {
        color: #ff544b;
        .font-size(13);
      }
      i.iB {
        .margin(0,0,0,5);
      }
      img {
        position: relative;
        top: -1px;
        left: 2px;
      }
    }
  }
  .inModular {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
  }
  .vipUser {
    position: fixed;
    z-index: 2;
    .bottom(62);
    .right(12);
    img {
      .width(47);
      display: block;
      border-radius: 4px;
    }
  }
}
.successTipCon,
.failureTipCon {
  background: #fff;
  position: fixed;
  z-index: 10;
  left: 50%;
  margin-left: -7.46rem;
  .bottom(60);
  .width(240);
  height: auto;
  .padding(26,20,26,20);
  border-radius: 3px;
  box-shadow: 2px 10px 20px rgba(128, 125, 125, 0.4);
  display: flex;
  align-items: center;
  justify-content: space-between;
  span {
    .font-size(12);
    img {
      display: block;
    }
  }
  span.left {
    img {
      .width(32);
      .height(30);
    }
  }
  span.content {
    h2,
    p {
      .font-size(14);
    }
    h2 {
      i {
        .width(5);
        .font-size(4);
      }
    }
    p {
      .font-size(12);
      color: #999;
      .line-height(12);
    }
  }
  span.right {
    img {
      .width(26);
      .height(22);
    }
  }
}
/* Iphone X */
@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
  /*增加底部适配层*/
  .indexCon .vipUser {
    .bottom(96);
  }
}

.stepOne{
  position:fixed;
  /*width: 100%;*/
  float: right;
  bottom:0px;
  right:10px;
  z-index: 1;
}

.stepOneImg{
  img{
    width:220px;
  }
}

.stepTwo,.stepThree{
  position:fixed;
  width: 100%;
  bottom:0px;
  right:0px;
  z-index: 1;
}


.stepTwoImg,.stepThreeImg{
  display: flex;
  width:100%;
  height:auto;
  justify-content: center;
  align-items: center;
  img{
    width:220px;
  }
}
</style>
