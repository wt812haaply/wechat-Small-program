<!--itemType 2-->
<template>
  <div class="ModularSwiperCustom" v-if="info">
    <div class="inModularTitle">
      <h2 class="font-m">{{info.titleZh}}</h2>
      <p class="font-l">{{info.titleEn}}</p>
    </div>
    <swiper :options="swiperOption" v-if="info && info.collectionItems" style="padding:0 10px">
      <swiper-slide v-for="item in info.collectionItems" :key="item.id">
        <a :href="item.url">
          <div class="imgP image-ratio" v-if="info">
            <img :src="item.imagePath" alt="">
          </div>
        </a>
      </swiper-slide>
    </swiper>

    <div class="inMore">
        <div class="moreBtn">
          <a :href="info.renderInfo.showListButtonUrl">
          <i class="iA yi23iconfont icon-jiantao"></i>
          <i class="iB">{{info.renderInfo.showListButtonTitle}}</i>
          </a>
        </div>
    </div>

  </div>
</template>
<script>
  export default {
    data () {
      return{
        swiperOption: {
          slidesPerView: 2.8,
          spaceBetween: 2,
        },
      }
    },
    props:[
      'info'
    ],
    components:{
    },
    watch:{
    },
    computed: {
    },
    methods: {
    },
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";
  .image-ratio:after{
    padding-top: 100%;
  }
  /*swiper 自定义个数 2.5*/
  .ModularSwiperCustom{
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    align-items:center;
    width: 100%;
    height:auto;
  }
  .swiper-container,.swiper-wrapper,.swiper-slide{
    width:100%;
  }
  .swiper-slide{
    height:auto;
    .imgP{
      padding-bottom: 125%;
      background:#eee;
    }
  }

  .inModularTitle{
    .padding(20,0,20,0);
    width:100%;
    h2,p{
      text-align: center;
      .font-size(18);
    }
    p{
      .font-size(10);
      line-height: 1.4;
    }
  }

  .inMore{
    display: flex;
    justify-content:center;
    align-items:center;
    width:100%;
    .padding(20,0,40,0);
    .moreBtn{
      text-align: center;
      //.width(110);
      width:auto;
      min-width: 80px;
      .padding(0,10,0,10);
      .height(32);
      border:1px #333 solid;
      a{
        display: flex;
        justify-content:center;
        align-items:center;
        width:100%;
        .height(32);
        color: #222;
        i.iA{
          .font-size(20);
          .padding(0,4,0,0);
        }
        i.iB{
          .font-size(12);
        }
      }
      /*
      i{
        flex: 1;
        text-align: center;
        .line-height(32);
        .font-size(12);
      }
      .iA{

      }
      .iB{

      }
      */
    }
  }
</style>
