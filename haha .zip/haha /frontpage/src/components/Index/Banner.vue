<!--itemType 12-->
<template>
  <div class="ModularSwiperBanner" v-if="info">
    <swiper :options="swiperOption" v-if="info && info.collectionItems && info.collectionItems.length > 1">
      <swiper-slide v-for="item in info.collectionItems" :key="item.id">
        <a :href="item.url">
        <div class="imgP1 image-ratio1 impp">
          <img :src="item.imagePath" alt="">
        </div>
        </a>
      </swiper-slide>
      <div class="swiper-pagination" slot="pagination"></div>
    </swiper>

    <div class="smallBanner" v-else-if="info && info.collectionItems &&  info.collectionItems.length == 1">
      <div v-for="item in info.collectionItems">
      <a :href="item.url">
      <img :src="item.imagePath" alt="">
      </a>
      </div>
    </div>
  </div>

</template>
<script>
  export default {
    data () {
      return{
        swiperOption: {
          spaceBetween: 30,
          pagination: {
            el: '.swiper-pagination',
            bulletElement : 'li',
            clickable: true
          }
        },
      }
    },
    props:[
      'info'
    ],
    components:{
    },
    watch:{
    },
    computed: {
    },
    methods: {
    },
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";
  /*swiper banner*/
  .ModularSwiperBanner{
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    align-items:center;
    width: 100%;
    height:auto;
    background-color:#eee;
  }
  .swiper-container,.swiper-wrapper,.swiper-slide,.smallBanner img,.impp,.impp img{
    width:100%;
  }
  .swiper-slide{
    height:auto;
  }
</style>
<style lang="less">
  .swiper-pagination-bullet{  background:#222;  }
</style>
<!--<style lang="less" scoped>-->
<!--.swiper-pagination-bullet-active{-->
<!--background:#fff;-->
<!--width: 20px;-->
<!--height:4px;-->
<!--border-radius: 4px;-->
<!--}-->
<!--.swiper-pagination-bullet{-->
<!--height:4px;-->
<!--border-radius: 8px;-->
<!--background:#fff;-->
<!--}-->
<!--</style>-->
