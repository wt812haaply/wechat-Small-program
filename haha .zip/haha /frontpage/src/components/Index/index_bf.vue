<template>
  <div class="yclosetContainer"><!--comments-->
    <div class="yclosetHeader"><!--Header-->
      <go-back></go-back>
    </div>
    <div class="yclosetCon bG"><!--核心内容部分-->
      <div class="indexCon">
        <!--定位-->
        <div class="inTopLocation">
          <!--成功 success-->
            <div class="locationSuccess font-l">
              <img src="https://tu.95vintage.com/web_source/Home/Common/images/2017122501/map.svg" alt="">
              <i>北京</i>
            </div>
              <div class="locationSuccessTip locationAnimation">
                  <div class="successTipCon">
                    <span class="left">
                      <img src="http://tu.yi23.net/topicBanner/862-20180301_144132-1519886492628-1.png">
                    </span>
                    <span class="content">
                      <h2>点击选择你的收件城市 <i class="icon yi23iconfont icon-arrow"></i></h2>
                      <p>北京</p>
                    </span>
                    <span class="right">
                      <img src="http://tu.yi23.net/topicBanner/862-20180301_144132-1519886492628-1.png">
                    </span>
                  </div>
              </div>
          <!--失败 failure-->
            <div class="locationFailure font-l">
              <i class="iA">自动定位失败</i>
              <i class="iB">点击重试</i>
              <img src="https://tu.95vintage.com/web_source/Home/Common/images/2017122501/refresh.svg" alt="">
            </div>
            <div class="locationFailureTip locationAnimation">
              <div class="failureTipCon">
                    <span class="left">
                      <img src="http://tu.yi23.net/topicBanner/862-20180301_144132-1519886492628-1.png">
                    </span>
                     <span class="content">
                      <h2>点击选择你的收件城市 <i class="icon yi23iconfont icon-arrow"></i></h2>
                      <p>定位失败</p>
                    </span>
                    <span class="right">
                      <img src="http://tu.yi23.net/topicBanner/862-20180301_144132-1519886492628-1.png">
                    </span>
              </div>
            </div>
        </div>

        <!--banner 1-->
        <div class="ModularSwiperBanner">
          <swiper :options="swiperOption">
            <swiper-slide>
              <div class="imgP image-ratio">
              <img src="http://tu.yi23.net/collections/862-20180302_174443-1519983883132-1.gif" alt="">
              </div>
            </swiper-slide>
            <div class="swiper-pagination" slot="pagination"></div>
          </swiper>
        </div>

        <!-- 普通banner -->
        <div class="imgP inHero image-ratio">
          <img src="http://tu.yi23.net/collections/862-20180227_194211-1519731731191-1.jpg" alt="">
        </div>

        <!--swiper 2 热租品类-->
        <div class="ModularSwiperMultiRow">
          <div class="inModularTitle">
          <h2 class="font-m">热租品类</h2>
          <p class="font-l">BY CATEGORY</p>
          </div>
          <swiper :options="swiperOption2">
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>

            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/logservice/863-20180303_184200-1520073720931-1.png" alt="">
              </div>
            </swiper-slide>

          </swiper>
          <div class="inMore">
              <div class="moreBtn">
                <i class="iA">11</i>
                <i class="iB">全部</i>
              </div>
          </div>
        </div>


        <!--swiper 3 每日上新-->
        <div class="ModularSwiperCustom">
          <div class="inModularTitle">
            <h2 class="font-m">热租品类</h2>
            <p class="font-l">BY CATEGORY</p>
          </div>
          <swiper :options="swiperOption3">
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/22971/41-20180131_151458-1517382898543-1.jpg!300" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/22971/41-20180131_151458-1517382898543-1.jpg!300" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/22971/41-20180131_151458-1517382898543-1.jpg!300" alt="">
              </div>
            </swiper-slide>

            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/22971/41-20180131_151458-1517382898543-1.jpg!300" alt="">
              </div>
            </swiper-slide>
            <swiper-slide>
              <div class="imgP image-ratio">
                <img src="http://tu.yi23.net/22971/41-20180131_151458-1517382898543-1.jpg!300" alt="">
              </div>
            </swiper-slide>
          </swiper>
          <div class="inMore">
            <div class="moreBtn">
              <i class="iA">11</i>
              <i class="iB">全部</i>
            </div>
          </div>
        </div>

        <!--专题-->
        <div class="inModular">
          <div class="inModularTitle">
            <h2 class="font-m">热租品类</h2>
            <p class="font-l">BY CATEGORY</p>
          </div>
          <div class="ModularFeature">
              <div class="ModularBanner">
                <div class="bannerImg image-ratio">
                  <img src="http://tu.yi23.net/posting/862-20180122_154155-1516606915035-1.jpg!750" alt="">
                </div>
              </div>
              <div class="modularCon">
                <h2 class="font-r">标题字数请限制在二十字以内，多了影响阅读多了影响阅读多了影响阅读多了影响阅读多了影响阅读</h2>
                <p class="font-l">来自韩国的alive stories，是深受韩国都市女性欢迎的新晋服饰品牌，旗下拥有多个产品线旗下拥有多个产品线，风格多样。内文最多显示两行…</p>
              </div>
          </div>
          <div class="ModularFeature">
            <div class="ModularBanner">
              <div class="bannerImg image-ratio">
                <img src="http://tu.yi23.net/posting/862-20180122_154155-1516606915035-1.jpg!750" alt="">
              </div>
            </div>
            <div class="modularCon">
              <h2 class="font-r">标题字数请限制在二十字以内，多了影响阅读多了影响阅读多了影响阅读多了影响阅读多了影响阅读</h2>
              <p class="font-l">来自韩国的alive stories，是深受韩国都市女性欢迎的新晋服饰品牌，旗下拥有多个产品线旗下拥有多个产品线，风格多样。内文最多显示两行…</p>
            </div>
          </div>
        </div>

        <div class="vipUser">
            <img src="http://tu.yi23.net/topicBanner/862-20180301_144132-1519886492628-1.png">
        </div>



      </div>
    </div>
    <div class="yclosetFooter">
      <bottom-Bar></bottom-Bar>
    </div>
  </div>
</template>
<script>

  import goBack from 'base/GoBack'
  import yi23Toast from '@/components/lib/Toast.vue'
  import bottomBar from 'base/BottomBar'
  export default {
    data () {
      return{
        //1
        swiperOption: {
          spaceBetween: 30,
          pagination: {
            el: '.swiper-pagination',
            clickable: true
          }
        },
        //2
        swiperOption2: {
          slidesPerView: 4,
          slidesPerColumn: 2,
          spaceBetween: 6,
        },
        //3
        swiperOption3: {
          slidesPerView: 2.5,
          spaceBetween: 2,
        },
      }
    },
    components:{
      goBack,
      yi23Toast,
      bottomBar
    },
    watch:{
    },
    computed: {
    },
    created:function () {
      let mapObj = new AMap.Map('iCenter');
      mapObj.plugin('AMap.Geolocation', function () {
        let geolocation = new AMap.Geolocation({
          "noIpLocate":0,
          "noGeoLocation":0,
          "GeoLocationFirst":true,
          "convert":true,
          "useNative":true,
          "extensions":"base"
        });
        console.log(geolocation)
        geolocation.getCityInfo(function (status,result) {
          if(status==="complete" && result.status==1){
            var cityCode = result.citycode;
//            console.log(cityCode)
          }else {

          }

        });
      });
    },
    methods: {
    },
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";

  .image-ratio:after{
    padding-top: 100%;
  }

  .yclosetContainer{
    background: #fafafa;
  }
  /*img placeholder*/
  .imgP{
    width:100%;
    .height(0);
    padding-bottom: 100%;
    position: relative;
    overflow: hidden;
    img{
      width:100%;
      position: absolute;
    }
  }
  /*普通 banner*/
  .inHero{
    padding-bottom: 21.8666%;
    .margin(3,0,0,0);
  }

  .locationAnimation{
      animation:fadeInUp 1s .2s ease both;
    }
  @keyframes fadeInUp{
    0%{
      opacity:0;
      transform:translateY(20px)
    }
    100%{
      opacity:1;
      transform:translateY(0)
    }
  }

  /*swiper 轮播banner*/
  .ModularSwiperBanner{
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    align-items:center;
    width: 100%;
    height:auto;
    .swiper-container{
      width:100%;
      .swiper-wrapper{
        width: 100%;
        .swiper-slide{
          width: 100%;
          height:auto;
          .imgP{
            padding-bottom: 51.2%;
          }
        }
      }
    }
  }
  /*swiper 多行展示*/
  .ModularSwiperMultiRow{
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    align-items:center;
    width: 100%;
    height:auto;
    .swiper-container{
      width:100%;
      .swiper-wrapper{
        width: 100%;
        .swiper-slide{
          width: 25%;
          height:auto;
        }
      }
    }
  }
  /*swiper 自定义个数 2.5*/
  .ModularSwiperCustom{
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    align-items:center;
    width: 100%;
    height:auto;
    .swiper-container{
      width:100%;
      .swiper-wrapper{
        width: 100%;
        .swiper-slide{
          width: 100%;
          height:auto;
          .imgP{
            padding-bottom: 125%;
          }
        }
      }
    }
  }
  /*专题*/
  .ModularFeature{
    width:100%;
    flex-wrap: wrap;
    display: flex;
    .ModularBanner{
      display: flex;
      width:100%;
      .bannerImg{
        width:100%;
        .height(0);
        padding-bottom: 51.2%;
        position: relative;
        overflow: hidden;
        img{
          width:100%;
          position: absolute;
        }
      }
    }
    .modularCon{
      .padding(10,20,40,20);
      h2{
        .font-size(14);
        line-height:1.3;
        text-align: left;
        color: #000000;
        .padding(10,0,10,0);
      }
      p{
        .font-size(12);
        line-height: 1.5;
        text-align: left;
        color: #000000;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;  /*2行*/
        overflow: hidden;
      }
    }
  }

  .inModularTitle{
    .padding(20,0,20,0);
    width:100%;
    h2,p{
      text-align: center;
      .font-size(18);
    }
    p{
      .font-size(10);
      line-height: 1.4;
    }
  }

  .inMore{
    display: flex;
    justify-content:center;
    align-items:center;
    width:100%;
    .padding(20,0,20,0);
    .moreBtn{
      text-align: center;
      width:100px;
      .width(100);
      .height(32);
      border:1px #333 solid;
      i{
        flex: 1;
        text-align: center;
        .line-height(32);
        .font-size(12);
      }
    }
  }

  .indexCon{
    display: flex;
    flex-wrap: wrap;
    width:100%;
    .inTopLocation{
      display: flex;
      flex-wrap: wrap;
      width:100%;
      .locationSuccess, .locationFailure{
        display: flex;
        width:100%;
        justify-content:center;
        align-items:center;
        line-height: 40px;
        .font-size(12);
        i{
          color: #000;
          .font-size(12)
        }
      }
      .locationSuccessTip,.locationFailureTip{
        position: fixed;
        .bottom(40);
        width: 100%;
        z-index: 10000;
        display: flex;
        align-items:center;
        justify-content:center;
      }
      .successTipCon,.failureTipCon{
        background: #fff;
        .width(240);
        height:auto;
        .padding(26,20,26,20);
        border-radius: 3px;
        box-shadow:2px 10px 20px rgba(128, 125, 125, .4);
        display: flex;
        align-items:center;
        justify-content:space-between;
        span{
          .font-size(12);
          img{
            display: block;
          }
        }
        span.left{
          img{
            .width(32);
            .height(30);
          }
        }
        span.content{
          h2,p{
            .font-size(14);
          }
          h2{
            i{
              .width(5);
              .font-size(4);
            }
          }
          p{
            .font-size(12);
            color: #999;
            .line-height(12);
          }
        }
        span.right{
          img{
            .width(26);
            .height(22);
          }
        }
      }
      .locationFailure{
        i{
          color: #000;
          .font-size(12)
        }
        i.iA{
          color: #ff544b;
          .font-size(13)
        }
        i.iB{
          .margin(0,0,0,5)
        }
        img{
          position: relative;
          top:-1px;
          left:2px;
        }
      }
    }
    .inModular{
      width:100%;
      display: flex;
      flex-wrap: wrap;
    }
    .vipUser{
      position: fixed;
      z-index: 2;
      .bottom(62);
      .right(12);
      img{
        .width(47);
        display: block;
      }
    }
  }
</style>
