<!--itemType 3-->
<template>
  <div class="inModular" v-if="info">
    <!--<div class="inModularTitle">-->
      <!--<h2 class="font-m">{{info.titleZh}}</h2>-->
      <!--<p class="font-l">{{info.titleEn}}</p>-->
    <!--</div>-->
    <div class="ModularFeature">
      <div class="ModularBanner" v-if="info">
        <div class="bannerImg image-ratio">
          <a :href="info.url">
          <img :src="info.imagePath" alt="">
          </a>
        </div>
      </div>
      <div class="modularCon" >
        <h2 class="font-r">{{info.title}}</h2>
        <p class="font-l">{{info.itemText}}</p>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    data () {
      return{
      title:false,
      }
    },
    props:[
      'info'
    ],
    components:{
    },
    watch:{
    },
    computed: {
    },
    methods: {
    },
  }
</script>
<style scoped lang="less">
  @import "~common/less/variable";

  .image-ratio:after{
    padding-top: 100%;
  }
  /*专题*/
  .ModularFeature{
    width:100%;
    flex-wrap: wrap;
    display: flex;
  }

  .ModularBanner{
    display: flex;
    width:100%;
  }

  .bannerImg{
    width:100%;
    .height(0);
    padding-bottom: 51.2%;
    position: relative;
    overflow: hidden;
    background: #eee;
    img{
      width:100%;
      position: absolute;
    }
  }


  .modularCon{
    .padding(10,20,10,20);
    display: block;
    width: 100%;
    h2{
      .font-size(14);
      line-height:1.3;
      text-align: left;
      color: #000000;
      .padding(10,0,10,0);
    }
    p{
      .font-size(12);
      line-height: 1.5;
      text-align: left;
      color: #000000;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;  /*2行*/
      overflow: hidden;
    }
  }

  .inModularTitle{
    .padding(20,0,20,0);
    width:100%;
    h2,p{
      text-align: center;
      .font-size(18);
    }
    p{
      .font-size(10);
      line-height: 1.4;
    }
  }
    .inModular{
      width:100%;
      display: flex;
      flex-wrap: wrap;
    }

</style>
