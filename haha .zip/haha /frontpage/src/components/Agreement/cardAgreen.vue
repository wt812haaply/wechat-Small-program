<template>
  <div class="agreenContent">
    <go-back></go-back>
    <!--<div class="leaseAgreement">-->
      <!--<div class="LATitle">欢迎使用衣二三共享订阅平台（以下简称“衣二三”）会员订阅服务，您在使用本服务前应认真阅读本服务条款。若您开始使用本服务，即表示您已阅读、理解并同意接受以下条款的约束，并遵守所有适用的法律和法规：  </div>-->
      <!--<div class="LACon">-->
        <!--<div class="listLi">-->
          <!--<span class="number">1.</span>-->
          <!--<span class="listLiCon">-->
          <!--使用衣二三服务的会员仅获得该商品在相应服务期限内的使用权，并不获得该商品的所有权。支付并开通会员服务后，会员将根据购买的会员服务种类获得相对应的会员有效期，自首次下单之日起计算并扣除。若开通会员服务后15日（含当日）内仍未下单，则会员有效期自第16日起自动扣除。当会员剩余有效期少于4天时，即使会员未下单，仍将自动扣除会员剩余有效期。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">2.</span>-->
          <!--<span class="listLiCon">-->

          <!--会员正常更换商品的往返物流服务，会员可选择衣二三指派的免费第三方物流服务提供商（以下简称“快递”）进行往返运送。会员也可选择衣二三指派的其他快递送达订单，会员支付差价，差价支付标准由当日的平台页面所示为准。会员应在会员期结束前将商品寄回（以快递揽收时间为准）。会员寄回时应保证商品完好无损。<br>-->
          <!--因如下情况造成订单延迟或无法配送等，衣二三不承担延迟配送或无法配送的责任：-->
          <!--</span>-->
        <!--</div>-->
        <!--<div class="ef">-->
          <!--1) 	用户提供的信息错误、地址不详细等原因导致的；-->
        <!--</div>-->
        <!--<div class="ef">-->
          <!--2) 	货物送达后无人签收，导致无法配送或延迟配送的；-->
        <!--</div>-->
        <!--<div class="ef">-->
          <!--3) 	不可抗力因素导致的，例如：自然灾害、交通戒严、突发战争等。-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">3.</span>-->
          <!--<span class="listLiCon">-->
          <!--衣二三上所有服饰均为共享服饰，不保证全新，敬请谅解。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">4.</span>-->
          <!--<span class="listLiCon">-->
          <!--衣二三在每件商品归还入库后，都会进行清洗、消毒、保养处理和质检后，再次上架。接受本协议表示您已认可衣二三的清洗、消毒、保养处理服务及质检标准。会员请勿私自对商品进行包括不限于清洗、消毒、保养处理、修补等。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">5.</span>-->
          <!--<span class="listLiCon">-->

          <!--会员所下单的衣箱内的商品，由于衣二三取消或者部分取消会员的订单，会员可联系衣二三在线客服沟通，衣二三核实后，为会员提供每一件未发商品一张加衣券的补偿；会员未在约定时间内归还衣箱等因素导致的问题除外。-->

          <!--</span>-->
        <!--</div>-->


        <!--<div class="listLi">-->
          <!--<span class="number">6.</span>-->
          <!--<span class="listLiCon">-->
          <!--商品因会员正常使用而产生的可去除的轻微污渍、成色降低、老化问题等情况，客户不承担相应费用。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">7.</span>-->
          <!--<span class="listLiCon">-->
          <!--如会员在使用过程中造成对商品的非正常磨损、丢失或被窃、归还商品不一致或逾期归还的，会员需要承担赔偿责任，具体规则如下：-->
          <!--</span>-->
        <!--</div>-->
        <!--<div class="ef">-->

          <!--1) 非正常损耗：<br>-->
          <!--a若商品无法修复并影响再次使用，包括不限于无法去除的污渍、磨损、破洞、褪色、金属件明显划痕刮花等，须由使用的会员对该商品进行赔偿。该会员订单进入异常订单流程，在异常订单处理期间，衣二三暂停会员下单权利，并扣除异常订单处理期间的会员有效期，直至会员按要求完成赔付且异常订单解除。会员应以会员下单当日该商品页面所示的零售价为标准进行赔付。<br>-->
          <!--b在会员有效期届满时，异常订单仍未解除的，在衣二三客服人员追讨后会员未赔偿的，衣二三有权扣除该会员相对应的押金或花呗额度，用于抵扣衣二三的实际损失，不足抵扣的，衣二三保留追偿权利。衣二三有权终止该账户的会员资格，拒绝该账户会员重新开通会员服务。<br>-->

        <!--</div>-->
        <!--<div class="ef">-->
          <!--2) 不归还商品：<br>-->

          <!--a如会员不归还商品，包括不限于丢失或被盗，商品未寄回等，应以会员下单当日商品页面所示的零售价进行赔付。该会员订单进入异常订单流程；在异常订单处理期间，衣二三暂停会员下单权利，并扣除异常订单处理期间的会员有效期，直至会员按要求完成赔付且异常订单解除。<br>-->
          <!--b在会员有效期届满时，异常订单仍未解除的，在衣二三客服人员追索后会员未赔偿的，衣二三有权扣除该会员相对应的押金或花呗额度，用于抵扣衣二三的实际损失，不足抵扣的，衣二三保留追偿权利。衣二三有权终止该账户的会员资格，拒绝该账户会员重新开通会员服务。<br>-->


        <!--</div>-->
        <!--<div class="ef">-->

          <!--3) 归还商品不一致：如会员寄回的商品与衣二三发出的原商品不一致，该会员订单进入异常订单流程，在异常订单处理期间，衣二三暂停会员下单权利，并扣除异常订单处理期间的会员有效期，直至会员归还原商品且异常订单解除。衣二三有权终止该账户的会员资格，拒绝该账户会员重新开通会员服务。-->
        <!--</div>-->
        <!--<div class="ef">-->
          <!--4) 逾期归还：会员在约定的会员有效期届满后未及时归还商品的，衣二三客服人员向该会员追讨未归还的商品后，会员未将商品归还的，衣二三有权根据逾期归还天数和商品实际情况，扣除该会员相对应的押金或花呗额度，用于抵扣衣二三的实际损失，不足抵扣的，衣二三保留追偿权利。衣二三有权终止该账户的会员资格，拒绝该账户会员重新开通会员服务。-->


        <!--</div>-->
        <!--<div class="ef">-->
          <!--5) 如有未尽事宜，商品情况符合本条相关约定的，按照本条相关约定履行。-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">8.</span>-->
          <!--<span class="listLiCon">-->
          <!--以下情况，包括不限于实际收到商品或有快递签收信息等，均视为接收商品。会员应本人接收商品并于接收商品时查验商品。如商品衣箱内商品存在包括不限于非正常损耗，或是与下单商品不一致等，须在接收商品24小时内联系衣二三在线客服进行协商解决。如需要归还上述问题商品，应于在线客服发出寄回信息后24小时内归还商品（即24小时内有快递揽收信息）。如会员接收商品，在24小时内没有联系衣二三在线客服提出异议，视为认可商品完好一致，包括不限于无丢失或被窃、无商品不一致、商品无非正常损耗等。-->

          <!--</span>-->
        <!--</div>-->

        <!--&lt;!&ndash;<div class="ef">&ndash;&gt;-->
        <!--&lt;!&ndash;1) 非正常损耗：经衣二三质检中心查验认为需要对商品进行“非常规处理”等额外修复后方能再次使用的商品，不影响正常穿着的损伤，由衣二三修复并承担修复费用；若质检中心查验认为商品损坏已影响正常穿着，则须由承租的会员对该商品进行赔偿，赔偿金额为该商品页面所示零售价的50%-100%，具体比例由衣二三根据商品流转周期裁定。&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->
        <!--&lt;!&ndash;<div class="ef">&ndash;&gt;-->
        <!--&lt;!&ndash;2) 丢失或被窃：如商品在会员租用期间丢失或被盗，会员须按照所丢失商品的零售价进行购买。客服人员会在核实商品未跟随其他衣物一并寄回后，进入异常订单流程；在异常订单处理期间，衣服将暂停配送，直至会员按要求缴纳完毕购买费用。&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->

        <!--&lt;!&ndash;<div class="ef">&ndash;&gt;-->
        <!--&lt;!&ndash;3) 逾期归还：会员在约定的租赁期限届满后未及时归还商品且未进行续费处理的，衣二三客服将向该会员追索未归还的商品，并约定时间取回。若客户逾期2日后仍不归还所租商品，则视为已购买所未归还的商品，须以平台上公布的售卖价格全额支付；衣二三有权优先以客户押金进行抵扣，并保留追偿权利。&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->

        <!--&lt;!&ndash;<div class="ef">&ndash;&gt;-->
        <!--&lt;!&ndash;4) 归还商品不一致：如会员寄回的商品与衣二三发出的原商品不一致，衣二三客服将提供原订单货品的核实信息向会员进行商品追讨。一旦产生问题，视同订单异常，租赁服务暂停，直至归还商品。&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->

        <!--&lt;!&ndash;<div class="ef">&ndash;&gt;-->
        <!--&lt;!&ndash;5) 恶意损坏：若会员未能完好归还商品或恶意对商品进行损坏，且在客服追索后拒绝赔偿，则衣二三有权扣除该会员全部押金及会员费，用于抵扣因衣物损坏所造成的损失，并保留追偿权利。&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->

        <!--&lt;!&ndash;<div class="ef">&ndash;&gt;-->
        <!--&lt;!&ndash;6) 如会员在快递签收时非本人接收，丢失风险由客人自行承担。&ndash;&gt;-->
        <!--&lt;!&ndash;</div>&ndash;&gt;-->


        <!--<div class="listLi">-->
          <!--<span class="number">9.</span>-->
          <!--<span class="listLiCon">-->
          <!--以下情况包括不限于会员指定快递放置商品的地点为代收地点，非会员本人实际收到商品等，均视为非会员本人接收商品。如非会员本人接收商品，商品丢失或被窃的风险由会员承担。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">10.</span>-->
          <!--<span class="listLiCon">-->
          <!--当会员选择衣二三指派的快递时，会员接收商品前，会员不承担商品丢失或被窃的风险。会员归还商品时，快递人员接收商品后，会员不承担商品丢失或被窃的风险；当会员使用非衣二三指派的快递归还商品时，衣二三接收会员归还的商品前，衣二三不承担商品丢失或被窃的风险。会员不应在接收或归还商品时将其放置于无人看管区，由此导致的商品丢失或被窃的风险由会员承担。-->

          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">11.</span>-->
          <!--<span class="listLiCon">-->
          <!--已购买服务的会员如需终止衣二三会员服务的，在支付会员费之日起7日内未使用会员服务的情况下，可申请退还已缴纳的会员费。超出7日或7日内使用了会员服务的，则不予退还已缴纳的费用。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">12.</span>-->
          <!--<span class="listLiCon">-->
          <!--请会员于归还商品前注意整理并取出在商品中的或附着在商品上的私人物品。如因会员在归还商品时未能取出该等私人物品而造成任何损失，衣二三不承担任何责任。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">13.</span>-->
          <!--<span class="listLiCon">-->
          <!--会员每次只能下1个商品衣箱，商品衣箱内商品数量根据不同商品所占衣位数量所定。预约下单新商品衣箱时，会员需提前预约归还旧商品衣箱，在新商品衣箱发货后按期归还旧商品衣箱。会员未按期归还旧商品衣箱的，将根据实际占用商品衣箱数扣除会员有效期。扣除会员有效期公式= 双商品衣箱日*商品衣箱数量。双商品衣箱日为自预约归还旧商品衣箱日期的次日起至会员归还一个商品衣箱的当日止。例如会员持有一个旧商品衣箱，1月2日下单新商品衣箱，1月3日新商品衣箱发货，会员预约旧商品衣箱的归还日期为1月4日，会员1月8日归还了旧衣箱，则1月4日至1月8日期间用户手中占用了两个商品衣箱，扣除会员有效期天数为4天*2=8天，若用户占用的旧衣箱按预约时间如期归还，则在此期间用户仅占用了新商品衣箱，应扣除的会员有效期天数为4天。-->



          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">14.</span>-->
          <!--<span class="listLiCon">-->
          <!--会员同时占用两个商品衣箱时，将无法继续下单；会员收到商品衣箱3天后，可继续下单新商品衣箱；会员在异常订单处理期间，将无法下单。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">15.</span>-->
          <!--<span class="listLiCon">-->
          <!--衣二三对月卡会员一次性收取人民币300元的押金或冻结相应的花呗额度。会员可于会员期结束后，致电衣二三客服，或在衣二三APP内申请退还押金/解冻花呗额度。申请通过后，押金将在7个工作日内退还至原支付账户或会员在衣二三平台app的资金账号上，花呗额度将在7个工作日内解冻。若按照本协议约定存在尚未解除的异常订单或有待支付项（包括不限于：商品赔款等），衣二三有权按照本协议约定扣除该会员相应的押金或花呗额度，用于抵扣衣二三实际损失，实际退还的押金或解冻的花呗额度为扣除上述赔付项的净额；若会员押金或花呗额度不够抵扣衣二三实际损失的，衣二三保留追偿权利。-->

          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">16.</span>-->
          <!--<span class="listLiCon">-->
          <!--商品衣箱内不同的商品占用衣位数量不同，具体以下单当日该商品的商品页面所标的占用衣位数量信息为准。-->

          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">17.</span>-->
          <!--<span class="listLiCon">-->
          <!--为满足会员对衣二三所提供的服务连续性及自动续费的需求，衣二三提供“连续包月”续费服务，若需开通“连续包月”续费服务，请于支付会员费时选择“连续包月”支付方式。当会员选择开通“连续包月”续费服务时，则视为会员同意授权衣二三和第三方支付渠道包括不限于微信、支付宝（以下简称“会员支付账户”）自动扣除会员服务费。扣费时间为会员有效期结束前2天内。因会员支付账户可扣款金额不足导致的续费失败，衣二三不承担责任。-->

          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">18.</span>-->
          <!--<span class="listLiCon">-->

          <!--会员如需解除“连续包月”续费服务，可在衣二三APP中「我的」-「我的钱包」中进行申请。会员应在其会员期届满前3天申请解除“连续包月”续费服务，会员应把商品衣箱在会员有效期结束后3天内通过衣二三指定的物流合作商寄回，寄回时间以物流合作商显示的揽收时间为准，商品经检验完好一致，未出现本协议第7条的情况，衣二三将解除会员“连续包月”续费服务。若会员未在上述约定时间内寄回商品衣箱，或寄回的商品衣箱出现本协议第7条的情况，则会员需按照本协议第7条承担相应责任。在会员承担相应责任后，衣二三将解除会员“连续包月”续费服务。-->


          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">19.</span>-->
          <!--<span class="listLiCon">-->

          <!--使用过程中，一组收货信息仅对应一个衣二三会员身份，衣二三有权取消同一会员多个重复账号的会员资格。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">20.</span>-->
          <!--<span class="listLiCon">-->

          <!--会员在输入、查看包括但不限于手机号码、身份证等个人保密信息时需妥善保护。-->

          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">21.</span>-->
          <!--<span class="listLiCon">-->
          <!--如有未尽事宜，包括不限于衣二三商品及服务相关情况符合本协议相关约定的，按照本协议相关约定履行。-->
          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">22.</span>-->
          <!--<span class="listLiCon">-->
          <!--本服务条款随公司业务调整而可能被修改，若会员对条款的修改有异议，可随时联系在线客服提出异议，我们将充分考虑会员的宝贵意见；若会员最终不同意条款的修改，则在会员完好归还使用商品后，可协商申请解除本协议。-->

          <!--</span>-->
        <!--</div>-->

        <!--<div class="listLi">-->
          <!--<span class="number">23.</span>-->
          <!--<span class="listLiCon">-->
          <!--以上内容如有疑问，请与衣二三客服联系。-->


          <!--</span>-->
        <!--</div>-->
      <!--</div>-->
    <!--</div>-->

      <div class="leaseAgreement">
        <div class="agreementInfo" v-html="txtFilter(agreementInfo)"></div>
      </div>
    </div>
</template>

<script>
import GoBack from 'base/GoBack';
import { agreement } from 'api/user';
export default {
  data(){
    return {
      agreementInfo:''
    }
  },
  components:{
    GoBack
  },
  methods:{
    txtFilter(text){
      let atxt = text.split('\n')
      this.title =  atxt[0]
      atxt.shift()
      return atxt.join('<br>')
    }
  },
  created(){
    agreement().then((res) =>{
      if(res && res.code == 200){
          this.agreementInfo = res.data.contract
      }
    })
  }
}
</script>

<style lang="less">
  .agreeTitle{
    text-align: center;
  }
  .agreementInfo{
    font-size: 12 * @unit;
    color: #000;
    line-height: 1.5;
  }
  @import "~common/less/variable";
.agreenContent{
  display: flex;
  flex-direction: column;
  height: 100%;
}
.leaseAgreement{
    padding: .533333rem /* 40/75 */;
    background: #fff;
    flex:1;
    overflow-y: auto;
}
.leaseAgreement .LATitle{
  text-indent: 2em;
        font-size: .373333rem /* 28/75 */;
        color: #000;
        line-height: 1.5;
        margin-bottom: .533333rem /* 40/75 */;
        .font-size(12);
    }
.leaseAgreement .LACon{
        font-size: .32rem /* 24/75 */;

    }
.leaseAgreement .LACon .listLi{
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
                -ms-flex: 1;
                    flex: 1;
            text-align: left;
            font-size: .346667rem /* 26/75 */;
            line-height: 1.7;
            letter-spacing: 0.2px;
            text-align: left;
            margin-bottom: .4rem /* 30/75 */;
            color: #333;

            .font-size(12);
        }
.leaseAgreement .LACon .listLi span.number{
                -webkit-box-flex: 1.2;
                    -ms-flex: 1.2;
                        flex: 1.2;
            }
.leaseAgreement .LACon .listLi span.listLiCon{
                -webkit-box-flex: 20;
                    -ms-flex: 20;
                        flex: 20;
            }
.leaseAgreement .LACon .ef{
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
                -ms-flex-pack: center;
                    justify-content: left;
            -webkit-box-align: center;
                -ms-flex-align: center;
                    align-items: center;
            font-size: .346667rem /* 26/75 */;
            line-height: 1.7;
            letter-spacing: 0.2px;
            margin-bottom: .266667rem /* 20/75 */;
            padding-left: .533333rem /* 40/75 */;
            .font-size(11);
            }

</style>
