<template>
    <div class="mallPage">
      <go-back></go-back>
      <div class="wrapper" v-if="mallInfo">
        <div class="user-mall">
          <img :src="mallInfo.data.userinfo.headImg">
          <div class="user-msg">
            <h1>{{mallInfo.data.userinfo.nickname}}</h1>
            <div :class="levelClass(mallInfo.data.userinfo.pointLevel)">
              <i>★</i><span>{{mallInfo.data.userinfo.levelName}}</span><router-link to="/User/userRightsPage"><span class="rights">查看权益</span></router-link>
            </div>
          </div>
          <div class="user-integral">
            <p>可用积分余额</p>
            <router-link tag="div" to="/Buy/purchaseHistoryPage">
              <span>{{mallInfo.data.userinfo.pointAvailable}}</span>
            </router-link>
          </div>
        </div>
        <div class="buy-mall">
          <div class="listview">
            <h1>全部特选权益</h1>
            <ul>
              <li v-for="(item,index) of mallInfo.data.iteminfo" @click="toPointItemPage(item.itemId)">
                <!-- <router-link :to="{path: '/Buy/pointItemPage', query: { id: item.itemId }}"> -->
                  <img :src="item.imgUrl"/>
                  <div class="content">
                    <p class="title">{{item.itemTitle}}</p>
                    <div class="money">
                      <template v-for="(iitem,iindex) of item.buytype">
                        <span v-if="iitem == 1">¥{{ parseFloat(item.moneyPrice/100)}}元 | </span><span v-if="iitem == 2">1权益 | </span><span v-if="iitem == 3">{{ item.price }}积分 | </span>
                      </template>
                    </div>
                    <div class="level-color">
                      <span v-for="type of item.buylevel" :class="levelClass(Number(type))">★</span>
                    </div>
                  </div>
                <!-- </router-link> -->
              </li>
            </ul>
          </div>
        </div>
        <div class="mall-footer">
          <p>{{ mallInfo.data.contract }}</br>积分与活动解释权归衣二三所有</p>
        </div>
      </div>
    </div>
</template>
<script>
import {mapGetters, mapActions} from 'vuex'
import GoBack from 'base/GoBack'

export default {

  components:{
    GoBack
  },
  computed:{
    ...mapGetters(['mallInfo'])
  },
  created(){
    this.$store.dispatch('getMallPage');
  },
  methods:{
    ...mapActions(['getMallPage']),
    levelClass(leveltype){
      if(!leveltype) return;
      switch (leveltype) {
        case 1:
          return 'level_1'
          break;
        case 2:
          return 'level_2'
          break;
        case 3:
          return 'level_3'
          break;
      }
    },
    toPointItemPage(itemId){

      window.location.href=`/yi23/Home/Buy/pointItemPage?id=${itemId}`;

    }
  }


}
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.level();

.mallPage{
  display: flex;
  flex-direction: column;
  height: 100%;
  -webkit-font-smoothing: antialiased;
  font-weight: @font-weight;
  .wrapper{
    flex: 1;
    overflow-y: scroll;
    .user-mall{
      width: 100%;
      height: 100px;
      display: flex;
      box-sizing: border-box;
      padding: 20px 23px;
      background: #fff;
      align-items:center;
      margin-bottom: 10px;
      img{
        display: block;
        width: 50px;
        height: 50px;
        border-radius: 50%;
      }
      .user-msg{
        flex:1;
        padding-left: 10px;
        margin-right: 20px;
        border-right:1px solid #EDEDED;
        .rights{
          color:#d2d2d2;
          margin-left: 3px;
        }
        h1{
          font-size: @font-size-medium-x;
        }
        div{
          font-size: @font-size-small;
          font-weight: @font-weight-m;
          i{
            font-style:normal;
          }
        }
      }
      .user-integral{
        font-size: @font-size-small;
        max-width: 72px;
        p{
          font-size: 10px;
        }
        div{
          text-align: center;
          font-size: 24px;
          color: @color-text;
          // text-overflow: ellipsis;
          // white-space: normal;
          // overflow: hidden;
          span{
            position: relative;
            font-weight: @font-weight-m;
            display: block;
            white-space:;
            &::after{
              content: '';
              display: block;
              width: 10px;
              height: 10px;
              position: absolute;
              right: -12px;
              top: 10px;
              background: url('https://yimg.yi23.net/webimg/20180420/frontpage//integral-mall-jt.png');
              background-size:cover;
            }
          }
        }
      }
    }
    .buy-mall{
      padding-top: 20px;
      background: @color-background;
      .listview{
        .px-top();
        padding: 24px 23px 0 23px;
        & > h1 {
          font-weight: @font-weight-m;
          font-size: @font-size-medium;
        }
        ul {
          li{
              display: flex;
              align-items: center;
              padding: 16px 0;
              color: #111;
              .px-bottom();
              img{
                display: block;
                width: 88px;
                height: 88px;
              }
              .content{
                flex: 1;
                padding-left: 11px;
                .title{
                  .text-overflow(2);
                  font-size: 14px;
                  line-height: 19px;
                }
                .money{
                  line-height: 19px;
                  font-size: @font-size-small;
                  color: @color-text;
                }
                .level-color{
                  font-size: @font-size-small;
                  span{
                    margin-right: 2px;
                  }
                }
              }
          }
          &:last-child{
            a{
              border-bottom: none;
            }
          }
        }
      }
    }
    .mall-footer{
      padding: 20px 0;
      text-align: center;
      font-size: 12px;
      color: #999;
      line-height: 20px;
    }
  }
}
</style>
