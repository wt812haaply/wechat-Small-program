<template>
  <div class="buypage">
    <go-back></go-back>
    <div class="content">

      <template v-if="detailId && detailId > 0 || pdtInfo && pdtInfo.productInUserBox == 1">
        <div class="topMsg">
          <p>{{purchaseNotice}}</p>
        </div>
      </template>

      <template v-else>
        <div class="address" @click="checkAddress">
          <template v-if="addressInfo">
            <div class="innter">
              <div class="item flex">
                <p class="name dark">{{addressInfo.consignee}}</p>
                <p class="phone dark">{{addressInfo.mobile}}</p>
              </div>
              <div class="item">
                <p>{{addressInfo.province}} {{addressInfo.city}} {{addressInfo.country}}</p>
                <p>{{addressInfo.address}}</p>
              </div>
            </div>
            <i class="arrow yi23iconfont icon-right"></i>
          </template>
          <div class="innter" style="text-align:center; border:1px dashed #f0f0f0;" v-else-if="!addressInfo">
            <span class="color_3 font_14" style="line-height:54px; color: #999;">+添加收货地址</span>
          </div>
        </div>
      </template>

      <div class="product" v-if="pdtInfo">
        <div class="pic image-ratio">
          <img :src="pdtInfo.thumbPic" alt="">
        </div>

        <div class="inner">
          <h6 class="">{{pdtInfo.productName}}</h6>
          <p>{{pdtInfo.brandName}}</p>
          <div class="size"><span>{{pdtInfo.size}}</span></div>
        </div>

      </div>

      <div class="product_detail" v-if="pdtInfo">

        <div class="item" v-for="(item, inex) of pdtInfo.newProductDiscount">
          <p>{{item.name}}</p>
          <span class="color_ff5c81 p_right_18">-¥{{parseInt(item.value*100)/100}}</span>
        </div>
        <div class="item" @click="couponsLayerOpen">
          <p>优惠券</p>
          <span class="add gray coupon" v-if="JSON.stringify(couponsActive) == '{}'">没有可用优惠券哦</span>
          <span class="gray" v-if="nocoupons">不使用优惠券</span>
          <template v-if="couponsActive != null && JSON.stringify(couponsActive) != '{}' && !nocoupons">
            <span class="coupon" v-if="couponType(couponsActive.couponType)">-¥{{couponsActive.value}}</span>
            <span class="coupon" v-else>{{couponsActive.value * 10}}折</span>
          </template>
          <i class="yi23iconfont icon-right"></i>
        </div>
        <div class="item">
          <p class="color_3 font_16 weight_500">总价</p>
          <span class="color_3 font_16 weight_500 p_right_18">¥{{total}}</span>
        </div>
      </div>
    </div>
    <div class="button">
      <p @click="goAgree">提交支付表示你已同意<span class="color_ff5c81">《衣二三购买协议》</span></p>
      <div class="paysubmit" @click="goBuy" v-if="clientType == 3 && pdtInfo && (pdtInfo.isCanBuy != 0 || pdtInfo.productInUserBox ==1)">去微信支付</div>
      <div class="paysubmit" @click="goBuy" v-else-if="clientType != 3 && pdtInfo && (pdtInfo.isCanBuy != 0 || pdtInfo.productInUserBox ==1 )">去支付宝支付</div>
      <div class="paysubmit_disabled"  v-else-if="pdtInfo && pdtInfo.isCanBuy == 0 && pdtInfo.productInUserBox !=1">{{ pdtInfo.buyBtnText }}</div>

    </div>

    <pop-up-layer v-if="couponsLayerShow">
      <Coupons
        @btnClick="unUseCoupons"
        @closedPopLayer="couponsLayerClosed"
        :data="couponsList"
      >
        <ul class="coupons-wrapper">
          <li class="coupons-item" v-for="(item, index) of couponsList" @click="choiceCoupon(item)">
            <div class="dec">
              <p>{{item.couponTitle}}</p>
              <span>{{item.startDate | YYYY_MM_DD}}-{{item.expDate | YYYY_MM_DD}}</span>
            </div>

            <div class="money type_a" v-if="couponType(item.couponType)">
              <p><i>¥</i>{{item.value}}</p>
            </div>

            <div class="money type_b" v-else>
              <p>{{item.value * 10}}<i>折</i></p>
            </div>
          </li>
        </ul>
      </Coupons>
    </pop-up-layer>

    <!--地址修改-->
    <yi23Dialog @dialogOk="doDialogOk" @dialogClose="doDialogClose" :open="open" :hasCannel="true" >
      <div slot="header">确定更改收件城市吗？</div>
      <div slot="body">
        订单已选城市与收件城市不符，单品在{{cityName}}可能无货。请返回重新购买
      </div>
      <div slot="btnCannel">取消</div>
    </yi23Dialog>

    <yi23Toast v-model="toastMsg"></yi23Toast>
  </div>
</template>

<script>
  import GoBack from 'base/GoBack';
  import PopUpLayer from 'base/PopUpLayer';
  import Coupons from 'components/Member/_coupons';
  import { toastMixin,couponMixin } from 'common/js/mixin';
  import payClothes from '@/mixins/payClothes';
  import { mapGetters } from 'vuex';
  import { sale } from 'api/buy';
  import region from '@/common/js/region';

  export default {
    mixins: [toastMixin,couponMixin,payClothes],
    data(){
      return {
        pdtInfo:null,
        clientType : this.$clientType,
        detailId:null,
        skuId:null,
        redirect:this.$route.fullPath,
        open:false,
        cityName:'',
        regionObj:'',
        stockLocation:'',
        specifiedStock: null,
        showInfoPid:'',
        purchaseNotice:''

      }
    },
    created(){
      this.initQuery();
      this.initAddress();
      this.initProduct();
    },
    computed:{
      ...mapGetters({
        addressInfo:'addressInfo'
      }),
      total(){

        let salePrice = this.pdtInfo.salePrice;

        if(this.$route.query.fromYshop){
          salePrice = this.pdtInfo.originalPrice;
        }

        let total = 0;

        let couponsActive = this.couponsActive;

        if(this.nocoupons == false &&  couponsActive != null && JSON.stringify(couponsActive) != '{}'){
          if(couponsActive.couponType == 1){
            total = parseInt((salePrice * this.pdtInfo.levelRate) - couponsActive.value);
          }else if(couponsActive.couponType == 2){
            total = parseInt(salePrice * this.pdtInfo.levelRate * couponsActive.value);
          }
        }else{
          total = parseInt(salePrice * this.pdtInfo.levelRate);
        }

        return total >= 0 ? total : 0;

      }
    },
    methods:{

      doDialogClose(){
        this.open=false
      },

      initQuery(){
        this.skuId = this.$route.query.skuId || 0;
        this.detailId = this.$route.query.detailId || 0;
      },
      checkAddress(){
        this.$router.push({
          path:'/User/myAddress',
          query: { redirect: encodeURIComponent(this.$route.fullPath)}
        })
      },
      initAddress(){
        this.$store.dispatch('getAddressInfo')
      },
      initProduct(){

        let _t = this;
        // 初始化商品信息
        let skuId = this.skuId;
        let detailId = this.detailId;
        let reqParam;

        let regionObj = region.getLocalRegion();
        if(detailId){
          //来自衣箱
          reqParam = {
            id:detailId,
            type: 'closet',
            stockLocation: regionObj.regionId
          }
        }else{
          //来自详情页
          reqParam = {
            id:skuId,
            type: 'salePromotion',
            stockLocation:regionObj.regionId
          }
        }

        if(this.$route.query.fromYshop){
          reqParam['buyNewProduct'] = 1
        }

        sale(reqParam).then((res)=>{
          if(res.data.code == 200){
            this.pdtInfo = res.data.data.showInfo;
            this.couponsList = res.data.data.couponInfo;
            this.couponsActive = res.data.data.couponInfo[0] || {};
            this.specifiedStock = res.data.data.specifiedStock || 0;
            this.showInfoPid = res.data.data.showInfo.productId
            this.purchaseNotice = res.data.data.purchaseNotice
          }else{
            _t.$router.back(-1)
          }
        }).catch((res)=>{
          this.setToastMsg(res.data.msg)
        })
      },
      getParams(){
        // 来自混合模式
        let detailId = this.detailId || 0;
        let skuId = this.skuId || 0;
        let saleType = '';
        let payType = this.pdtInfo.payType;
        let couponId = this.couponsActiveId || 0;
        let pdtCoupon = (this.couponsActive && this.couponsActive.value) || 0;
        let pdtValueType = (this.couponsActive && this.couponsActive.couponType) || 0;
        let path = this.$route.query.path ? this.$route.query.path : '';

        const params = {
          detailId,
          skuId,
          saleType,
          payType,
          couponId,
          pdtCoupon,
          pdtValueType,
          path
        }

        if(detailId <= 0){
          params['addrId'] = this.addressInfo.addrId
        }

        //来自于会员电商时候加buyNewProduct
        if(this.$route.query.fromYshop){
          params['buyNewProduct'] = 1
        }

        return params
      },

      goBuy(){
        if(!this.addressInfo){
          this.toastMsg='请填写详细地址';
          return false
        }  else {
          this.isProductInUserBox()
        }
      },
      isProductInUserBox(){
        let specifiedStock = this.specifiedStock;
        //判断是否手中衣箱子 ==1 手中衣箱
        if(this.pdtInfo.productInUserBox !=1 ){
          let regionObj = region.getLocalRegion();
          if(regionObj.regionId!= this.addressInfo.cityRgn){
            this.cityName=this.addressInfo.city;
            this.open=true
            return false
          }
          else if( specifiedStock ==1 ){
            this.submitBuy();
            return
          }
        } else{
          this.submitBuy();
        }
      },

      doDialogOk(){
        region.setLocalRegion({cityName:this.addressInfo.city,regionId:this.addressInfo.cityRgn})
        this.$router.push({
          name: "pdtDetailPage",
          query: { pid: this.showInfoPid }
        });
      },


      // 支付宝、微信支付
      submitBuy(){
        let success = 'ProductPaySuccess';
        let params = this.getParams();
        // let redirect = this.redirect
        this.clothes_creatPayment({params,success});
      },


      goAgree(){
        this.$router.push({
          name:'yishopAgree'
        })
      }
    },
    components:{
      GoBack,
      PopUpLayer,
      Coupons
    }
  }
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import "~common/less/variable";
  @import "~common/less/mixin";

  .buypage{
    font: 12px/18px "Pingfang SC","Heiti SC","DroidSansFallback","微软雅黑","Microsoft JhengHei","WenQuanYi Micro Hei","Helvetica Neue",Verdana,Arial,Helvetica,sans-serif;
    display: flex;
    flex-direction: column;
    height: 100%;
    font-weight: @font-weight;
    .content{
      flex:1;
      overflow-y: auto;
    }
    .address{
      width: 100%;
      box-sizing: border-box;
      padding:.533333rem /* 10/18.75 */;
      display: flex;
      align-items: center;
      .innter{
        flex:1;
        .item.flex{
          display: flex;
          p:nth-child(1){
            flex: 1;
          }
          .phone{
            padding-right:1.493333rem /* 28/18.75 */;
          }
        }
        .item{
          p{
            color: #999;
            &.dark{
              color:#333;
            }
          }
        }
      }
      .arrow{
        display: block;
        color: #ccc;
        font-size: 10px;
      }
    }
    .topMsg{
      padding:  .4rem /* 30/75 */ 2rem /* 37.5/18.75 */;
      background: #000;
      color:#fff;
      font-size: 12px;
    }
    .product{
      display: flex;
      align-items:center;
      justify-content: center;
      margin-top: .8rem /* 15/18.75 */;
      background: #fafafa;
      padding: .533333rem /* 10/18.75 */ 2rem /* 37.5/18.75 */;
      .pic{
        width: 4.266667rem /* 80/18.75 */;
        font-size: 0;
        img{
          width: 100%;
          height: 100%;
        }
      }
      .inner{
        flex:1;
        padding-left: .96rem /* 18/18.75 */;
        h6{
          color: #333;
          margin-bottom: 1.066667rem /* 20/18.75 */;
        }
        p{
          color:#999;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
        }
        .size{
          color: #333;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
        }
      }
    }
    .product_detail{
      display: flex;
      flex-direction:column;
      align-items: center;
      .item{
        width: 80%;
        line-height: 2.133333rem /* 40/18.75 */;
        height: 2.133333rem /* 40/18.75 */;
        color: #999;
        display: flex;
        padding:10px 0;
        border-bottom: 1px solid #eee;
        &:last-child{
          border:none;
        }
        p{
          flex:1;
        }
        i{
          font-size: 10px;
          margin-left: 5px;
          color: #ccc;
        }
      }
    }
    .button{
      width: 100%;
      text-align: center;
      box-sizing: border-box;
      padding: 10px;
      border-top:1px solid #eee;
      p{
        font-size: .533333rem /* 10/18.75 */;
        color: #666;
        margin-bottom: 10px;
      }
      .paysubmit,.paysubmit_disabled{
        width: 100%;
        background: #FF544b;
        margin: 0 auto;
        color: #fff;
        height: 40px;
        line-height: 40px;
      }
      .paysubmit_disabled{
        background: #ccc;
      }
    }
  }
  .color_ff5c81{
    color:#FF544b;
  }
  .color_3{
    color:#333;
  }
  .font_16{
    font-size: 16px /* 16/18.75 */;
  }
  .p_right_18{
    padding-right: 18px /* 18/18.75 */;
  }
  .weight_500{
    font-weight: 500;
  }
  .couponsShow();
</style>
