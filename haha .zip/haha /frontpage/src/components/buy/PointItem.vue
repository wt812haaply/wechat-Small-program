<template>
  <div class="pointitem">
      <go-back></go-back>
      <div class="wrapper" v-if="pointData">
        <div class="banner image-normal">
          <img :src="pointData.iteminfo.bigImgUrl">
        </div>
        <div class="ticket">
          <div class="ticket-header">
            <div class="title">{{pointData.iteminfo.itemTitle}}</div>
            <p>等级要求: <i v-for="item of pointData.buylevel" :class="[`level_${item}`]">★</i></p>
            <scroll-x
              :sliderItemWidth= "122"
              :listMarginSpace= "{left:10}"
              :beforeSpace = "13"
              :afterSpace = "23"
              :probeType = "probeType"
              :data = "pointData"
              >
              <div class="slideritem"
                v-for="(item, index) of pointData.buytype"
                @click.stop="sliderItemClick(item,index)"
                :class="{active:(index == sliderIndex), 'slider-item': true}"
              >
              <template v-if="item == 1">
                <h6>使用现金购买</h6>
                <p>{{pointData.iteminfo.moneyPrice/100}}元</p>
              </template>
              <template v-if="item == 2">
                <h6>使用权益兑换</h6>
                <p>1权益</p>
              </template>
              <template v-if="item == 3">
                <h6>使用积分兑换</h6>
                <p>{{pointData.iteminfo.price}}积分</p>
              </template>
              </div>
            </scroll-x>
          </div>
          <div class="html-ticket-desc  ticket-desc" v-html="pointData.iteminfo.itemDesc"></div>
        </div>
      </div>
      <div class="pay-group" v-if="pointData">
        <div class="pay-title">
          共支付：
        </div>
        <div class="pay-all-number">
          <template v-if="sliderBuyType == 1">
            <i class="money-type">¥</i>{{pointData.iteminfo.moneyPrice/100}}<i>元</i>
          </template>
          <template v-if="sliderBuyType == 2">
            1<i>权益</i>
          </template>
          <template v-if="sliderBuyType == 3">
            {{pointData.iteminfo.price}}<i>积分</i>
          </template>
        </div>
        <div class="pay-button">
          <div class="button" @click="pay">
            立即支付
          </div>
        </div>
      </div>
      <div class="orderBox" ref="orderBox"></div>
  </div>
</template>

<script>
import GoBack from 'base/GoBack';
import ScrollX from 'base/ScrollX';
import {getPointItemPage,subOrder} from 'api/buy';
import {ERR_OK,BUY_TYPE_I,BUY_TYPE_II,BUY_TYPE_III,PAY_WAY_WX,PAY_WAY_ALI,PAY_WAY_JF,PAY_WAY_QY} from 'api/const';

export default {
  data(){
    return{
      sliderIndex: 0,
      sliderBuyType: null,
      pointData: null,
      payAction: false,
      payWay: 0
    }
  },
  created(){
    this.probeType = 3;
    this._getPointItem();
  },
  methods:{
    sliderItemClick(item,index){
      this.sliderBuyType = item;
      this.sliderIndex = index;
      // console.log(this.sliderBuyType);
      // console.log(this.sliderIndex);
    },
    initSliderIndexChoise(item){
      this.sliderItemClick(item,0);
    },
    pay(){
      this.setPayWay()
      this._subOrder()
    },
    setPayWay(){
      let _payWay = this.getClientPayWay();
      let buyTypePayWay = this.getBuyTypePayWay();
      if(buyTypePayWay != 0) _payWay = buyTypePayWay;
      this.payWay = _payWay;
    },
    getBuyTypePayWay(){
      let buyType = this.sliderBuyType;
      const buyTypeMap = {
        '1': 0,
        '2': PAY_WAY_QY,
        '3': PAY_WAY_JF
      }
      return buyTypeMap[buyType];
    },
    getClientPayWay(){
      let clientType = this.$clientType
      const clientMap = {
        '3': PAY_WAY_WX,
        '4': PAY_WAY_ALI
      }
      if(clientMap[clientType]){
        return clientMap[clientType]
      }
      return clientMap[4]
    },
    _getPointItem(){
      let id = this.$route.query.id;
      getPointItemPage(id).then((res)=>{
        if(res.code == ERR_OK){
          this.pointData = res.data;
          let item = this.pointData.buytype[0];
          this.initSliderIndexChoise(item);
        }
      })
    },
    _subOrder(){
      let itemId = this.$route.query.id;
      let payType = 7;
      let payWay = this.payWay;
      let callBackUrl = '/yi23/Home/Buy/paySuccess?is_success=';
      subOrder({itemId,payType,payWay,callBackUrl}).then((res)=>{
        let code = res.code;
        if( code == ERR_OK){
          this.createPayForm(this.payWay,res.data)
        }else if(code == 110){
          this.$router.push({ name: 'BuyPaySuccess', query: { is_success: 'T' }})
        }else{
          this.$router.push({ name: 'BuyPaySuccess', query: { is_success: 'F' }})
        }
      });
    },
    wxCallPay(params, callBackUrl) {
      WeixinJSBridge.invoke(
        'getBrandWCPayRequest', {
          "appId": params.appId,
          "nonceStr": params.nonceStr,
          "package": params.package,
          "paySign": params.paySign,
          "signType": params.signType,
          "timeStamp": params.timeStamp.toString()
        },
        function(res) {
          console.log('微信回调:' + res.err_msg);
          if (res.err_msg == "get_brand_wcpay_request:ok") {
            window.location.href = callBackUrl + '?is_success=T';
          } else {
            window.location.href = callBackUrl + '?is_success=F';
          }
        }
      )
      if (typeof WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
          document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      } else {
        onBridgeReady();
      }
    },
    createPayForm(payWay,data){
      let formStr;

      if(payWay == PAY_WAY_ALI){
        formStr = data.resHtml;

        const div = document.createElement('div');
        div.innerHTML = formStr;
        document.body.appendChild(div);

        setTimeout(()=>{
          if(payWay == PAY_WAY_ALI){
            document.forms.alipaysubmit.submit();
          }
        },20)

      }

      if(payWay == PAY_WAY_WX){

        let contents = data.payContents;
        this.wxCallPay(contents,'/yi23/Home/Buy/paySuccess')
      }

    }
  },
  components:{
    GoBack,
    ScrollX
  }
}
</script>

<style lang="css">
  .html-ticket-desc i{
    font-style: normal;
  }
  .html-ticket-desc p{
    color: #666;
    line-height: 20px;
  }
  .html-ticket-desc h3{
    font-size: 14px;
  }
</style>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.level();

.pointitem{
  display: flex;
  flex-direction: column;
  -webkit-font-smoothing: antialiased;
  height: 100%;
  font-weight: @font-weight;
  background: @color-background;
  .wrapper{
    flex: 1;
    overflow-y: auto;
    .banner{
      position: relative;
      width: 100%;
      height: 0;
      padding-bottom: 6.4rem /* 120/18.75 */;
      img{
        display: block;
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
      }
    }
    .ticket{
      .title{
        font-size: @font-size-large;
        line-height: 25px;
        font-weight: @font-weight-l;
        padding: 0 23px;
      }
      .ticket-header{
        padding-top: 10px;
        padding-bottom: 20px;
        border-bottom: 10px #FAFAFA solid;
        & > p{
          padding: 12px 23px;
          font-size: @font-size-small;
          i{
            padding-left: 1px;
          }
        }
      }
      .ticket-desc{
        padding: 10px 23px;
        font-size: 12px;
        p{
          line-height: 20px;
          color: #666;
        }
      }
    }
  }
  .pay-group{
    height: 52px;
    display: flex;
    font-size: 16px;
    box-shadow: 0px -2px 5px rgba(0,0,0,.05);
    display: flex;
    align-items: center;
    .pay-title{
      font-size: 16px;
      padding-left: 10px;
      color:#999;
    }
    .pay-all-number{
      flex:1;
      text-align: right;
      color:@color-text;
      font-size: 20px;
      padding-right: 10px;
      i:not(.money-type){
        font-style: normal;
        font-size: 10px;
        font-weight: 500;
      }
      .money-type{
        font-style: normal;
        font-size: 20px;
        font-weight: 550;
      }
    }
    .pay-button{
      width: 134px;
      height: 52px;
      line-height: 52px;
      .button{
        text-align: center;
        background: @color-text;
        font-size: @font-size-medium;
        color:#fff;
        font-weight: 500;
        box-shadow: 0px -2px 5px rgba(0, 0, 0, 0.04);
      }
    }
  }
  .slideritem{
      display: block;
      padding: 24px 0 0 15px;
      width: 122px;
      height: 72px;
      text-align: left;
      font-size: 12px;
      color: rgba(0,0,0,.3);
      border: 1px rgba(0,0,0,.1) solid;
      &.active{
        color: @color-text;
        border-color: @color-text;
      }
  }
}

</style>
