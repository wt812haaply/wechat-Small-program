<template>
    <div class="intergral">
      <go-back></go-back>
      <div class="wrapper" v-if="priceData">
        <div class="intergral-title">
          <p>可用积分余额</p>
          <h2>{{priceData.pointa}}<i>分</i></h2>
        </div>
        <div class="intergral-content">
          <h1>积分变动记录</h1>
          <div class="listview">
            <ul>
              <li v-for="item of priceData.pointl">
                <div class="content">
                  <h2>{{item.itemName}}</h2>
                  <span>{{item.showTime}}</span>
                </div>
                <span
                  class="points"
                  :class="{'add': item.pointType == 0,'remove': item.pointType == 1}">{{item.point}}<i>积分</i></span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
import GoBack from 'base/GoBack';
import { getPurchaseHistoryPage } from 'api/user';
import { ERR_OK } from 'api/const';

export default {
  data(){
    return{
      priceData: null
    }
  },
  created(){
    this._getPriceHistory();
  },
  methods:{
    _getPriceHistory(){
      getPurchaseHistoryPage().then((res)=>{
        if(res.code == ERR_OK){
          this.priceData = res.data;
        }
      });
    }
  },
  components:{
    GoBack
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import "~common/less/variable";
@import "~common/less/mixin";

.intergral{
  display: flex;
  flex-direction: column;
  -webkit-font-smoothing: antialiased;
  height: 100%;
  font-weight: @font-weight;
  .an-slider(10%);
  .wrapper{
    flex: 1;
    overflow-y: auto;
    .intergral-title{
      background: @color-background;
      padding: 23px 0 24px 0;
      text-align: center;
      color: @color-text;
      p{
        font-size: @font-size-small;
      }
      h2{
        font-size: 38px;
        font-weight: 500;
        line-height: 1.1;
        i{
          font-size: @font-size-small;
          font-style: normal;
        }
      }
    }
    .intergral-content{
      padding: 0 23px;
      background: @color-background;
      margin-top: 10px;
      h1{
        padding: 15px 0;
        font-weight: @font-weight-m;
        font-size: @font-size-medium;
      }
      .listview{
        li{
          display: flex;
          align-items: center;
          padding: 18px 0;
          .px-bottom();
          &:last-child{
            border-bottom: none;
          }
          .content{
            flex: 1;
            padding-right: 10px;
            h2{
              font-size: @font-size-medium;
              color:#666;
              font-weight: @font-weight-m;
            }
            span{
              font-size: @font-size-small;
              color:rgba(0,0,0,.3);
            }
          }
          .points{
            color: @color-text;
            font-size: @font-size-medium;
            position: relative;
            &.add:after{
              content: '+';
              position: absolute;
              left: -10px;
              top: -4px;
              font-size: 16px;
            }
            &.remove:after{
              content: '—';
              position: absolute;
              left: -12px;
              top: 0px;
              font-size: 12px;
            }
            i{
              font-style: normal;
              margin-left: 2px;
            }
          }
        }
      }
    }

  }
}

</style>
