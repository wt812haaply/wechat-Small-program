<template>
  <div class="flex postingpart--box">
    <div class="flex-item" v-for="(value,i) in item.itemList" :key="i">
      <a class="SA_A SA_POSTINH_COLUMN_TEM postingIMG image-ratio" @click="doJump(value.linkUrl)" :style="{'padding-bottom':pd(value)}">
        <img :src="value.imgUrl" alt="">
      </a>
    </div>
  </div>

</template>

<script>
    import { postingMd } from './methods'
    export default {
        name: "column-tem",
        mixins:[postingMd],
        props:['item']
    }
</script>
