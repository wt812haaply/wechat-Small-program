<template>
  <div class="postingCoupon">
    <div class="PartOne">
      <div class="PartOneIMG image-ratio" :style="pd(item)" v-if="item.bgImg">
        <img :src="item.bgImg" alt="">
      </div>
      <div class="PartOneCon">
        <input type="" :placeholder="item.placeholder" v-model="mobile" :style="{'border':item.inputBorder+ ' solid','color':item.inputColor,'border-color':item.inputBorderColor,'background':item.inputBgColor}" name="" class="tel font-fm font-r couponInput">
        <a class="SA_A SA_POSTINH_INPUT btn btn-defult btn-black font-fm font-m getCouponByTel" :class="'phone_btn_'+cIndex"  :style="{'color':item.btnColor,'background':item.btnBgColor}" @click="getCoupon(item)">{{item.btnText}}</a>
      </div>
    </div>
  </div>

</template>

<script>
  import { postingMd } from './methods'
  import postingPart from 'api/postingPart'
    export default {
      name: "coupon-by-input",
      mixins:[postingMd],
      props:['item','cIndex'],
      data(){
       return{
         mobile:'',
         txt:['数据错误请稍后重试','你的新人专享优惠已经发放到账户','你已领取过新人优惠，快去使用吧','您已享受过新人优惠']
       }
      },
      methods:{
        getCoupon(info){
          if(this.mobile){
            let options=this.$parent.options;
            let params={ mobile:this.mobile,source:options.source||''};
            postingPart.loginSource(params).then((res)=>{
                if(res.statusCode && +res.statusCode!==200){
                  this.$parent.msg=res.message
                  return false
                }
                if(res.data.code && +res.data.code===200){
                  /*userStatus:
                   0:未付费
                   1:有效期
                   2:已过期*/
                  let is_new = res.data.data.is_new,
                      userStatus = res.data.data.userStatus,
                      number = 0;
                  if(+is_new === 1){
                    number = 1;
                  }else if(+is_new === 0 && +userStatus === 0){
                    number = 2;
                  }else if(+userStatus === 1 || +userStatus === 2){
                    number = 3;
                  }
                  this.$parent.msg=this.txt[number];
                }else{
                  this.$parent.msg=res.data.msg;
                }
            })
          }else{
            this.$parent.msg='手机号不能为空'
          }
        }
      }
    }
</script>

<style scoped>

</style>
