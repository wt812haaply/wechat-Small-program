<template>
  <div class="postingCoupon">
    <div class="PartOne">
      <div class="PartOneIMG image-ratio" :style="pd(item)" v-if="item.bgImg">
        <img :src="item.bgImg" alt="">
      </div>
      <div class="PartOneCon">
        <input type="" :placeholder="item.placeholder" v-model="mobile" :style="{'border':item.inputBorder+ ' solid','color':item.inputColor,'border-color':item.inputBorderColor,'background':item.inputBgColor}" name="" class="tel font-fm font-r couponInput">
        <a class="SA_A SA_POSTINH_INPUT btn btn-defult btn-black font-fm font-m getCouponByTel" :class="'phone_btn_'+cIndex"  :style="{'color':item.btnColor,'background':item.btnBgColor}" @click="getCoupon(item)">{{item.btnText}}</a>
      </div>
    </div>
  </div>

</template>

<script>
  import { postingMd } from './methods'
  import postingPart from 'api/postingPart'
    export default {
      name: "coupon-by-input",
      mixins:[postingMd],
      props:['item','cIndex'],
      data(){
       return{
         mobile:'',
       }
      },
      methods:{
        getCoupon(info){
          if(this.mobile){
//            try{
//              // adhocLpo.track('click_get_cell_coupon')
//              adhoc('track', 'Coupon_btn_Tel', 1)
//            }catch (e){
//              console.log(e)
//            }
            let options=this.$parent.options;
            let params={ eventId:info.eventId, mobile:this.mobile,referId:options.referId,source:options.source};
            postingPart.getPhoneForFree(params).then((res)=>{
              if(info.successInfo && info.successInfo.successImgUrl){
                if(res.data.code==200){
                  this.$parent.successInfo=info.successInfo
                  this.$parent.showImgDialog=true;
                }else{
                  this.$parent.msg=res.data.msg
                }

              }else{
                this.$parent.msg=res.data.msg
              }
            })
          }else{
            this.$parent.msg='手机号不能为空'
          }
        }
      }
    }
</script>

<style scoped>

</style>
