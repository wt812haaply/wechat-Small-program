<template>
<div v-if="pageData" class="postingContent">
  <div :style="{'padding-bottom':info.top+'%'}"></div>
  <component :is="compoentAction(item.partType)"  :item="item" v-for="(item,index) in pageData.postingParts" :key="index" :cIndex="index">
  </component>
  <div :style="{'padding-bottom':info.bottom+'%'}"></div>
<yi23-toast v-model="msg"></yi23-toast>
  <yi23-alert-img v-model="showImgDialog">
    <a class="SA_A SA_POSTINH_SUCCESS_IMG" @click="goSuccess(successInfo.successImgJump)" v-if="successInfo">
      <img :src="successInfo.successImgUrl">
    </a>
  </yi23-alert-img>
</div>
</template>

<script>
  import topFix from './topFix'
  import columnTem from './columnTem'
  import couponByInput from './couponByInput'
  import couponByBtn from './couponByBtnGetMember'
  import textTem from './textTem'
  import bannerTem from './bannerTem'
  import productListTem from './productListTem'
  import bottomFix from './bottomFix'
  import postingPart from 'api/postingPart'
  import { mapGetters } from 'vuex'
  import  shareMixin  from '@/mixins/share'
  import {
    setTitle
  } from 'common/js/utils'
    export default {
        name: "posting-part",
        mixins:[shareMixin],
        data () {
          return {
            info:{top:0,bottom:0},
            options:null,
            successInfo:null,
            posting:null,
            showImgDialog:false,
            msg:'',
            data:{"postingParts":[
              {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180921_185110-1537527070872-1.jpg","linkUrl":"","partHeight":600,"partWidth":750,"sort":1,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
              {"postingId":0,"partType":9,"imgUrl":"https://yimg.yi23.net/posting/1776-20181009_161842-1539073122850-1.jpg","linkUrl":"","partHeight":382,"partWidth":750,"sort":2,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":{"successImgUrl":null,"successImgJump":null,"feedbackType":2,"partWidth":0,"partHeight":0},"bgImg":"https://yimg.yi23.net/posting/1776-20181009_161842-1539073122850-1.jpg"},
              {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144559-1537425959899-1.jpg","linkUrl":"","partHeight":502,"partWidth":750,"sort":4,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
              {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144616-1537425976071-1.jpg","linkUrl":"","partHeight":718,"partWidth":750,"sort":5,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
              {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144634-1537425994720-1.jpg","linkUrl":"","partHeight":920,"partWidth":750,"sort":6,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
              {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144642-1537426002757-1.jpg","linkUrl":"","partHeight":948,"partWidth":750,"sort":7,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null}
              ],"url":"","postingType":0},
            pageData:{"postingId":0,"titleZh":"关注公众号领积分","titleEn":"10 POINTS","shareDescription":"包月租衣，往返包邮，免费清洗","sharePageUrl":"https://www.95vintage.com/yi23/Home/Index/postingPartGetMember","shareImgUrl":"https://yimg.yi23.net/posting/1776-20181009_162322-1539073402626-1.jpg","shareTitle":"关注衣二三，领取会员积分","shareType":0,
              "postingParts":[
                {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180921_185110-1537527070872-1.jpg","linkUrl":"","partHeight":600,"partWidth":750,"sort":1,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
                {"postingId":0,"partType":9,"imgUrl":"https://yimg.yi23.net/posting/1776-20180921_185209-1537527129913-1.jpg","linkUrl":"https://api.95vintage.com/gw/coupon/promotionCouponSet","partHeight":382,"partWidth":750,"sort":2,"products":[],"text":"","partParam":{"eventId":"67"},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":67,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,
                  "successInfo": {"successImgUrl":null,"successImgJump":null,"feedbackType":2,"partWidth":0,"partHeight":0},
                  "bgImg":"https://yimg.yi23.net/posting/1776-20180921_185209-1537527129913-1.jpg"},
                {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144559-1537425959899-1.jpg","linkUrl":"","partHeight":502,"partWidth":750,"sort":3,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
                {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144616-1537425976071-1.jpg","linkUrl":"","partHeight":718,"partWidth":750,"sort":4,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
                {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144634-1537425994720-1.jpg","linkUrl":"","partHeight":920,"partWidth":750,"sort":5,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null},
                {"postingId":0,"partType":0,"imgUrl":"https://yimg.yi23.net/posting/1776-20180920_144642-1537426002757-1.jpg","linkUrl":"","partHeight":948,"partWidth":750,"sort":6,"products":[],"text":"","partParam":{},"shareInfo":null,"postingText":null,"postingTextList":null,"itemList":[],"eventId":0,"placeholder":null,"placeholderColor":null,"inputColor":null,"inputBgColor":null,"inputBorderColor":null,"inputBorder":null,"btnBgColor":null,"btnText":null,"btnColor":null,"popupImgUrl":null,"popupLinkUrl":null,"popupPartWidth":0,"popupPartHeight":0,"successInfo":null,"bgImg":null}],
              "url":"","postingType":0}
          }
        },
      computed: {
        ...mapGetters({
          authorization: 'authorization'
        })
      },
        created() {
          this.options = this.$route.query;
          let _t=this;

          postingPart.postingExtend({id: 8301}).then((res) => {
            if (res.data.code == 200) {
              let params = {
                title: res.data.data.shareTitle,
                url: window.location.href,
                shareType: res.data.data.postingType,
                message: res.data.data.shareDescription,
                image: res.data.data.shareImgUrl,
                thumb_pic:res.data.data.shareImgUrl
              }
              setTitle(res.data.data.titleZh?res.data.data.titleZh:res.data.data.titleEn)
              this.setShareMessage(params);
              res.data.data.postingParts.map(function (el) {
                  if(el.partType==6){
                    el.itemList.forEach((t,v)=>{
                      _t.info.top += t.partHeight/t.partWidth*100;
                    });
                  }else if(el.partType==10){
                    el.itemList.forEach((t,v)=>{
                      _t.info.bottom += t.partHeight/t.partWidth*100;
                    });
                  }
              })
              this.pageData = res.data.data
            } else {

               let params = {
                  title: this.pageData.shareTitle,
                  url: this.pageData.sharePageUrl?this.pageData.sharePageUrl:window.location.href,
                  shareType: this.pageData.postingType,
                  message: this.pageData.shareDescription,
                  image: this.pageData.shareImgUrl,
                  thumb_pic:this.pageData.shareImgUrl
                }
                setTitle(this.pageData.titleZh?this.pageData.titleZh:this.pageData.titleEn)
                this.setShareMessage(params);
                this.pageData.postingParts.map(function (el) {
                  if(el.partType==6){
                    el.itemList.forEach((t,v)=>{
                      _t.info.top += t.partHeight/t.partWidth*100;
                    });
                  }else if(el.partType==10){
                    el.itemList.forEach((t,v)=>{
                      _t.info.bottom += t.partHeight/t.partWidth*100;
                    });
                  }
                })
                this.posting = this.pageData
            }
          })
        },
        methods:{
          goSuccess:function (url) {
            window.location.href=url;
          },
          compoentAction(id) {
            let temKeyData={
              "6":{templateName: 'topFix'}, //吸顶
              "7":{templateName: 'columnTem'}, //分栏组件
              "8":{templateName: 'couponByInput'}, //input输入框 领券
              "9":{templateName: 'couponByBtn'}, //btn 按钮直接领券
              "5":{templateName: 'textTem'}, //纯文本组件
              "0":{templateName: 'bannerTem'}, //单图
              "1":{templateName: 'productListTem'}, //商品pid
              "10":{templateName: 'bottomFix'} //吸低
            };
            return temKeyData[id].templateName
          },
        },
        components:{
          topFix,
          columnTem,
          couponByInput,
          couponByBtn,
          textTem,
          bannerTem,
          productListTem,
          bottomFix,
        }
    }
</script>

<style  lang="less">
  @import "~common/less/variable";
  .none {
    display: none;
  }
  .SA_A{
     display: block;
  }
  .postingContent{
    img {
      width: 100%;
      display: block;
      margin: 0;
      padding: 0;
      border: 0;
    }
    input{
      -webkit-appearance: none;
    }
  }
  .postingIMG {
    width: 100%;
    height: 0;
    position: relative;
    overflow: hidden;
    vertical-align: top;
  }
  .postingIMG image {
    width: 100%;
    position: absolute;
  }

  ::-webkit-input-placeholder {
    color: #ccc;
  }
  ::-moz-placeholder {
    color: #ccc;
  }
  :-ms-input-placeholder {
    color: #ccc;
  }
  /* text 文字排版 */
  .postingText {
    padding: 0.533333rem 1.226667rem;
    background: #fff;
  }
  .postingTextTitle {
    display: table;
    white-space: nowrap;
    margin-bottom: 0.533333rem;
    width: 100%;
  }
  .postingTextTitle:before, .postingTextTitle:after {
    border-top: 1px solid #eee;
    content: '';
    display: table-cell;
    position: relative;
    top: 0.64rem;
    width: 45%;
  }
  .postingTextTitle:before {
    right: 1.5%;
  }
  .postingTextTitle:after {
    left: 1.5%;
  }
  .postingText p {
    line-height: 1.173333rem;
    font-size: 0.746667rem;
    letter-spacing: .3px;
    text-align: left;
    color: #000;
    margin-bottom: 0.853333rem;
    font-family: PingFangSC;
    font-weight: 300;
    word-wrap: break-word;
  }
  .postingText p:last-of-type {
    margin-bottom: 0px;
  }
  /* 领取优惠券 */
  .postingCoupon {
    /* 01 */
    /* 01 End */
  }
  .postingCoupon .PartOne {
    position: relative;
    top: 0;
    right: 0;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    min-height: 5.866666666666666rem;
    /*0503*/
    .padding(10,0,10,0);
  }
  .postingCoupon .PartOne .PartOneIMG {
    width: 100%;
    height: 0;
    position: relative;
    overflow-y: hidden;
    background: #fff;
    padding-bottom: 28.2626%;
  }
  .postingCoupon .PartOne .PartOneIMG img {
    width: 100%;
    position: absolute;
    display: block;
  }
  .postingCoupon .PartOne .PartOneCon {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    /*width: 80%;*/
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    /*z-index: 1;*/
    /*0503*/
    .width(303);
  }
  .postingCoupon .PartOne .PartOneCon input.tel {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    /*height: 2.346667rem;*/
    font-size: 0.746667rem;
    /*border: 0.106667rem #000 solid;*/
    /*margin-bottom: 0.533333rem;*/
    text-align: center;
    /*background: #fff;*/

    /*0503*/
    .height(48);
    border:1px #ccc solid;
    .margin(0,0,14,0);
    background: #f4f4f4;
    border-radius: 2px;
  }
  .postingCoupon .PartOne .PartOneCon .btn {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    text-align: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    height: 2.56rem;
    line-height: 2.56rem;
    font-size: 0.746667rem;
    width: 100%;
    /*0504*/
    border-radius: 2px;
  }
  /* 9 */
  .PFTop {
    position: fixed;
    top: 0px;
    left: 0px;
    z-index: 9;
    width: 100%;
    display: block;
  }
  .PFTopCon1, .PFTopCon2 {
    position: relative;
    top: 0;
    left: 0;
    width: 100%;
    background: #fff;
    z-index: 1;
    line-height: 1;
  }
  .PFTopCon1 {
    height: auto;
  }
  .PFTopCon2 {
    height: auto;
  }
  .PFBottom {
    position: fixed;
    bottom: 0px;
    left: 0px;
    z-index: 9;
    width: 100%;
    display: block;
  }

  .PFBottomCon1, .PFBottomCon2 {
    position: relative;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #fff;
    z-index: 1;
    line-height: 1;
  }
  .PFBottomCon1 {
    height: auto;
  }
  .PFBottomCon2 {
    height: auto;
  }
  /* 分栏 */
  .flex-item {
    /* background: red; */
  }
  /* pid */
  .postingProList {
    background: #fff;
    display: block;
    padding: 0 1.5%;
  }
  .postingProList ul {
    padding-top: 0.533333rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
  }
  .postingProList ul li {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    width: 48.5%;
    height: auto;
    margin-bottom: 1.6rem;
  }
  .postingProList ul li .PopHOT {
    position: relative;
    float: left;
    height: 0px;
    top: 0.426667rem;
    left: 0px;
    width: 2.88rem;
    z-index: 1;
  }
  .postingProList ul li .ListIMG {
    width: 100%;
    position: relative;
    height: 0;
    display: block;
    padding-bottom: 124.0333%;
    margin-bottom: 0.533333rem;
  }
  .postingProList ul li .ListIMG img {
    width: 100%;
    position: absolute;
  }
  .postingProList ul li .sx {
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    padding-left: 0.533333rem;
    font-size: 0.746667rem;
    width: 100%;
    color: #333;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    /*2行*/
    overflow: hidden;
    word-wrap: break-word;
  }
  .postingProList ul li .LiSize {
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    padding-left: 0.64rem;
    line-height: 1.2;
  }
  .postingProList ul li .LiSize span {
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    color: #ccc;
    margin-right: 0.266667rem;
    font-size: 0.746667rem;
    width: auto;
  }
  .jijiangfanjia {
    position: absolute;
    margin: 0px;
    top: 50%;
    width: 4.586667rem;
    height: 1.28rem;
    line-height: 1.28rem;
    text-align: center;
    background: #333;
    font-size: 0.533333rem;
    color: #fff;
    left: 50%;
    display: block;
    z-index: 2;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }
  .TagBg {
    position: absolute;
    margin: 0px;
    top: 50%;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.3);
    left: 50%;
    display: block;
    z-index: 1;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }


  /* Iphone X */
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .PFBottom{
      .bottom(34);
    }
    .postingContent{
      padding-bottom:34px;
    }
  }

</style>
