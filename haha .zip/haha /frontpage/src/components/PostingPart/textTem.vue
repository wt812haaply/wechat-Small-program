<template>
  <div class="postingText">

    <p v-for="(value,i) in item" v-if="value">{{value}}</p>

  </div>

</template>

<script>
    export default {
        name: "text-tem",
      props:['item']
    }
</script>

<style scoped>

</style>
