<template>
  <div class="postingProList">
    <ul>
      <li
        v-for="(value,i) in item.products"
        :class="{'yiList':value.productCategory == 2}"
      >
        <div class="PopHOT">
        </div>
        <a
          class="SA_A SA_POSTINH_PRODUCT_LIST_TEM ListIMG image-ratio"
          @click="jumpTo(value.productLink,value.productCategory,value.productId)"
        >
          <img
            v-lazy="value.productThumbnailUrl"
            alt=""
          >
        </a>
        <div class="sx font-roboto-l">
          <p class="sx-brand hide">{{value.brandName}}</p>
          <p
            class="sx-price font-roboto-r"
            v-if="value.productCategory == 2"
          ><span class="font-roboto-l">￥{{value.marketPrice}}</span> ￥{{value.originalPrice}}</p>
        </div>
        <div class="sxtxt hide">{{value.productName}}</div>
      </li>
    </ul>
  </div>

</template>

<script>
import { postingMd } from './methods';
export default {
  name: 'product-list-tem',
  mixins: [postingMd],
  props: ['item'],
  methods: {
    jumpTo(url, type, productId) {
      if (url) {
        if (type && type == 1) {
          let queryObj = this.replaceUrl(url);
          let obj = {};
          obj.productId = productId;
          obj.jumpNativeType = 24;
          let jumpUrl =
            '/yi23/Home/Gown/gownDetailPage' +
            this.urlEncode(Object.assign(obj, queryObj));
          window.location.href = jumpUrl;
        } else {
          let reUrl = /^((ht|f)tp?):\/\//;
          if (reUrl.test(url) && this.testOrFormal(url)) {
            url = url.replace('http', 'https');
          }
          window.location.href = url;
        }
      } else {
        return false;
      }
    },
    replaceUrl(url) {
      var queryObj = {};
      var reg = /[?&]([^=&#]+)=([^&#]*)/g;
      var querys = url.match(reg);
      if (querys) {
        for (var i in querys) {
          var query = querys[i].split('=');
          var key = query[0].substr(1),
            value = query[1];
          if (key != 'productId' && key != 'pid' && key != 'jumpNativeType') {
            queryObj[key]
              ? (queryObj[key] = [].concat(queryObj[key], value))
              : (queryObj[key] = value);
          }
        }
      }
      return queryObj;
    },
    urlEncode(obj) {
      var qstring = '?';
      for (var k in obj) {
        qstring += k + '=' + obj[k] + '&';
      }
      return qstring.substring(0,qstring.length-1);
    },
    testOrFormal(url){
      let type = ~url.indexOf('www.95vintage.com')?1:0
      return type
    }
  }
};
</script>

<style lang="less" scoped>
.postingProList ul li .sx {
  padding-left: 0;
  font-size: 12 * @unit;
}
.sxtxt {
  padding-left: 0;
  font-size: 12 * @unit;
  font-weight: 500;
  line-height: 1.33;
  color: #333333;
  margin-top: 8 * @unit;
}
.yiList {
  .sx {
    display: flex;
    justify-content: space-between;

    p {
      width: 50%;
      flex-wrap: wrap;
      font-size: 12 * @unit;

      span {
        font-weight: 300;
        font-style: normal;
        font-stretch: condensed;
        letter-spacing: normal;
        text-align: right;
        color: #afafaf;
        margin-right: 4 * @unit;
        text-decoration: line-through;
      }
    }
    .sx-price {
      text-align: right;
      color: #ff544b;
      width: 53%;
      white-space: nowrap;
    }
    .sx-brand {
      font-size: 12 * @unit;
      font-weight: 300;
      font-stretch: condensed;
      letter-spacing: normal;
      color: #333333;
      width: 47%;
    }
  }
}
</style>
