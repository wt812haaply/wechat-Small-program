/**
 * Created by ahu on 2018/4/26
 */
export const postingMd = {
  methods:{
    doJump (url){
      if(url){
        window.location.href=url
      }else{
        return false
      }
    },
    pd (info) {
      return info.partHeight/info.partWidth*100+'%'
    }
  }
}
