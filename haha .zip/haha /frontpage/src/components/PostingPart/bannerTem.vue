<template>
  <a class="SA_A SA_POSTINH_PRODUCT_BANNER_TEM postingIMG image-ratio" @click="doJump(item.linkUrl)" :style="{'padding-bottom':pd(item)}">
    <img v-lazy="item.imgUrl" alt="">
  </a>
</template>

<script>
  import { postingMd } from './methods'
    export default {
      name: "banner-tem",
      mixins:[postingMd],
      props:['item']
    }
</script>

<style scoped>

</style>
