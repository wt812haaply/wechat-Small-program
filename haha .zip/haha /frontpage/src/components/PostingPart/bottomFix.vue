<template>
  <div class="PFBottom">
    <div class="PFBottomCon1" v-for="(value,i) in item.itemList">
      <a class="SA_A SA_POSTINH_BOTTOM_FIX postingIMG image-ratio" @click="doJump(value.linkUrl)" :style="{'padding-bottom':pd(value)}">
        <img v-lazy="value.imgUrl" alt="" >
      </a>
    </div>
  </div>

</template>

<script>
  import { postingMd } from './methods'
    export default {
      name: "bottom-fix",
      mixins:[postingMd],
      props:['item']
    }
</script>

<style scoped>

</style>
