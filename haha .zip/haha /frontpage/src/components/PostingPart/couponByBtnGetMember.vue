<template>
  <a class="SA_A SA_POSTINH_BTN postingIMG image-ratio" @click="getCoupon(item)" :style="{'padding-bottom':pd(item)}">
    <img v-lazy="item.imgUrl"  class="getCoupon " :class="'action_btn_'+cIndex">
  </a>

</template>

<script>
  import { postingMd } from './methods'
  import postingPart from 'api/postingPart'
    export default {
      name: "coupon-by-btn",
      mixins:[postingMd],
      props:['item','cIndex'],
      methods:{
        getCoupon (info) {
          if( !this.$parent.authorization){
            window.location.href =
              '/yi23/Home/User/loginPage?redirect=' +
              encodeURIComponent(this.$parent.$route.fullPath) +
              '&back=' +
              encodeURIComponent('yi23/Home'+this.$parent.$route.fullPath);
            return false
          }
          let options=this.$parent.options;
//          let params={ eventId:info.eventId,referId:options.referId,source:options.source};
          postingPart.postForceWechat().then((res)=>{
            if(info.successInfo && info.successInfo.successImgUrl){
              if(res.data.code==200){
                this.$parent.successInfo=info.successInfo
                this.$parent.showImgDialog=true;
              }else{
                this.$parent.msg=res.data.msg
              }
            }else{
              this.$parent.msg=res.data.msg
            }
          })
        }
      }
    }
</script>

<style scoped>

</style>
