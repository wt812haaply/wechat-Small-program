<template>
  <div class="PFTop">
    <div class="PFTopCon1"  v-for="(value,i) in item.itemList" :key="i">
      <a class="SA_A SA_POSTINH_TOP_FIX postingIMG image-ratio" :style="{'padding-bottom':pd(value)}" @click="doJump(value.linkUrl)">
        <img v-lazy="value.imgUrl" alt="">
      </a>
    </div>
  </div>
</template>

<script>
    import { postingMd } from './methods'
    export default {
        name: "top-fix",
        mixins:[postingMd],
        props:['item']
    }
</script>

<style>

</style>
