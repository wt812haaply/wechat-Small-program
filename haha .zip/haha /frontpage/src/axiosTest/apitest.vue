<template lang="html">
  <div class="">
    <template v-if="data2 != null">
      <p v-for="item in data2.list">{{ item.couponId }}</p>
    </template>
  </div>
</template>

<script>
import { couponPage } from 'api/user'

export default {

  data(){
    return{
      data2: null,
    }
  },
  created(){
    console.log('11');
    couponPage().then((res)=>{
      console.log(res);
      this.data2 = res;
    });
  },
  methods:{

  }
}
</script>

<style lang="css">
</style>
