<template>
  <!--<transition :name="transitionName">-->
  <div class="contentBox">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive">
      </router-view>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive">
    </router-view>
    <bigLoading :open="bigLoading"></bigLoading>
    <!-- 新增全局toast -->
    <ToastV></ToastV>
  </div>
  <!--</transition>-->
</template>
<style lang="less">
  @import "~common/less/variable";
  @import "~common/less/font";
  body{
    background: #ffffff;
  }
  .contentBox{
    height: 100%;
    /*position: relative;*/
  }
  * {
    outline: none; //overflow:auto;/* winphone8和android4+ */
    -webkit-overflow-scrolling: touch;
    /* ios5+ */
  }

  i {
    font-style: normal;
  }

  .none {
    display: none;
  }

  .image-ratio {
    background-color: transparent;
  }
  .hide {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    /*1行*/
    overflow: hidden;
  }
  .yclosetContainer {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    width: 100%;
    background: @color-background;
  }

  /* 暂不显示
  .yclosetHeader {
    width: 100%;
    height: 44px;
    display: flex;
    flex-wrap: wrap;
    background: @color-background;
    position: relative;
    z-index: 9;
  }
  */

  .yclosetCon {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    flex: 1;
    width: 100%;
    height: 100%;
    overflow: scroll;
    background: @color-background;
  }
  .yclosetFooter {
    /*display: flex;*/
    width: 100%;
    background: @color-background;
  }
  /*水平垂直居中 Horizontal Vertical*/
  .HVcenter {
    position: fixed;
    top: 50%;
    left: 50%;
    background: transparent;
    padding: 0;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    width: 100%;
    transform: translateX(-50%) translateY(-50%);
    z-index:11;
  }
  .yclosetCenter {
    width: 100%;
    overflow: auto;
    top: 44px;
    position: absolute;
    z-index: 9999;
    bottom: 0;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
  }
  .yclosetCenterClose {
    display: flex;
    justify-content: center;
    align-items: center;
    .wh(44,44);
    .margin(20,0,0,0);
  }
  .yclosetShade {
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    /*FF*/
    z-index:10;
    position: fixed!important;
    /*FF IE7*/
    position: absolute;
    /*IE6*/
    background: rgba(0, 0, 0, .8);
  }
  .yclosetShade img{
    display: block;
    width: 100%;
  }
  .bG {
    background: @color-background;
  }
  /* yi23 title */
  .yi23ConTitle {
    .padding(35, 23, 35, 23);
    text-align: left;
    display: flex;
    flex-direction: column;
    h2 {
      .font-size(28);
      .line-height(30);
      color: #333;
    }
    em {
      .font-size(14);
      .line-height(30);
      color: #999;
      font-style: normal;
    }
  }
  /* yi23 null状态 */
  .RecordPageCon {
    height: auto;
    justify-content: center;
    align-items: center;
    h2,
    p {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      width: 100%;
    }
    h2 {
      .font-size(20);
    }
    p {
      .font-size(12);
      line-height: 2;
    }
  }
  /* 图片占位 */
  .imgP {
    width: 100%;
    .height(0);
    padding-bottom: 100%;
    position: relative;
    overflow: hidden;
    img {
      width: 100%;
      position: absolute;
    }
  }

  // all
  .yi23red{
    color:#ff544b;
  }
  .yi23gold{
    color:#CDAB6A;
  }
  .yi23gray{
    color:#dedede;
  }
  .yi23bgred{
    background-color:#ff544b;
  }

  input::-webkit-input-placeholder{
      color:rgba(0,0,0,.3);
  }
  input::-moz-placeholder{   /* Mozilla Firefox 19+ */
      color:rgba(0,0,0,.3);
  }
  input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
      color:rgba(0,0,0,.3);
  }
  input:-ms-input-placeholder{  /* Internet Explorer 10-11 */
      color:rgba(0,0,0,.3);
  }

  /* Iphone X*/
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    /*增加底部适配层*/
    .has-bottombar {
      height: 100%;
      box-sizing: border-box;
      padding-bottom: 34px;
      &:after {
        content: '';
        z-index: 9;
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 34px;
        /*background: #f7f7f8;*/
      }
    }
    .bottomIphoneX{
      bottom: 34px !important;
    }
    .paddingBottomIphoneX{
      padding-bottom: 34px !important;
    }
  }


   /*
  * 中划线
  */
  .decoration-line-through{
    text-decoration: line-through;
  }
</style>
<script>
  import TransitionSlideLeftRight from '@/components/lib/transition/SlideLeftRight'
  import bigLoading from '@/components/lib/bigLoading'
  import ToastV from '@/components/lib/ToastV'
  export default {
    components: {
      TransitionSlideLeftRight,
      bigLoading,
      ToastV
    },
    name: 'App',
    data () {
      return {
        transitionName: 'slide-left',
        getUserKey: null,
        toastMsg: '',
        errormsg:''
      }
    },
    watch: {
      '$route' (to, from) {
        const toDepth = to.path.split('/')
        const toDepthLength = toDepth.length
        const fromDepth = from.path.split('/')
        const fromDepthLength = fromDepth.length
        this.transitionName = 'slide-left'
        if (toDepthLength < fromDepthLength) {
          this.transitionName = 'slide-right'
        } else if (toDepthLength === fromDepthLength) {
          let aryIndex = fromDepthLength - 1
          if (toDepth[aryIndex] === '' && fromDepth[aryIndex] !== '') {
            this.transitionName = 'slide-right'
          }
        }
      }
    },
    methods: {
    },
    created () {

    }
  }
</script>
