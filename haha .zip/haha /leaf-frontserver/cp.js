const fs = require('fs-extra')

fs.copySync('./public', './build/public')
fs.copySync('./src/data', './build/src/data')
fs.copySync('./package.json', './build/package.json')
