interface IResolve {
  (path: string): string
}
import _ from 'lodash'
import path from 'path'
import rp from 'request-promise'
import word from '@utils/word'
const TextToSVG = require('text-to-svg')
const sharp = require('sharp')
const fs = require('fs-extra')
const qrcode = require('qrcode')
const OSS = require('ali-oss')
const stream = require('stream')
const client = new OSS({
  region: 'oss-cn-beijing',
  accessKeyId: 'LTAIQ2wcvtDKG54S',
  accessKeySecret: '4gasISPZQO743U4n72fo6IUIuZrdHj',
  bucket: 'ycloset'
})
const resolve: IResolve = _.partial(path.resolve, __dirname)
const svg = TextToSVG.loadSync(resolve('../../public/PingFang-SC-Regular.ttf'))
const fontOptions = {
  x: 0,
  y: 0,
  fontSize: 24,
  anchor: 'top',
  letterSpacing: 1 / 10
}
const avatarFrame = Buffer.from('<svg><circle r="56" cx="56" cy="56" /></svg>')
function makeAvatar(avatar_path: Buffer) {
  return sharp(avatar_path)
    .resize(56 * 2, 56 * 2)
    .overlayWith(avatarFrame, { cutout: true })
    .png()
    .toBuffer({
      resolveWithObject: true
    })
}
const border = Buffer.from(
  '<svg><circle r="58" cx="58" cy="58" fill="#000" /></svg>'
)
function makeBorder() {
  return sharp(border).toBuffer({
    resolveWithObject: true
  })
}
function makeName(text: string) {
  const userName = Buffer.from(svg.getSVG(text, fontOptions))
  return sharp(userName).toBuffer({
    resolveWithObject: true
  })
}
async function makeQrcode(uid: string) {
  const getQR: any = new Promise((resolve, reject) => {
    qrcode.toString(
      `https://www.95vintage.com/architecture/events/annual?referId=${uid}`,
      {
        type: 'svg',
        width: 66 * 2,
        margin: 0
      },
      (err: any, str: string) => {
        if (err) {
          reject(err)
        } else {
          resolve(str)
        }
      }
    )
  })
  const qrStr = await getQR
  const qr = Buffer.from(qrStr)
  return sharp(qr).toBuffer({
    resolveWithObject: true
  })
}
export default async function(info: any) {
  const uid = info.uid + ''
  const encode_uid = Buffer.from(uid)
    .toString('base64')
    .replace(/\=/, '')
  const share_url = `http://ycloset.oss-cn-beijing.aliyuncs.com/events/annual/${encode_uid}.jpg`
  const result = await rp({
    url: share_url,
    simple: false,
    transform(body, response, resolveWithFullResponse) {
      if (response.statusCode === 404) {
        return {
          isExist: false
        }
      } else {
        return {
          isExist: true
        }
      }
    }
  })
  if (result.isExist) {
    return share_url
  }
  let mantissa: number = parseInt(uid.charAt(uid.length - 1), 10)
  if (mantissa <= 1) {
    mantissa = 1
  } else if (mantissa >= 8) {
    mantissa = 8
  }
  let file = 'a'
  const orderCount = info.rent_order_num_18
  if (orderCount >= 5 && orderCount < 10) {
    file = 'b'
  } else if (orderCount >= 10) {
    file = 'c'
  }
  const bg = resolve(`../../public/annual/${mantissa}/${file}.jpg`)
  const base = sharp(bg)
    .png()
    .toBuffer({
      resolveWithObject: true
    })
  const avatar: Buffer = await rp({
    url: info.head_url,
    encoding: null
  })
  const username = word.textOverflow(info.nick_name || '我', 16, false)
  const widgetBuffer = await Promise.all([
    makeBorder(),
    makeAvatar(avatar),
    makeName(`${username} 的`),
    makeQrcode(uid)
  ])
  const overlayOptions = [
    {
      left: 16 * 2 + 24,
      top: 16 * 2 + 15
    },
    {
      left: 17 * 2 + 24,
      top: 17 * 2 + 15
    },
    {
      left: 86 * 2 + 28,
      top: 30 * 2 + 11
    },
    {
      left: 227 * 2 + 28,
      top: 390 * 2 + 11
    }
  ]
  const composite = widgetBuffer.reduce(function(
    input,
    overlay: any,
    index: number
  ) {
    return input.then(function({ data }: any) {
      return sharp(data)
        .overlayWith(overlay.data, overlayOptions[index])
        .toBuffer({
          resolveWithObject: true
        })
    })
  },
  base)
  const buffAll = await composite
  var bufferStream = new stream.PassThrough()
  bufferStream.end(buffAll.data)
  const aliOSS_url = await client.put(
    `events/annual/${encode_uid}.jpg`,
    bufferStream
  )
  return aliOSS_url.url
}
