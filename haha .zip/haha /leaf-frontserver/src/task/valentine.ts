interface IResolve {
  (path: string): string
}
import _ from 'lodash'
import path from 'path'
import rp from 'request-promise'
const TextToSVG = require('text-to-svg')
const sharp = require('sharp')
const fs = require('fs-extra')
const OSS = require('ali-oss')
const stream = require('stream')
const client = new OSS({
  region: 'oss-cn-beijing',
  accessKeyId: 'LTAIQ2wcvtDKG54S',
  accessKeySecret: '4gasISPZQO743U4n72fo6IUIuZrdHj',
  bucket: 'ycloset'
})
const resolve: IResolve = _.partial(path.resolve, __dirname)
const svg = TextToSVG.loadSync(resolve('../../public/PingFang-SC-Regular.ttf'))
const svg_Robt = TextToSVG.loadSync(
  resolve('../../public/RobotoCondensed-Regular.ttf')
)
const fontOptions = {
  x: 0,
  y: 0,
  fontSize: 23,
  anchor: 'top',
  attributes: { fill: '#fff', stroke: '#ffffff', 'stroke-width': 0.5 }
}

function makeTitle(text: string) {
  const tradeNo = Buffer.from(svg.getSVG(text, fontOptions))
  const metrics = {
    top: 475 * 2,
    ...svg.getMetrics(text, fontOptions)
  }
  return sharp(tradeNo)
    .toBuffer({
      resolveWithObject: true
    })
    .then((data: object) => {
      return { ...data, metrics }
    })
}

function makeNumber(text: string) {
  const tradeNo = Buffer.from(svg_Robt.getSVG(text, fontOptions))
  const metrics = {
    top: 475 * 2 + 3,
    ...svg_Robt.getMetrics(text, fontOptions)
  }
  return sharp(tradeNo)
    .toBuffer({
      resolveWithObject: true
    })
    .then((data: object) => {
      return { ...data, metrics }
    })
}

function getOverlayOptionWithAlignCenter(currentIndex: number, source: any) {
  let textWidthsum = source.reduce((Accumulator: number, options: any) => {
    const { width } = options.metrics
    return (Accumulator += width)
  }, 0)

  const offsetLeft =
    Math.ceil(textWidthsum) >= 658 ? 0 : (658 - textWidthsum) / 2
  let width = 0

  for (let i = 0; i <= currentIndex; i++) {
    if (currentIndex === 0) {
      width = 0
    } else if (i <= currentIndex - 1) {
      width += source[i].metrics.width
    }
  }

  return {
    left: Math.ceil(width + offsetLeft),
    top: source[currentIndex].metrics.top || 475 * 2
  }
}

export default async function(info: any) {
  const tradeNo = info.tradeNo + ''
  const totalPrice = info.totalPrice + ''
  const cardOriginPrice = info.cardOriginPrice + ''
  const encode_tradeNo = Buffer.from(tradeNo)
    .toString('base64')
    .replace(/\=/, '')
  const share_url = `http://ycloset.oss-cn-beijing.aliyuncs.com/events/valentine/${encode_tradeNo}.jpg`
  const result = await rp({
    url: share_url,
    simple: false,
    transform(body, response, resolveWithFullResponse) {
      if (response.statusCode === 404) {
        return {
          isExist: false
        }
      } else {
        return {
          isExist: true
        }
      }
    }
  })
  if (result.isExist) {
    return share_url
  }

  const bg = resolve(`../../public/valentine/share/${cardOriginPrice}.jpg`)
  const base = sharp(bg).toBuffer({
    resolveWithObject: true
  })

  const widgetBuffer = await Promise.all([
    makeTitle('衣二三订单号: '),
    makeNumber(`${tradeNo}`),
    makeTitle(` | 代付金额: ¥`),
    makeNumber(`${totalPrice}`)
  ])

  const composite = widgetBuffer.reduce(function(
    input,
    overlay: any,
    index: number,
    source: any
  ) {
    return input.then(function({ data }: any) {
      return sharp(data)
        .overlayWith(
          overlay.data,
          getOverlayOptionWithAlignCenter(index, source)
        )
        .toBuffer({
          resolveWithObject: true
        })
    })
  },
  base)
  const buffAll = await composite
  var bufferStream = new stream.PassThrough()
  bufferStream.end(buffAll.data)
  const aliOSS_url = await client.put(
    `events/valentine/${encode_tradeNo}.jpg`,
    bufferStream
  )
  return aliOSS_url.url
}
