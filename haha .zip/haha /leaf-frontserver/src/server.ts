// TODO: Class module
import Hapi from 'hapi'
import Path from 'path'
import config from '../config/index'
const isDev = config.env === 'development'
const isProd = config.env === 'production'
const isProdBranch = config.tag === 'production'
const server = new Hapi.Server({
  host: '0.0.0.0',
  port: 3000,
  routes: {
    cors: {
      origin: isDev
        ? ['http://localhost']
        : [
            'http://*.95vintage.com',
            'https://*.95vintage.com',
            'http://*.yi23.net',
            'https://*.yi23.net'
          ],
      credentials: true,
      additionalHeaders: ['region'],
      additionalExposedHeaders: ['Date']
    },
    validate: {
      failAction: async (request, h, err) => {
        // console.error('ValidationError:', err && err.message)
        // throw Boom.badRequest(`Invalid request payload input`)
        console.error(err)
        throw err
      }
    },
    files: {
      relativeTo: Path.join(__dirname, '../public')
    }
  },
  cache: [
    {
      name: 'redisCache',
      engine: require('catbox-redis'),
      host: config.redis.host,
      password: config.redis.pwd,
      partition: 'cache'
    }
  ],
  state: {
    strictHeader: true,
    ignoreErrors: true,
    isSecure: isProdBranch,
    isHttpOnly: true,
    isSameSite: 'Strict',
    encoding: 'none'
  }
})

// cookies state
const cookieConfig = {
  ttl: 1000 * 60 * 60 * 24 * 7, // 7 days
  domain: isProd ? '.95vintage.com' : null,
  path: '/'
}
server.state(
  'token',
  Object.assign(cookieConfig, {
    ttl: 1000 * 60 * 60 * 24 // 24 hours
  })
)
export default server
