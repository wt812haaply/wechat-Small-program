if (process.env.NODE_ENV !== 'development') {
  require('module-alias/register')
}
import Hapi from 'hapi'
import Path from 'path'
import routes from './routes'
import server from './server'
import config from '../config/index'
import redis from 'redis'
import bluebird from 'bluebird'
import mount from './plugins/index'
bluebird.promisifyAll(redis)
const isDev = config.env === 'development'
;(async () => {
  const client: any = redis.createClient({
    host: config.redis.host,
    port: config.redis.port,
    password: config.redis.pwd
  })
  client.on('error', (err: any) => {
    console.error(err)
  })
  ;(server.app as any).redis = client

  // vision
  await server.register(require('vision'))
  server.ext('onPreResponse', (request: any, h: Hapi.ResponseToolkit) => {
    const res: any = request.response
    const source: any = res.source
    if (
      res._contentType === 'application/json' &&
      source &&
      res.statusCode === 200
    ) {
      if (!source.code && !source.msg) {
        let schema
        if (
          request.route.settings.plugins.schema &&
          config.tag !== 'production'
        ) {
          schema = request.route.settings.plugins.schema
        }
        request.response.source = {
          code: 200,
          msg: '获取数据成功',
          data: source.data || source,
          schema
        }
      } else if (source.code === 100) {
        request.response.source.code = 200
      }
    }
    return h.continue
  })

  // log
  await server.register({
    plugin: require('hapi-pino'),
    options: {
      prettyPrint: isDev,
      logEvent: isDev
        ? ['response']
        : ['onPostStart', 'onPostStop', 'response', 'request-error'],
      ignorePaths: ['/monitor', '/public'],
      serializers: {
        req: require('pino-noir')(['req.headers.cookie'], null).req
      }
    }
  })

  // authorization
  await server.register(require('hapi-auth-jwt2'))
  server.auth.strategy('jwt', 'jwt', {
    key: 'WaGz6xkHbczU72LB7a8HHBWd',
    validate: (decoded: any, request: Hapi.Request) => {
      return {
        isValid:
          // 由于闲鱼频繁授权，以及精准曝光上报用户信息的问题，token 暂时不做失效
          // typeof decoded === 'object' && decoded.exp && decoded.exp > Date.now()
          typeof decoded === 'object'
      }
    },
    verifyOptions: {
      algorithms: ['HS256']
    },
    cookieKey: 'token'
  })

  await server.register(require('./plugins/internal'))
  // set realm prefix
  if (config.env === 'production') {
    server.realm.modifiers.route.prefix = '/leaf'
  }
  // docs
  await server.register({
    plugin: require('lout')
  })
  // static
  await server.register(require('inert'))
  await mount()
  server.route({
    method: 'GET',
    path: '/{param*}',
    handler: {
      directory: {
        path: Path.join(__dirname, '../public'),
        index: ['index.html', 'default.html'],
        defaultExtension: 'html'
      }
    }
  })
  // routes
  server.route(routes)
  await server.start()
  console.log(`Server running at: ${server.info.uri}`)
})()

process.on('unhandledRejection', err => {
  console.error(err)
  process.exit(1)
})
