const Sequelize = require('sequelize')
import dayjs from 'dayjs'
const sequelize = new Sequelize(
  'yearbook',
  'yearbook',
  'ebitSJVpo6HE6CxNan5L',
  {
    host: 'rm-2zeu04o4mw316zoox3o.mysql.rds.aliyuncs.com',
    dialect: 'mysql',
    logging: false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
)
const Annual = sequelize.define(
  'year_book_info',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true
    },
    uid: Sequelize.INTEGER,
    head_url: Sequelize.STRING(10000),
    nick_name: {
      type: Sequelize.STRING(500),
      get() {
        const context: any = this
        const name = context.getDataValue('nick_name')
        if (!name) {
          return ''
        } else {
          return name.replace(/\[\[EMOJI:[^\[]+\]\]/gi, '')
        }
      }
    },
    first_pay_time: {
      type: Sequelize.DATE,
      get() {
        const context: any = this
        return dayjs(context.getDataValue('first_pay_time')).format(
          'YYYY/MM/DD'
        )
      }
    },
    rent_num_18: Sequelize.INTEGER,
    rent_order_num_18: Sequelize.INTEGER,
    buy_product_num_18: Sequelize.INTEGER,
    total_market_price: Sequelize.INTEGER,
    color_name: Sequelize.STRING(30),
    brand_id: Sequelize.INTEGER,
    brand_name: Sequelize.STRING(50),
    favor_num: Sequelize.INTEGER,
    new_comers_promo: Sequelize.INTEGER,
    picture_num: Sequelize.INTEGER,
    best_review_num: Sequelize.INTEGER,
    like_picture: Sequelize.STRING(1000),
    free_rent_product: Sequelize.STRING(1000),
    free_rent_product_name: Sequelize.STRING(200),
    free_rent_num: Sequelize.INTEGER,
    most_valuable_product: Sequelize.STRING(1000),
    city_name: Sequelize.STRING(1000),
    last_rent_time: {
      type: Sequelize.DATE,
      get() {
        const context: any = this
        const date = context.getDataValue('last_rent_time')
        if (!date) {
          return null
        } else {
          const getHour = dayjs(date)
            .subtract(8, 'hour')
            .hour()
          if (date && (getHour >= 22 || getHour <= 5)) {
            return dayjs(date)
              .subtract(8, 'hour')
              .format('MM.DD / HH:mm')
          } else {
            return null
          }
        }
      }
    },
    first_pay_time_18: {
      type: Sequelize.DATE,
      get() {
        const context: any = this
        const date = context.getDataValue('first_pay_time_18')
        if (date) {
          return dayjs(date).format('YYYY/MM/DD')
        } else {
          return null
        }
      }
    },
    first_rent_time_18: {
      type: Sequelize.DATE,
      get() {
        const context: any = this
        const date = context.getDataValue('first_rent_time_18')
        if (date) {
          return dayjs(date).format('YYYY/MM/DD')
        } else {
          return null
        }
      }
    },
    pay_end_date: {
      type: Sequelize.DATE,
      get() {
        const context: any = this
        const date = context.getDataValue('pay_end_date')
        if (date) {
          return dayjs(date).format('YYYY/MM/DD')
        } else {
          return null
        }
      }
    }
  },
  {
    freezeTableName: true,
    timestamps: false
  }
)

export default Annual
