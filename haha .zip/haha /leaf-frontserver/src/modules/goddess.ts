const Sequelize = require('sequelize')
const sequelize = new Sequelize(
  'yearbook',
  'yearbook',
  'ebitSJVpo6HE6CxNan5L',
  {
    host: 'rm-2zeu04o4mw316zoox3o.mysql.rds.aliyuncs.com',
    dialect: 'mysql',
    logging: false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
)
const Goddress = sequelize.define(
  'goddess',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    uid: Sequelize.INTEGER,
    mobile: Sequelize.STRING(11),
    remind: {
      type: Sequelize.STRING,
      allowNull: true
    }
  },
  {
    freezeTableName: true
  }
)
export default Goddress
