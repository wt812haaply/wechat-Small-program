function getUserStatus(payload: any): number {
  let status: number = 0
  const user = (payload || {}).data
  if (user) {
    // 兼容 koa 项目 token
    if (typeof user.memberStatus === 'string') {
      status = parseMemberToCode(user.memberStatus)
    } else {
      status = user.memberStatus
    }
  }
  return status
}
function parseMemberToCode(memberStatus: string): number {
  let status: number
  switch (memberStatus) {
    case 'C':
      status = 1
      break
    case 'B':
      status = 0
      break
    default:
      status = 2
  }
  return status
}
export default {
  getUserStatus,
  parseMemberToCode
}
