const OSS = require('ali-oss')
export interface IOSSConfig {
  region?: string
  accessKeyId?: string
  accessKeySecret?: string
  bucket?: string
}
export default (config?: IOSSConfig) => {
  config = config || {}
  return new OSS(
    Object.assign(
      {
        region: 'oss-cn-beijing',
        accessKeyId: 'MKLNl7XYcFF5nJJj',
        accessKeySecret: 'fu8HqhR3h7EGULlc8hgy9qziLqY2v9',
        bucket: 'ycloset'
      },
      config
    )
  )
}
