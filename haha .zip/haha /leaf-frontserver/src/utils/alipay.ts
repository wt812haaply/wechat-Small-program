import qs from 'querystring'
import config from '../../config'
import request from 'request-promise'
import dayjs from 'dayjs'
interface IAlipayGatewayPublicParams {
  app_id: string
  method: string
  format?: string
  charset: string
  sign_type: string
  sign: string
  timestamp: string
  version: string
  app_auth_token?: string
}
interface IAlipayGatewayAuthParams extends IAlipayGatewayPublicParams {
  grant_type: string
  code?: string
  refresh_token?: string
}
interface IAlipayGatewayUserParams extends IAlipayGatewayPublicParams {
  auth_token: string
}
/**
 * 拼接支付宝授权页面 url
 * @param redirect - 为页面跳回地址（重定向地址）
 */
function getAlipayAuthUrl(redirect: string): string {
  return (
    'https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?' +
    qs.stringify({
      app_id: config.alipay.app_id,
      scope: 'auth_user',
      redirect_uri: redirect
    })
  )
}
/**
 * 使用 auth_code 换取 access_token 及用户 userId
 * https://docs.open.alipay.com/api_9/alipay.system.oauth.token
 * @param auth_code
 * @param sign
 */
async function getAlipayToken(auth_code: string, sign: string) {
  const params: IAlipayGatewayAuthParams = {
    app_id: config.alipay.app_id,
    method: 'alipay.system.oauth.token',
    format: 'JSON',
    charset: 'utf-8',
    sign_type: 'RSA',
    timestamp: dayjs().format('YYYY-MM-DD HH:mm:ss'),
    version: '1.0',
    grant_type: 'authorization_code',
    code: auth_code,
    sign
  }
  return await request({
    method: 'POST',
    url: 'https://openapi.alipay.com/gateway.do',
    qs: params
  })
}
/**
 * 支付宝会员授权信息查询接口
 * https://docs.open.alipay.com/api_2/alipay.user.info.share
 * @param token
 * @param sign
 */
async function getAlipayUserInfo(token: string, sign: string) {
  const params: IAlipayGatewayUserParams = {
    app_id: config.alipay.app_id,
    method: 'alipay.user.info.share',
    format: 'JSON',
    charset: 'utf-8',
    sign_type: 'RSA',
    timestamp: dayjs().format('YYYY-MM-DD HH:mm:ss'),
    version: '1.0',
    auth_token: token,
    sign
  }
  return await request({
    method: 'POST',
    url: 'https://openapi.alipay.com/gateway.do',
    qs: params
  })
}

export default {
  getAlipayAuthUrl,
  getAlipayToken,
  getAlipayUserInfo
}
