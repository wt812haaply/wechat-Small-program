const request = require('request-promise')
import Hapi from 'hapi'
import config from '../../config'
import * as sign from '../utils/sign'
import jwt from './jwt'
import _ from 'lodash'
if (process.env.debug) {
  require('request-debug')(request)
}
interface IParams {
  device: string
  version: string
  timestamp: number
  source?: string
  channelId: number
  uid: string
  regionId: number
  signature?: string
  deviceId?: string
}
interface IOptions {
  uid?: string
  baseUrl?: string
  prefix?: string
  debug?: IDebug
}
interface IDebug {
  (err: string, res: any, body: any): void
}
interface ISensor {
  distinct_id: string
  $device_id: string
}
function getBaseUrl() {
  let url = 'http://testapi.95vintage.com'
  if (config.tag === 'production') {
    url = 'http://yc.95vintage.com'
  } else if (config.tag === 'staging') {
    url = 'http://stageapi.95vintage.com'
  }
  return url
}
const BASE_URL = getBaseUrl()

const baseRequest = request.defaults({
  BASE_URL,
  json: true
})

interface IUser {
  uid: string
  mobile: string
  [propName: string]: any
}
/**
 * 从手机号获取用户信息
 * @param context
 * @param mobile
 * @return IUser
 */
export async function getUserInfoByMobile(
  context: Hapi.Request,
  mobile: string,
  referId?: number
): Promise<IUser> {
  referId = referId ? referId : 0
  const { data } = await iRequest(context, {
    uid: '0'
  })({
    url: '/user/login',
    method: 'POST',
    form: {
      mobile,
      code: '0000',
      special: '4bf106abe283bee611f1df95c448cf20',
      referId
    }
  })
  return data as IUser
}
/**
 * 获取微信分享信息
 * @param context
 */
export async function wechatShare(context: Hapi.Request) {
  const link = decodeURIComponent((context.query as any).link)
  const { data } = await iRequest(context, {
    baseUrl: config.server3rd,
    prefix: ''
  })({
    method: 'GET',
    url: '/getSignPackage',
    qs: {
      link
    }
  })
  return data
}

export { baseRequest }

function requestStrict(context: Hapi.Request, options: IOptions, params: any) {
  let env_prefix = 't'
  if (config.tag === 'production' || config.tag === 'staging') {
    env_prefix = 'w'
  }
  let project_prefix = ''
  let device = 'Web'
  let channelId = 0
  let uid = options.uid || '0'
  let region = context.headers.region
  let regionId = region ? <number>(region as any) : 52

  if (/xy/.test(context.info.host)) {
    project_prefix = 'xy'
    device = 'XY'
  }
  const cookie_prefix: string = env_prefix + project_prefix
  let isNeedSource = true
  let source = context.state[`${cookie_prefix}_source`] || ''
  if (params.qs && params.qs.source) {
    isNeedSource = false
  }
  if (params.form && params.form.source) {
    isNeedSource = false
  }
  let channelKey = context.state[`${cookie_prefix}_yi23_channel`] || ''
  switch (channelKey) {
    case 'huabei':
      channelId = 10
      break
    case 'zhima':
      channelId = 11
      break
    case 'mayi':
      channelId = 12
      break
  }

  const token: string | undefined = context.state.token
  let payload: any = context.auth.credentials
  if (!payload && token) {
    const decoded = jwt.decode(token) || {}
    payload = decoded.payload
  }

  if (payload && payload.data) {
    let { regionId: region, clientKey } = payload.data
    if (region) {
      regionId = region
    }
    if (!options.uid && clientKey) {
      uid = sign.decode(clientKey)
    }
  }

  const base = options.baseUrl || BASE_URL
  let prefix = '/gw'
  if (options.prefix !== undefined) {
    prefix = options.prefix
  }
  const common: IParams = {
    device,
    version: config.version,
    timestamp: Math.ceil(Date.now() / 1000),
    regionId,
    uid,
    channelId
  }
  if (isNeedSource) {
    common.source = source
  }
  const sensorData = context.state.sensorsdata2015jssdkcross
  if (sensorData) {
    try {
      const data: ISensor = JSON.parse(decodeURIComponent(sensorData))
      if (data && data.$device_id) {
        common.deviceId = data.$device_id
      }
    } catch (e) {
      console.error(e)
    }
  }
  const request = baseRequest.defaults({
    baseUrl: base + prefix,
    headers: {
      wtoken: config.wtoken
    }
  })
  let query = _.pickBy(params.qs, _.identity) || {}
  query = Object.assign(common, query)
  query.signature = sign.createOriginalRSA(query, config.private_key)
  params.qs = query
  const debug = options.debug || function() {}
  return request(params, debug)
}
const curryRequestStrict = _.curry(requestStrict)
export { requestStrict, curryRequestStrict }

export default function iRequest(
  context: Hapi.Request,
  options: IOptions = {}
) {
  return curryRequestStrict(context, options)
}
