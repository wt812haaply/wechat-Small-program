import crypto = require('crypto')
import config from '../../config'

// 微信支付 获取签名和参数
function GetJsApiParameters(param: any) {
  const appid = param.appid
  const prepayId = param.prepayid
  if (!param || !appid || !prepayId) {
    throw new Error('价签参数错误')
  }
  const today = new Date()

  const signParams = {
    appId: appid,
    timeStamp: Math.round(today.getTime() / 1000),
    nonceStr: randomString(32),
    package: 'prepay_id=' + param.prepayid,
    signType: 'MD5'
  } as any
  let urlParams = ToUrlParams(signParams)
  const key = config.wechat.payment_key
  urlParams = urlParams + '&key=' + key

  const sign = crypto
    .createHash('md5')
    .update(urlParams, 'utf8')
    .digest('hex')

  signParams.sign = sign
  return signParams
}

// 产生随机数
function randomString(length: number) {
  let result = ''
  for (; result.length < length; ) {
    result += Math.random()
      .toString(36)
      .slice(2)
  }
  return result
}

// 支付宝加RSA签名
function buildRequestForm(param: any): string {
  delete param.sign
  delete param.sign_type
  const privateKey =
    '-----BEGIN RSA PRIVATE KEY-----\n' +
    insert(config.alipay.payment_private_key, '\n', 64) +
    '-----END RSA PRIVATE KEY-----'
  const signData = ToUrlParams(param)
  const sign = crypto
    .createSign('RSA-SHA1')
    .update(signData)
    .sign(privateKey, 'base64')
  param.sign = sign
  param.sign_type = 'RSA'

  return param
}

function ToUrlParams(args: any) {
  let keys = Object.keys(args)
  keys = keys.sort()
  const newArgs = new Object() as any
  keys.forEach(key => {
    newArgs[key] = args[key]
  })
  let urlParams = ''
  for (const k in newArgs) {
    if (k) {
      urlParams += '&' + k + '=' + newArgs[k]
    }
  }
  urlParams = urlParams.substr(1)
  return urlParams
}

function insert(str: string, insertStr: string, sn: number): string {
  let newstr = ''
  for (let i = 0; i < str.length; i += sn) {
    const tmp = str.substring(i, i + sn)
    newstr += tmp + insertStr
  }
  return newstr
}

export default {
  GetJsApiParameters,
  buildRequestForm
}
