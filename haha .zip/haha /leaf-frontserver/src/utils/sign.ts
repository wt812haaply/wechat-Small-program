import crypto from 'crypto'
import dayjs from 'dayjs'
interface ICipherParam {
  key: string
  plain: string
  iv?: string
  algorithm?: string
  autoPad?: boolean
}

export function signParams(params: any): string {
  let sign: string = ''
  Object.keys(params)
    .sort()
    .forEach(item => {
      if (!/[]/g.test(item)) {
        sign += params[item]
      }
    })
  return sign
}

/**
 * 创建签名文件
 * https://docs.open.alipay.com/291/106130
 * https://stackoverflow.com/questions/20065304/differences-between-begin-rsa-private-key-and-begin-private-key
 * @param options - 签名参数
 * @param key
 * @param isRSA - 是否是 PKCS#8
 */
export function createOriginalRSA(
  options: object,
  key: string,
  isRSA = true
): string {
  const tag = isRSA ? 'RSA' : ''
  let pubkey = `-----BEGIN ${tag} PRIVATE KEY-----\n`
  pubkey += insertChar(key, 64, '\n')
  pubkey += `\n-----END ${tag} PRIVATE KEY-----`
  const signData = signParams(options)

  const sign = crypto.createSign('RSA-SHA1')
  sign.update(signData)
  return sign.sign(pubkey, 'base64')
}

export function insertChar(str: string, mark = 0, insert = ''): string {
  insert = insert || ''
  return str.replace(/./g, (match, offset) => {
    if (offset % mark === 0 && offset !== 0) {
      match = insert + match
    }
    return match
  })
}
export function cipher(param: ICipherParam): string {
  const cipher = crypto.createCipheriv(
    param.algorithm || 'des-cbc',
    Buffer.from(param.key),
    Buffer.from(param.iv || '0')
  )
  cipher.setAutoPadding(param.autoPad || true)
  let ciph = cipher.update(param.plain, 'utf8', 'base64')
  ciph += cipher.final('base64')
  return ciph
}
export function decipher(param: ICipherParam): string {
  const decipher = crypto.createDecipheriv(
    param.algorithm || 'des-cbc',
    Buffer.from(param.key),
    Buffer.from(param.iv || '0')
  )
  decipher.setAutoPadding(param.autoPad || true)
  let constxt = decipher.update(param.plain, 'base64', 'utf8')
  constxt += decipher.final('utf8')
  return constxt
}
export function encode(original: string): string {
  let key: string = dayjs().format('YYYYMMDDHHmmss') + Math.random()
  const md5sum = crypto.createHash('md5')
  md5sum.update(key)
  key = md5sum
    .digest('hex')
    .toUpperCase()
    .substring(5, 13)

  let final: string = ''
  try {
    final = cipher({
      key,
      plain: original,
      iv: key
    })
  } catch (error) {
    console.log(error)
  }
  if (final === '') {
    return ''
  }

  const partA = key.substring(0, 3)
  const partC = key.substring(3, 8)
  const partB = final.substring(0, 5)
  const partD = final.substring(5, final.length)

  const base64Str = partA + partB + partC + partD

  let encodeResult: string = ''
  try {
    encodeResult = Buffer.from(base64Str)
      .toString('base64')
      .replace(/=/g, '')
  } catch (error) {
    console.log(error)
  }

  return encodeResult
}
export function decode(final: string): string {
  let length: number = final.length % 4
  if (length === 3) {
    length = 1
  }
  for (let i = 0; i < length; i++) {
    final += '='
  }
  const code = Buffer.from(final, 'base64').toString()
  const partA = code.substring(0, 3)
  const partB = code.substring(8, 13)
  const partC = code.substring(3, 8)
  const partD = code.substring(13, code.length)

  let decodeResult: string = ''
  try {
    decodeResult = decipher({
      key: partA + partB,
      plain: partC + partD,
      iv: partA + partB
    })
  } catch (error) {
    console.log(error)
  }
  return decodeResult
}
