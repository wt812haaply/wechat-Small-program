import Joi from 'joi'
export default {
  mobile: Joi.string()
    .length(11)
    .required()
    .error(new Error('请输入正确的手机号')),
  code: Joi.string()
    .regex(/^(\d{4}|\d{6})$/)
    .required()
    .error(new Error('请输入有效的验证码'))
}
