import uuid from 'uuid'
import fs from 'fs'
import path from 'path'

const uploader = function(file: any, options?: any) {
  if (!file) throw new Error('no file(s)')
  options = options || {}
  return _fileHandler(file, options)
}

const _fileHandler = function(file: any, options?: any) {
  if (!file) throw new Error('no file')
  const originalname = file.hapi.filename
  const filename = uuid.v1() + path.extname(originalname)
  const _path = path.resolve(__dirname, '../../temp/' + filename)
  const fileStream = fs.createWriteStream(_path)

  return new Promise((resolve, reject) => {
    file.on('error', function(err: any) {
      reject(err)
    })

    file.pipe(fileStream)

    file.on('end', function(err: any) {
      const fileDetails = {
        fieldname: file.hapi.name,
        originalname,
        filename,
        mimetype: file.hapi.headers['content-type'],
        destination: `${options.dest}`,
        path,
        size: fs.statSync(_path).size
      }

      resolve(fileDetails)
    })
  })
}

async function uploadOSS(file: any, client: any, options?: any) {
  if (!file) throw new Error('no file')
  const originalname = file.hapi.filename
  const filename = uuid.v1() + path.extname(originalname)
  const _path = path.resolve(__dirname, '../../temp/' + filename)
  file.path = _path
  const result = await client.putStream(options.target + filename, file)
  return result
}

const imageFilter = function(fileName: string) {
  // accept image only
  if (!fileName.match(/\.(jpg|jpeg|png|gif)$/)) {
    return false
  }

  return true
}

interface IDateRange {
  start: object
  end: object
}
/**
 * 判断是否在一个时间段内
 * @param {object} range  - 范围
 * @param {Date?} date - 对比的时间
 * @return {number} - -1 小于 0 进行中 1 过期
 */
function expiryDate(range: IDateRange, date?: Date): number {
  const _date: number = date ? date.valueOf() : Date.now()
  let code = 0
  if (_date < range.start.valueOf()) {
    code = -1
  } else if (_date > range.end.valueOf()) {
    code = 1
  }
  return code
}

export { uploader, imageFilter, uploadOSS, expiryDate }
