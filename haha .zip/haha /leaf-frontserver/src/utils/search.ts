const AipImageSearchClient = require('baidu-aip-sdk').imageSearch

// 设置APPID/AK/SK
const APP_ID = '15168303'
const API_KEY = 'hAXMps16fSfYG5K2LRmpLbvg'
const SECRET_KEY = 'YiPieZT82jxP8YT8hc6E48Zf21qX4bw8'

// 新建一个对象，建议只保存一个对象调用服务接口
const client = new AipImageSearchClient(APP_ID, API_KEY, SECRET_KEY)

function getSimilarSearch(image: any): any {
  return new Promise(function(resolve, rejection): any {
    const option: any = {}
    option['pn'] = '0'
    option['rn'] = '10'

    client
      .productSearch(image, option)
      .then(function(result: any) {
        resolve(result)
      })
      .catch(function(err: any) {
        // 如果发生网络错误
        rejection(err)
      })
  })
}

export { client, getSimilarSearch }
