const JWT = require('jsonwebtoken')
interface IToken {
  header: object
  payload: {
    data: object
  }
  signature: object
}
function decode(token: string): IToken {
  return JWT.decode(token, {
    complete: true,
    json: true
  })
}
function create(data: any, secret: string): string {
  const now = Date.now()
  const date = new Date()
  return JWT.sign(
    {
      data,
      iat: now,
      exp: date.setHours(date.getHours() + 2).valueOf()
    },
    secret
  )
}
export default {
  create,
  decode,
  refresh: (jwt: string): string => {
    const payload: any = decode(jwt).payload.data
    if (/^\d{11}$/g.test(payload.nickname)) {
      payload.nickname = payload.nickname.replace(/(\d{3})\d{4}/g, '$1****')
    }
    return create(payload, 'WaGz6xkHbczU72LB7a8HHBWd')
  }
}
