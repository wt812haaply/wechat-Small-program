import * as Hapi from 'hapi'
import config from '../../config'
import * as sign from './sign'
import jwt from './jwt'
import _ from 'lodash'

interface IParams {
  device: string
  version: string
  timestamp: number
  source: string
  channelId: number
  uid: string
  regionId: number
  signature?: string
  deviceId?: string
}

interface ISensor {
  distinct_id: string
  $device_id: string
}

function deleteAttr(data: any, delArray: any): string {
  for (const key in data) {
    delArray.map((del: any) => {
      if (key === del) {
        delete data[key]
      }
    })
  }
  return data
}

function exposure(request: any, data: any) {
  let device = 'Web'
  if (/xy/.test(request.info.host)) {
    device = 'XY'
  }

  let statePrefix = process.env.tag === 'production' ? 'w' : 't'
  if (/xy/.test(request.info.host)) {
    statePrefix += 'xy'
  }
  if (statePrefix) {
    statePrefix += '_'
  }
  const params = {
    uid: '0',
    device: device,
    version: config.version,
    regionId: 52,
    source: request.state[`${statePrefix}source`] || '',
    channelId: 0,
    timestamp: Math.ceil(Date.now() / 1000)
  }

  switch (request.state.yi23_channel) {
    case 'huabei':
      params.channelId = 10
      break
    case 'zhima':
      params.channelId = 11
      break
    case 'mayi':
      params.channelId = 12
      break
  }

  const token: string | undefined = request.state.token

  let payload: any = request.auth.credentials
  if (!payload && token) {
    const decoded = jwt.decode(token) || {}
    payload = decoded.payload
  }
  if (payload && payload.data) {
    const { regionId, clientKey } = payload.data
    if (regionId) {
      params.regionId = regionId
    }
    params.uid = sign.decode(clientKey)
  }

  const suffix =
    '&device=' +
    device +
    '&version=' +
    config.version +
    '&regionId=' +
    params.regionId +
    '&timestamp=' +
    params.timestamp +
    '&channelId=' +
    params.channelId +
    '&uid=' +
    params.uid

  const baseUrl =
    process.env.tag === 'production'
      ? 'http://yc.95vintage.com'
      : 'http://testapi.95vintage.com'
  const baseUrl1 =
    process.env.tag === 'production'
      ? 'https://api.95vintage.com/gw/'
      : 'http://testapi.95vintage.com/gw/'
  const typeArr = new Array()
  data.forEach((item: any) => {
    item.type = item.exposedPidInfo[0].type
    const exposedPidInfo = new Array()
    item.exposedPidInfo.forEach((elType: any) => {
      if (item.type !== elType.type) {
        exposedPidInfo.push(elType)
      }
      delete elType.type
    })
    const typeObj = {
      exposedPidInfo,
      urlParam: item.urlParam
    }
    if (typeObj.exposedPidInfo.length > 0) {
      typeArr.push(typeObj)
    }
    if (item.urlParam.indexOf('/Ajax/Subscribe/promotionListPage') > 0) {
      const after = item.urlParam.split('?')[1]
      item.urlParam = baseUrl1 + '/product/productSearch?' + after + suffix
    } else if (item.urlParam.indexOf('/Ajax/Subscribe/pdtListPage') > 0) {
      const after = item.urlParam.split('?')[1]
      item.urlParam = baseUrl1 + '/product/productList?' + after + suffix
    } else if (item.urlParam.indexOf('/leaf/gallery') > 0) {
      const after = item.urlParam.split('?')[1]
      item.urlParam =
        baseUrl + '/ms/content/v1/user/ab/sharePhotoList?' + after + suffix
    } else if (item.urlParam.indexOf('/leaf/gallery/') > 0) {
      const after = item.urlParam.split('?')[1]
      item.urlParam =
        baseUrl + '/ms/content/v1/user/sharePhotoDetail?' + after + suffix
    } else if (item.urlParam.indexOf('/leaf/products/list') > 0) {
      const after = item.urlParam.split('?')[1]
      item.urlParam = baseUrl + '/gw/product/productList?' + after + suffix
    } else if (
      item.urlParam.indexOf('/leaf/products/') > 0 &&
      item.urlParam.indexOf('/recommend') > 0
    ) {
      const after = item.urlParam.split('?')[1]
      item.urlParam =
        baseUrl + '/gw/product/productDetailRecommend?' + after + '&' + suffix
    }
  })
  data = data.concat(typeArr)
  return data
}

/**
 * 用于数据上报，恢复原使用的数据，由于请求时无缓冲。
 * @param currentContext 当前的请求
 */
function recoverRequestParams(currentContext: Hapi.Request, paramStr?: String) {
  const productionEnv: boolean = config.tag === 'production'
  let envPrefix = 't'
  if (productionEnv) {
    envPrefix = 'w'
  }
  const hostEnv: boolean = /xy/.test(currentContext.info.host)
  let projectPrefix = ''
  let device = 'Web'
  if (hostEnv) {
    projectPrefix = 'xy'
    device = 'XY'
  }

  let channelId = exchangeRequestChannel(currentContext.state.yi23_channel)
  let uid = '0'
  let regionId = 52

  let source = currentContext.state[`${envPrefix}${projectPrefix}_source`] || ''

  const token: string | undefined = currentContext.state.token
  let payload: any = currentContext.auth.credentials
  if (!payload && token) {
    const decoded = jwt.decode(token) || {}
    payload = decoded.payload
  }

  if (payload && payload.data) {
    let { regionId: region, clientKey } = payload.data
    if (region) {
      regionId = region
    }
    if (clientKey) {
      uid = sign.decode(clientKey)
    }
  }

  const common: IParams = {
    device,
    version: config.version,
    timestamp: Math.ceil(Date.now() / 1000),
    source,
    regionId,
    uid,
    channelId
  }
  const sensorData = currentContext.state.sensorsdata2015jssdkcross
  if (sensorData) {
    try {
      const data: ISensor = JSON.parse(decodeURIComponent(sensorData))
      if (data && data.$device_id) {
        common.deviceId = data.$device_id
      }
    } catch (e) {
      console.error(e)
    }
  }
  let paramObj = urlStrToObj(paramStr)

  let query: any = paramObj ? Object.assign(common, paramObj) : common
  query.signature = sign.createOriginalRSA(query, config.private_key)
  let requestString = ''
  _.forIn(query, function(val, key) {
    if (typeof val === 'object') {
      _.forEach(val, function(o) {
        requestString = requestString + key + '=' + o + '&'
      })
    } else {
      requestString = requestString + key + '=' + val + '&'
    }
  })
  return _.trimEnd(requestString, '&')
}

function urlStrToObj(url: String | undefined) {
  let resultObj: any = {}
  if (!url) {
    return resultObj
  }
  const urlArr = url.split('&')
  _.forEach(urlArr, function(o) {
    let mapArr = o.split('=')
    let key = mapArr[0]
    let val = mapArr[1]
    const valType = _.get(resultObj, key, false)
    if (valType) {
      if (typeof valType === 'string') {
        let valArr = [valType, val]
        resultObj[key] = valArr
      } else {
        valType.push(val)
        resultObj[key] = valType
      }
    } else {
      resultObj[key] = val
    }
  })
  return resultObj
}

/**
 * 根据 type 返回对应的请求链接
 * @param originUrl 前端请求 URL
 */
function recoverRequestLink(typeString: any) {
  typeString =
    typeString === 'product_detail_recommended'
      ? 'product_detail_related'
      : typeString
  const urlMapping = {
    product_short_list: 'gw/product/productSearch',
    product_detail_related: 'gw/product/productDetailRecommend',
    product_list: 'gw/product/productList',
    sharePhotoList: 'ms/content/v1/user/ab/sharePhotoList'
  }
  const baseUrl =
    config.tag === 'production'
      ? 'https://api.95vintage.com/'
      : 'http://testapi.95vintage.com/'

  return baseUrl + _.get(urlMapping, typeString, false)
}

function exchangeRequestChannel(channelString: String) {
  let channelId: number = 0
  switch (channelString) {
    case 'huabei':
      channelId = 10
      break
    case 'zhima':
      channelId = 11
      break
    case 'mayi':
      channelId = 12
      break
  }
  return channelId
}

/**
 * 筛选 exposedPidInfo 数据
 * @param requestData 请求数据
 */
function recoverOriginData(requestData: any) {
  if (!requestData) {
    return false
  }
  const type: String = requestData[0].type
  _.forEach(requestData, function(o) {
    delete o.type
  })
  const formatData = {
    type,
    data: requestData
  }
  return formatData
}

function recoverDataSet(
  originData: any,
  context: Hapi.Request,
  paramUrl?: string
) {
  if (!originData) {
    return false
  }
  const formatData: any = recoverOriginData(originData)
  let requetUrl: string = recoverRequestLink(formatData.type)
  const requestData: any = formatData.data
  if (!requetUrl || !requestData) {
    return false
  }
  if (paramUrl) {
    const paramArr = paramUrl.split('?')
    //当 recommend 的时候 pid 由于 rest 在链接中
    let subStrArr: any = paramArr[0].match(/\/products\/(\S*)\/recommend$/)
    let query: string = paramArr[1] || ''
    let pidStr: string = ''
    if (subStrArr !== null) {
      pidStr = 'pid=' + subStrArr[1] + '&'
    }
    paramUrl = pidStr + query
    paramUrl = _.trimEnd(paramUrl, '&')
  }
  const queryString: String = recoverRequestParams(context, paramUrl)

  requetUrl = queryString ? requetUrl + '?' + queryString : requetUrl

  const originDataSet = {
    urlParam: requetUrl,
    exposedPidInfo: requestData
  }
  const codeStr = Buffer.from(JSON.stringify(originDataSet)).toString('base64')
  const reportDataSet = {
    type: formatData.type,
    data: codeStr
  }
  return reportDataSet
}

export default {
  deleteAttr,
  exposure,
  recoverDataSet
}
