import { plugin, options } from './user'
import server from '../server'
async function mount() {
  await server.register(plugin, options)
}
export default mount
