import routes from '../routes/login'
import path from 'path'
export const plugin = {
  name: 'user',
  pkg: require(path.resolve(__dirname, '../../package.json')),
  register: async function(server: any, options: any) {
    server.route(routes)
  }
}
export const options = {
  routes: {
    prefix: '/user'
  }
}
