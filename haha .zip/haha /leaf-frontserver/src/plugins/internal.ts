import * as Hapi from 'hapi'
import rp from '../utils/request'
import path from 'path'
import fs from 'fs'
import OSS, { IOSSConfig } from '../utils/oss'
export const plugin = {
  name: 'internal',
  pkg: require(path.resolve(__dirname, '../../package.json')),
  register: async function(server: any, options: any) {
    server.route({
      method: 'POST',
      path: '/internal/login',
      options: {
        isInternal: true
      },
      handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
        const data = await rp(request)({
          method: 'POST',
          url: '/user/login',
          form: request.payload
        })
        return data
      }
    })
    server.method('login', async (payload: any) => {
      return await server.inject({
        method: 'POST',
        url: '/internal/login',
        payload,
        allowInternals: true
      })
    })
  }
}
