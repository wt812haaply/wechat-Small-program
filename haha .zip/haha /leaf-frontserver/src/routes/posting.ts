import * as Hapi from 'hapi'
import rp, { getUserInfoByMobile } from '../utils/request'
const Joi = require('joi')
const Boom = require('boom')

export default [
  {
    method: 'GET',
    path: '/posting/coupon/promotion',
    options: {
      validate: {
        query: {
          mobile: Joi.string()
            .length(11)
            .required()
            .error(new Error('请输入正确手机号')),
          eventId: Joi.number().required(),
          referId: Joi.number()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { mobile, eventId, referId = 0 } = request.query as any
      const { data } = await rp(request)({
        url: '/user/login',
        method: 'POST',
        form: {
          mobile,
          code: '0000',
          special: '4bf106abe283bee611f1df95c448cf20',
          referId
        }
      })
      if (!data) {
        return Boom.forbidden('请确认信息后再重试')
      }
      const uid: number = data.uid || 0
      const result = await rp(request, { uid: String(uid) })({
        url: '/coupon/promotionCouponSet',
        method: 'POST',
        form: {
          eventId,
          referId
        }
      })
      return result
    }
  },
  {
    method: 'GET',
    path: '/posting/extend/{id}',
    options: {
      validate: {
        params: {
          id: Joi.string()
            .required()
            .error(new Error('参数id不正确'))
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: 'posting详情页(承接页)'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const postingId = request.params.id
      const res = await rp(request, {
        prefix: '/ms'
      })({
        url: '/content/v1/page/posting',
        method: 'GET',
        qs: {
          postingId
        }
      })

      if (res.code !== 100) {
        console.error(res)
        return { code: 105, msg: '网络错误，请稍后重试！' }
      }
      return res.data
    }
  },
  {
    method: 'GET',
    path: '/posting/{eventId}/reward',
    options: {
      auth: 'jwt',
      validate: {
        params: {
          eventId: Joi.number()
            .required()
            .error(new Error('你没有参加此活动的权限'))
        }
      },
      description: '无需手机号领券接口，但必须登录'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const eventId = request.params.eventId
      const requestResult = await rp(request)({
        url: '/coupon/promotionCouponSet',
        method: 'POST',
        form: {
          eventId
        }
      })
      if (!requestResult) {
        return {
          code: 105,
          msg: '活动已经结束'
        }
      }
      return requestResult
    }
  }
]
