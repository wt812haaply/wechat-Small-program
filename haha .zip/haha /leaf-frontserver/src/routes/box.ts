import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')
const Boom = require('boom')
import dayjs from 'dayjs'
import status from '../utils/status'
import _ from 'lodash'

export interface ISendBoxParam {
  addrId: number
  date: string
  'items[]': string[]
}

export default [
  {
    method: 'GET',
    path: '/box',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const getBox = rp(request)({
        url: '/order/userBoxList'
      })
      const getOrder = rp(request)({
        url: '/order/canUserOrder'
      })
      const getBoxComplete = rp(request)({
        url: '/order/completedUserBoxList'
      })
      const getCoupon = rp(request)({
        url: '/user/clothCouponList'
      })
      const getUser = rp(request)({
        url: '/user/userInfo'
      })

      const [
        { data: box },
        { data: order },
        { data: boxComplete },
        { data: coupon },
        { data: user }
      ] = await Promise.all([
        getBox,
        getOrder,
        getBoxComplete,
        getCoupon,
        getUser
      ])
      if (box && box.pendingOrderId > 0) {
        throw Boom.badRequest()
      }
      const { boxMeta = {}, cart, boxesInUse = [] } = box
      boxesInUse.forEach((item: { addTime: string; revDate: string }) => {
        if (item.addTime) {
          item.addTime = dayjs(item.addTime).format('YYYY/MM/DD')
        }
        if (item.revDate) {
          item.revDate = dayjs(item.revDate).format('YYYY/MM/DD')
        }
      })
      const { extra_field = 0 } = boxMeta
      const boxStatus: number = (function getBoxStatus(
        cart: number,
        base: number
      ): number {
        let status
        if (cart === 0) {
          status = 1
        } else if (cart > 0 && cart < base + 3) {
          status = 2
        } else {
          status = 3
        }
        return status
      })(Object.keys(cart).length, extra_field)

      const stockCanOrder: number = +cart.some(
        (item: any) => item.stockNum <= 0
      )
      cart.forEach((item: { thumbPic: string }) => {
        item.thumbPic = item.thumbPic.replace(/!240w/g, '')
      })
      const { is_order: canPlaceOrder = 0, reason_msg: orderMsg } = order
      const { list: completList = [] } = boxComplete
      completList.forEach((item: any) => {
        if (item.addTime) {
          item.addTime = dayjs(item.addTime).format('YYYY/MM/DD')
        }
        if (item.revDate) {
          item.revDate = dayjs(item.revDate).format('YYYY/MM/DD')
        }
      })
      const { list: couponList = [] } = coupon
      couponList.forEach((item: any) => {
        if (item.startDate) {
          item.startDate = dayjs(item.startDate).format('YYYY/MM/DD')
        }
        if (item.expDate) {
          item.expDate = dayjs(item.expDate).format('YYYY/MM/DD')
        }
      })
      const userStatus: number = status.getUserStatus(request.auth.credentials)
      return {
        extra_field,
        boxusing: boxesInUse,
        items: cart.map((item: any) => item.boxId).join(),
        cantOrder: stockCanOrder,
        boxnum: boxMeta.boxNum,
        clothesNum: Object.keys(cart).length,
        boxInfo: cart,
        box_status: boxStatus,
        allnum: extra_field + 3,
        is_have_using: +(Object.keys(cart).length > 0),
        can_place_order: canPlaceOrder,
        orderMsg,
        is_have_history: +(completList.length > 0),
        boxlist: completList,
        couponinfo: couponList,
        havecoupon: +(completList.length > 0),
        userStatus,
        depositInfo: box.depositInfo,
        boxMeta: box.boxMeta,
        canUserOrder: order,
        isValidUser: user.is_vip
      }
    }
  },
  {
    method: 'GET',
    path: '/box/v2',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const getBox = rp(request)({
        url: '/order/userBoxList'
      })
      const getOrder = rp(request)({
        url: '/order/canUserOrder'
      })
      const getBoxComplete = rp(request)({
        url: '/order/completedUserBoxList'
      })
      const getCoupon = rp(request)({
        url: '/user/clothCouponList'
      })
      const getUser = rp(request)({
        url: '/user/userInfo'
      })

      const [
        { data: box },
        { data: order },
        { data: boxComplete },
        { data: coupon },
        { data: user }
      ] = await Promise.all([
        getBox,
        getOrder,
        getBoxComplete,
        getCoupon,
        getUser
      ])
      const userStatus: number = status.getUserStatus(request.auth.credentials)
      return {
        box,
        order,
        boxComplete,
        coupon,
        userStatus,
        isValidUser: user ? user.is_vip : 0
      }
    }
  },
  {
    method: 'GET',
    path: '/box/express',
    options: {
      auth: 'jwt',
      validate: {
        query: {
          oid: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const query = request.query as Hapi.RequestQuery
      const getAddress = rp(request)({
        url: '/addr/addrList'
      })
      const getExpire = rp(request)({
        url: '/courier/availablePickupTimes',
        qs: {
          orderId: query.oid
        }
      })
      const [{ data: address }, { data: expire }] = await Promise.all([
        getAddress,
        getExpire
      ])
      return {
        reserve_time_list: expire.map(
          (item: { date: string; period: [string] | string }) => {
            item.period = (item.period as [string]).join('|')
            return item
          }
        ),
        addressList: address,
        default_address: address[0] || {},
        has_default_address: +(address.length > 0),
        oid: query.oid
      }
    }
  },
  {
    method: 'POST',
    path: '/box/lockStock/{regionId}',
    options: {
      auth: 'jwt',
      validate: {
        params: {
          regionId: Joi.string().error(new Error('归属地ID不正确'))
        }
      },
      notes: '锁定衣箱'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const regionId = request.params.regionId || '52'
      const lockRes = await rp(request)({
        method: 'POST',
        url: '/order/lockDepositStock',
        form: {
          regionId
        }
      })
      return lockRes
    }
  },
  {
    method: 'POST',
    path: '/box/unlockStock',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const unRes = await rp(request)({
        method: 'POST',
        url: '/order/cancelDepositStockLocks'
      })
      return unRes
    }
  },
  {
    method: 'POST',
    path: '/box/{skuId}/addToCart',
    options: {
      validate: {
        params: {
          skuId: Joi.number().error(new Error('请选择要添加的衣服'))
        }
      },
      auth: 'jwt',
      notes: '添加衣箱接口，同时接收 path 参数'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const path: string = (request.payload as any).path || ''
      const skuId: number = (request.params as any).skuId || 0

      const addResult = await rp(request)({
        method: 'POST',
        url: '/order/addItemToCart',
        form: {
          path,
          skuId
        }
      })
      return addResult
    }
  },
  {
    method: 'POST',
    path: '/box/{skuId}/removeFromCart',
    options: {
      validate: {
        params: {
          skuId: Joi.number().error(new Error('请选择要移除的衣服'))
        }
      },
      auth: 'jwt',
      notes: '移除衣箱接口，同时接收 path 参数'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const path = (request.payload as any).path || ''
      const skuId: number = (request.params as any).skuId || 0
      const removeResult = await rp(request)({
        method: 'PUT',
        url: '/order/removeItemFromCart',
        form: {
          path,
          skuId
        }
      })
      return removeResult
    }
  },
  {
    method: 'POST',
    path: '/box/{addrId}/send',
    options: {
      validate: {
        params: {
          addrId: Joi.number()
            .required()
            .error(new Error('请选择收货地址后，再提交订单'))
        },
        payload: {
          items: Joi.string()
            .required()
            .error(new Error('请选择要下单的商品')),
          date: Joi.string()
            .regex(/^\d{4}-\d{1,2}-\d{1,2}/)
            .required()
            .error(new Error('日期错误请稍后重试'))
        },
        options: {
          allowUnknown: true
        }
      },
      auth: 'jwt',
      notes: '用户下单接口'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { addrId } = request.params as any
      const { date, items } = request.payload as any
      const itemsArr = _.split(items, ',')
      const params: ISendBoxParam = {
        addrId: addrId,
        date: date,
        'items[]': itemsArr
      }
      const orderResult = await rp(request)({
        method: 'POST',
        url: '/order/placeOrder',
        form: params,
        useQuerystring: true
      })
      return orderResult
    }
  }
]
