import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')
import status from '../utils/status'
export default [
  {
    method: 'GET',
    path: '/page/index',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request, {
        prefix: '/ms'
      })({
        url: '/content/v1/page/discoverPage',
        method: 'GET'
      })
      if (!data) {
        data = {}
      }
      if (request.auth.isAuthenticated) {
        data.userStatus = status.getUserStatus(request.auth.credentials)
      } else {
        data.userStatus = 0
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/page/agreement',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request, {
        prefix: '/ms'
      })({
        url: '/card/v1/contract',
        method: 'GET',
        qs: {
          device: 'web'
        }
      })
      if (!data) {
        data = {}
      }
      return data
    }
  },
  {
    method: 'POST',
    path: '/page/beginnerSelectionReport',
    options: {
      auth: 'jwt',
      description: '用户冷启动选择结果提交接口'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const payload = request.payload as any
      let data = await rp(request, {
        prefix: '/ms'
      })({
        url: '/content/v1/page/userLikeRecoTopic',
        method: 'POST',
        form: payload
      })
      return data
    }
  }
]
