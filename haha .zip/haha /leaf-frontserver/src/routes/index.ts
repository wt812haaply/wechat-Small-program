import box from './box'
import monitor from './monitor'
import posting from './posting'
import product from './product'
import user from './user'
import manager from './manager'
import page from './page'
import card from './card'
import points from './points'
import gallery from './gallery'
import brand from './brand'
import events from './events/index'
import pay from './pay'
import party from './party'
import experience from './experience'
import rules from './rules'
import coupon from './coupon'
import address from './address'
import setting from './setting'
import member from './member'
import proxy from './proxy'
export default [
  ...product,
  ...box,
  ...user,
  ...monitor,
  ...posting,
  ...manager,
  ...page,
  ...card,
  ...points,
  ...gallery,
  ...brand,
  ...events,
  ...pay,
  ...party,
  ...experience,
  ...rules,
  ...coupon,
  ...address,
  ...setting,
  ...member,
  ...proxy
]
