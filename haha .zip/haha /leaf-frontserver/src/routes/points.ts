import * as Hapi from 'hapi'
import rp from '../utils/request'
const Boom = require('boom')
const Joi = require('joi')
export default [
  {
    method: 'POST',
    path: '/points/forceWechat',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/addForceServerNumber'
      })
      return data
    }
  }
]
