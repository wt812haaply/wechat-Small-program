import * as Hapi from 'hapi'
import server from '../server'
import status from '../utils/status'
import rp from '@request'
import validate from '@utils/validate'
import Path from 'path'
import alipay from '@utils/alipay'
import config from '../../config'
import qs from 'querystring'

const Joi = require('joi')
const Boom = require('boom')
const captcha = require('svg-captcha')
let $cache: any = server.cache({
  cache: 'redisCache',
  expiresIn: 3 * 60 * 1000,
  segment: 'captcha'
})

export default [
  {
    method: 'POST',
    path: '/login',
    options: {
      validate: {
        payload: {
          code: validate.code,
          mobile: validate.mobile,
          referId: Joi.string().optional()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { result } = await server.methods.login(request.payload)
      let { data } = result
      if (data) {
        if ((request.query as any).cookie) {
          h.state('token', data.jwtToken)
        }
        return {
          code: 100,
          msg: '登录成功',
          data: {
            success: true,
            token: data.jwtToken
          }
        }
      } else {
        data = result
      }
      return data
    }
  },
  {
    method: 'POST',
    path: '/login/source',
    options: {
      validate: {
        payload: {
          source: Joi.string().required(),
          mobile: validate.mobile
        }
      },
      description: '使用 source 登录'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { result } = await server.methods.login(
        Object.assign(request.payload, {
          special: '4bf106abe283bee611f1df95c448cf20',
          code: '0000'
        })
      )
      const { data: info } = result
      const { is_new, member_status } = info
      return {
        is_new,
        userStatus: status.parseMemberToCode(member_status)
      }
    }
  },
  {
    method: 'POST',
    path: '/bind/taobao',
    options: {
      validate: {
        payload: {
          code: validate.code,
          mobile: validate.mobile,
          tbUid: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const result = await rp(request)({
        method: 'POST',
        url: '/user/bindingTaobao',
        form: Object.assign(request.payload, {
          source: '36cfe87b0b09ac1ede0ae7424dc74a02'
        })
      })
      if (result.code !== 100) {
        return result
      }
      const { data } = result
      return data
    }
  },
  {
    method: 'POST',
    path: '/login/taobao',
    options: {
      validate: {
        payload: {
          code: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const result = await rp(request)({
        method: 'POST',
        url: '/user/loginWithTaobao',
        form: {
          tbAuthCode: (request.payload as any).code
        }
      })
      let body: any = {}
      try {
        const { data } = result
        if (data) {
          const step = data.loginStep
          let _data = data.loginData
          if (step === 2) {
            _data = data.loginData.jwtToken
          }
          body.loginData = _data
          body.loginStep = step
        } else {
          body = result
        }
      } catch (e) {
        body = result
      }
      return body
    }
  },
  {
    method: 'POST',
    path: '/jwt',
    options: {
      description: 'postman jwt 生成'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      if (!/postmanruntime/gi.test(request.headers['user-agent'])) {
        return Boom.unauthorized()
      }
      const { result } = await server.methods.login(request.payload)
      const { data } = result
      if (data) {
        if ((request.query as any).cookie) {
          h.state('token', data.jwtToken)
        }
        return {
          code: 200,
          access_token: data.jwtToken,
          name: 'test'
        }
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/captcha',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      captcha.loadFont(
        Path.resolve(__dirname, '../../public/Ubuntu-Medium.ttf')
      )
      const code = captcha.create({
        inverse: false,
        color: false,
        fontSize: 28,
        noise: 2,
        width: 100,
        height: 30,
        size: 4,
        charPreset: '1234567890abcdefghjklmnpqrstuvwxyz',
        background: '#909090'
      })
      const str = Math.random()
        .toString(36)
        .substr(2)

      await $cache.set(`captcha:${str}`, code.text)
      return {
        picture: code.data,
        sign: str
      }
    }
  },
  {
    method: 'POST',
    path: '/captcha/verify',
    options: {
      validate: {
        payload: {
          sign: Joi.string().required()
        }
      },
      description: '图形验证码验证'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const state = (request.payload as any).sign
      const body = await $cache.get(`captcha:${state}`)
      return body
    }
  },
  {
    method: 'POST',
    path: '/verify-code',
    options: {
      validate: {
        payload: {
          code: Joi.string()
            .length(4)
            .required()
            .error(new Error('请输入有效的图形验证码')),
          mobile: Joi.string()
            .length(11)
            .required()
            .error(new Error('请输入正确的手机号')),
          sign: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { code, mobile, sign } = request.payload as any
      const captcha = await $cache.get(`captcha:${sign}`)
      let body
      if (code.toLowerCase() !== captcha) {
        body = {
          code: 105,
          msg: '图形验证码错误！'
        }
      } else {
        await $cache.drop(`captcha:${sign}`)
        body = await rp(request)({
          url: '/user/sendVerification',
          method: 'POST',
          form: {
            mobile
          }
        })
      }
      return body
    }
  },
  {
    method: 'POST',
    path: '/fish/verify-code',
    options: {
      validate: {
        payload: {
          mobile: Joi.string()
            .length(11)
            .required()
            .error(new Error('请输入正确的手机号'))
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { mobile } = request.payload as any
      const body = await rp(request)({
        url: '/user/sendVerification',
        method: 'POST',
        form: {
          mobile
        }
      })
      return body
    }
  },
  {
    method: 'GET',
    path: '/login/alipay/url',
    options: {
      validate: {
        query: {
          redirect: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const query: any = request.query
      return {
        url: alipay.getAlipayAuthUrl(query.redirect)
      }
    }
  },
  {
    method: 'POST',
    path: '/login/alipay',
    options: {
      validate: {
        payload: {
          code: Joi.string().required(),
          channel: Joi.string().optional()
        }
      },
      notes: 'https://docs.open.alipay.com/263/105809'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      try {
        const res_token = await rp(request, {
          baseUrl: config.server3rd,
          prefix: ''
        })({
          url: '/getAliUserTokenByCode',
          qs: {
            code: (request.payload as any).code
          }
        })
        if (res_token.code !== 100) {
          return {
            code: 105,
            msg: '支付宝请求Token错误，请稍后重试!'
          }
        }
        const res_info = await rp(request, {
          baseUrl: config.server3rd,
          prefix: ''
        })({
          url: '/getAliUserInfoByToken',
          qs: {
            token: res_token.data.access_token
          }
        })
        if (res_info.code !== 100) {
          return {
            code: 105,
            msg: '支付宝请求用户信息错误，请稍后重试!'
          }
        }
        const res_user = await rp(request)({
          method: 'POST',
          url: '/user/userAliLogin',
          form: {
            aliData: JSON.stringify(res_info.data),
            yi23Channel: (request.payload as any).channel || ''
          }
        })
        if (res_user.code !== 100) {
          return {
            code: 105,
            msg: '数据错误，请稍后再试!'
          }
        }
        return res_user.data
      } catch (e) {
        console.error(e)
        return {
          code: 105,
          msg: '数据错误，请稍后再试!'
        }
      }
    }
  },
  {
    method: 'GET',
    path: '/wechat/code',
    options: {
      validate: {
        query: {
          url: Joi.string().required()
        }
      },
      notes:
        'https://mp.weixin.qq.com/wiki?action=doc&id=mp1421140842&t=0.4622491167403#4'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const url = (request.query as any).url
      let queryParams = {
        appid: config.wechat.app_id,
        redirect_uri: url,
        response_type: 'code',
        scope: 'snsapi_userinfo',
        state: 'STATE#wechat_redirect'
      }
      return {
        url:
          'https://open.weixin.qq.com/connect/oauth2/authorize?' +
          qs.stringify(queryParams)
      }
    }
  },
  {
    method: 'GET',
    path: '/wechat/openId',
    options: {
      validate: {
        query: {
          code: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data_alipay_user = await rp(request, {
        baseUrl: config.server3rd,
        prefix: ''
      })({
        url: '/wechatAuth',
        qs: {
          code: (request.query as any).code
        }
      })
      return data_alipay_user
    }
  }
]
