import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')
export default [
  {
    method: 'GET',
    path: '/manager/popup',
    options: {
      validate: {
        query: {
          id: Joi.number()
            .required()
            .description('页面 ID')
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request)({
        url: '/page/popupView',
        method: 'GET',
        qs: {
          vid: (request.query as any).id
        }
      })
      if (!data) {
        data = {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/manager/beginnerPopup',
    options: {
      auth: 'jwt',
      description: '获取新人启动弹窗列表'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request, {
        prefix: '/ms'
      })({
        url: '/content/v1/page/recoTopic',
        method: 'GET'
      })
      if (!data) {
        data = {}
      }
      return data
    }
  }
]
