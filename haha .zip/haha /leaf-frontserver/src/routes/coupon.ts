import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')
export default [
  {
    method: 'GET',
    path: '/coupon',
    options: {
      auth: 'jwt',
      description: '优惠券列表'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = await rp(request)({
        url: '/user/couponList'
      })
      return data
    }
  },
  {
    method: 'POST',
    path: '/coupon',
    options: {
      auth: 'jwt',
      validate: {
        payload: {
          code: Joi.string().required()
        }
      },
      description: '兑换优惠券'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const code = (request.payload as any).code
      const data = await rp(request)({
        method: 'POST',
        url: '/coupon/exchangeCouponCode',
        form: {
          code
        }
      })
      return data
    }
  }
]
