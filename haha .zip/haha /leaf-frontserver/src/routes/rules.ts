import * as Hapi from 'hapi'
import Joi from 'joi'
import path from 'path'
import server from '../server'
import _ from 'lodash'
const fs = require('fs-extra')
interface IRuleItem {
  title: string
  content: string
  hidden: IHidden
  slots?: ISlots
}
interface IHidden {
  [key: string]: any
  alipay?: boolean
  fish?: boolean
  yi23?: boolean
  web?: boolean
  wechat?: boolean
}
interface ISlots {
  [index: number]: IRuleType
}
interface IRuleType {
  [key: string]: any
  alipay?: string
  fish?: string
  yi23?: string
  web?: string
  wechat?: string
}
const fileCache = server.cache({
  cache: 'redisCache',
  expiresIn: 10 * 60 * 1000,
  segment: 'QnA_rules',
  generateFunc: async file => {
    const filePath: string = path.resolve(__dirname, `../data/rules/${file}.js`)
    return require(filePath)
  },
  generateTimeout: 2000
})
export default [
  {
    method: 'GET',
    path: '/rules/{rule}',
    options: {
      validate: {
        params: {
          rule: Joi.string()
            .required()
            .valid([
              'rent',
              'return',
              'validity',
              'buy',
              'product',
              'other',
              'clean'
            ])
        },
        query: {
          type: Joi.string()
            .optional()
            .valid(['alipay', 'fish', 'yi23', 'web', 'wechat'])
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      // 关闭缓存
      // const filePath: string = path.resolve(
      //   __dirname,
      //   `../data/rules/${request.params.rule}.js`
      // )
      // delete require.cache[require.resolve(filePath)]
      // const file = require(filePath)

      // 开启缓存
      const file: any = await fileCache.get(request.params.rule)
      const type: string = (request.query as any).type || 'web'
      const filter = file.sections.filter(
        (item: IRuleItem) => !item.hidden || !item.hidden[type]
      )
      file.sections = filter.map((item: IRuleItem) => {
        const compiled = _.template(item.content)({
          type
        })
        let replaced = compiled
        if (item.slots) {
          replaced = compiled.replace(
            /{{(\d+)}}/g,
            (match: string, p1: number) => {
              const slot = (item.slots as ISlots)[p1][type]
              return slot !== undefined
                ? slot
                : (item.slots as ISlots)[p1]['web']
            }
          )
        }
        item.content = replaced.replace(/\n\s+/g, '')
        return item
      })
      return file
    }
  }
]
