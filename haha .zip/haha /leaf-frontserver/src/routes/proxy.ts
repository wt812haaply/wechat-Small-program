import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')
const Boom = require('boom')
export default [
  {
    path: '/proxy/{path*}',
    method: ['GET', 'POST'],
    options: {
      validate: {
        query: {
          prefix: Joi.string().optional(),
          auth: Joi.string().optional()
        },
        options: {
          allowUnknown: true
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'try'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const query = request.query as any
      if (query.auth === 'jwt' && !request.auth.isAuthenticated) {
        return Boom.unauthorized()
      }
      const params = request.params as any
      const payloay = request.payload as any
      const prefix = query.prefix
      if (prefix) {
        delete query.prefix
      }
      let res = await rp(request, {
        prefix
      })({
        url: params.path,
        method: 'GET',
        qs: query,
        form: payloay
      })
      return res
    }
  }
]
