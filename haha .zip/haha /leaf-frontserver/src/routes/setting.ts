import * as Hapi from 'hapi'
import _ from 'lodash'
interface ICity {
  rgnId: number
  city: string
  cityCode: string
  latitude: number
  longitude: number
}
interface ICities {
  hot: ICity[]
  [propName: string]: ICity[]
}
export default [
  {
    method: 'GET',
    path: '/location',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const cities: ICities = require('../data/city.json')
      const region = request.state.regionId || 341
      const clone = Object.assign({}, cities)

      delete clone.Hot
      let current: ICity | undefined
      if (region) {
        Object.values(clone).forEach((item: ICity[]) => {
          current = item.find((item: ICity) => item.rgnId === region)
        })
      }
      return {
        current: current ? current.city : '北京',
        hot: cities.Hot,
        list: clone
      }
    }
  }
]
