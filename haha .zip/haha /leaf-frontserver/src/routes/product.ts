import * as Hapi from 'hapi'
import utils from '../utils/common'
import rp from '../utils/request'
import status from '../utils/status'
const Joi = require('joi')
// Interface
interface IFilter {
  page?: number
  count?: number
  showall?: number
  'type_id[]'?: [number]
  'color_id[]'?: [number]
  'scene[]'?: [number]
  'brand_id[]'?: [number]
  'size[]': [number]
  'tagId[]': [number]
  searchKey?: string
}
interface IProduct {
  presaleDisplay: number
  sale_item: string
  stocknum: number
  is_star: number
  is_top: number
  is_new: number
  soldout: number
  tagUrl: string
}

// Utils
function replaceSuffix(target: [string] | string) {
  if (!target) {
    return ''
  }
  if (Array.isArray(target)) {
    return (target as [string]).map(item => item.replace(/(!\d+)w$/g, '$1'))
  } else {
    return target.replace(/(!\d+)w$/g, '$1')
  }
}

function getStatusaAndPath(
  product: IProduct
): {
  status: number
  path: string
} {
  const paths = [
    'shangjia',
    '',
    'star',
    'hot',
    'gangangshangjia',
    '',
    'qiudongxianding'
  ]
  let status
  if (product.presaleDisplay === 1 && +product.sale_item > Date.now()) {
    // 即将返架
    status = 1
  } else if (product.stocknum <= 0) {
    status = 2
  } else if (product.is_star === 2) {
    // 秋冬限定
    status = 7
  } else if (product.is_star === 1) {
    // 明星同款
    status = 3
  } else if (product.is_top === 1) {
    // 推荐
    status = 4
  } else if (product.is_new === 1) {
    // 新品
    status = 5
  } else {
    status = 6
  }
  const filename = paths[status - 1]
  let path = ''
  if (filename) {
    path = `https://tu.95vintage.com/web_source/Home/Common/images/${filename}.svg`
  }
  return {
    status,
    path
  }
}
/**
 * 获取产品状态标签
 * @param product
 */
function getProductTag(
  product: IProduct
): {
  status: string
  desc: string
  color: string
  code: number
} {
  let status = 'text'
  let desc = ''
  let code = 0
  let color = ''
  if (product.stocknum === 0) {
    desc = '待返架'
    code = 1
    color = 'rgba(0,0,0,0.6)'
  } else if (product.tagUrl) {
    desc = product.tagUrl
    status = 'url'
    code = 2
  } else if (product.is_star === 2) {
    desc = '秋冬限定'
    code = 3
    color = '#9fc4d1'
  } else if (product.is_new == 1) {
    desc = '刚刚上架'
    code = 4
    color = '#98cacc'
  } else if (product.is_star === 1) {
    desc = '明星同款'
    code = 5
    color = '#d1b686'
  }
  return {
    status,
    desc,
    color,
    code
  }
}

/**
 * 获取产品列表状态标签
 * @param product
 */
function getProductMiniTag(
  product: IProduct
): {
  status: string
  desc: string
  color: string
  background: string
  code: number
} {
  let status = 'text'
  let desc = ''
  let code = 0
  let color = ''
  let background = ''
  if (product.stocknum === 0) {
    desc = '待返架'
    code = 1
    color = '#fff'
    background = 'rgba(0,0,0,0.6)'
  } else if (product.tagUrl) {
    desc = product.tagUrl
    status = 'url'
    code = 2
  } else if (product.is_star === 2) {
    // 秋冬限定
    desc = '//yimg.yi23.net/webimg/web/images/icons/label_autumn@3x.png'
    status = 'url'
    code = 3
  } else if (product.is_new == 1) {
    // 刚刚上新
    desc = '//yimg.yi23.net/webimg/web/images/icons/label_new@3x.png'
    status = 'url'
    code = 4
  } else if (product.is_star === 1) {
    // 明星同款
    desc = '//yimg.yi23.net/webimg/web/images/icons/label_same@3x.png'
    status = 'url'
    code = 5
  }
  return {
    status,
    desc,
    color,
    background,
    code
  }
}

export default [
  {
    method: 'GET',
    path: '/products/list',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const query: IFilter = request.query as any
      const getProducts = rp(request)({
        url: '/product/productList',
        qs: Object.assign(
          {
            page: 1,
            count: 20,
            showall: 1,
            stockFirst: 1,
            noAppt: 1
          },
          query
        ) as IFilter,
        useQuerystring: true
      })
      let getWish = Promise.resolve({
        data: []
      })
      if (request.auth.isAuthenticated) {
        getWish = rp(request)({
          url: '/user/wishlistPids'
        })
      }

      const [{ data: products }, { data: wish }] = await Promise.all([
        getProducts,
        getWish
      ])
      ;(products.productList || []).forEach((item: any) => {
        if (wish) {
          item.isFavor = (wish as any).includes(item.product_id)
        }
        const { path, status } = getStatusaAndPath(item)
        item.showStatus = status
        item.showTapPath = path
        item.thumb_pic = replaceSuffix(item.thumb_pic)
        item.picture = replaceSuffix(item.picture)
        item.tag = getProductMiniTag(item)
      })

      return {
        product: products.productList,
        productType: products.productType || [],
        productSize: products.productSize || [],
        productTag: products.productTag || [],
        ...products.pageInfo
      }
    }
  },
  {
    method: 'GET',
    path: '/products/{id}',
    options: {
      validate: {
        params: {
          id: Joi.string().required()
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: '产品详情',
      plugins: {
        schema: {
          title: '产品详情',
          properties: {
            product_info: {
              type: 'object',
              description: '产品信息',
              properties: {
                tag: {
                  type: 'object',
                  description: '产品标签',
                  properties: {
                    status: {
                      type: 'string',
                      description: '状态',
                      enum: ['text', 'url']
                    },
                    desc: {
                      type: 'string'
                    },
                    code: {
                      type: 'number'
                    },
                    color: {
                      type: 'string',
                      description: '背景色'
                    }
                  }
                }
              }
            }
          }
        } as any
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const pid = request.params.id
      const path: string = (request.query as any).path || ''
      const { data } = await rp(request)({
        method: 'GET',
        url: '/product/newproductDetail',
        qs: {
          pid,
          path
        }
      })
      if (data === '' || data === null) {
        return {}
      }
      let userStatus: number = 0
      if (request.auth.isAuthenticated) {
        const { data: wishList } = await rp(request)({
          method: 'GET',
          url: '/user/wishlistPids'
        })
        if (wishList) {
          const wish = wishList.join()
          data.product_info.isFavor = ~wish.indexOf(pid + '') ? 1 : 0
        }
        userStatus = status.getUserStatus(request.auth.credentials)
      }
      data.userStatus = userStatus
      if (data.product_info) {
        data.product_info.tag = getProductTag(data.product_info)
        data.product_info.picture = replaceSuffix(data.product_info.picture)
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/products/{id}/recommend',
    options: {
      validate: {
        params: {
          id: Joi.string().required()
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      notes: '列表最大限制为 20 条；后端“推荐”与“相似”字段相反'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const pid = (request.params as any).id
      const { data } = await rp(request)({
        method: 'GET',
        url: '/product/productDetailRecommend',
        qs: {
          pid
        }
      })
      if (!data) {
        return {}
      }
      let related = []
      let recommend = []
      let wish = ''
      if (request.auth.isAuthenticated) {
        const { data: wishList } = await rp(request)({
          method: 'GET',
          url: '/user/wishlistPids'
        })
        if (wishList) {
          wish = wishList.join()
        }
      }
      if (data && Array.isArray(data.recommendedProducts)) {
        if (data.recommendedProducts.length > 20) {
          data.recommendedProducts.length = 20
        }
        related = data.recommendedProducts.map((item: any) => {
          item.tag = getProductTag(item)
          item.isFavor = ~wish.indexOf(item.product_id + '') ? 1 : 0
          return item
        })
      }
      if (data && Array.isArray(data.relatedProducts)) {
        if (data.relatedProducts.length > 20) {
          data.relatedProducts.length = 20
        }
        recommend = data.relatedProducts.map((item: any) => {
          item.tag = getProductTag(item)
          item.isFavor = ~wish.indexOf(item.product_id + '') ? 1 : 0
          return item
        })
      }
      data.relatedProducts = related
      data.recommendedProducts = recommend
      return data
    }
  },
  {
    method: 'GET',
    path: '/products/{id}/feedback',
    options: {
      validate: {
        params: {
          id: Joi.string().required()
        },
        query: {
          page: Joi.number(),
          count: Joi.number()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const pid = (request.params as any).id
      const { page, count } = request.query as any
      let { data } = await rp(request)({
        method: 'GET',
        url: '/product/productFeedback',
        qs: {
          productId: pid,
          page,
          count
        }
      })
      if (!data) {
        data = {}
      }
      if (data.feedbackList)
        data.feedbackList.forEach((item: any) => {
          if (item.picture) {
            item.picture = item.picture.map((pic: string) =>
              pic.replace(/w$/g, '')
            )
          }
        })
      return data
    }
  },
  {
    method: 'GET',
    path: '/products/filters',
    options: {
      validate: {
        query: {
          category: Joi.number()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request)({
        method: 'GET',
        url: '/filter/productFilters',
        qs: {
          productCategory: (request.query as any).category || 0
        }
      })
      if (!data) {
        data = {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/products/pdtEC',
    options: {
      validate: {
        query: {
          pid: Joi.number()
            .required()
            .error(new Error('参数错误，请稍后重试！')),
          path: Joi.string().error(new Error('参数错误，请稍后重试！'))
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: '商品详情页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { pid, path } = request.query as any
      const res = await rp(request)({
        method: 'GET',
        url: '/product/yshopProductDetail',
        qs: {
          pid,
          path
        }
      })
      if (res.code !== 100) {
        console.error(res)
        return { code: 105, msg: '网络错误，请稍后重试！' }
      }

      if (res.data.product_info) {
        res.data.product_info.picture = res.data.product_info.picture.map(
          (pic: string) => {
            return pic.replace(/w$/g, '')
          }
        )
      }

      const delArray = [
        'delayDescText',
        'delayDescUrl',
        'orderPromotion',
        'preheatEnd',
        'preheatStart',
        'promotionPrice',
        'recommendSizeInfo',
        'share_info'
      ]
      const data = utils.deleteAttr(res.data, delArray)

      return data
    }
  },
  {
    method: 'GET',
    path: '/product/searchTags',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request)({
        url: '/product/searchTags',
        method: 'GET'
      })
      if (!data) {
        data = {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/products/search',
    options: {
      validate: {
        query: {
          promotionOrder: Joi.number()
            .optional()
            .valid(0, 1, 2, 3, 4)
            .description('价格排序')
            .notes([
              '综合',
              '价格由高到低',
              '价格由低到高',
              '折扣由高到低',
              '折扣由低到高'
            ]),
          rentTimeOrder: Joi.number()
            .optional()
            .valid(0, 1, 2)
            .description('租次数')
            .notes(['不适用', '租次倒序', '租次正序']),
          promotionFirst: Joi.number()
            .optional()
            .valid(0, 1)
            .description('限时特惠')
            .notes(['不使用', '活动置前'])
        },
        options: {
          allowUnknown: true
        }
      },
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const query = request.query as any
      let getSearch = rp(request)({
        url: '/product/productSearch',
        method: 'GET',
        qs: Object.assign(
          {
            page: 1,
            count: 20,
            showall: 1,
            stockFirst: 1
          },
          query
        ) as IFilter,
        useQuerystring: true
      })
      let getWish = rp(request)({
        url: '/user/wishlistPids'
      })

      const [{ data: products }, { data: wish = {} }] = await Promise.all([
        getSearch,
        getWish
      ])
      ;(products.productList || []).forEach((item: any) => {
        if (wish) {
          item.isFavor = (wish as any).includes(item.product_id)
        }
        const { path, status } = getStatusaAndPath(item)
        item.showStatus = status
        item.showTapPath = path
        item.thumb_pic = replaceSuffix(item.thumb_pic)
        item.picture = replaceSuffix(item.picture)
        item.tag = getProductMiniTag(item)
      })
      return products
    }
  },
  {
    method: 'GET',
    path: '/product/beginnerCollection',
    options: {
      auth: 'jwt',
      description: '新人风格冷启动商品列表'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { page, count, coldListRefresh } = request.query as any
      page = page ? page : 1
      count = count ? count : 3
      coldListRefresh = coldListRefresh ? coldListRefresh : 0
      let { data: productResult } = await rp(request)({
        url: '/product/xyColdProductList',
        method: 'GET',
        qs: {
          page,
          count,
          coldListRefresh
        }
      })
      if (!productResult || !productResult.productList) {
        return { code: 105, msg: '无可用商品列表', data: [] }
      }
      const products = productResult.productList
      return {
        productList: products.productList,
        productType: products.productType || [],
        productSize: products.productSize || [],
        productTag: products.productTag || [],
        ...products.pageInfo
      }
    }
  },
  {
    method: 'GET',
    path: '/product/{id}/{type}/sale',
    options: {
      validate: {
        params: {
          id: Joi.string()
            .required()
            .error(new Error('请选择要购买的商品')),
          type: Joi.string()
            .required()
            .error(new Error('商品数据出错，请确认后重试')),
          stockLocation: Joi.number().optional()
        },
        options: {
          allowUnknown: true
        }
      },
      auth: 'jwt',
      notes: '购买商品详情页信息'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { id, type } = request.params as any
      const { stockLocation } = (request.query as any) || 0
      let skuId: string = '0'
      let detailId: string = '0'
      let rentSubOrderId: string = '0'
      switch (type) {
        case 'salePromotion':
          skuId = id
          break
        case 'closet':
          detailId = id
          break
        case 'singleRent':
          rentSubOrderId = id
          break
        default:
          break
      }
      const { data: saleProductInfo } = await rp(request)({
        method: 'GET',
        url: '/order/saleProductInfo',
        qs: {
          detailId,
          skuId,
          rentSubOrderId,
          specifiedRegionId: stockLocation
        }
      })
      if (saleProductInfo) {
        delete saleProductInfo.policyUrl
        delete saleProductInfo.payWay
      }
      return saleProductInfo
    }
  }
]
