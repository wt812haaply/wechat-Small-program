import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')

export default [
  {
    method: 'GET',
    path: '/brand/{id}',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { count = 10, brandCanbuy = 0 } = request.query as any
      const { id } = request.params
      const { data } = await rp(request)({
        url: '/product/brandPage',
        qs: {
          ['brand_id[]']: id,
          count,
          brandCanbuy
        },
        useQuerystring: true
      })
      return data
    }
  }
]
