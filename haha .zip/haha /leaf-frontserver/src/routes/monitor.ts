import { exec, spawn } from 'child_process'
import * as Hapi from 'hapi'
import path from 'path'
import util from 'util'
const Joi = require('joi')
const execPromise = util.promisify(exec)
async function grepToApi(command: string) {
  const { stdout, stderr } = await execPromise(command)
  if (stderr) {
    console.log(stderr)
  }
  return stdout
}
export default [
  {
    method: 'GET',
    path: '/monitor',
    handler: async (request: Hapi.Request, h: any) => {
      return h.file('./monitor.html')
    }
  },
  {
    method: 'GET',
    path: '/monitor/api',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const file = path.resolve(__dirname, '../../logs/out.log')
      const data = await grepToApi(`grep '"statusCode":200' ${file}`)
      try {
        return data
          .replace(/\n/g, '---')
          .split('---')
          .filter(item => item)
          .map(item => JSON.parse(item))
      } catch (e) {
        return []
      }
    }
  },
  {
    method: 'GET',
    path: '/monitor/test',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      if (request.headers['user-agent'].match(/MicroMessenger/gi)) {
        const response = h.response('')
        response.type('text/plain')
        response.code(206)
        response.header('Accept-Ranges', 'bytes')
        response.header('Content-Range', 'bytes 0-1/1')
        response.header('Content-Disposition', 'attachment;filename=1579.apk')
        response.header('Content-Length', '0')
        return response
      } else {
        let content = `<!DOCTYPE html><html><head> <meta charset="utf-8"> <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=0"> <meta name="apple-mobile-web-app-capable" content="yes"> <meta name="apple-mobile-web-app-status-bar-style" content="black"> <meta name="format-detection" content="telephone=no"> <title></title></head><body> <div style="text-align: center;font-size: 18px;margin: 100px 0 30px 0;"></div> <script>setTimeout(function(){window.location.replace('http://t.cn/EzSfapi');},300); </script></body></html>`
        const response = h.response(content)
        return response
      }
    }
  }
]
