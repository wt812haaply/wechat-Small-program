import * as Hapi from 'hapi'
import rp from '../utils/request'
import * as sign from '../utils/sign'
import _ from 'lodash'

export default [
  {
    method: 'GET',
    path: '/member',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const getUser = rp(request)({
        method: 'GET',
        url: '/user/userInfo'
      })
      const getLevel = rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/level'
      })
      const [{ data: levelInfo }, { data: userInfo }] = await Promise.all([
        getLevel,
        getUser
      ])
      return {
        level: levelInfo,
        user: userInfo
      }
    }
  }
]
