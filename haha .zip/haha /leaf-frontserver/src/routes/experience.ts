import * as Hapi from 'hapi'
import server from '../server'
import rp from '../utils/request'
import { uploader, uploadOSS } from '../utils/index'
import validate from '../utils/validate'
import OSS from '../utils/oss'
import * as sign from '../utils/sign'
const Joi = require('joi')
const Boom = require('boom')
const bucket = process.env.tag !== 'production' ? 'yi23imgtest' : 'yi23img'
const client = OSS({
  bucket
})
export default [
  {
    method: 'POST',
    path: '/experience/requirement',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = await rp(request)({
        method: 'POST',
        url: '/user/getYGirlFillPermission'
      })
      return data
    }
  },
  {
    method: 'POST',
    path: '/experience/sign',
    options: {
      payload: {
        output: 'stream',
        allow: 'multipart/form-data',
        maxBytes: 1048576 * 7
      } as any,
      auth: 'jwt',
      validate: {
        payload: {
          name: Joi.string().required(),
          mobile: validate.mobile,
          occupation: Joi.string().required(),
          age: Joi.number()
            .max(40)
            .min(18)
            .required(),
          city: Joi.string().required(),
          pictures: Joi.any().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = request.payload as any
      const files = data['pictures']
      const { name, mobile, age, occupation, city } = data
      let errorInfo: string = ''
      let error: boolean = false
      const hasRequiredPictures = Array.isArray(files) && files.length === 3
      if (!hasRequiredPictures) {
        errorInfo = '上传搭配美图不能少于3张'
        error = true
      } else {
        let moreThanMaxBytes = files.some((file: any) => {
          return file._data.toString().length > 1024 * 1024 * 2
        })
        if (moreThanMaxBytes) {
          errorInfo = '单张图片不能大于 2 MB'
          error = true
        }
      }
      if (!error) {
        const requirement = await rp(request)({
          method: 'POST',
          url: '/user/getYGirlFillPermission'
        })

        if (requirement.code === 105) {
          errorInfo = requirement.msg
          error = true
        }
      }
      let body
      if (!error) {
        let promiseUpload = []
        const {
          data: { clientKey: id }
        } = request.auth.credentials as any
        const uid = sign.decode(id)
        try {
          promiseUpload = files.map(async (file: any) => {
            return uploadOSS(file, client, {
              target: `experiencer/${uid}/`
            })
          })
        } catch {
          errorInfo = '上传图片失败'
          error = true
        }
        if (!error) {
          let uploaded = await Promise.all(promiseUpload)
          body = await rp(request)({
            method: 'POST',
            url: 'user/experiencerDataCollector',
            form: {
              uid,
              weiboName: name,
              mobile: mobile,
              job: occupation,
              age,
              city,
              file: uploaded.map((fileObj: any) => fileObj.url).join()
            }
          })
        }
      }
      if (error) {
        body = {
          code: 105,
          msg: errorInfo,
          data: {}
        }
      }
      return body
    }
  }
]
