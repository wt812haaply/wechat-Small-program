import * as Hapi from 'hapi'
import rp from '../utils/request'
import * as sign from '../utils/sign'
import status from '../utils/status'
import common from '../utils/common'
import _ from 'lodash'
const Joi = require('joi')

function checkUAClient(ua: string): string {
  ua = ua.toLowerCase()
  const iosPatt = /yi23-ios-client/
  const AnrPatt = /yi23-android-client/
  if (iosPatt.test(ua)) {
    return 'ios'
  } else if (AnrPatt.test(ua)) {
    return 'android'
  }
  return ''
}

export default [
  {
    method: 'GET',
    path: '/user/center',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = await rp(request)({
        method: 'GET',
        url: '/user/userInfo'
      })
      const { data: user } = data
      if (data && user) {
        user.mobile = sign.encode(user.mobile)
        if (/^\d{11}$/g.test(user.nickname)) {
          user.nickname = user.nickname.replace(/(\d{3})\d{4}/g, '$1****')
        }
        delete user.jwtToken
        delete user.uid
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/user/profile',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const getUserInfo = rp(request)({
        url: '/user/userInfo',
        method: 'GET'
      })
      const getJobList = rp(request)({
        url: '/user/getJobList',
        method: 'GET'
      })
      const [{ data: userInfo }, { data: jobList }] = await Promise.all([
        getUserInfo,
        getJobList
      ])
      const tallList = []
      for (let i = 120; i <= 200; i += 5) {
        tallList.push(i)
      }
      const heavyList = []
      for (let i = 40; i <= 100; i += 2) {
        heavyList.push(i)
      }
      return {
        sizeList: ['XS', 'S', 'M', 'L', 'XL'],
        heavyList,
        tallList,
        jobList,
        uInfo: userInfo
      }
    }
  },
  {
    method: 'GET',
    path: '/user/member',
    options: {
      validate: {
        query: {
          version: Joi.any().error(new Error('参数version错误'))
        }
      },
      auth: 'jwt',
      description: '会员权益详情页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const getLevel = rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/level'
      })
      const { version } = request.query as any
      const getPointTask = rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/pointTaskBlock',
        form: {
          miniEnable: 0,
          appVersion: version
        }
      })
      const getModify = rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/levelModify'
      })

      const getUser = rp(request)({
        url: '/user/userInfo'
      })

      const [
        { data: levelInfo },
        { data: taskInfo },
        { data: modifyInfo },
        { data: userInfo }
      ] = await Promise.all([getLevel, getPointTask, getModify, getUser])

      if (levelInfo) {
        const { data: benefitInfo } = await rp(request, {
          prefix: '/ms'
        })({
          method: 'POST',
          url: '/user/v1/memberBenefit',
          form: {
            userLevel: levelInfo.currentLevel
          }
        })
        if (benefitInfo) {
          levelInfo.userBenefits = benefitInfo.memberBenefitVOS
          levelInfo.userBenefitList = benefitInfo.userBenefitDetailVOMap || []
        }
      }

      if (!levelInfo || !taskInfo) {
        return {}
      }
      const user = { memberStatus: 0, remainDays: 0 }
      if (userInfo) {
        user.memberStatus = status.parseMemberToCode(
          userInfo.member_status || 'B'
        )
        user.remainDays = userInfo.remaining_days
        levelInfo.user = user
      } else {
        levelInfo.user = user
      }

      levelInfo.hotExchange = {
        title: taskInfo.userPointTaskTitle || '',
        content: taskInfo.userPointTaskContent,
        task: taskInfo.userPointTaskBlockVOS[0].userPointTaskVOS
      }

      levelInfo.levelModify = modifyInfo
      return levelInfo
    }
  },
  {
    method: 'GET',
    path: '/user/point/{num}/{size}',
    options: {
      validate: {
        params: {
          num: Joi.string()
            .required()
            .error(new Error('num 不能为空')),
          size: Joi.number()
            .required()
            .error(new Error('size 不能为空'))
        }
      },
      auth: 'jwt',
      description: '用户积分详情查看'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const pageNum: number = (request.params as any).num
      const pageSize: number = (request.params as any).size
      const getMember = rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/level'
      })
      const getPoint = rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/pointDetail',
        form: {
          pageNum,
          pageSize
        }
      })
      const [{ data: memberInfo }, { data: pointInfo }] = await Promise.all([
        getMember,
        getPoint
      ])

      let totalPoint = 0
      if (memberInfo) {
        totalPoint = memberInfo.totalPoint
      }
      if (!pointInfo) {
        return {}
      }
      pointInfo.totalPoint = totalPoint
      return pointInfo
    }
  },
  {
    method: 'GET',
    path: '/user/pointTask',
    options: {
      validate: {
        query: {
          version: Joi.any().error(new Error('参数version错误'))
        }
      },
      auth: 'jwt',
      description: '用户获取积分任务页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { version } = request.query as any
      const { 'user-agent': ua } = request.headers as any
      let userAgent: string = ''
      if (ua) {
        userAgent = checkUAClient(ua)
      }
      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/pointTaskBlock',
        form: {
          miniEnable: 1,
          appVersion: version,
          userAgent
        }
      })
      if (!data) {
        return {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/user/bindInfo',
    options: {
      auth: 'jwt',
      description: '用户绑定信息'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/userBindInfo'
      })
      if (!data) {
        return {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/user/pointMall',
    options: {
      auth: 'jwt',
      description: '积分商城首页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: 'point/v1/mall/thumbnail'
      })
      if (!data) {
        return {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/user/benefit',
    options: {
      auth: 'jwt',
      description: '用户会员详情'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/memberBenefit'
      })
      if (!data) {
        return {}
      }
      return data.memberBenefitVOS
    }
  },
  {
    method: 'POST',
    path: '/user/operate',
    options: {
      validate: {
        payload: {
          pointType: Joi.string()
            .required()
            .error(new Error('参数pointType不正确')),
          version: Joi.any().error(new Error('参数version不正确'))
        }
      },
      auth: 'jwt',
      description: '操作积分接口'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const {
        data: { clientKey: id }
      } = request.auth.credentials as any
      const uid = sign.decode(id)

      const form = (request.payload as any) || {}
      const requestId = uid + '_' + form.pointType
      const originId = uid
      const pointType = form.pointType
      const appVersion = form.version
      let result
      if (pointType === 'APP_STORE_COMMENT') {
        result = await rp(request, {
          prefix: '/ms'
        })({
          method: 'POST',
          url: '/user/v1/appStoreComment',
          form: {
            uid,
            appVersion
          }
        })
      } else {
        result = await rp(request, {
          prefix: '/ms'
        })({
          method: 'GET',
          url: '/point/v1/operate',
          qs: {
            uid,
            requestId,
            originId,
            pointType
          }
        })
      }

      if (result.code !== 100) {
        return result
      }
      return result
    }
  },
  {
    method: 'GET',
    path: '/user/grade',
    options: {
      auth: 'jwt',
      description: '用户等级展示页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let levelInfo = {} as any
      const res = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/level'
      })
      if (res.code !== 100) {
        return res
      } else if (res.data) {
        levelInfo = res.data
        const { data: benefitInfo } = await rp(request, {
          prefix: '/ms'
        })({
          method: 'POST',
          url: '/user/v1/memberBenefit',
          form: {
            userLevel: res.data.currentLevel
          }
        })
        if (benefitInfo) {
          levelInfo.userBenefits = benefitInfo.memberBenefitVOS
        }
      } else {
        return { code: 105, msg: '网络错误，请稍后重试！' }
      }
      return levelInfo
    }
  },
  {
    method: 'GET',
    path: '/user/grading',
    options: {
      validate: {
        query: {
          quarterInfo: Joi.string()
            .required()
            .error(new Error('参数quarterInfo不正确')),
          pageNum: Joi.number().error(new Error('参数pageNum不正确')),
          pageSize: Joi.number().error(new Error('参数pageSize不正确'))
        }
      },
      auth: 'jwt',
      description: '定级积分明细页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { quarterInfo, pageNum, pageSize } = request.query as any
      const res = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: '/user/v1/levelPointDetail',
        qs: {
          quarterInfo,
          pageNum,
          pageSize
        }
      })
      if (res !== 100) {
        return res
      } else if (res.data) {
        return res.data
      } else {
        return {
          code: 105,
          msg: '网络错误，请稍后重试！'
        }
      }
    }
  },
  {
    method: 'GET',
    path: '/user/pointRead/{quarter}',
    options: {
      auth: 'jwt',
      description: '用户定级积分积分解读'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { quarter: quarterInfo = 0 } = request.params as any
      const data = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: '/user/v1/userLevelPointIntroduce',
        qs: {
          quarterInfo
        }
      })
      if (!data) {
        return {}
      }
      return data
    }
  },
  {
    method: ['POST', 'DELETE'],
    path: '/user/fav/{id}',
    options: {
      auth: 'jwt',
      description: '用户心愿单'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      //按照数据要求，所有心愿单的删减操作收集path 参数
      const { path } = (request.payload as any) || ''
      const data = await rp(request)({
        method: 'POST',
        url:
          '/user/' +
          ((request.method as string) === 'post'
            ? 'addWishListItem'
            : 'delWishListItem'),
        qs: {
          pid: request.params.id,
          path
        }
      })
      if (!data) {
        return {}
      }
      return data
    }
  },
  {
    method: 'POST',
    path: '/user/report',
    options: {
      validate: {
        payload: {
          data: Joi.string()
            .required()
            .error(new Error('data参数不正确'))
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: '用户行为上报'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = request.payload as any

      data = JSON.parse(data)
      const codeArray = new Array()
      data.forEach((item: any) => {
        const modifyItem = item.exposedPidInfo
        const paramUrl = item.urlParam
        const reportData = common.recoverDataSet(modifyItem, request, paramUrl)
        const res = rp(request)({
          method: 'POST',
          url: '/ms/analysis/v1/report',
          form: reportData
        })
        codeArray.push(res)
      })
      try {
        const result = await Promise.all(codeArray)
      } catch (e) {
        return { code: 105, msg: '记录错误', data: '' }
      }
      return { code: 200, msg: '记录成功', data: '' }
    }
  },
  {
    method: 'GET',
    path: '/user/invite',
    options: {
      auth: 'jwt',
      notes: '邀请好友记录'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const record = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: '/user/v1/getInvitationRecord'
      })
      return record
    }
  },
  {
    method: 'GET',
    path: '/user/id',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'try'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let uid: string = '0'
      if (request.auth.isAuthenticated) {
        const {
          data: { clientKey: id }
        } = request.auth.credentials as any
        uid = sign.decode(id)
      }
      return {
        uid
      }
    }
  }
]
