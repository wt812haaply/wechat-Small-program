import * as Hapi from 'hapi'
import rp from '../utils/request'
import validate from '@utils/validate'

const Joi = require('joi')

export default [
  {
    method: 'GET',
    path: '/address/list',
    options: {
      auth: 'jwt',
      notes: '获取用户地址列表接口'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { data } = await rp(request)({
        url: '/addr/addrList'
      })
      return {
        addressList: data ? data : []
      }
    }
  },
  {
    method: 'POST',
    path: '/address',
    options: {
      auth: 'jwt',
      notes: '新增地址',
      validate: {
        payload: {
          mobile: validate.mobile,
          address: Joi.string().required(),
          consignee: Joi.string().required(),
          region: Joi.number().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { address, mobile, consignee, region } = request.payload as any
      const data = await rp(request)({
        method: 'POST',
        url: '/addr/addAddr',
        form: {
          address,
          mobile,
          consignee,
          rgn: region
        }
      })
      return data
    }
  },
  {
    method: 'PUT',
    path: '/address/{id}',
    options: {
      auth: 'jwt',
      notes: '修改地址',
      validate: {
        payload: {
          mobile: validate.mobile,
          address: Joi.string().required(),
          consignee: Joi.string().required(),
          region: Joi.number().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { address, mobile, consignee, region } = request.payload as any
      const data = await rp(request)({
        method: 'POST',
        url: '/addr/editAddr',
        form: {
          address,
          mobile,
          consignee,
          rgn: region,
          addrId: request.params.id
        }
      })
      return data
    }
  },
  {
    method: 'DELETE',
    path: '/address/{id}',
    options: {
      auth: 'jwt',
      notes: '删除地址'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = await rp(request)({
        method: 'POST',
        url: '/addr/deleteAddr',
        form: {
          addrId: request.params.id
        }
      })
      return data
    }
  }
]
