import * as Hapi from 'hapi'
import rp from '../utils/request'
const Joi = require('joi')
export default [
  {
    method: 'GET',
    path: '/gallery',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: '晒单列表页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { page = 1, count = 20 } = request.query as any

      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: '/content/v1/user/ab/sharePhotoList',
        qs: Object.assign(request.query, {
          page,
          count
        })
      })
      if (!data) {
        return {}
      }
      return data
    }
  },
  {
    method: 'GET',
    path: '/gallery/{feedBackId}',
    options: {
      validate: {
        params: {
          feedBackId: Joi.string()
            .required()
            .error(new Error('商品ID错误'))
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: '晒单详情页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { feedBackId } = request.params as any

      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: '/content/v1/user/sharePhotoDetail',
        qs: Object.assign(request.params, {
          feedBackId
        })
      })
      if (!data) {
        return {}
      }
      return data
    }
  }
]
