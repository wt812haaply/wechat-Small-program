import * as Hapi from 'hapi'
import * as client from '../../utils/search'

export default [
  {
    method: 'POST',
    path: '/search/images',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const imageCode = (request.payload as any).imageCode
      const { result } = await client.getSimilarSearch(imageCode)
      if (!result) {
        return { code: 105, msg: '没有要查询的商品', data: [] }
      }
      const selectList = []
      for (const iterator of result) {
        if (parseFloat(iterator.score) > 0.3) {
          selectList.push(iterator)
        }
      }
      return selectList
    }
  }
]
