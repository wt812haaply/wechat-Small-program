import * as Hapi from 'hapi'
import rp from '../../utils/request'
const Joi = require('joi')
const puppeteer = require('puppeteer')
const orderURL = 'https://api.td.cainiao.com/service/createOrder.json'
const orderFail = {
  success: false,
  statusMessage: '下单失败，请重试',
  data: null
}
export default [
  {
    method: 'POST',
    path: '/events/brand-day',
    options: {
      validate: {
        payload: {
          mobile: Joi.string()
            .length(11)
            .required()
            .error(new Error('请输入正确的手机号')),
          address: Joi.string().required(),
          rgn: Joi.number().required(),
          consignee: Joi.string().required(),
          donationNumber: Joi.number().required(),
          appointmentStr: Joi.string()
            .allow('')
            .optional(),
          appointmentEndStr: Joi.string()
            .allow('')
            .optional(),
          timelinessType: Joi.string()
            .allow('')
            .optional()
        },
        options: {
          allowUnknown: true
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const {
        mobile,
        rgn,
        address,
        donationNumber,
        consignee,
        appointmentEndStr,
        appointmentStr,
        timelinessType
      } = request.payload as any
      const { data: info } = await rp(request)({
        method: 'POST',
        url: '/user/login',
        form: {
          mobile,
          special: '4bf106abe283bee611f1df95c448cf20',
          code: '0000'
        }
      })
      const { uid } = info
      const { data: addressInfo } = await rp(request, {
        uid
      })({
        method: 'POST',
        url: '/addr/addAddr',
        form: {
          mobile,
          address,
          rgn,
          consignee
        }
      })
      const { addrId } = addressInfo
      const data = await rp(request, {
        prefix: '/ms'
      })({
        url: '/courier/v1/cainiaoSend',
        qs: {
          donationNumber,
          uid,
          addrId
        }
      })
      if (data.code === 100) {
        const link = data.data.createUrl
        const browser = await puppeteer.launch({
          // headless: false,
          // devtools: true
          args: ['--no-sandbox', '--disable-setuid-sandbox']
        })
        try {
          const page = await browser.newPage()
          await page.goto(link, { waitUntil: 'networkidle0' })
          await page.setRequestInterception(true)
          await page.on('request', (request: any) => {
            let payload = request.postData()
            if (~request.url().indexOf(orderURL)) {
              payload = JSON.parse(payload)
              if (!timelinessType) {
                payload = Object.assign(payload, {
                  appointmentEndStr,
                  appointmentStr
                })
                delete payload.timelinessType
              } else {
                payload = Object.assign(payload, {
                  timelinessType
                })
                delete payload.appointmentEndStr
                delete payload.appointmentStr
              }
            }
            request.continue({
              postData: JSON.stringify(payload)
            })
          })
          await page.evaluate(() => {
            const btn = document.querySelector(
              '.HomeView__footer_right--2Xkh8 .am-button-primary'
            )
            if (btn) {
              ;(btn as any).click()
            }
          })
          const orderResponse = await page.waitForResponse(
            (response: any) =>
              ~response.url().indexOf(orderURL) && response.status() === 200
          )
          const order = await orderResponse.json()
          if (!order.success) {
            delete order.data
            return order
          }
          const detailResponse = await page.waitForResponse(
            (response: any) =>
              ~response
                .url()
                .indexOf(
                  'https://api.td.cainiao.com/service/queryOrderDetail.json'
                ) && response.status() === 200
          )
          let detail = await detailResponse.json()

          await browser.close()
          let tipMap: any = {}
          if (detail.data && detail.data.tipMap) {
            tipMap = detail.data.tipMap
          }
          if (detail.success) {
            await rp(request, {
              prefix: '/ms'
            })({
              method: 'POST',
              url: 'courier/v1/updateDonation',
              form: {
                donationOrderId: data.data.orderNo
              }
            })
          } else {
            detail = {}
          }

          return {
            success: detail.success,
            statusMessage: tipMap.statusDesc,
            noteDesc: tipMap.noteDesc
          }
        } catch (e) {
          await browser.close()
          return orderFail
        }
      } else {
        return orderFail
      }
    }
  }
]
