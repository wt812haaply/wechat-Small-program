import dayjs from 'dayjs'
import * as Hapi from 'hapi'
import rp from '../../utils/request'

const Joi = require('joi')

const REDIS_KEY = 'event_enter'

export default [
  {
    //
    method: 'GET',
    path: '/events/1112/info',
    options: {
      description: '拉新PK页'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const mobile =
        '13632803638,18612992045,13240390492,18810570810,13810385002,17633057165,18252095719,17600563240,13699229466,17602200732,15510037357,18210019982,15010049857,17744418313,13164212022,17600167766,15911079929,13624711208,15600681507,17705604907,15010949313,18612598875,18612832824,13717798010,17600161798,15652710763,13260187225,18310295248,13253571657,18330160573,15824167007,18511695171,13522775773,13857164052,13216117823,18911703974,18610850835,13932991516,18911703974,18610850835'
      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/user/v1/pullNew',
        form: {
          mobile
        }
      })
      if (!data) {
        return {}
      }

      return { timeStamp: Date.now(), info: data }
    }
  },
  {
    method: 'POST',
    path: '/events/1112/enter',
    options: {
      validate: {
        payload: {
          mobile: Joi.string()
            .length(11)
            .required()
            .error(new Error('手机号不正确')),
          code: Joi.string()
            .regex(/^(\d{4}|\d{6})$/)
            .required()
            .error(new Error('验证码不正确'))
        }
      },
      description: '美上天活动报名'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { mobile, code } = request.payload as any
      const source = '46ce2aab3eb29f3b4bf6eca4befca976'
      const res = await rp(request)({
        method: 'POST',
        url: '/user/login',
        form: {
          mobile,
          code,
          source
        }
      })
      if (res.code !== 100) {
        return res
      }

      const uid = res.data.uid
      const { redis } = request.server.app as any
      const date: number = parseInt(dayjs().format('YYYYMMDD'), 10)
      await redis.saddAsync(`${REDIS_KEY}-${date}`, uid)
      await redis.expireAsync(`${REDIS_KEY}-${date}`, 60 * 60 * 24 * 30)
      return {
        status: true
      }
    }
  },
  {
    method: 'GET',
    path: '/events/1112/report',
    options: {
      validate: {
        query: {
          date: Joi.string()
            .length(8)
            .error(new Error('date不正确'))
        }
      },
      auth: 'jwt',
      description: '美上天报名后查询'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { date } = request.query as any
      if (!date) {
        date = parseInt(dayjs().format('YYYYMMDD'), 10)
      }
      const { redis } = request.server.app as any
      const res = await redis.smembersAsync(`${REDIS_KEY}-${date}`)
      if (!res) {
        return ''
      }
      return res
    }
  }
]
