import * as Hapi from 'hapi'
import rp from '../../utils/request'
import status from '../../utils/status'

const Joi = require('joi')

export default [
  {
    method: 'GET',
    path: '/events/wheel/{drawId}/info',
    options: {
      validate: {
        params: {
          drawId: Joi.string()
            .required()
            .error(new Error('请选择要参加的活动'))
        }
      },
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      description: '转盘抽奖活动抽奖次数'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const drawId = (request.params as any).drawId
      const getDrawInfo = rp(request)({
        method: 'GET',
        url: '/promotion/drawTimesInfo',
        qs: {
          drawId
        }
      })
      const getUserInfo = rp(request)({ url: '/user/userInfo' })
      const [drawInfo, userInfo] = await Promise.all([getDrawInfo, getUserInfo])
      let userStatus = 0
      if (userInfo.code == 100) {
        const memberStatus = userInfo.data.member_status
        userStatus = status.parseMemberToCode(memberStatus)
      }
      if (drawInfo.code == 100) {
        //删除无需显示给前台的 key
        delete drawInfo.data.uid
        delete drawInfo.data.drawId
        delete drawInfo.data.id
        drawInfo.data.userStatus = userStatus
      }
      return drawInfo
    }
  },
  {
    method: 'POST',
    path: '/events/wheel/draw',
    options: {
      validate: {
        payload: {
          drawId: Joi.string()
            .required()
            .error(new Error('请选择要参加的活动'))
        }
      },
      auth: 'jwt',
      description: '转盘抽奖活动抽奖抽奖'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { drawId } = request.payload as any
      const result = await rp(request)({
        method: 'POST',
        url: '/promotion/drawBonusPromotion',
        form: {
          drawId
        }
      })
      if (result && result.code != 100) {
        return { code: result.code, msg: result.msg, data: '' }
      }
      return result.data
    }
  },
  {
    method: 'GET',
    path: '/events/wheel/{drawId}/result',
    options: {
      validate: {
        params: {
          drawId: Joi.string()
            .required()
            .error(new Error('请选择要参加的活动'))
        }
      },
      auth: 'jwt',
      description: '转盘抽奖活动抽奖次数'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const drawId = (request.params as any).drawId
      let { data } = await rp(request, {
        prefix: '/ms'
      })({
        url: '/event/v1/drawResultList',
        method: 'GET',
        qs: {
          drawId
        }
      })
      return data
    }
  }
]
