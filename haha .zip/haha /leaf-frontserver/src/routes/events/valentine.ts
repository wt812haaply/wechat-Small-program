import * as Hapi from 'hapi'
import rp from '../../utils/request'
import status from '../../utils/status'
import * as sign from '../../utils/sign'
const Joi = require('joi')
const Boom = require('boom')
import valentineTask from '../../task/valentine'

export interface ICardDetail {
  cardDepositAmount: number
  cardName: string
  cardOriginPrice: number
  cardPreDayPriceShow: string
  cardPrice: number
  cardTemplateId: number
  purchaseNeedDeposit: number
  showCoupons: number
  showDeposit: number
  totalPrice: number
  userDepositName: string
  promotionList: IPromotionList[]
}

export interface IPromotionList {
  reductionAmount: number
  reductionAmountShow: string
  reductionName: string
}

const START = new Date(2019, 0, 14)
const END = new Date(2019, 1, 15, 23, 59)

function isVerify() {
  let validity = false
  let text = '活动正在进行中'
  let now = Date.now()
  const isBeforeStart = now < START.valueOf()
  const isAfterEnd = now > END.valueOf()
  if (isBeforeStart) {
    text = '不要心急，活动还没开始呢！'
  } else if (isAfterEnd) {
    text = '来晚了呢，活动已经结束了！'
  } else {
    validity = true
  }
  return {
    eventStatus: validity,
    text
  }
}

function getUid(request: Hapi.Request) {
  const credentials: any = request.auth.credentials
  let {
    data: { clientKey: uid }
  } = credentials
  return uid
}

function giveMyCardType(cardType: string): number {
  let cardTemplateId: number = 0

  //2019 01 31
  //根据后端需求，74 季卡 75 月卡，测试卡 ID 修改为正式卡 ID
  // const isProductionEnv = process.env.tag === 'production' ? true : false
  switch (cardType) {
    case 'FOREVER':
      cardTemplateId = 74
      break
    case 'LOVE':
      cardTemplateId = 75
      break
    default:
      break
  }
  return cardTemplateId
}

export default [
  {
    method: 'GET',
    path: '/events/valentine/info',
    options: {
      auth: 'jwt',
      description: '2019年情人节活动，转发前获取转发信息'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { eventStatus, text } = isVerify()
      if (!eventStatus) {
        return {
          code: 105,
          msg: text,
          data: ''
        }
      }
      const shareText = getUid(request)
      const { data } = await rp(request)({
        url: '/user/userInfo',
        method: 'GET'
      })
      const userStatus: number =
        data && data.member_status
          ? status.parseMemberToCode(data.member_status)
          : 0
      return {
        shareText,
        userStatus,
        date: Date.now()
      }
    }
  },
  {
    method: 'GET',
    path: '/events/valentine/payInfo',
    options: {
      validate: {
        query: {
          cardType: Joi.string()
            .required()
            .error(new Error('请选择要支付的类型')),
          shareText: Joi.string()
            .required()
            .error(new Error('请从官方渠道进行支付'))
        }
      },
      description: '2019年情人节活动，落地页获取支付信息'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { cardType, shareText } = request.query as any
      const uid: string = sign.decode(shareText)
      const cardTemplateId: number = giveMyCardType(cardType)
      //如果没有活动的卡 id，或者 uid，则支付结束
      if (cardTemplateId == 0 || !uid || uid == '0') {
        return {
          code: 105,
          msg: '请在官方渠道进行支付',
          data: ''
        }
      }
      //假装这里有个接口,并且已经返回了数据,需要根据接口返回值，再判断是否需要自己筛选数据
      const { data } = await rp(request, {
        prefix: '/ms',
        uid
      })({
        method: 'GET',
        url: '/card/v2/list',
        qs: {
          origin: '214valentine',
          couponsId: '0'
        }
      })
      let cardInfoDetail: ICardDetail | undefined
      if (data && data.cardDetailList) {
        cardInfoDetail = (data.cardDetailList as ICardDetail[]).find(
          (item: ICardDetail) => item.cardTemplateId === cardTemplateId
        )
      }
      return cardInfoDetail
    }
  },
  {
    method: 'POST',
    path: '/events/{payType}/valentine',
    options: {
      validate: {
        params: {
          payType: Joi.string()
            .required()
            .error(new Error('请选择支付方式'))
        },
        payload: {
          cardType: Joi.string()
            .required()
            .error(new Error('请选择要支付的类型')),
          shareText: Joi.string()
            .required()
            .error(new Error('请从官方渠道进行支付'))
        },
        options: {
          allowUnknown: true
        }
      },
      description: '情人节活动支付页。发起支付'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { eventStatus, text } = isVerify()
      if (!eventStatus) {
        return {
          code: 105,
          msg: text,
          data: ''
        }
      }
      const payType = (request.params as any).payType
      const { cardType, openId, returnUrl, shareText } = request.payload as any
      let tempRetrunUrl = returnUrl ? decodeURIComponent(returnUrl) : ''
      if (payType === 'WECHAT_WEB' && !openId) {
        return Boom.forbidden('请在微信中打开')
      }
      const uid: string = sign.decode(shareText)
      const cardTemplateId: number = giveMyCardType(cardType)
      //如果没有活动的卡 id，或者 uid，则支付结束
      if (cardTemplateId == 0 || !uid || uid == '0') {
        return {
          code: 105,
          msg: '请在官方渠道进行支付',
          data: ''
        }
      }
      const result = await rp(request, {
        prefix: '/ms',
        uid
      })({
        method: 'POST',
        url: '/card/v1/purchase',
        form: {
          returnUrl: tempRetrunUrl,
          cardTemplateId,
          payType,
          couponId: 0,
          origin: '214valentine',
          openId
        }
      })
      return result
    }
  },
  {
    method: 'POST',
    path: '/events/valentine/{tradeNo}',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const tradeNo = request.params.tradeNo
      const payload: Object = request.payload
      let success = false
      let _data
      let url = ''
      try {
        // _data = {
        //   tradeNo: tradeNo || '0',
        //   ...payload
        // }
        // url = (await valentineTask(_data)) as any
        success = true
      } catch (e) {}
      return {
        success,
        url
      }
    }
  }
]
