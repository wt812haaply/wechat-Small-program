import * as Hapi from 'hapi'
import * as sign from '../../utils/sign'
import status from '../../utils/status'
import module from '../../modules/annual'
import dayjs from 'dayjs'
import compose from '../../task/compose'
export default [
  {
    method: 'GET',
    path: '/events/annual/{id}',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const id = request.params.id
      const data = await module.findOne({
        where: {
          uid: id
        }
      })
      const userStatus = 1
      let _data
      try {
        _data = JSON.parse(JSON.stringify(data))
      } catch (e) {}
      if (_data) {
        _data.userStatus = userStatus
        let usingTime
        if (userStatus === 1) {
          const diffPayTime: number =
            dayjs().diff(_data.first_pay_time_18, 'day') || 0
          const diffRentTime: number =
            dayjs().diff(_data.first_rent_time_18, 'day') || 0
          usingTime = Math.max(diffPayTime, diffRentTime)
        } else if (userStatus === 2) {
          const diffPayTime: number =
            dayjs(_data.pay_end_date).diff(_data.first_pay_time_18, 'day') || 0
          const diffRentTime: number =
            dayjs(_data.pay_end_date).diff(_data.first_rent_time_18, 'day') || 0
          usingTime = Math.max(diffPayTime, diffRentTime)
        }
        _data.usingTime = usingTime
        _data.rank = _data.uid
        delete _data.uid
      } else {
        _data = {}
      }
      return _data
    }
  },
  {
    method: 'GET',
    path: '/events/annual',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'try'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      if (!request.auth.isAuthenticated) {
        return {
          code: 105,
          msg: '无效的认证信息',
          data: null
        }
      }
      const {
        data: { clientKey: id }
      } = request.auth.credentials as any
      const uid = sign.decode(id)
      const data = await module.findOne({
        where: {
          uid
        }
      })
      const userStatus = status.getUserStatus(request.auth.credentials)
      let _data
      try {
        _data = JSON.parse(JSON.stringify(data))
      } catch (e) {}
      if (_data) {
        _data.userStatus = userStatus
        let usingTime
        if (userStatus === 1) {
          const diffPayTime: number =
            dayjs().diff(_data.first_pay_time_18, 'day') || 0
          const diffRentTime: number =
            dayjs().diff(_data.first_rent_time_18, 'day') || 0
          usingTime = Math.max(diffPayTime, diffRentTime)
        } else if (userStatus === 2) {
          const diffPayTime: number =
            dayjs(_data.pay_end_date).diff(_data.first_pay_time_18, 'day') || 0
          const diffRentTime: number =
            dayjs(_data.pay_end_date).diff(_data.first_rent_time_18, 'day') || 0
          usingTime = Math.max(diffPayTime, diffRentTime)
        }
        _data.usingTime = usingTime
        _data.rank = _data.uid
        delete _data.uid
      } else {
        _data = {}
      }
      return _data
    }
  },
  {
    method: 'POST',
    path: '/events/annual',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'try'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      if (!request.auth.isAuthenticated) {
        return {
          code: 105,
          msg: '无效的认证信息',
          data: null
        }
      }
      const {
        data: { clientKey: id }
      } = request.auth.credentials as any
      const uid = sign.decode(id)
      const data = await module.findOne({
        where: {
          uid
        }
      })

      let success = false
      let _data
      let url = ''
      try {
        _data = JSON.parse(JSON.stringify(data))
        url = (await compose(_data)) as any
        success = true
      } catch (e) {}
      return {
        success,
        url
      }
    }
  },
  {
    method: 'POST',
    path: '/events/annual/{id}',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const id = request.params.id
      const data = await module.findOne({
        where: {
          uid: id
        }
      })
      let success = false
      let _data
      let url = ''
      try {
        _data = JSON.parse(JSON.stringify(data))
        url = (await compose(_data)) as any
        success = true
      } catch (e) {}
      return {
        success,
        url
      }
    }
  }
]
