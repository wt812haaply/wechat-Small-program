import event_1111 from './1111'
import event_1112 from './1112'
import brandDay from './brandDay'
import prizeWheel from './prizeWheel'
import search from './search'
import valentine from './valentine'
import goddess from './goddess'
export default [
  ...event_1111,
  ...event_1112,
  ...brandDay,
  ...prizeWheel,
  ...search,
  ...valentine,
  ...goddess
]
