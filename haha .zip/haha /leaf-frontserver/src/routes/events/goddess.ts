import * as Hapi from 'hapi'
import Goddess from '../../modules/goddess'
import * as sign from '../../utils/sign'
import { expiryDate } from '../../utils/index'
import rp from '../../utils/request'
const day1_preset = new Date(2019, 2, 7, 12, 58)
const day1_start = new Date(2019, 2, 7, 13, 8)
const day1_end = new Date(2019, 2, 7, 23, 8)
const day2_preset = new Date(2019, 2, 8, 12, 58)
const day2_start = new Date(2019, 2, 8, 13, 8)
const day2_end = new Date(2019, 2, 8, 23, 8)
function isActivityOnGoing(now = new Date()) {
  const day1_ready_validate = expiryDate(
    {
      start: day1_preset,
      end: day1_start
    },
    now
  )
  const day1_ongoing_validate = expiryDate(
    {
      start: day1_start,
      end: day1_end
    },
    now
  )
  const day2_ready_validate = expiryDate(
    {
      start: day2_preset,
      end: day2_start
    },
    now
  )
  const day2_ongoing_validate = expiryDate(
    {
      start: day2_start,
      end: day2_end
    },
    now
  )
  return {
    day1: {
      ready: day1_ready_validate,
      ongoing: day1_ongoing_validate
    },
    day2: {
      ready: day2_ready_validate,
      ongoing: day2_ongoing_validate
    }
  }
}
export default [
  {
    method: 'POST',
    path: '/events/goddess/remind',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const query: any = request.query
      let date
      if (query.date) {
        const args: number[] = query.date.split(',')
        // @ts-ignore
        date = new Date(...args)
      }
      if (query.ts) {
        date = new Date(+query.ts as number)
      }
      const validate = isActivityOnGoing(date)
      // 第一天准备期之前
      // 第一天结束距第二天准备期之前
      if (
        validate.day1.ready === -1 ||
        (validate.day1.ongoing === 1 && validate.day2.ready === -1)
      ) {
        let {
          data: { clientKey: id, mobile }
        } = request.auth.credentials as any
        const uid = sign.decode(id)
        mobile = sign.decode(mobile)
        let remind_time = '03-07'
        if (validate.day1.ongoing === 1 && validate.day2.ready === -1) {
          remind_time = '03-08'
        }
        const exsited = await Goddess.findOne({
          where: {
            uid
          },
          raw: true
        })
        if (exsited) {
          let remind = new Set(exsited.remind.split(','))
          remind.add(remind_time)
          await Goddess.update(
            {
              remind: [...remind].join(',')
            },
            {
              where: {
                uid
              }
            }
          )
        } else {
          await Goddess.create({
            uid,
            mobile,
            remind: remind_time
          })
        }
        return {
          code: 100,
          msg: '设置提醒成功，将在开抢前10分钟短信提醒您'
        }
      } else {
        let err
        // 准备期中
        if (validate.day1.ready === 0 || validate.day2.ready === 0) {
          err = '抢购马上就要开始了，别走开~'
        } else if (validate.day1.ongoing === 0 || validate.day2.ongoing === 0) {
          err = '抢购已经开始啦~'
        } else if (validate.day2.ready === 1) {
          err = '来晚啦，活动已结束~'
        } else if (validate.day1.ongoing === -1) {
          err = '活动暂未开始'
        }
        return {
          code: 105,
          msg: err
        }
      }
    }
  },
  {
    method: 'GET',
    path: '/events/goddess/remind',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'try'
      } as any
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      if (request.auth.isAuthenticated) {
        const {
          data: { memberType: typefromToken, clientKey: id }
        } = request.auth.credentials as any
        const uid = sign.decode(id)
        let member_type = typefromToken
        try {
          let data = await rp(request)({
            method: 'GET',
            url: '/user/userInfo'
          })
          member_type = data.data.member_type
        } catch (e) {}
        let exsited = await Goddess.findOne({
          where: {
            uid
          },
          raw: true
        })
        let isRemind = false
        if (exsited) {
          const query: any = request.query
          let date
          if (query.date) {
            const args: number[] = query.date.split(',')
            // @ts-ignore
            date = new Date(...args)
          }
          if (query.ts) {
            date = new Date(+query.ts as number)
          }
          const validate = isActivityOnGoing(date)
          let remind_time = '03-07'
          if (validate.day1.ongoing === 1 && validate.day2.ready === -1) {
            remind_time = '03-08'
          }
          isRemind = !!~exsited.remind.indexOf(remind_time)
        }
        return {
          data: {
            isNew: member_type === 0,
            isRemind
          }
        }
      } else {
        return {
          data: {
            isNew: true,
            isRemind: false
          }
        }
      }
    }
  },
  {
    method: 'DELETE',
    path: '/events/goddess/remind',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const {
        data: { clientKey: id }
      } = request.auth.credentials as any
      const uid = sign.decode(id)
      const query: any = request.query
      let date
      if (query.date) {
        const args: number[] = query.date.split(',')
        // @ts-ignore
        date = new Date(...args)
      }
      if (query.ts) {
        date = new Date(+query.ts as number)
      }
      const validate = isActivityOnGoing(date)
      if (
        validate.day1.ready === -1 ||
        (validate.day1.ongoing === 1 && validate.day2.ready === -1)
      ) {
        let remind_time = '03-07'
        if (validate.day1.ongoing === 1 && validate.day2.ready === -1) {
          remind_time = '03-08'
        }
        const exsited = await Goddess.findOne({
          where: {
            uid
          },
          raw: true
        })
        if (exsited) {
          let remind = new Set(exsited.remind.split(','))
          remind.delete(remind_time)
          await Goddess.update(
            {
              remind: remind.size ? [...remind].join(',') : ''
            },
            {
              where: {
                uid
              }
            }
          )
          return {
            code: 100,
            msg: '取消提醒成功'
          }
        } else {
          return {
            code: 105,
            msg: '取消提醒失败'
          }
        }
      } else {
        let err
        // 准备期中
        if (validate.day1.ready === 0 || validate.day2.ready === 0) {
          err = '抢购马上就要开始了，别走开~'
        } else if (validate.day1.ongoing === 0 || validate.day2.ongoing === 0) {
          err = '抢购已经开始啦~'
        } else if (validate.day2.ready === 1) {
          err = '来晚啦，活动已结束~'
        } else if (validate.day1.ongoing === -1) {
          err = '活动暂未开始'
        }
        return {
          code: 105,
          msg: err
        }
      }
    }
  }
]
