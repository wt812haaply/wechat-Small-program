import * as Hapi from 'hapi'
import rp from '../../utils/request'
export default [
  {
    method: 'GET',
    path: '/events/brand-day',
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { data } = await rp(request, {
        prefix: '/ms'
      })({
        url: '/courier/v1/branchDonationInfo'
      })
      if (!data) {
        return {}
      }
      return data
    }
  }
]
