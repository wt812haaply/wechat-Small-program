import * as Hapi from 'hapi'
import rp from '../../utils/request'
import status from '../../utils/status'
import dayjs from 'dayjs'
import * as sign from '../../utils/sign'
const Boom = require('boom')
const MONTH = 11 - 1
const START = new Date(2018, MONTH, 5)
const END = new Date(2018, MONTH, 10, 23, 59)
function isVerify(date?: Date) {
  let validity = false
  let text = ''
  let nextDay = false
  let now = Date.now()
  if (date) {
    now = date.valueOf()
  }
  const isBeforeStart = now < START.valueOf()
  const isAfterEnd = now > END.valueOf()
  if (!isBeforeStart && !isAfterEnd) {
    const time = +dayjs(now).format('HHmm.ss')
    if (time <= 1101) {
      validity = true
    } else if (time > 1101 && time < 1111) {
      text = '抢购马上就要开始了，别走开~'
    } else if (time >= 1111 && time <= 1211) {
      text = '抢购已经开始啦~'
    } else {
      validity = true
      nextDay = true
    }
  } else {
    if (isBeforeStart) {
      text = '活动暂未开始~'
    } else if (isAfterEnd) {
      if (now < new Date(2018, MONTH, 12).valueOf()) {
        text = '抢购已经开始啦~'
      } else {
        text = '来晚啦，活动已结束~'
      }
    }
  }
  return {
    status: validity,
    text,
    nextDay
  }
}
function getUid(request: Hapi.Request) {
  const credentials: any = request.auth.credentials
  let {
    data: { clientKey: uid }
  } = credentials
  uid = sign.decode(uid)
  return uid
}
const REDIS_KEY = 'event_notify'
export default [
  {
    method: 'GET',
    path: '/events/1111/info',
    options: {
      auth: {
        strategy: 'jwt',
        mode: 'optional'
      } as any,
      plugins: {
        schema: {
          remind: {
            types: 'boolean',
            description: '是否设置过提醒'
          }
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let remind = false
      let userStatus: number = 0
      if (request.auth.isAuthenticated) {
        const credentials: any = request.auth.credentials
        userStatus = status.getUserStatus(credentials)
        if (userStatus === 0) {
          const { data } = await rp(request)({
            url: '/user/userInfo'
          })
          if (data) {
            userStatus = data.member_type
          }
        }
        const { redis } = request.server.app as any
        const uid = getUid(request)
        let date: number = parseInt(dayjs().format('YYYYMMDD'), 10)
        if (isVerify().nextDay) {
          date++
        }
        remind = await redis.sismemberAsync(`${REDIS_KEY}-${date}`, uid)
        remind = !!remind
      }
      return {
        remind,
        isLogin: request.auth.isAuthenticated,
        userStatus,
        date: Date.now()
      }
    }
  },
  {
    method: 'GET',
    path: '/events/1111/notify/{date?}',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { redis } = request.server.app as any
      const date = request.params.date || dayjs().format('YYYYMMDD')
      const set = await redis.smembersAsync(`${REDIS_KEY}-${date}`)
      const expire = await redis.ttlAsync(`${REDIS_KEY}-${date}`)
      return {
        users: set,
        expire
      }
    }
  },
  {
    method: ['PATCH', 'POST'],
    // 不幂等 请求统一资源时，需要判断是否参加过
    path: '/events/1111/notify',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const credentials: any = request.auth.credentials
      const userStatus: number = status.getUserStatus(credentials)
      const verify = isVerify()
      if (userStatus !== 0) {
        return Boom.forbidden('该活动仅限新用户参加~')
      } else if (!verify.status) {
        return {
          code: 105,
          msg: verify.text,
          data: {
            success: false
          }
        }
      } else {
        const uid = getUid(request)
        const { redis } = request.server.app as any
        let date: number = parseInt(dayjs().format('YYYYMMDD'), 10)
        if (verify.nextDay) {
          date++
        }
        await redis.saddAsync(`${REDIS_KEY}-${date}`, uid)
        await redis.expireAsync(`${REDIS_KEY}-${date}`, 60 * 60 * 24 * 30)
        return {
          success: true
        }
      }
    }
  },
  {
    method: 'DELETE',
    path: '/events/1111/notify',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { redis } = request.server.app as any
      const uid = getUid(request)
      let date: number = parseInt(dayjs().format('YYYYMMDD'), 10)
      if (isVerify().nextDay) {
        date++
      }
      const remove = await redis.sremAsync(`${REDIS_KEY}-${date}`, uid)
      return {
        success: !!remove
      }
    }
  },
  {
    method: 'DELETE',
    path: '/events/1111/notify/all/{date?}',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { redis } = request.server.app as any
      let {
        data: { mobile }
      } = request.auth.credentials as any
      mobile = sign.decode(mobile)
      if (mobile !== '18500070928') {
        return Boom.unauthorized()
      }
      const date = request.params.date || dayjs().format('YYYYMMDD')
      const del = await redis.delAsync(`${REDIS_KEY}-${date}`)
      return {
        success: !!del
      }
    }
  }
]

export { isVerify }
