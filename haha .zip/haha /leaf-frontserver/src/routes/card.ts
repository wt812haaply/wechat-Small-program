import * as Hapi from 'hapi'
import rp from '../utils/request'
import config from '../../config/index'
import * as sign from '../utils/sign'
const Joi = require('joi')

export default [
  {
    method: 'GET',
    path: '/card/panel',
    options: {
      auth: 'jwt',
      notes: 'https://yapi.95vintage.com/project/23',
      description: '取消连续包月页面'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      let { data } = await rp(request, {
        prefix: '/ms'
      })({
        url: '/card/v1/card/autoMonthPaymentManagePanel',
        method: 'GET'
      })
      if (!data) {
        data = {}
      }

      let oldId = 'OTdGcmRta2ZENjU1RVRxSnNxOD0'
      let newId = 'MkVCQXRoRmI3QjA5Rk5wK2tPYz0'
      const normalId = 'RDc4ZG83Q241RTMxM2NONDB3OD0'

      if (config.tag === 'production') {
        oldId = 'NjE3NWNvQWhERDE5MTdFVXN3ST0'
        newId = 'MDFEbGZtN1Q0MTk4RnBZY2k3UT0'
      }

      data.eventId = {
        o: oldId,
        n: newId,
        nor: normalId
      }
      return data
    }
  },
  {
    method: 'POST',
    path: '/card/apply',
    options: {
      auth: 'jwt',
      notes: 'https://yapi.95vintage.com/project/23',
      description: '用户申请取消连续包月'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const {
        data: { clientKey: id }
      } = request.auth.credentials as any
      const uid = sign.decode(id)
      const data = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/card/v1/card/applyCancelContract',
        form: {
          uid
        }
      })
      return data
    }
  },
  {
    method: 'POST',
    path: '/card/reason',
    options: {
      auth: 'jwt',
      validate: {
        payload: {
          contractId: Joi.string()
            .required()
            .error(new Error('参数合同id不正确')),
          reasonId: Joi.string()
            .required()
            .error(new Error('参数理由id不正确')),
          reasonText: Joi.any().error(new Error('参数其他理由不正确'))
        }
      },
      notes: 'https://yapi.95vintage.com/project/23',
      description: '提交取消原因'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { contractId, reasonId, reasonText } = request.payload as any
      const res = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/card/v1/card/cancelContractReason',
        form: {
          contractId,
          reasonId,
          reasonText
        }
      })

      if (!res) {
        return {}
      }
      return res
    }
  },
  {
    method: 'POST',
    path: '/card/cancel',
    options: {
      auth: 'jwt',
      notes: 'https://yapi.95vintage.com/project/23',
      description: '取消申请'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const result = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/card/v1/card/userCancelApply',
        form: request.payload
      })
      if (result.code !== 100) {
        return result
      }

      return result.data
    }
  },
  {
    method: 'GET',
    path: '/card/{id}',
    options: {
      validate: {
        params: {
          id: Joi.string()
            .required()
            .error(new Error('参数eventId不正确'))
        }
      },
      auth: 'jwt',
      notes: 'http://jk.95vintage.com/doc/index.php?s=/1&page_id=346',
      description: '确认用户是否领过奖励'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const eventId = sign.decode(request.params.id)
      const { data } = await rp(request)({
        method: 'GET',
        url: '/event/confirmEventStatus',
        qs: {
          eventId
        }
      })
      if (!data) {
        return { times: 0 }
      }
      return data
    }
  },
  {
    method: 'POST',
    path: '/card/coupon/{id}',
    options: {
      validate: {
        params: {
          id: Joi.string()
            .required()
            .error(new Error('参数couponId不正确'))
        }
      },
      auth: 'jwt',
      description: '领券'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const eventId = sign.decode(request.params.id)
      const {
        data: { clientKey: id }
      } = request.auth.credentials as any
      const uid = sign.decode(id)
      const res = await rp(request)({
        method: 'POST',
        url: '/coupon/promotionCouponSet',
        form: {
          uid,
          eventId
        }
      })
      return res
    }
  },
  {
    method: 'GET',
    path: '/card/list',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { code, data } = await rp(request, {
        prefix: '/ms'
      })({
        method: 'GET',
        url: '/card/v1/list'
      })
      let tempPayCard = []
      let inviteCode = ''
      let showInvitation = 0
      if (code === 100 && data) {
        tempPayCard = data.showInfo
        inviteCode = data.inviteCode || ''
        showInvitation = data.showInvitation || 0
      }

      return {
        paydetail: tempPayCard,
        inviteCode,
        showInvitation,
        isFirstPay: data.isFirstPay || '',
        promotion13time: data.promotion13time || ''
      }
    }
  },
  {
    method: 'POST',
    path: '/card/purchase',
    options: {
      auth: 'jwt',
      notes: 'https://yapi.95vintage.com/project/23/interface/api/130',
      validate: {
        payload: {
          payType: Joi.string()
            .required()
            .error(new Error('请选择支付类型'))
        },
        options: {
          allowUnknown: true
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      interface IPurchase {
        cardTemplateId?: number
        payType?:
          | 'ALI'
          | 'ALI_WEB'
          | 'WECHAT'
          | 'WECHAT_WEB'
          | 'ALI_AUTH_FREEZE'
          | 'ALI_CREDIT_LIFE'
          | 'ALI_CONTRACT_BINDING'
          | 'ALI_POINT'
        couponId?: string
        inviteCode?: string
        openId?: string
        extraData?: string
        aliAuthToken?: string
        aliUserId?: string
        aliUserLevel?: string
        returnUrl?: string
        origin?: string
      }
      const payload = request.payload
      const result = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/card/v1/purchase',
        form: payload as IPurchase
      })
      return result
    }
  }
]
