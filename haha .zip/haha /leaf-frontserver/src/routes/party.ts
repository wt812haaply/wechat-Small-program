import * as Hapi from 'hapi'
import { wechatShare } from '../utils/request'
const Joi = require('joi')
export default [
  {
    method: 'GET',
    path: '/party/weixin/share',
    options: {
      validate: {
        query: {
          link: Joi.string().required()
        }
      }
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      return wechatShare(request)
    }
  }
]
