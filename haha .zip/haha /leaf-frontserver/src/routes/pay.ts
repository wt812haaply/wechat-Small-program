import * as Hapi from 'hapi'
import config from '../../config'
import payment from '../utils/payment'
import rp from '../utils/request'
const Joi = require('joi')
const Boom = require('boom')

export default [
  {
    method: 'POST',
    path: '/pay/payDeposit',
    options: {
      validate: {
        payload: {
          payType: Joi.string()
            .required()
            .error(new Error('请选择支付类型')),
          openId: Joi.string().default(''),
          url: Joi.string().default('')
        }
      },
      auth: 'jwt',
      description: '押金后置，只发起押金支付'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const { url, payType, openId = '' } = request.payload as any
      if (payType === 'WECHAT_WEB' && !openId) {
        return Boom.forbidden('请在微信中打开')
      }
      const payRes = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/card/v1/payDeposit',
        form: {
          returnUrl: url,
          openId,
          payType
        }
      })
      if (payRes.code === 100) {
        const responsData = payRes.data.paymentInfo
        if (payType === 'WECHAT_WEB') {
          const payContents = payment.GetJsApiParameters(responsData)
          return payContents
        } else if (payType === 'ALI_WEB') {
          let resUrl = responsData.return_url
          if (url) {
            resUrl = decodeURIComponent(url)
          }
          responsData.return_url = resUrl
          const res = payment.buildRequestForm(responsData)
          return res
        } else if (payType === 'ALI_AUTH_FREEZE') {
          return { freezeLink: responsData }
        } else {
          return responsData
        }
      } else {
        return payRes
      }
    }
  },
  {
    method: 'POST',
    path: '/pay/{payType}/purchase',
    options: {
      validate: {
        params: {
          payType: Joi.string()
            .required()
            .error(new Error('请选择支付方式'))
        }
      },
      auth: 'jwt',
      notes: 'https://yapi.95vintage.com/project/23',
      description: '支付所有卡类型购买'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const payParams = (request.payload as any) || {}
      const payType = (request.params as any).payType
      if (payParams.payType === 'WECHAT_WEB' && !payParams.openId) {
        return Boom.forbidden('请在微信中打开')
      }
      const result = await rp(request, {
        prefix: '/ms'
      })({
        method: 'POST',
        url: '/card/v1/purchase',
        form: {
          returnUrl: payParams.returnUrl
            ? decodeURIComponent(payParams.returnUrl)
            : '',
          cardTemplateId: payParams.cardTemplateId || 0,
          payType,
          couponId: payParams.couponId || 0,
          inviteCode: payParams.inviteCode || '',
          openId: payParams.openId || '',
          extraData: payParams.extraData || '',
          aliAuthToken: payParams.aliAuthToken || '',
          aliUserId: payParams.aliUserId || '',
          aliUserLevel: payParams.aliUserId || '',
          origin: payParams.origin || ''
        }
      })
      return result
    }
  },
  {
    method: 'POST',
    path: '/pay/payment',
    options: {
      validate: {
        payload: {
          payType: Joi.number()
            .required()
            .error(new Error('请选择购买的方式')),
          payWay: Joi.number()
            .required()
            .error(new Error('请求参数出错，请刷新后重试')),
          couponId: Joi.number().default(0),
          detailId: Joi.number().default(0),
          skuId: Joi.number().default(0)
        },
        options: {
          allowUnknown: true
        }
      },
      auth: 'jwt',
      description: '购买商品信息接口'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const payParams = (request.payload as any) || {}
      const result = await rp(request)({
        method: 'POST',
        url: '/pay/pay',
        form: payParams
      })
      if (result.code === 100) {
        const responsData = result.data.paymentInfo
        let paymentInfo = {}

        //本来应该只返回给前台 java 的返回值即可，但是由于购买接口没有改造，因此返回值需要中台加签
        //等到以后后台加签的话，中台直接返回即可
        if (payParams.payWay === 2) {
          responsData.appid = config.wechat.app_id
          paymentInfo = payment.GetJsApiParameters(responsData)
        } else if (payParams.payWay === 3) {
          let resUrl = responsData.return_url
          if (payParams.url) {
            resUrl = decodeURIComponent(payParams.url)
          }
          responsData.return_url = resUrl
          responsData.service = 'alipay.wap.create.direct.pay.by.user'
          responsData.partner = config.alipay.partner_id
          responsData.seller_id = config.alipay.seller_id
          responsData._input_charset = 'utf-8'
          responsData.out_trade_no = responsData.trade_no
          responsData.subject = responsData.pay_name
          delete responsData.trade_no
          delete responsData.pay_name
          paymentInfo = payment.buildRequestForm(responsData)
        }
        result.data.paymentInfo = paymentInfo
      }
      return result
    }
  },
  {
    path: '/pay/history',
    method: 'GET',
    options: {
      auth: 'jwt'
    },
    handler: async (request: Hapi.Request, h: Hapi.ResponseToolkit) => {
      const data = await rp(request)({
        url: '/pay/payHistory'
      })
      return data
    }
  }
]
