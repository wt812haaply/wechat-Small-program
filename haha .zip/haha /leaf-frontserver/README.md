# 指引

## 目录

## 启动脚本

```js
// 本地开发
npm run dev
// 本地测试
npm test
// 本地启动 PM2
npm start
// 本地启动产品模式
npm run prod
// 本地格式化代码
npm run lint
// Typescript 检查
npm run check
```

## State(Cookie)

+ token - 认证（开发模式）

## 环境变量

```js
// 开发环境
NODE_ENV {
  // 本地开发环境
  development
  // 线上环境
  production
}
// repos 标签
tag {
  // 线上 develop 仓库
  develop
  // 线上 stage 仓库
  staging
  // 线上 master 仓库
  production
}
// 调试模式
debug
```

## 编程习惯

### 注释

[JS DOC](http://usejsdoc.org/about-getting-started.html) [中文](https://www.css88.com/doc/jsdoc/index.html)
