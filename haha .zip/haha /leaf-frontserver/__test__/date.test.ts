import { isVerify } from '../src/routes/events/1111'
const MONTH = 11 - 1
describe('test date verify', () => {
  // 5号之前
  test('before 2018 11 5', () => {
    expect(isVerify(new Date(2018, MONTH, 4)).status).toBe(false)
    expect(isVerify(new Date(2018, MONTH, 4)).text).toBe('活动暂未开始~')
  })
  // 11号当天
  test('at 2018 11 11', () => {
    expect(isVerify(new Date(2018, MONTH, 11)).status).toBe(false)
    expect(isVerify(new Date(2018, MONTH, 11)).text).toBe('抢购已经开始啦~')
  })
  // 11号之后
  test('after 2018 11 11', () => {
    expect(isVerify(new Date(2018, MONTH, 12)).status).toBe(false)
    expect(isVerify(new Date(2018, MONTH, 12)).text).toBe('来晚啦，活动已结束~')
  })
  // 11:01 之前 可预约提醒
  test('before 2018 11 5 11:01', () => {
    expect(isVerify(new Date(2018, MONTH, 5, 11, 1)).status).toBe(true)
    expect(isVerify(new Date(2018, MONTH, 5, 11, 1)).text).toBe('')
  })
  // 11:10 之后 马上开始
  test('after 2018 11 5 11:10', () => {
    expect(isVerify(new Date(2018, MONTH, 5, 11, 10)).status).toBe(false)
    expect(isVerify(new Date(2018, MONTH, 5, 11, 10)).text).toBe(
      '抢购马上就要开始了，别走开~'
    )
  })
  // 12:11 之后 当日结束 预约第二日
  test('after 2018 11 5 12:11', () => {
    expect(isVerify(new Date(2018, MONTH, 5, 12, 11, 1)).status).toBe(true)
    expect(isVerify(new Date(2018, MONTH, 5, 12, 11, 1)).text).toBe('')
    expect(isVerify(new Date(2018, MONTH, 5, 12, 11, 1)).nextDay).toBe(true)
  })
})
