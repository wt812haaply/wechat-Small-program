const puppeteer = require('puppeteer-core')
const fs = require('fs-extra')
import path from 'path'
import rp from 'request-promise'
const routes = [
  'rent',
  'return',
  'validity',
  'buy',
  'product',
  'other',
  'clean'
]
interface IHTMLElement extends Element {
  innerText: string
}
async function saveFile(file: string) {
  const index = routes.findIndex((item: string) => !!~file.indexOf(item))
  const charCode: number = 'a'.charCodeAt(0)
  const char: string = String.fromCharCode(charCode + index)
  const browser = await puppeteer.launch({
    executablePath: '/Applications/Chromium.app/Contents/MacOS/Chromium',
    headless: false
  })
  const page = await browser.newPage()
  await page.goto(
    `https://www.95vintage.com/yi23/Home/Others/qnaApp_detail_${char}`
  )
  const $title = await page.$eval('h3', (el: HTMLElement) => el.innerHTML)
  const $sections = await page.$$eval(
    '.collapse > .collapseItem',
    (els: HTMLElement[]) => {
      return els.map(e => {
        return {
          title: (e.querySelector('h4') as HTMLElement).innerHTML
            .replace(/&nbsp;/g, '')
            .replace(/\d+\./g, ''),
          content: (e!.querySelector('.qnaCon') as IHTMLElement).innerText
            .replace(/^(\n\n)?\s+/g, '')
            .replace(/\n\n\s+/g, '<br/>')
            .replace(/\n/g, '')
        }
      })
    }
  )
  const result = {
    title: $title,
    sections: $sections
  }
  await fs.writeFile(file, JSON.stringify(result, null, '\t\t'))
  await browser.close()
}
const resolve = (_p: string) => {
  return path.resolve(__dirname, _p)
}
const toJson = (s: string) => JSON.parse(s)
let body: any
let result: any

beforeAll(async () => {
  const current = routes[0]
  const file = resolve(`./rules/${current}.json`)
  const isExist = await fs.pathExists(file)
  if (!isExist) {
    await saveFile(file)
  }
  result = toJson(await fs.readFile(file, 'utf8'))
  const { data } = await rp({
    url: `http://localhost:3000/rules/${current}?type=yi23`,
    json: true
  })
  body = data
})
const replace = (s: string) => s.replace(/(<br\/?>|\n|\r|\s+|<[^>]*>)/g, '')
test('data', () => {
  result.sections.map((item: any, index: number) => {
    expect(replace(item.content)).toEqual(replace(body.sections[index].content))
  })
})
