import crypto from 'crypto'
import fs from 'fs'
import path from 'path'
import config from '../config'
import * as sign from '../src/utils/sign'
const privateKey = `MIICXgIBAAKBgQDDxD3OoYv60qronumXay3supv5s1b19ZCVEp6fWTdjBRlqlC3P6pUpIAqTxHCyVjUOGAGjKI3hb+QaTQCqXSNwj+0YvWJIlExHblWJ+IRHL6iLEmWh8PxQtd2XhXL1fhLt+F4Bx2OMrRzV/lt4QscngEEAsDssIeVXutiXcLJogQIDAQABAoGBALEvzFVaiCzEQmZ7dqdTHeT23be6p4nE8lDK4oENqgDYm7GIXpKiGtF3K7uk/++Z8TlJZyn6ybfyov1fFqwb0rc1qkmcVh7I9DgPeZ/Yd5XbUm5lGhKK/ejJljw5ahKdr2ziAFsJ5+cHZH6PRJvS/h4B35d2gatXj8uLCTO3LdkVAkEA++3TbtPot7D4TnZqgYzHqcxhvUXWHxs7ULUhcpeoZtXJuplHFlD99lk+H13UXtlwKtDa8caHsL0b8rJh4WPPZwJBAMbuFYPvYDB+Ja5l0mFBqMuUluvTTxJOysKNP7EcemdB/6rafUSmvrD7oTYidBpv9DHzdnHQr5shyiJ+LdvYX9cCQQCb2K35W4IVUJbrAvo0FkDV26eDDRa+u3vgG40LdKIqq4pVssh1F7ljkiWKBeOAoYZwFi+7bZM3VGVbp9pBMht1AkBYV4LWhIeDAYJaYH19E1uSjPo44C5NQxBoNbIDRVJWaMjRZxYaVrJ4hkahc8t7shwP0r7W7IYProHFr6NN7lkhAkEAiTWTctbdDpUm4vnL+9yq1ZGfjCm2CwTAo5D7oIX5IyHJB+Iik8ZYIHZilJhinG5F+SlIyXLoBUcNf77SLpimjw==`
const data: object = {
  device: 'Web',
  version: config.version,
  source: 0,
  uid: 0,
  regionId: 52,
  channelId: 0
}
function verify(data: object, key: string, sig: string) {
  const verify = crypto.createVerify('RSA-SHA1')
  verify.update(sign.signParams(data))
  const pubkey = fs.readFileSync(
    path.resolve(__dirname, './rsa_public_key.pem'),
    'utf8'
  )
  return verify.verify(pubkey, sig, 'base64')
}
describe('test sign', () => {
  describe('insert char function', () => {
    test('optional arguments', () => {
      expect(sign.insertChar('abcde')).toEqual('abcde')
    })
    test('insert /', () => {
      expect(sign.insertChar('abcde', 1, '/')).toEqual('a/b/c/d/e')
    })
    test('insert \\n in private key', () => {
      expect(
        fs.readFileSync(
          path.resolve(__dirname, './rsa_private_key.pem'),
          'utf8'
        )
      ).toMatch(sign.insertChar(privateKey, 64, '\n'))
    })
  })
  test('private key RSA with local file', () => {
    const signer = sign.createOriginalRSA(data, privateKey)
    expect(verify(data, privateKey, signer)).toBe(true)
  })
  test('private key RSA', () => {
    const signer = sign.createOriginalRSA(
      {
        uid: '83101',
        device: 'Web',
        version: '2.7.5',
        regionId: 52,
        source: '',
        channelId: 0,
        timestamp: 1532581929
      },
      config.private_key
    )
    expect(signer).toBe(
      'Oz2ILZPHkigO1cN6N72uR1gfaTuX1wNsUZ7juzty4akh1zr+FQ3quW2tAFnMHHZifwc99uc2SHkhrIRr0bSlLXL24JRwOcj5/0nueYhdDp+xZe/uRFWBzT8nxWzaosgueXBb5P/9TpnGNxjrvIn+G1eNbcfMwysLg4Jy0+R1LZ4='
    )
  })
  test('encode mobile', () => {
    const mobile = '18500070928'
    const code = sign.encode(mobile)
    expect(sign.decode(code)).toEqual(mobile)
  })
})
