import JWT from '../src/utils/jwt'

const data = {
  birthday: '2018-03-05',
  member_type: 2,
  server_time: 1532420442075,
  invitation_code: null,
  default_size: 'M',
  point_available: 2001,
  is_aut: 1,
  pay_hava_nub: 0,
  level_begin: '2018-02-03 17:07:30',
  modify_time: null,
  pay_end_date: '2000-06-25 23:59:59',
  bonusText: '邀请好友获得各50元现金奖励',
  type: 1,
  uuid: null,
  uid: 83101,
  password: null,
  hava_nub_end_date: null,
  member_status: 'D',
  nickname: '15712967154',
  default_addr: 2422,
  level_next: 2000,
  tall: 0,
  extra_field: 1,
  email: null,
  profession: '广告/公关/策划',
  is_email: 0,
  uhash: null,
  headImg: 'http://tu.yi23.net/headImgs/12515416/12515416-132.jpg',
  level: 1,
  is_new: 0,
  is_vip: 0,
  sex: 0,
  mobile: '15712967154',
  point_total: 501,
  point_factor: 1,
  server_date: 1532361600000,
  buy_discount_rate: 1,
  level_exp: '2019-02-03 17:07:30',
  heavy: 50,
  labels: '',
  level_name: '银星级',
  referee_uid: 0,
  add_time: '2018-02-03 17:07:14',
  remaining_days: 0,
  messageCenter: 1,
  unreadMessage: 1,
  uToken: 'd8891a56-c315-4919-8276-b064ef449d2d',
  status: 0,
  stockLockRemainingMillis: 0,
  hasSpecialEvent: 1,
  specialEvent: {
    eventDesc: '会员免费得',
    eventUrl: 'http://www.95vintage.com/yi23/Home/Promotion/yi23_experiencer',
    eventName: '成为Y Girl'
  }
}
let token = ''

describe('test JWT', () => {
  test('token is string', () => {
    token = JWT.create(data, 'this is secret')
    expect(typeof token).toBe('string')
  })
  test('payload', () => {
    expect(JWT.decode(token).payload.data).toEqual(data)
  })
  test('user token', () => {
    const jwt = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Im1lbWJlclR5cGUiOjIsInBvaW50QXZhaWxhYmxlIjo0OTksInBheUVuZERhdGUiOiIyMDE4LTA2LTI4IDIzOjU5OjU5IiwibWVtYmVyU3RhdHVzIjoyLCJuaWNrbmFtZSI6IjE4NTAwMDcwOTI4IiwibmV4dExldmVsIjoyMDAwLCJoZWFkSW1hZ2UiOiJodHRwOi8vdHUueWkyMy5uZXQvaGVhZEltZ3MvMTMxMDAxNzIvMTUyOTM5ODI1NzYyMS5qcGciLCJsZXZlbCI6MSwiaXNWYWxpZFVzZXIiOjAsInBvaW50VG90YWwiOjQ5OSwicG9pbnRGYWN0b3IiOjEsInBvaW50RGlzY291bnQiOjEsImxldmVsTmFtZSI6IumTtuaYn-e6pyIsInJlbWFpbkRheXMiOjAsImlzWWdpcmwiOjAsInJlZ2lzdGVyVGltZSI6IjIwMTgtMDUtMjEgMTg6MTY6MTYiLCJtU2VyaWVzIjoiMjNhMDUzNmItYzE5MC00NGI3LWI2ZTMtZDgyM2Y5MzVhMDdiIiwiY2xpZW50S2V5IjoiUkRCRFRqZERRbXRFTXpJME5WbEtSSE54TWs1M1JHTm5VMEZ6UWxkM1BUMCIsIm1vYmlsZSI6IlFVRXpVVmhOVVdjek9EaERNRFZ4TTJ4WlFWUjFSbkpVYTFwT1RHNVJQVDAifSwiaWF0IjoxNTMyNTg3MjkwMTM2LCJleHAiOjE1MzI1OTQ0OTAxMzZ9.MWCd-DqWye5tjU-0KmK-p2934b3imf2ji-RgRz68WN8`
    expect(JWT.decode(jwt).payload.data).toMatchObject({
      memberType: 2,
      pointAvailable: 499,
      payEndDate: '2018-06-28 23:59:59',
      memberStatus: 2,
      nickname: '18500070928',
      nextLevel: 2000,
      headImage: 'http://tu.yi23.net/headImgs/13100172/1529398257621.jpg',
      level: 1,
      isValidUser: 0,
      pointTotal: 499,
      pointFactor: 1,
      pointDiscount: 1,
      levelName: '银星级',
      remainDays: 0,
      isYgirl: 0,
      registerTime: '2018-05-21 18:16:16',
      mSeries: '23a0536b-c190-44b7-b6e3-d823f935a07b',
      clientKey: 'RDBDTjdDQmtEMzI0NVlKRHNxMk53RGNnU0FzQld3PT0',
      mobile: 'QUEzUVhNUWczODhDMDVxM2xZQVR1RnJUa1pOTG5RPT0'
    })
  })
})
