# 产品详情标签显示顺序

优先级：

+ 待返架 (stocknum == 0)
+ tagUrl
+ 秋冬限定 (is_star == 2)
+ 刚刚上架 (is_new == 1)
+ 明星同款 (is_star == 1)
