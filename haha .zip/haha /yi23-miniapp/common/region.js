/**
 * Created by ahu on 2017/11/25.
 */
var constants = require('./lib/constants');
var comm = require('./common');
var WX_REGION_ID_KEY = constants.WX_REGION_ID_KEY;
const locationCityRegionIdUrl = require('../config').locationCityRegionIdUrl;
var Region = {
    init:function () {
        var region={rgnId:constants.WX_REGION_ID_DEFULT,cityName:constants.WX_REGION_NAME_DEFULT},
            _t=this;
        if(_t.get() && _t.get().rgnId){
            return;
        }
        wx.getLocation({
            type: 'wgs84',
            success: (res) => {
                console.log(res);
                var latitude = res.latitude;// 经度
                var longitude = res.longitude; // 纬度
                comm.request({
                    url:locationCityRegionIdUrl,
                    hideToast:true,
                    data:{
                        lat:res.latitude,
                        lng:res.longitude,
                    },
                    success:function (res) {
                        if(res.data && res.data.code==100){
                            region=res.data.data;
                        }
                        _t.set(region);
                    },
                    fail:function () {
                        _t.set(region);
                    }
                });
            },
            fail:(res)=>{
                console.log(res);
                _t.set({rgnId:constants.WX_REGION_ID_DEFULT,cityName:constants.WX_REGION_NAME_DEFULT});
            }

        });
    },
    get: function () {
        return wx.getStorageSync(WX_REGION_ID_KEY) || '';
    },
    set: function (region) {
        wx.setStorage({key:WX_REGION_ID_KEY,data:region});
    },

    clear: function () {
        wx.removeStorageSync(WX_REGION_ID_KEY);
    },
};

module.exports = Region;