/**
 * Created by ahu on 2017/11/17.
 */
var untils = require('../util/util.js');
var config = require('../config');
var constants = require('./lib/constants');
var Session = require('./session');
var us = require('../common/lib/underscore.js');
var countAction = require('./countAction');
var handle = {

    //选择与取消筛选项->添加
    addFilter:function (doFilterList) {
        doFilterList.barSelect.unshift({
            key : doFilterList.key,
            id : doFilterList.id,
            name : doFilterList.name,
            category : doFilterList.category,
            tag : doFilterList.tag
        });
        if(doFilterList.tag && doFilterList.tag.length>1){
            console.log(doFilterList.tagMap)
            doFilterList.tagMap = doFilterList.tagMap.concat(doFilterList.tag);
        }
        console.log(doFilterList.tagMap)
        // this.setData({tagMap:this.data.tagMap,barSelect:barSelect})
        return doFilterList;
    },
    //选择与取消筛选项->取消
    cancelFilter:function (doFilterList) {
        // console.log(key,id,name,tag,seleted)
        doFilterList.seleted[doFilterList.key]=us.without(doFilterList.seleted[doFilterList.key],doFilterList.id);
        doFilterList.barSelect.some((v,t)=>{
            if(v.key===doFilterList.key && (v.name===doFilterList.name||v.id===doFilterList.id)){
                doFilterList.barSelect.splice(t, 1);
                doFilterList.seleted[doFilterList.key]=us.without(doFilterList.seleted[doFilterList.key],v.id);
                return true;
            }
        });
        if(doFilterList.tag && doFilterList.tag.length>1){
            doFilterList.tag.forEach((t,v)=> {
                doFilterList.tagMap.some((i,j)=> {
                    if (i === t) {
                        doFilterList.tagMap.splice(j, 1);
                        return true;
                    }
                })
            })
        }

        return doFilterList;
    },
    //选择与取消筛选项->取消->多个tag
    cancelFilterTag:function (doFilterList) {
        doFilterList.tag.forEach((n,j)=>{
            for (let i = doFilterList.barSelect.length - 1; i >= 0; i -= 1){
                if(doFilterList.barSelect[i].category && doFilterList.barSelect[i].category===n){
                    doFilterList.seleted['tagList']=us.without(doFilterList.seleted['tagList'],doFilterList.barSelect[i].id);
                    doFilterList.barSelect.splice(i, 1);
                }
            }
        })
        return doFilterList;
    },

};


module.exports = handle;