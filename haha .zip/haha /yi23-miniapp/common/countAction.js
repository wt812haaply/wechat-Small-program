/**
 * Created by ahu on 2018/5/4
 */
var constants = require('./lib/constants');
var cookie = require('./cookie');
var WX_HEADER_CLICKID = constants.WX_HEADER_CLICKID;
var WX_HEADER_SOURCE = constants.WX_HEADER_SOURCE;
let countAction={
    getId:function () {
       return cookie.getCookie(WX_HEADER_CLICKID)
    },
    setId:function (id) {
           cookie.setCookie(WX_HEADER_CLICKID,id,15)// 缓存15天
    },
    getSource:function () {
      return  cookie.getCookie(WX_HEADER_SOURCE)
    },
    setSource:function (id) {
        cookie.setCookie(WX_HEADER_SOURCE,id,15)// 缓存15天
    }
}
module.exports = countAction;