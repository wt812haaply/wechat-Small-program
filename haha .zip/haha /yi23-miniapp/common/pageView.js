/**
 * Created by ahu on 2017/11/27.
 */
var PageView={
        pages:"" ,
    currPage :'',
     prevPage:'',
        count:'',
    init:function () {
        this.pages = getCurrentPages();
        if(this.pages.length>1){
            this.currPage = this.pages[this.pages.length - 1];   //当前页面
            this.prevPage = this.pages[this.pages.length - 2];  //上一个页面
        }else if(this.pages && this.pages.length==1){
          this.currPage = this.pages[this.pages.length - 1];   //当前页面
          this.prevPage=null;
        }
    },
    hasRoute:function (url) {
       let pages=this.pages?this.pages:getCurrentPages();
       for(var i=0;i<pages.length;i++){
            if(pages[i].route==url){
                return {has:true,index:i}
            }
       }
       return {has:false};
    },
    routeEqual:function (page,url) {
        var has=false;
        try{
            if(page.route.indexOf(url)!=-1){
                has=true;
            }
        }catch (e){
            console.log(e)
        }
        return has;
    }
}
module.exports = PageView;