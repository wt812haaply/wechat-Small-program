import  cookie from '../common/cookie';
import  constants from './lib/constants'
export default {
    getOpenId(){
        return cookie.getCookie(constants.WX_DEVICE_OPENID)
    },
    setOpenId(id){
        cookie.setCookie(constants.WX_DEVICE_OPENID,id)
    },
    //设备Id
    getId(){
        if(cookie.getCookie(constants.WX_DEVICE_UUID)){
            return cookie.getCookie(constants.WX_DEVICE_UUID)
        }else{
            let uuid= "" + Date.now() + '-' + Math.floor(1e7 * Math.random()) + '-' + Math.random().toString(16).replace('.', '') + '-' + String(Math.random() * 31242).replace('.', '').slice(0, 8);
            this.setId(uuid)
            return uuid
        }

     },
    setId(id){
        cookie.setCookie(constants.WX_DEVICE_UUID,id)
    },
    deleteId(){
        cookie.deleteCookie(constants.WX_DEVICE_UUID)
    },
    //设备盐
    getSalt(){
        return cookie.getCookie(constants.WX_DEVICE_SALT)
    },
    setSalt(salt){//设备盐
        return cookie.setCookie(constants.WX_DEVICE_SALT,salt)
    },
    deletSalt(){
        cookie.deleteCookie(constants.WX_DEVICE_SALT)
    },
    //用户盐
    getSignSalt(){
        return cookie.getCookie(constants.WX_DEVICE_SIGN_SALT)
    },
    setSignSalt(sign){//用户盐
        return cookie.setCookie(constants.WX_DEVICE_SIGN_SALT,sign)
    },
    deleteSignSalt(){
        cookie.deleteCookie(constants.WX_DEVICE_SIGN_SALT)
    }

}