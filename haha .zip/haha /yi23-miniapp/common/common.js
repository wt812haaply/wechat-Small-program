/**
 * Created by ahu on 2017/11/17.
 */

import Device from './device'
import Login from "../api/login";
import Session from "./session";
import User from '../api/user'
var untils = require('../util/util.js');
var config = require('../config');
var constants = require('./lib/constants');
// var loginLib = require('./login');
var loginLib =require('./login_authorize');
var countAction = require('./countAction');
var WX_REGION_ID_KEY=constants.WX_REGION_ID_KEY;
var noop = function noop(e) {
};

var buildAuthHeader = function buildAuthHeader(session,options) {
    var header = {};
    if (session && session.sessionKey) {
        header[constants.WX_HEADER_SKEY] = session.sessionKey;
    }else{
      header[constants.WX_HEADER_SKEY]= ''
    }
    header[constants.WX_HEADER_DEVICE] = constants.WX_DEVICE;
    header[constants.WX_HEADER_CLICKID] = countAction.getId();
    header['yi23Source'] = countAction.getSource();
    header[constants.WX_HEADER_VERSION] = constants.WX_VERSION;
    if(options && options.data && options.data.version){
        header[constants.WX_HEADER_VERSION] = options.data.version
    }
    header[constants.WX_HEADER_REGIONID] = wx.getStorageSync(WX_REGION_ID_KEY)?wx.getStorageSync(WX_REGION_ID_KEY).rgnId:'52';//暂时写死北京
    return header;
};
/***
 * @class
 * 表示请求过程中发生的异常
 */
var RequestError = (function () {
    function RequestError(type, message) {
        Error.call(this, message);
        this.type = type;
        this.message = message;
    }

    RequestError.prototype = new Error();
    RequestError.prototype.constructor = RequestError;

    return RequestError;
})();
var handle = {
    request:function (options) {
        var requireLogin = options.login;
        var hideToast = options.hideToast;
        var success = options.success || noop;
        var fail = options.fail || noop;
        var complete = options.complete || noop;
        var originHeader = options.header || {};
        //增加版本信息 暂时写死用户id 3052
        // options.data=untils.extend({version:'2.6.4',uid:5065351,regionId:'52'},options.data);
        // console.log(options.data)
        // 成功回调
        var callSuccess = function () {
            if(wx.hideLoading){
                wx.hideLoading()
            }
            success.apply(null, arguments);
            complete.apply(null, arguments);
        };

        // 失败回调
        var callFail = function (error) {
            if(wx.hideLoading){
                wx.hideLoading()
            }
            console.log('--fail--');
            // wx.showToast({
            //     title: '请稍后再试',
            //     icon: 'loading',
            //     duration: 1500
            // })
            fail.call(null, error);
            complete.call(null, error);
        };
        if(!hideToast && wx.showLoading){
            wx.showLoading({
                title: '',
            })
        }
        // 是否已经进行过重试
        var hasRetried = false;

        if (requireLogin) {
            doRequestWithLogin();
        } else {
            doRequest();
        }

        // 登录后再请求
        function doRequestWithLogin() {
            loginLib.setLoginUrl(config.getSessionKeyUrl);
            loginLib.login({ success: doRequest, fail: callFail });
        }

        function doRequest (){

            var authHeader = buildAuthHeader(Session.get(),options);

            wx.request(untils.extend({},options,{
                header:untils.extend({}, originHeader, authHeader),
                success:function (response) {
                    var data = response.data;
                    if (data && data.code && data.code==108) {
                        Device.deleteSignSalt()
                        if (!hasRetried) {
                            hasRetried = true;
                            wx.login({
                                success:  (loginResult) =>{
                                    Login.login({authCode:loginResult.code}).then((resdata)=>{
                                        let res=resdata.data
                                        if(res  && res.code==100){
                                            if(res.data.subCode=='SUCCESS'){
                                                let data=res.data
                                                Device.setSignSalt(data.s)
                                                let user = Session.get()
                                                let info = untils.extend({}, user, {isLogin:1,sessionKey:data.sessionKey,uid:data.uid})
                                                Session.set(info)
                                                User.userInfo({uid:data.uid}).then((res)=>{
                                                    let resData=res.data
                                                    if(resData.code == 100){
                                                        let user=resData.data;
                                                        let data={
                                                            isLogin:1,
                                                            isMember:user.remainingDays>0,
                                                            remainingDays:user.remainingDays,
                                                            userInfo:{
                                                                nickName:user.nickname,
                                                                avatarUrl:user.avatar,
                                                            }
                                                        }
                                                        let userLocal = Session.get()
                                                        let info = untils.extend({}, userLocal, data)
                                                        Session.set(info)
                                                    }
                                                    doRequest ()
                                                })
                                            }else if(res.data.subCode=='NEED_BINDING'){
                                                wx.getSetting({
                                                    success: res => {
                                                        if (res.authSetting['scope.userInfo']) {
                                                            wx.navigateTo({
                                                                url: '/page/component/pages/loginByTel/login'
                                                            })
                                                        }else {
                                                            wx.navigateTo({
                                                                url: '/page/component/pages/authorize/authorize'
                                                            })
                                                        }
                                                    }
                                                })
                                            }else{
                                                wx.navigateTo({
                                                    url: '/page/component/pages/login/login'
                                                })
                                            }
                                            Device.setOpenId(res.data.openId)
                                        }else{


                                        }
                                    })
                                }
                            })
                            return
                        }
                        //     message = '登录态已过期';
                        //     error = new RequestError(constants.ERR_INVALID_SESSION, message);
                        // callFail(error);
                        //     error = new RequestError(constants.ERR_INVALID_SESSION, message);
                        // callFail(error);
                        // // 清除登录态
                        // Session.clear();
                        //
                        // var error, message;
                        //     // 如果是登录态无效，并且还没重试过，会尝试登录后刷新凭据重新请求
                        //     if (!hasRetried) {
                        //         hasRetried = true;
                        //         doRequestWithLogin();
                        //
                        //         return;
                        //     }
                        //     message = '登录态已过期';
                        //     error = new RequestError(constants.ERR_INVALID_SESSION, message);
                        // callFail(error);
                        return;
                    }
                    callSuccess.apply(null, arguments);
                },
                fail: callFail,
                complete: noop,
            }));
        }

    },
    setStorage:function(){
        var key,data,complete,fail;
        if(arguments.length===1 && untils.isObject(arguments[0]) && !untils.isArray(arguments[0])){//异步
            key = arguments[0].key;
            data = arguments[0].data;
            complete = arguments[0].complete;
            fail = arguments[0].fail;
            wx.setStorage({
                key:key,
                data:data,
                complete:function(data){
                    if(untils.isFunction(complete)){
                        complete(data);
                    }
                }
            });
        }else{//同步
            key = arguments[0];
            data = arguments[1];
            try{
                return wx.setStorageSync(key,data);
            }catch(e){
                console.error(e);
            }
        }
    },
    getStorage:function(){
        var key,complete,fail;
        if(arguments.length===2){//异步
            key = arguments[0];
            complete = arguments[1];
            wx.getStorage({
                key:key,
                complete:function(data){
                    if(untils.isFunction(complete)){
                        complete(data);
                    }
                }
            });
        }else{//同步
            key = arguments[0];
            try{
                return wx.getStorageSync(key);
            }catch(e){
                console.error(e);
            }
        }
    },
    clearStorage:function(){
        try{
            return wx.clearStorageSync();
        }catch(e){
            console.error(e);
        }
    },
    showMsg:function (msg,title,color,callback) {
        wx.showModal({
            title: title?title:'提示',
            content: msg,
            showCancel:false,
            confirmColor:color?color:'#ff544b',
            success: function(res) {
                callback && callback(res)
            }
        })
    }
};

module.exports = handle;