/**
 * Created by ahu on 2017/11/30.
 */
var constants = require('./lib/constants');
var comm = require('./common');
var WX_CLOTHESCOUNT_KEY = constants.WX_CLOTHESCOUNT_KEY;
const getClothesCountInBoxUrl = require('../config').getClothesCountInBoxUrl;
var Clothes = {
    clothesCountInBox:0,
    init:function () {
    },
    getForRq:function (calback) {
        var _t=this;
        comm.request({
            url:getClothesCountInBoxUrl,
            hideToast:true,
            success:function (res) {
                if(res.data && res.data.code==100){
                    calback && calback(res.data.data)
                }
            },
            fail:function () {

            }
        });
    },
    get: function (calback) {
        var _t=this;
        let clothes=wx.getStorageSync(WX_CLOTHESCOUNT_KEY);
        if(clothes){
            _t.clothesCountInBox=clothes.clothesCountInBox;
            calback && calback(clothes)
        }else{
            comm.request({
                url:getClothesCountInBoxUrl,
                success:function (res) {
                    if(res.data && res.data.code==100){
                        clothes=res.data.data;
                        _t.clothesCountInBox=clothes.clothesCountInBox;
                        calback && calback(clothes)
                    }
                    _t.set(clothes);
                },
                fail:function () {
                    _t.set(clothes);
                }
            });
        }
        return wx.getStorageSync(WX_CLOTHESCOUNT_KEY) || null;
    },
    set: function (clothes) {

        wx.setStorage({key:WX_CLOTHESCOUNT_KEY,data:clothes});
    },

    clear: function () {
        wx.removeStorageSync(WX_CLOTHESCOUNT_KEY);
    },
};

module.exports = Clothes;