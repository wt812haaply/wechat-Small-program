/**
 * Created by ahu on 2018/5/19
 */
module.exports= {
    prefix:'date_',
    getCookie:function (name) {
       if(this.checkCookie(name)){
           return wx.getStorageSync(name)
       }else{
           return ''
       }
    },
    checkCookie:function (name) {
        let timeStamp=wx.getStorageSync(this.prefix+name)
        if(timeStamp){
            if(new Date().getTime()>timeStamp){
                this.deleteCookie(name)
                return false
            }else {
                return true
            }
        }else{
            return true
        }
    },
    setCookie:function (name ,value, day) {//day 缓存天数
        wx.setStorageSync(name, value);
        if(day){
            wx.setStorageSync(this.prefix+name,new Date().getTime()+day* 24 * 60 * 60 * 1000)
        }
    },
    deleteCookie:function (name) {
        try {
          wx.removeStorageSync(name)
          wx.removeStorageSync(this.prefix+name)
        }catch (e){
          console.log(e)
        }
    }

}
