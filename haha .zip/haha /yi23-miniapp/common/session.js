var constants = require('./lib/constants');
var SESSION_KEY = constants.WX_SESSION_MAGIC_ID;
var sensors = require('../util/sensorsdata.min.js');
var Session = {
    get: function () {
        return wx.getStorageSync(SESSION_KEY) || null;
    },

    set: function (session) {
      sensors.login(session.uid);
      sensors.setProfile(session);
        wx.setStorageSync(SESSION_KEY, session);
    },

    clear: function () {
        wx.removeStorageSync(SESSION_KEY);
    },
};

module.exports = Session;