import Session from './session'
import Login from '../api/login'
import User from '../api/user'
import Device from './device'
var us = require('./lib/underscore.js')
var wishlistAction = require('../page/common/wishlist')
export default {
    isLogin(){
        let  userInfo= Session.get();
        let loginRes=false;
        if(userInfo && userInfo.isLogin==1){
            loginRes=true
        }
        return loginRes
    },
    updateUserInfo(){
       return new Promise((resolve,reject)=>{
           let uid=Session.get()?Session.get().uid:''
           User.userInfo({uid:uid}).then((res)=>{
               let resData=res.data
               if(resData.code == 100){
                   let user=resData.data;
                   let data={
                       isLogin:1,
                       isMember:user.remainingDays>0,
                       remainingDays:user.remainingDays,
                       userInfo:{
                           nickName:user.nickname,
                           avatarUrl:user.avatar,
                       }
                   }
                   let userLocal = Session.get()
                   let info = us.extend({}, userLocal, data)
                   Session.set(info)
               }
               resolve()
           })
       })

    },
    getLoginStatus(){
        return new Promise((resolve,reject)=>{
            wx.login({
                success:  (loginResult) =>{
                    Login.login({authCode:loginResult.code}).then((resdata)=>{
                        let res=resdata.data
                        if(res  && res.code==100){
                            let isLogin=false
                            if(res.data.subCode=='SUCCESS'){
                                isLogin =true
                                this.loginSucessLocalAction(res.data)
                            }
                            resolve({code:res.data.subCode,isLogin:isLogin,data:res.data})

                        }else{
                            reject(res.errMsg)
                        }
                    })
                }
            })
        })
    },
    login(){
       return this.getLoginStatus().then((res)=>{
            return new Promise((resolve,reject) => {
               if(res.code=='NEED_BINDING'){
                    Device.setOpenId(res.data.openId)
                    this.bindBefore()
                }else if(res.code=='MOBILE_ERROR'){
                    Device.setOpenId(res.data.openId)
                    wx.navigateTo({
                        url: '/page/component/pages/login/login'
                    })
                }
                resolve(res.code)
            })
        },(msg)=>{
            wx.showToast({
                title: msg,
                icon: 'none',
                duration: 2000
            })
        })
    },
    loginSucessLocalAction(data){
        Device.setSignSalt(data.s)
        let user = Session.get()
        let info = us.extend({}, user, {isLogin:1,sessionKey:data.sessionKey,uid:data.uid})
        Session.set(info)
        Device.setOpenId(data.specialId)
        this.updateUserInfo()
        wishlistAction.setWishlistProds()//更新 用户心愿单数据
    },
    bindBefore(){
        wx.getSetting({
            success: res => {
                if (res.authSetting['scope.userInfo']) {
                    wx.navigateTo({
                        url: '/page/component/pages/loginByTel/login'
                    })
                }else {
                    wx.navigateTo({
                        url: '/page/component/pages/authorize/authorize'
                    })
                }
            }
        })
    },
    bindMobile(dataJson){
        let referId = wx.getStorageSync('referId')
        if (referId) {
            dataJson.referId = referId
        }
        wx.getUserInfo({
            withCredentials:true,
            success:  userResult => {
                dataJson.encryptStr=userResult.encryptedData;
                dataJson.iv=userResult.iv;
                dataJson.openId=Device.getOpenId();
                Login.bind(dataJson).then((res)=>{
                    let data=res.data
                    if(data.code==100){
                        this.loginSucessLocalAction(data.data);
                        if(dataJson.mobile){//todo 手机号输入绑定 返回两层
                            wx.navigateBack({
                                delta: 2
                            })
                        }else{
                            wx.navigateBack({
                                delta: 1
                            })
                        }

                    }else{
                        wx.showToast({
                            title: data.msg,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                })
            },
            fail:  userError =>{
                wx.navigateTo({
                    url: '/page/component/pages/authorize/authorize'
                })
            }
        })
    }
}


