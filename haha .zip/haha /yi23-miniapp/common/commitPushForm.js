/**
 * Created by ahu on 2017/12/3.
 */
/**
 * Created by ahu on 2017/11/25.
 */
var comm = require('./common');
const commitPushFormUrl = require('../config').commitPushFormUrl;
var pushFormId = {
    send:function (formId,actionId) {
        console.log('----------formId------')
        console.log(formId)
        console.log('----------formId------')
        comm.request({
            url:commitPushFormUrl,
            hideToast:true,
            method:'POST',
            header:{'content-type':'application/x-www-form-urlencoded'},
            data:{
                formId:formId,
                actionId:actionId?actionId:1,
            },
            success:function (res) {
            },
            fail:function () {
            }
        });
    }
};

module.exports = pushFormId;