// const openIdUrl = require('./config').openIdUrl
var Region = require('./common/region.js');
var countAction = require('./common/countAction');
var sensors = require('./util/sensorsdata.min.js');
var Session = require('./common/session');
var constants = require('./common/lib/constants');
var WX_SCENE_KEY = constants.WX_SCENE_KEY;
var WX_SCENE_KEY_FLAG = constants.WX_SCENE_KEY_FLAG;
import Device from './common/device'
var pageView = require('./common/pageView.js');
var wishlistAction = require('./page/common/wishlist');
import base from './api/base.js';
import Auth from './common/auth';
App({
  onLaunch: function (options) {
      // if(!Device.getSalt()){
          base.helloWorld().then((res)=>{
              if(res && +res.data.code === 100){
                  Device.setSalt(res.data.data.s)
              }
          }).catch((res)=>{
              console.log(res);
          })
      // }
      //取消上来获取登陆处理
      // Login.login({//sessionkey获取
      //   success:function (res) {
      //
      //     console.log(res)
      //   },
      //   fail:(res)=>{
      //     console.log(res)
      //   }
      // })
      if(options.query.gdt_vid){
          countAction.setId(options.query.gdt_vid)
      }
      if(options.query.source){
          countAction.setSource(options.query.source)
      }
      Region.init();//定位处理
      var clientKey = Session.get();
      if(clientKey){
          clientKey.city = Region.get();
          sensors.login(clientKey.uid);
          sensors.setProfile(clientKey);
      }
      sensors.init();
      sensors.registerApp({
          PlatformType:'WX'
      });

  },
  onShow: function (options) {

    wx.removeStorageSync(constants.WX_REQUEST_INTERCEPT)
    if(options.scene){
      wx.setStorageSync(WX_SCENE_KEY,options.scene)
      if(options.scene==1036 || options.scene==1069 ){
        wx.setStorageSync(WX_SCENE_KEY_FLAG,true)
      }else if(options.scene!=1089 && options.scene!=1090){
        wx.setStorageSync(WX_SCENE_KEY_FLAG,false)
      }
    }
    if(Auth.isLogin()){
        Auth.updateUserInfo()
        wishlistAction.setWishlistProds()//更新 用户心愿单数据
    }
    this.contractCallback(options)
  },
  contractCallback:function (res) {
    if (res.scene === 1038) {
      const { appId, extraData } = res.referrerInfo
      if (appId == 'wxbd687630cd02ce1d') {
        if (typeof extraData == 'undefined'){
          // Session.clear();
          // Login.login({//sessionkey获取
          //   success:function (res) {
          //     console.log(res)
          //   },
          //   fail:(res)=>{
          //     console.log(res)
          //   }
          // })
          // wx.navigateTo({
          //   url: '/page/component/pages/openCardShim/openCardShim'
          // })
          wx.setStorageSync(constants.WX_CONTRACT_STATUS,1)
          return;
        }
        if(extraData.return_code == 'SUCCESS'){
          // console.log(extraData)
          wx.setStorageSync(constants.WX_CONTRACT_STATUS,2)
          // wx.navigateTo({
          //   url: '/page/component/pages/openCardSuccess/openCardSuccess'
          // })
          return;
        } else {
          wx.navigateTo({
            url: '/page/component/pages/payFailed/paystatus'
          })
          return;
        }
      }
    }
  },
  onHide: function () {
    console.log('App Hide')
    pageView.init()
    try{
      sensors.track('BTN_Close_Miniprogram',{'page':pageView.currPage.route});
    }catch (e){
      console.log(e)
    }
  },

  globalData: {
    hasLogin: false,
    openid: null,
    indexPopView: false, //首页弹窗是否开启过
    itemMaxShowNum:6,
    wishlistActionData:''
  },
  // lazy loading openid
  getUserOpenId: function(callback) {
    // var self = this
    // if (self.globalData.openid) {
    //   callback(null, self.globalData.openid)
    // } else {
    //   wx.login({
    //     success: function(data) {
    //       wx.request({
    //         url: openIdUrl,
    //         data: {
    //           code: data.code
    //         },
    //         success: function(res) {
    //           console.log('拉取openid成功', res)
    //           self.globalData.openid = res.data.openid
    //           callback(null, self.globalData.openid)
    //         },
    //         fail: function(res) {
    //           console.log('拉取用户openid失败，将无法正常使用开放接口等服务', res)
    //           callback(res)
    //         }
    //       })
    //     },
    //     fail: function(err) {
    //       console.log('wx.login 接口调用失败，将无法正常使用开放接口等服务', err)
    //       callback(err)
    //     }
    //   })
    // }
  }
})
