/**
 * Created by ahu on 2017/11/28.
 */
var wxService = require('../common/common.js')
var Login = require('../common/login.js')
var utils = require('../util/util.js')
const config = require('../config')
const loginUrl = config.loginUrl
const sendVerificationUrl = config.sendVerificationUrl
var handle = {
  getVerification: function (args) {
    wxService.request(utils.extend({}, args, {
      url: sendVerificationUrl,
      method: 'POST',
      header: {'content-type': 'application/x-www-form-urlencoded'}
    }))
  },
  bindMobile: function (args) {
    var urls = utils.extend({}, {
      url: loginUrl,
      method: 'POST',
      header: {'content-type': 'application/x-www-form-urlencoded'}
    }, args)
    wxService.request(urls)
  }
}
module.exports = handle