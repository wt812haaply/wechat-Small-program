/**
 * Created by ahu on 2017/11/20.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const listUrl = require('../config').listUrl;
var handle={
    queryList:function (args) {
        wxService.request(utils.extend({},args,{url:listUrl}));
    },
}
module.exports=handle;