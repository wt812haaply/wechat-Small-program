/**
 * Created by ahu on 2017/12/13.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const config = require('../config');
const productList = config.productList;
var handle={
    queryList:function (args) {
        wxService.request(utils.extend({},args,{url:productList}));
    },
}
module.exports=handle;