/**
 * Created by ahu on 2017/11/30.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
let config = require('../config');
let isNeedCheckUserIdentityCardUrl = config.isNeedCheckUserIdentityCardUrl;
let checkUserIdentityCardUrl = config.checkUserIdentityCardUrl;
var handle={
    isNeedCheckUserIdentityCard:function (args) {
        wxService.request(utils.extend({},args,{url:isNeedCheckUserIdentityCardUrl}));
    },
    checkUserIdentityCard:function (args) {
        wxService.request(utils.extend({},args,{url:checkUserIdentityCardUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    }
}
module.exports=handle;