/**
 * Created by ahu on 2017/11/29.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const config = require('../config');
const placeOrderUrl = config.placeOrderUrl;
const cancelPendingOrderUrl = config.cancelPendingOrderUrl;
var handle={
    placeOrder:function (args) {
        wxService.request(utils.extend({},args,{url:placeOrderUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    cancelPendingOrder:function (args) {
        wxService.request(utils.extend({},args,{url:cancelPendingOrderUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    }

}
module.exports=handle;