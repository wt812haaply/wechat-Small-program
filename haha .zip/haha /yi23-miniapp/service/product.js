/**
 * Created by ahu on 2017/11/22.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const config = require('../config');
const detailUrl = config.prodDetailUrl,
    addItemToCartUrl = config.addItemToCartUrl,
    productFeedbackUrl = config.productFeedbackUrl,
    recommendUrl = config.prodRecommendUrl;
var handle={
    queryProdDetail:function (args) {
        wxService.request(utils.extend({},args,{url:detailUrl}));
    },
    queryProductFeedback:function (args) {
        wxService.request(utils.extend({},args,{url:productFeedbackUrl}));
    },
    queryProdDetailRecommend:function (args) {
        wxService.request(utils.extend({},args,{url:recommendUrl}));
    },
    addItemToCart:function (args) {
        wxService.request(utils.extend({},args,{url:addItemToCartUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    }
}
module.exports=handle;