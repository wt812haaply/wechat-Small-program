/**
 * Created by ahu on 2017/11/28.
 */
var wxService = require('../common/common.js')
var utils = require('../util/util.js')
const config = require('../config')
const orderShareApplet = config.orderShareAppletUrl
const getRedPacketReceiveStatusUrl = config.getRedPacketReceiveStatusUrl
const getInvitationShareApplet = config.getInvitationShareApplet

var handle = {
  orderShareApplet: function (args) {
    wxService.request(utils.extend({}, args, {url: orderShareApplet}))
  },
  getRedPacketReceiveStatus: function (args) {
    wxService.request(utils.extend({}, args, {url: getRedPacketReceiveStatusUrl}))
  },
  getInvitationShareApplet: function (args) {
    wxService.request(utils.extend({}, args, { url: getInvitationShareApplet }))
  }

}
module.exports = handle