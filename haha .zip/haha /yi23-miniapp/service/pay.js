/**
 * Created by ahu on 2017/11/28.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const config = require('../config');
const payListUrl = config.payListUrl;
const payUrl = config.payUrl;
const cardListUrl = config.cardListUrl;
const purchaseCardUrl = config.purchaseCardUrl;
const couponListUrl = config.couponListUrl;
const validCouponListByPayTypeUrl = config.validCouponListByPayTypeUrl;
const bindingInvitationRelationUrl = config.bindingInvitationRelationUrl;
var handle={
    payList:function (args) {
        wxService.request(utils.extend({},args,{url:payListUrl}));
    },
    cardList:function (args){
      wxService.request(utils.extend({},args,{url:cardListUrl}));
    },
    purchaseCard:function (args) {
      wxService.request(utils.extend({},args,{url:purchaseCardUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}))
    },
    bindingInvitationRelation:function (args) {
      wxService.request(utils.extend({},args,{url:bindingInvitationRelationUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}))
    },
    pay:function (args) {
        wxService.request(utils.extend({},args,{url:payUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}))
    },
    getValidCouponListByPayType:function (args) {
        wxService.request(utils.extend({},args,{url:validCouponListByPayTypeUrl}))
    },
    getCouponList:function (args) {
        wxService.request(utils.extend({},args,{url:couponListUrl}));
    }

}
module.exports=handle;