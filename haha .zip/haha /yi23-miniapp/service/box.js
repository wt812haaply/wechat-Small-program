/**
 * Created by ahu on 2017/11/25.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
let userBoxUrl = require('../config').userBoxUrl;
let userBoxRemoveItemUrl = require('../config').userBoxRemoveItemUrl;
var handle={
    queryUserBoxList:function (args) {
        // userBoxUrl=userBoxUrl+'?access=7aa7a4a933ab86f1532be7372d42d1af&device=iPhone&deviceId=D90A22F0-1D5D-4C41-81D2-F5BAF12180FF1502184724&regionId=52&signature=34MBkqMBaHOInbThXFqsRYtooFm4EuJ221L%2B5EXjra0OlNkHbmq6DLLiNoEU5NMr7vXX9F2IuuRDJYO81AHjt9kx6WhyFSD6e%2BP1lZNhNXmJ4YfhlCP2cUN32FVa0Dj/FhxK1S6MAq1qE6Cv8/najqDPKRfoDS3ivhtOigctQRA%3D&timestamp=1511347350&uid=5065351&version=2.6.4&wid=cf123f62-d997-4d76-a0a7-b6d26821fcfe'
        wxService.request(utils.extend({},args,{url:userBoxUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    delUserBoxItemList:function (args) {
        wxService.request(utils.extend({},args,{url:userBoxRemoveItemUrl,method:'PUT',header:{'content-type':'application/x-www-form-urlencoded'}}));
    }
}
module.exports=handle;