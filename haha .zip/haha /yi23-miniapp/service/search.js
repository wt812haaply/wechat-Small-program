/**
 * Created by ahu on 2017/11/22.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const url = require('../config').searchTagsUrl;
var handle={
    queryTagsList:function (args) {
        wxService.request(utils.extend({},args,{url:url}));
    },

}
module.exports=handle;