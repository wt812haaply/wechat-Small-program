/**
 * Created by ahu on 2018/1/24.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
let checkUserZhimaUrl = require('../config').checkUserZhimaUrl;
var handle={
    checkUserZhima:function (args) {
        wxService.request(utils.extend({},args,{url:checkUserZhimaUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    }
}
module.exports=handle;