/**
 * Created by ahu on 2017/11/24.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const addAddrUrl = require('../config').addAddrUrl;
const addrListUrl = require('../config').addrListUrl;
const editAddrUrl = require('../config').editAddrUrl;
const delAddrUrl = require('../config').delAddrUrl;
const serviceAreaListUrl = require('../config').serviceAreaListUrl;
var handle={
    queryAddrList:function (args) {
        wxService.request(utils.extend({},args,{url:addrListUrl}));
    },
    addAddr:function (args) {
        wxService.request(utils.extend({},args,{url:addAddrUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    editAddr:function (args) {
        wxService.request(utils.extend({},args,{url:editAddrUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    delAddr:function (args) {
        wxService.request(utils.extend({},args,{url:delAddrUrl}));
    },
    queryServiceAreaList:function (args) {
        wxService.request(utils.extend({},args,{url:serviceAreaListUrl}));
    }

}
module.exports=handle;