/**
 * Created by ahu on 2017/11/20.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const url = require('../config').indexUrl;
const homeUrl = require('../config').homePageTopV2;
const popupView = require('../config').popupView;
var handle={
    queryList:function (args) {
        wxService.request(utils.extend({},args,{url:url}));
    },
    queryHome:function (args) {
        wxService.request(utils.extend({},args,{url:homeUrl}));
    },
    popupView:function(args){
        wxService.request(utils.extend({},args,{url:popupView}));
    }
}
module.exports=handle;