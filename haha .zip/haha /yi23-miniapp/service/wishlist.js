/**
 * Created by ahu on 2017/11/24.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const wishlistPidsUrl = require('../config').wishlistPidsUrl;
const wishlistUrl = require('../config').wishlistUrl;
const addWishListItemUrl = require('../config').addWishListItemUrl;
const delWishListItemUrl = require('../config').delWishListItemUrl;
const wishlistShareUrl = require('../config').wishlistShareUrl;

var handle={
    wishlistPids:function (args) {
        wxService.request(utils.extend({},args,{url:wishlistPidsUrl}));
    },
    addWishListItem:function (args) {
        wxService.request(utils.extend({},args,{url:addWishListItemUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    delWishListItem:function (args) {
        wxService.request(utils.extend({},args,{url:delWishListItemUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    wishlist:function (args) {
        wxService.request(utils.extend({},args,{url:wishlistUrl}));
    },
    share:function (args) {
        wxService.request(utils.extend({},args,{url:wishlistShareUrl}));
    }
}
module.exports=handle;