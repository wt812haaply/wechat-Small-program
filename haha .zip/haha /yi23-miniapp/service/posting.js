/**
 * Created by ahu on 2017/11/22.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const config = require('../config');
const postingUrl = config.postingUrl;
const promotionCouponSetUrl = config.promotionCouponSetUrl;
const registerAndPromotionUrl = config.registerAndPromotionUrl;
var handle={
    queryPosting:function (args) {
        wxService.request(utils.extend({},args,{url:postingUrl}));
    },
    promotionCouponSet:function (args) {
        wxService.request(utils.extend({},args,{url:promotionCouponSetUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    },
    registerAndPromotion:function (args) {
        wxService.request(utils.extend({},args,{url:registerAndPromotionUrl,method:'POST',header:{'content-type':'application/x-www-form-urlencoded'}}));
    }
}
module.exports=handle;