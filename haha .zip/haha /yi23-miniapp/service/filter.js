/**
 * Created by ahu on 2017/12/11.
 */
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
const config = require('../config');
const productFiltersUrl = config.productFiltersUrl;
var handle={
    queryProductFilters:function (args) {
        wxService.request(utils.extend({},args,{url:productFiltersUrl}));
    }
}
module.exports=handle;