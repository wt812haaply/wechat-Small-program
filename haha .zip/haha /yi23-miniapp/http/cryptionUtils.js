let secret =require('./secret.js');
import Device from '../common/device';
let utils =require('../util/util.js');

function getDecryptAesString(salt){

  const key = "yiiiiiiiiiiiii23";
  const iv = "1236585215963214";
  
  const decryptStr = secret.decrypt.AES(salt,key,iv);
  return decryptStr;
}

function getMD5Hash(params,signString){
  const value= Object.keys(params)
      .filter((el)=>el.toString().indexOf('[]')==-1)
      .map(key=> params[key])
      .join('')
  const string = `${value}${signString}`;
  return secret.encrypt.MD5(string);
}

function transformDataByMD5(data){
  const sign = Device.getSignSalt()|| Device.getSalt();
  let transformData = utils.sorting(data);
  if(sign){
    const signString = getDecryptAesString(sign);
    transformData['sign'] = getMD5Hash(transformData,signString);
  }
  return transformData;
}

module.exports={
  getDecryptAesString,
  getMD5Hash,
  transformDataByMD5
}

