
let constants = require('../common/lib/constants');
let countAction =require('../common/countAction');
import region from '../common/region'
import  session from '../common/session';
import  deviceAction from '../common/device';

const getBaseOptions = function(){
  const uid = session.get() && session.get().uid || 0;
  const yi23Source = countAction.getSource() || 0;
  const regionId = region.get()?region.get().rgnId:52;
  const device = constants.WX_DEVICE;
  const deviceId = deviceAction.getId();
  const timestamp = new Date().getTime();
  const version = constants.WX_VERSION_NEW;
  return {
    uid,
    version,
    deviceId,
    regionId,
    device,
    timestamp,
    yi23Source
  }

}


module.exports=getBaseOptions