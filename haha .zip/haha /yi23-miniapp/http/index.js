import $http from './http.js';
import Device from '../common/device';
import Auth from '../common/auth';
const regeneratorRuntime = require('../util/runtime.js')
var pageView = require('../common/pageView.js');
const pollingSign = function(config){
  return new Promise(resolve => {
    let count = 0;
    let timer = setInterval(()=>{
      count++
      console.log(count);
      if(Device.getSalt() || count >= 5){
        resolve(config)
        clearInterval(timer);
      }
    },1000)
  })
}
let authLock=false
$http.interceptors.request.use(
  async function onFulfilled(config){
    wx.showLoading({
      title: '',
    })
    const url = config.url;
    if(/\/helloWorld/.test(url) || Device.getSalt()){
      return config;
    }else{
      config = await pollingSign(config);
      return config;
    }
  },
  function onRejected(config){
    console.log('config拦截器失败了')
  }
)


$http.interceptors.response.use(
  function onFulfilled(response){
           wx.hideLoading()
      const code = +response.data.code
      switch (code){
          case 10000:
              wx.showToast({
                  title: response.data.msg,
                  icon: 'none',
                  duration: 2000
              })
          case 10002:
              if(!authLock){
                  authLock = true
                  Device.deleteSignSalt()
                  Auth.getLoginStatus().then(res => {
                      if(res.code=='SUCCESS'){
                          pageView.init();
                          let options=pageView.currPage.options
                          let params=[]
                          let str=''
                          for(var k in options){
                              params.push(k+'='+options[k])
                          }
                          if(params.length>0){
                              str='?'+params.join('&')
                          }
                          console.log(pageView.currPage.route+str)
                          wx.redirectTo({
                              url: '/'+pageView.currPage.route+str
                          })
                          authLock = false
                      }

                  })
              }
          default:
              return response;

      }

  },
  function onRejected(reason){
    console.log('我是拦截器失败')
      wx.hideLoading()
  }
)

export default $http;