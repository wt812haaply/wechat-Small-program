var CryptoJS = require('../cryptoJs/crypto-js')

function DecryptAES(seversSign,originKey,originIv){

  //十六位十六进制数作为密钥
  const key = CryptoJS.enc.Utf8.parse(originKey);  
  const iv = CryptoJS.enc.Utf8.parse(originIv);

  let decrypt = CryptoJS.AES.decrypt(seversSign, key, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
  if(decrypt){
    return CryptoJS.enc.Utf8.stringify(decrypt);
  }else{
    return ''
  }
}

function EncryptMD5(string){
  return CryptoJS.MD5(string).toString();
}

module.exports= {
  encrypt:{
    MD5:EncryptMD5
  },
  decrypt:{
    AES:DecryptAES
  }
}