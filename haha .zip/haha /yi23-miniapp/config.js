/**
 * 小程序配置文件
 */
// var host = "api.95vintage.com";
// var hostMs='api.95vintage.com';

// var host = "devapi.95vintage.com";
// var hostMs='testapi.95vintage.com';

    let host='stageapi.95vintage.com'
    let hostMs='stageapi.95vintage.com'
var config = {
    host,
    hostMs,
    // 登录地址，用于建立会话
    loginUrl: `https://${host}/mp/auth/normalLogin`,
    //短信验证码
    sendVerificationUrl: `https://${host}/mp/auth/sendVerification`,
    getSessionKeyUrl: `https://${host}/mp/auth/wechatSessionKeyFinder`,
    //短列表
    listUrl: `https://${host}/mp/product/productSearch`,
    //首页展示
    indexUrl:`https://${host}/mp/page/homepage`,
    homePageTopV1:`https://${host}/mp/page/homePageTopV1`,
    homePageTopV2:`https://${host}/mp/page/homePageTopV2`,
    //新版首页接口
    homeUrl:`https://${host}/mp/page/homePageTop`,

    //搜索提示
    searchTagsUrl:`https://${host}/mp/product/searchTags`,


    //商品详情主信息
    prodDetailUrl:`https://${host}/mp/product/productDetail`,
    //商品评价信息
    productFeedbackUrl:`https://${host}/mp/product/productFeedback`,
    //商品详情推荐信息
    prodRecommendUrl:`https://${host}/mp/product/productDetailRecommend`,
    //加入衣箱
    addItemToCartUrl:`https://${host}/mp/order/addItemToCart`,


    //城市地区处理
    serviceAreaListUrl:`https://${host}/mp/addr/serviceAreaList`,

    //查看收货地址获取
    addrListUrl:`https://${host}/mp/addr/addrList`,
    //修改收货地址
    editAddrUrl:`https://${host}/mp/addr/editAddr`,
    //增加收货地址
    addAddrUrl:`https://${host}/mp/addr/addAddr`,
    //删除收货地址
    delAddrUrl:`https://${host}/mp/addr/deleteAddr`,

    //衣箱页面接口
    userBoxUrl:`https://${host}/mp/order/userBoxList`,
    //衣箱删除衣服
    userBoxRemoveItemUrl:`https://${host}/mp/order/removeItemFromCart`,
    //获取用户衣箱衣服件数
    getClothesCountInBoxUrl:`https://${host}/mp/user/getClothesCountInBox`,
    //经纬度转地区
    locationCityRegionIdUrl:`https://${host}/mp/auth/locationCityRegionId`,

    //可购买会员列表
    payListUrl:`https://${host}/mp/pay/payList`,
    cardListUrl:`https://${host}/mp/pay/cardList`,
    //邀请码激活
    bindingInvitationRelationUrl:`https://${host}/mp/pay/bindingInvitationRelation`,
    //生成支付参数
    payUrl:`https://${host}/mp/pay/pay`,
    purchaseCardUrl:`https://${host}/mp/pay/purchaseCard`,
    //获取模版推送消息
    commitPushFormUrl:`https://${host}/mp/user/commitPushForm`,
    //用户优惠券
    couponListUrl:`https://${host}/mp/user/couponList`,
    //获取可用优惠券
    validCouponListByPayTypeUrl:`https://${host}/mp/user/validCouponListByPayType`,
    //生成订单
    placeOrderUrl: `https://${host}/mp/order/placeOrder`,
    //取消临时订单
    cancelPendingOrderUrl: `https://${host}/mp/order/cancelPendingOrder`,

    //校验用户身份证号
    checkUserIdentityCardUrl: `https://${host}/mp/user/checkUserIdentityCard`,
    //判断是否上传身份证件号
    isNeedCheckUserIdentityCardUrl: `https://${host}/mp/user/isNeedCheckUserIdentityCard`,

    //筛选接口
    productFiltersUrl: `https://${host}/mp/filter/productFilters`,
    //大列表
    productList: `https://${host}/mp/product/productList`,
    //posting页面
    postingUrl: `https://${host}/mp/page/posting`,
    //posting页面领券
    promotionCouponSetUrl: `https://${host}/mp/user/promotionCouponSet`,
    //posting页面手机号领券页面
    registerAndPromotionUrl: `https://${host}/mp/user/registerAndPromotion`,

    //芝麻信用
    checkUserZhimaUrl: `https://${host}/mp/auth/checkUserZhima`,

    //微信统计
    reportPromotionEventUrl : `https://${host}/mp/auth/reportPromotionEvent`,

    //首页弹窗配置展示接口
    popupView:`https://${host}/mp/page/popupView`,

    //心愿单查询接口 返回商品id
    wishlistPidsUrl : `https://${host}/mp/product/wishlistPids`,
    //心愿单查询接口 返回商品详细信息
    wishlistUrl : `https://${host}/mp/product/wishlist`,
    //心愿单分享承接
    wishlistShareUrl : `https://${hostMs}/ms/wish/v1/favor/share`,
    //心愿单 添加
    addWishListItemUrl : `https://${host}/mp/product/addWishListItem`,
    //心愿单 删除
    delWishListItemUrl : `https://${host}/mp/product/delWishListItem`,
    //老带新落地页
    orderShareAppletUrl : `https://${host}/mp/order/orderShareApplet`,
    //老带新 领取
    getRedPacketReceiveStatusUrl : `https://${host}/mp/user/getRedPacketReceiveStatus`,
    // 面对面
    getInvitationShareApplet: `https://${host}/mp/user/invitationShareApplet`,

};

module.exports = config
