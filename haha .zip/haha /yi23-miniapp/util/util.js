/**
 * Created by ahu on 2017/11/15.
 */
function formatTime(time) {
    if (typeof time !== 'number' || time < 0) {
        return time
    }

    var hour = parseInt(time / 3600)
    time = time % 3600
    var minute = parseInt(time / 60)
    time = time % 60
    var second = time

    return ([hour, minute, second]).map(function (n) {
        n = n.toString()
        return n[1] ? n : '0' + n
    }).join(':')
}

function timeFormat(timestamp) {
    const date = new Date(timestamp)
    let y = date.getFullYear();
    let m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    let d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    return y + '.' + m + '.' + d
}

function formatLocation(longitude, latitude) {
    if (typeof longitude === 'string' && typeof latitude === 'string') {
        longitude = parseFloat(longitude)
        latitude = parseFloat(latitude)
    }

    longitude = longitude.toFixed(2)
    latitude = latitude.toFixed(2)

    return {
        longitude: longitude.toString().split('.'),
        latitude: latitude.toString().split('.')
    }
}
/**
 * 拓展对象
 */
 function extend(target) {
    var sources = Array.prototype.slice.call(arguments, 1);

    for (var i = 0; i < sources.length; i += 1) {
        var source = sources[i];
        for (var key in source) {
            if (source.hasOwnProperty(key)) {
                target[key] = source[key];
            }
        }
    }

    return target;
};
 function isObject (obj) {
    var type = typeof obj;
    return type === 'function' || type === 'object' && !! obj;
}
var searchAction =function (search,name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = search.match(reg);
    if (r != null) return decodeURI(r[2]);
    return null;
}
function jumpUrlAction(urls){
    var urls='https://www.95vintage.com/yi23/Home/Others/jumpNativePage.html?jumpNativeType=47&jumpNativeId=kf_9515_1512620101745';
    var search= urls.split('?')[1],hasJump=urls.indexOf('jumpNativeType')!=-1;
    if(hasJump){

    }else{

    }
}

 /**
 * 时间转换年月日格式化补0 例：19891209
 */
 function toLocaleDateStringFormat(time){
    let date = new Date(time);
    let format = date.toLocaleDateString();
    let dateArr = format.split('/').map((el)=>{
    if(Number(el) < 10){
        el= '0'+el;
    }
    return el;
    })
    return dateArr.join('');
}
function createdQueryWidthUrl(query, url) {

    query = query || {};

    var urlArr = url.split('?');
    var queryArr = [];

    if (urlArr.length > 1 && urlArr[1]) {
        queryArr = urlArr[1].split('&');
    }

    Object.keys(query).forEach(item => {
        queryArr.push(`${item}=${query[item]}`);
    });

    const queryString = queryArr.join('&');

    if(typeof  queryString === 'string'){
        url = `${urlArr[0]}?${queryArr.join('&')}`;
    }else{
        url = `${urlArr[0]}`
    }


    return url;
};

function sorting(arr) {
    let keys = Object.keys(arr).sort(function (a, b) {
        return a.toLowerCase().localeCompare(b.toLowerCase());
    });
    let objArr = {};
    for(let i = 0; i<keys.length; i++){
        objArr[keys[i]] = arr[keys[i]];
    }
    return objArr
}
module.exports = {
    timeFormat:timeFormat,
    formatTime: formatTime,
    formatLocation: formatLocation,
    extend:extend,
    isObject:isObject,
    toLocaleDateStringFormat:toLocaleDateStringFormat,
    createdQueryWidthUrl,
    sorting
}
