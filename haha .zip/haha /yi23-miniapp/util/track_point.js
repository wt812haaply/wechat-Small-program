// var sensors = require('./sensorsdata.js');
var app = getApp();
var _track = {};
var countAction = require('../common/countAction.js');
var reportPromotionEventUrl = require('../config').reportPromotionEventUrl;
var wxService = require('../common/common.js');
var utils = require('../util/util.js');
var handle = {
    postCompleteUrl : function (args) {
        wxService.request(utils.extend({},args,{url:reportPromotionEventUrl,method:'POST',header:{'Content-Type': 'application/x-www-form-urlencoded'}}));
    }
}

//支付成功：支付成功
_track.paySuccess = function (res) {
    console.log('_track paySuccess');
    try{
        // var click_id = countAction.getId();
        app.sensors.track('paySuccess',res);
        if(countAction.getId)
            _track.paySuccessWx(res);
    }catch (e){
        console.log(e);
    }
};

// 微信统计: 支付成功 金额 clickId
_track.paySuccessWx = function (trackPayMoney) {
    console.log('_track paySuccessWx');
    let payMoney = trackPayMoney || 0;
    try{
        // countAction.setId(22);
        handle.postCompleteUrl({
            data:{
                amount : payMoney
            },
            success:function (res) {
                console.log(res);
            }
        })
    }catch (e){
        console.log(e);
    }
};

//支付金额
// _track.payMoney = function (res) {
//     console.log('_track.payMoney');
//     try{
//         app.sensors.track('payMoney',{res});
//         trackPayMoney = res;
//     }catch (e){
//         console.log(e);
//     }
// };

//登陆成功：手机号
_track.mobile = function (res) {
    console.log('_track mobile');
   try{
       app.sensors.track('mobile',{res});
   }catch (e){
      console.log(e);
   }
};

//次banner点击
_track.getBanner = function (res) {
    console.log('_track.getBanner');
    try{
        app.sensors.track('getBanner',{res});
    }catch (e){
        console.log(e);
    }
};

//后台弹窗浏览
_track.popViewVisit = function (res) {
    console.log('_track popViewVisit');
    try{
        app.sensors.track('popViewVisit',res);
    }catch (e){
        console.log(e);
    }
};

//后台弹窗点击
_track.popviewTapCount = function (res) {
    console.log('_track popviewTapCount');
    try{
        app.sensors.track('popviewTapCount',res);
    }catch (e){
        console.log(e);
    }
};


_track.clickCount = function (name,res) {
  res=res?res:{}
  try{
    app.sensors.track(name,res);
  }catch (e){
    console.log(e);
  }
};


module.exports = _track;