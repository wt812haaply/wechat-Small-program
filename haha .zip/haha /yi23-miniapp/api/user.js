import $http from '../http/index'
import config from '../config.js';

const handle = {
    myPage() {
        return $http.get(`https://${config.hostMs}/gw/ms/user/v1/myPage`)
    },
    userInfo(options) {
        return $http.get(`https://${config.hostMs}/ms/user/v1/${options.uid}`)
    },
    clothCouponList() {
        return $http.get(`https://${config.hostMs}/gw/ms/coupon/v1/clothCouponList`)
    },
    invitationSharePageInfo(){
        return $http.get(`https://${config.hostMs}/gw/ms/user/v1/invitationSharePageInfo`)
    }
}
export default handle;