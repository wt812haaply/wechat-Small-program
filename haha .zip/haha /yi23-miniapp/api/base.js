import $http from '../http/index'
import config from '../config.js';

const handle = {
    helloWorld() {
        return $http.post(`https://${config.hostMs}/ms/app/v1/helloWorld`)
    }
}
export default handle;