import $http from '../http/index'
import config from '../config.js';

const handle = {
    login(args) {
        return $http.post(`https://${config.hostMs}/ms/user/v1/login/applet/login`,args)
    },
    bind(args) {
        return $http.post(`https://${config.hostMs}/ms/user/v1/login/applet/bind`,args)
    },
    sendVerification(args) {
        return $http.post(`https://${config.hostMs}/gw/user/sendVerification`,args)
    }
}
export default handle;