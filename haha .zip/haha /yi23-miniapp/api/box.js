import $http from '../http/index'
import config from '../config.js';

const handle = {
    userCloset() {
        return $http.get(`https://${config.hostMs}/gw/order/userCloset`)
    },
    cancelAddClothCoupon() {
        return $http.post(`https://${config.hostMs}/gw/coupon/cancelAddClothCoupon`)
    },
    useAddClothCoupon(args){
        return $http.post(`https://${config.hostMs}/gw/coupon/useAddClothCoupon`,args)
    },
    placeOrderUrl(args) {
    return $http.post(`https://${config.hostMs}/gw/order/placeOrder`,args)
   }
}
export default handle;