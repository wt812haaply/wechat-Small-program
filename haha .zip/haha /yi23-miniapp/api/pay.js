import $http from '../http/index'
import config from '../config.js';

const handle = {
    pay(options){
        return $http.post(`https://${config.hostMs}/gw/pay/pay`,options)
    }
}
export default handle;