import $http from '../http/index'
import config from '../config.js';

const handle = {
  addrListUrl(args) {
    return $http.get(`https://${config.hostMs}/gw/addr/addrList`,{params:args})
  }
}
export default handle;