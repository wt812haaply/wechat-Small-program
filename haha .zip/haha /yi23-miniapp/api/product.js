import $http from '../http/index'
import config from '../config.js';

const handle = {
    productDetailRecommend(args) {
        return $http.get(`https://${config.hostMs}/gw/product/productDetailRecommend`,{params:args})
    },
    pointItemDetail(args) {
        return $http.get(`https://${config.hostMs}/gw/product/pointItemDetail`,{params:args})
    },
    productFeedback(args) {
        return $http.get(`https://${config.hostMs}/gw/product/productFeedback`,{params:args})
    },
    newproductDetail(args) {
        return $http.get(`https://${config.hostMs}/gw/product/newproductDetail`,{params:args})
    }
}
export default handle;