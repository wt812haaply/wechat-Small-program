var indexService = require('../../service/index.js');
var bindMobile = require('../../service/bindMobile');
var Session = require('../../common/session.js');
var commitPushForm = require('../../common/commitPushForm');
var ClothesCount = require('../../common/clothesCount');
Page({
    data:{
        clothesCountInBox:0,
        showShareBox:false
    },
    onLoad:function (options) {
        var _t=this;
        var referId=options.referId;
        if(referId){
            _t.referAction(referId);
        }
        wx.showLoading({
            title: ''
        })
        _t.initData();
        // window.location.href='http://a.app.qq.com/o/simple.jsp?pkgname=com.yiersan'
    },
    onShow:function () {
        var _t=this;
        ClothesCount.getForRq(function (res) {
            _t.setData(res)
        })
    },
    //此为搜索相关的函数
    inputfocus:function(e){
        console.log(e);
        wx.navigateTo({
            url: "./pages/search/search"
        })
    },
    toList:function (event) {
        var searchkey= event.currentTarget.dataset.searchkey;
        console.log(searchkey);
        wx.navigateTo({
            url: './pages/list/list?searchKey='+searchkey
        })
    },
    initData: function() {
        var _t=this;
        indexService.queryList({
            success:function (res) {
                console.log(res)
                if(res.data && res.data.code==100){
                    _t.setData(res.data.data)
                }
            }
        })
    },
    goUserBox:function (event) {
        let formId = event.detail.formId;
        commitPushForm.send(formId);
        wx.navigateTo({
            url: '/page/component/pages/box/box'
        })
    },
    clearAllBtn:function () {
        wx.clearStorageSync();
    },
    onShareAppMessage: function (res) {
        var userInfo= Session.get(),referId='';
        if(userInfo.uid){
            referId='?referId='+userInfo.uid
        }
        return {
            title: '快来和我一起包月换穿全球大牌时装',
            imageUrl:'https://yimg.yi23.net/webimg/web/images/2018/1207/share_222.png',
            path: '/page/component/index'+referId,
            success: function(res) {
                // 转发成功
            },
            fail: function(res) {
                // 转发失败
            }
        }
    },
    // 新老带新 处理
    referAction:function (referId) {
        var _t=this;
        var userInfo= Session.get();
        if(userInfo && userInfo.isMember==1){
            return false;
        }
        wx.setStorage({
            key:'referId',
            data:referId,
            complete:function(data){

            }
        });
        _t.setData({showShareBox:true});
    },
    toPostingPage:function () {
        wx.navigateTo({
            url: '/page/component/pages/posting/posting'
        })
    },
    closeShareBox:function () {
        var _t=this;
        _t.setData({
            showShareBox:false
        })
    }
})
