var addrService = require('../../../../service/addr.js');
var us = require('../../../../common/lib/underscore.js');
var areaList = require('../../../../common/lib/cityJSON').data;
Page({
  data:{
      isVisible: false,
      animationData: {},
      animationAddressMenu: {},
      addressMenuIsShow: false,
      addressInfo:'',
      value: [0, 0, 0],
      address:'',
      areaList:'',
      addrId:'',
      provinces: [],
      citys: [],
      areas: [],
      areaInfo:'',
      areaId: ''
  },
  onLoad: function (options) {
      var _t=this;
      try{
          if(options.info){
              var addressInfo=JSON.parse(options.info);
             _t.setData({addressInfo:addressInfo,areaInfo:addressInfo.province+' '+addressInfo.city+' '+addressInfo.country,addrId:addressInfo.addrId,areaId:addressInfo.rgn}) ;
          }else{
              wx.setNavigationBarTitle({
                  title: '添加地址'
              })
          }
      }catch (e){
          console.log(e)
      }
      // _t.areaListInit(function (res) {
      //     console.log(res)
          // areaList=res.data.data;
          var animation = wx.createAnimation({
              duration: 500,
              transformOrigin: "50% 50%",
              timingFunction: 'ease',
          })
          _t.animation = animation;
          // 默认联动显示北京
          var id = 0,
              provinces=areaList.str.split(','),
              citys=areaList.list[provinces[id]].str.split(','),
              areas=areaList.list[provinces[id]].list[citys[id]];

          _t.setData({
              provinces: provinces,
              citys: citys,
              areas: areas,
          })
          console.log(_t.data)
      // });


  },
  // areaListInit:function (callback) {
  //   var _t=this;
  //
  //     addrService.queryServiceAreaList({
  //         hideToast:true,
  //         data:{version:'2.6.4'},//todo以后去掉
  //         success:function (res) {
  //             console.log(res)
  //             callback && callback(res);
  //         }
  //     })
  // },
    //form表单提交
    formSubmit:function (e) {
      var _t=this;
        console.log('form发生了submit事件，携带数据为：', e.detail.value);
        var info=e.detail.value;
        console.log(_t.data)
        if(info.consignee==''){
            wx.showToast({
                title: '姓名不能为空',
                duration: 1500
            })
        }else if(info.mobile=='' || info.mobile.length!=11){
            wx.showToast({
                title: '手机号不正确',
                duration: 1500
            })
        }else if(_t.data.areaId==''){
            wx.showToast({
                title: '请选择所在区域',
                duration: 1500
            })
        }else if(info.address==''){
            wx.showToast({
                title: '详细地址不能为空',
                duration: 1500
            })
        }else{
            if(_t.data.addrId==''){//新增收货地址
                _t.addAddr(us.extend({},info,{rgn:_t.data.areaId}));

            }else{//修改收货地址
                _t.editAddr(us.extend({},info,{rgn:_t.data.areaId,addrId:_t.data.addrId}));
            }
        }
    },
    editAddr:function (info) {
      console.log(info)
        addrService.editAddr({
           data:info,
            success:function (res) {
                console.log('editAddr:'+ res);
                if(res.data && res.data.code==100){
                    wx.navigateBack({
                        delta: 1
                    })
                }else{
                    wx.showToast({
                        title: res.data.msg,
                        duration: 1500
                    })
                }

            }
        });
    },
    addAddr:function (info) {
        console.log(info)
        addrService.addAddr({
            data:info,
            success:function (res) {
                console.log('editAddr:'+ res);
                if(res.data && res.data.code==100){
                    wx.navigateBack({
                        delta: 1
                    })
                }else{
                    wx.showToast({
                        title: res.data.msg,
                        duration: 1500
                    })
                }
            }
        });
    },
    /* 省市区 级联*/
    // 城市级联
    startAnimation: function (isShow, offset) {
        var that = this
        var offsetTem
        if (offset == 0) {
            offsetTem = offset
        } else {
            offsetTem = offset + 'rpx'
        }
        this.animation.translateY(offset).step()
        this.setData({
            animationData: this.animation.export(),
            isVisible: isShow
        })
    },
    // 点击所在地区弹出选择框
    selectDistrict: function (e) {
        var that = this
        if (that.data.addressMenuIsShow) {
            return
        }
        that.startAddressAnimation(true)
    },
    // 执行动画
    startAddressAnimation: function (isShow) {
        console.log(isShow)
        var that = this
        if (isShow) {
            that.animation.translateY(0 + 'vh').step()
        } else {
            that.animation.translateY(40 + 'vh').step()
        }
        that.setData({
            animationAddressMenu: that.animation.export(),
            addressMenuIsShow: isShow,
        })
    },
    // 点击地区选择取消按钮
    cityCancel: function (e) {
        this.startAddressAnimation(false)
    },
    // 点击地区选择确定按钮
    citySure: function (e) {
        var that = this
        var value = that.data.value
        that.startAddressAnimation(false);
        // 将选择的城市信息显示到输入框
        var areaInfo = that.data.provinces[value[0]] + ' ' + that.data.citys[value[1]] + ' ' + that.data.areas[value[2]].name;
        that.setData({
            areaInfo: areaInfo,
            areaId:that.data.areas[value[2]].rgn
        })
        console.log(that.data);
    },
    hideCitySelected: function (e) {
        console.log(e)
        this.startAddressAnimation(false)
    },
    // 处理省市县联动逻辑
    cityChange: function (e) {
        var value = e.detail.value
        var provinceNum = value[0],
            cityNum = value[1],
            countyNum = value[2],
            provinces = this.data.provinces,
            citys = areaList.list[provinces[provinceNum]].str.split(','),
            areas = areaList.list[provinces[provinceNum]].list[citys[cityNum]];
        if (this.data.value[0] != provinceNum) {
            this.setData({
                value: [provinceNum, 0, 0],
                citys: citys,
                areas: areas,
            })
        } else if (this.data.value[1] != cityNum) {
            this.setData({
                value: [provinceNum, cityNum, 0],
                areas: areas,
            })
        } else {
            console.log(countyNum)
            this.setData({
                value: [provinceNum, cityNum, countyNum]
            })
        }
        console.log(this.data)
    }
})