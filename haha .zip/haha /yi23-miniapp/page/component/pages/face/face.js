var Invite = require('../../../../service/invite.js')
var trackPoint = require('../../../../util/track_point.js');
var Session = require('../../../../common/session.js');
var loginByPhoneNumber = require('../../../common/loginByPhoneNumber.js');
/**
 * getStatus
 * 红包领取状态
 * 0 ： 领取成功
 * 1 ： 非新人
 * 2 ： 重复领取
 */
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isLogin:false,
    faceTopImg: 'https://yimg.yi23.net/webimg/web/images/2019/0121/faceTop.png',
    faceListImg: [{
      id: '001',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face01.png',
    }, {
      id: '002',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face02.png',
    }, {
      id: '003',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face03.png',
    }, {
      id: '004',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face04.png',
    }, {
      id: '005',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face05.png',
    }, {
      id: '006',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face06.png',
    }, {
      id: '007',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face07.png',
    }, {
      id: '008',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face08.png',
    }, {
      id: '009',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face09.png',
    }, {
      id: '010',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face10.png',
    }, {
      id: '011',
      imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/face11.png',
    }],
    pid: '',
    referId: '',
    info: null,
    getStatus: '',
    message: {
      success: {
        isShow: false,
        title: '红包领取成功！',
        message: '现在成为会员，还可再减##¥200##',
        imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/success@2x.png',
        type: 0,
        btnText: '去看看衣服'
      },
      fail1: {
        isShow: false,
        title: '红包仅限新人领取',
        message: '你已经是衣二三的老朋友啦！\n快去首页看看最近上新的美衣吧~',
        imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/repeat@2x.png',
        type: 1,
        btnText: '去首页'
      },
      fail2: {
        isShow: false,
        title: '红包不能重复领取',
        message: '您已领过¥50好友红包\n现在支付还可再减##¥200##',
        imgUrl: 'https://yimg.yi23.net/webimg/web/images/2019/0121/repeat@2x.png',
        type: 2,
        btnText: '成为会员'
      },
    },
    showMessage: {
      isShow: false,
      title: '',
      message: '',
      imgUrl: '',
      btnText: ''
    }
  },
  ...loginByPhoneNumber,
    doLoginNext:function () {
        this.setData({isLogin:true})
        this.receiveStatus()
    },
  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    let uid = options.scene
    console.log(uid)
    if (uid) {
      uid = decodeURIComponent(uid)
      this.setData({
        referId: uid,
      })
    }

    this.getData()

  },
  getData: function () {
    let _t = this
    Invite.getInvitationShareApplet({
      data: {
        uid: this.data.referId,
      },
      success: function (res) {
        var data = res.data
        if (data && data.code == 100) {
          _t.setData({ info: data.data })
          _t.userDese()
        }
      }
    })

  },

  userDese: function () {
    let _t = this
    let appletMessage = this.data.info.appletMessage.split('#')
    _t.setData({ appletMessage: appletMessage })
  },
  receiveStatus: function () {
    trackPoint.clickCount('BTN_FF_Receive',{'status':'0'})
    let _t = this;
    if (!_t.isLogin()) {
      wx.navigateTo({
        url: '/page/component/pages/login/login'
      });
      return false
    } else {
    }
    Invite.getRedPacketReceiveStatus({
      data: {
        referUid: this.data.referId
      },
      success: function (res) {
        var data = res.data
        if (data && data.code == 100) {
          _t.setData({ getStatus: data.data.redPacketReceiveStatus })
          _t.messageAction(data.data.redPacketReceiveStatus + '')
        }
      }
    })
  },
  closeMessage: function () {
    this.setData({ showMessage: { isShow: false } })
  },
  doClick: function () {
    let status = this.data.getStatus + ''
    /**
     * getStatus
     * 红包领取状态
     * 0 ： 领取成功
     * 1 ： 非新人
     * 2 ： 重复领取
     */
    switch (status) {
      case '0':
        wx.navigateTo({
          url: '/page/component/pages/index/index'
        })
        trackPoint.clickCount('BTN_FFGo_Hompage',{'status':'0'})
        break;
      case '1':
        wx.reLaunch({
          url: '/page/component/pages/index/index'
        })
        trackPoint.clickCount('BTN_FFGo_Hompage',{'status':'0'})
        break;
      case '2':
        wx.navigateTo({
          url: '/page/component/pages/pay/pay'
        })
        trackPoint.clickCount('BTN_FFGo_Payment',{'status':'0'})
        break;
    }


  },
  messageAction: function (type) {
    switch (type) {
      case '0':
        let info = JSON.parse(JSON.stringify(this.data.message.success))
        info.message = this.textAction(info.message)
        info.isShow = true
        this.setData({ showMessage: info })
        break
      case '1':
        let info1 = JSON.parse(JSON.stringify(this.data.message.fail1))
        info1.message = this.textAction(info1.message)
        info1.isShow = true
        this.setData({ showMessage: info1 })
        break
      case '2':
        let info2 = JSON.parse(JSON.stringify(this.data.message.fail2))
        info2.message = this.textAction(info2.message)
        info2.isShow = true
        this.setData({ showMessage: info2 })
        break
    }
  },
  textAction: function (text) {
    text.match(/([^#]+)([#]{2}([\s\S]*)[#]{2})?([\s\S]*)/)
    return { info1: RegExp.$1, red: RegExp.$3, info2: RegExp.$4 }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if(this.isLogin()){
      this.setData({isLogin:true})
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  //
  // }
})