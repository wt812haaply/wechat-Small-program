var Session = require('../../../../common/session.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
      isMember:0,
      isLogin:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var userInfo= Session.get(),_t=this;
      if(userInfo){
          _t.setData({isMember:userInfo.isMember,isLogin:userInfo.isLogin});
      }
  },
  buyVip:function () {//会员购买页
      var _t=this;
      if(_t.data.isLogin!=1){
          wx.navigateTo({
              url: '/page/component/pages/login/login?redirect='+encodeURIComponent('/page/component/pages/pay/pay')
          });
      }else{
          wx.redirectTo({
              url: '/page/component/pages/pay/pay'
          });
      }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  //
  // }
})