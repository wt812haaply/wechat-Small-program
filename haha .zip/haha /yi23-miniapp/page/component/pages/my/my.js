import navfooter from '../../../mixins/navfooter';
import userCenter from '../../../../api/user';
import loginMixin from '../../../mixins/login';
import * as  watch  from "../../../../util/watch.js";
import Session from "../../../../common/session";
Page({
    ...loginMixin,
    /**
     * 页面的初始数据
     */
    data: {
        clothesCountInBox:0,
        shareStatus:false,
        share:{
          banner:'https://yimg.yi23.net/webimg/web/images/2019/0225/myBanner_01.png?1',
          imgA:'https://yimg.yi23.net/webimg/web/images/2019/0225/myBanner_02.jpg',
          textA:'直接扫描小程序码',
          textB:'或分享给好友',
          btn:'分享给好友'
        },
        isMy:true,
        privilege:[{
            icon:'https://yimg.yi23.net/aliminiapp/aliapp/20190218/vip@3x.png',
            title:'会员包月换衣',
            dec:'每次可穿3-5件美衣'
        },{
            icon:'https://yimg.yi23.net/aliminiapp/aliapp/20190218/clothes@3x.png',
            title:'100万时装换穿',
            dec:'500+品牌美衣随心换'
        },{
            icon:'https://yimg.yi23.net/aliminiapp/aliapp/20190218/package@3x.png',
            title:'会员购衣折扣',
            dec:'特卖价最低1折起'
        },{
            icon:'https://yimg.yi23.net/aliminiapp/aliapp/20190218/calendar@3x.png',
            title:'会员期内支持冻结',
            dec:'最长可暂停15天'
        },{
            icon:'https://yimg.yi23.net/aliminiapp/aliapp/20190218/box@3x.png',
            title:'往返免运费',
            dec:'一键预约上门取件'
        },{
            icon:'https://yimg.yi23.net/aliminiapp/aliapp/20190218/wash.png',
            title:'专业清洗杀毒',
            dec:'16道清洁杀菌工序'
        }]
    },

    /**
     * 生命周期函数--监听页面加载
     */

    ///page/component/pages/webview/question
    bannerJump: function() {
        wx.navigateTo({
            url: '/page/component/pages/webview/question'
        })
    },
    toPayCard:function(){
        wx.navigateTo({
            url: '/page/component/pages/pay/pay'
        })
    },
    userCenter:function(){
        userCenter.myPage().then((res)=>{
            if(res.data && res.data.code==100){
                this.setData({myPage:res.data.data});
            }
        });
        let uid=Session.get()?Session.get().uid:''
        userCenter.userInfo({uid:uid}).then((res)=>{
            if(res.data && res.data.code==100){
                this.setData({userInfo:res.data.data});
            }
        })
    },
    getShareInfo:function(){
        userCenter.invitationSharePageInfo().then((res)=>{
            if(res.data && res.data.code==100){
                let invitation = {
                    invitationSharePageInfo:res.data.data,
                    appletQrCode:res.data.data.appletQrCode,
                    appletMessage:res.data.data.appletMessage,
                    appletWebUrl:res.data.data.appletWebUrl,
                    appletImage:res.data.data.appletImage,
                    appletQrCodeUrl:res.data.data.appletQrCodeUrl,
                }
                this.setData(invitation)
            }
        })

    },
    watch: {
        isLogin:function (newVal, oldVal){
            if(newVal){
              this.userCenter()
            }
        }
    },
    onLoad: function () {
        watch.setWatcher(this);
    },
    showShare:function(){
        this.getShareInfo()
        this.setData({shareStatus : true})
    },
    closeShare:function(){
      let _t = this;
      _t.setData({shareStatus : false})
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.setLoginStatus()
        if(!this.isLogin){
            return
        }
        this.userCenter()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
        return {
            title: this.data.appletMessage,
            imageUrl:this.data.appletImage,
            path: this.data.appletQrCodeUrl // 路径，传递参数到指定页面。
        }
    },
    ...navfooter,
})