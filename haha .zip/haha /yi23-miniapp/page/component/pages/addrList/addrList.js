import address from '../../../../api/address'

var addrService = require('../../../../service/addr.js');
var Region = require('../../../../common/region.js');
var pageView = require('../../../../common/pageView.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
      addrList:[]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _t=this;
    _t.addrListInit(options.delayDays);
    pageView.init();
  },
  //初始化收获地址列表
  addrListInit:function (delayDays) {

    let delay = 0
    if (delayDays) {
      delay = delayDays
    }
    address.addrListUrl({delay}).then((res) => {
      if (res.data && res.data.code == 100) {
        this.setData({
          addrList: res.data.data
        })
        var region=Region.get(),addrInfo=res.data.data[0];
        if(addrInfo && region && (region.rgnId != addrInfo.cityRgn)){
          Region.set({rgnId:addrInfo.cityRgn,cityName:addrInfo.city});
        }
      } else {
        common.showMsg(res.data.msg)
      }
    })
  },
  //选择收货地址
  selectedAddr:function (event) {
     var addrInfo= event.currentTarget.dataset.info;
      if(pageView.routeEqual(pageView.prevPage,'comfirmOrder/comfirmOrder')){
          var region=Region.get();
          if(region && (region.rgnId != addrInfo.cityRgn)){
              // Region.set({rgnId:addrInfo.cityRgn,cityName:addrInfo.city});
              pageView.prevPage.itemInit && pageView.prevPage.itemInit();
          }
          pageView.prevPage.setData({
              showNotInit:true,
              addrInfo: addrInfo
          })
          wx.navigateBack({
              delta: 1
          })
      }
  },
  //修改收货地址
  editAddr:function (event) {
      console.log('edit')
      var addrInfo= event.currentTarget.dataset.info;
      var addrInfoStr=decodeURIComponent(JSON.stringify(addrInfo));
      console.log(addrInfoStr)
      wx.redirectTo({
          url: '../addr/addr?info='+addrInfoStr
      })
  },
  addAddr:function () {
    wx.redirectTo({
        url: '../addr/addr'
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})