var wishlist = require('../../../../service/wishlist.js');
var us = require('../../../../common/lib/underscore.js');
var commitPushForm = require('../../../../common/commitPushForm');
var wishlistAction = require('../../../common/wishlist');
import navfooter from '../../../mixins/navfooter';
import loginMixin from '../../../mixins/login';
import * as  watch  from "../../../../util/watch.js";
Page({
  data: {
    isLikes:true,
    clothesCountInBox: 0,
    wishlist:[],
    isShowEmpty:false,
    isLoading:false,
    pageInfo:{
      count:20,
        page:1,
        totalPage:'1'
    },
  },
  ...loginMixin,
  onShow:function () {
    this.setLoginStatus()
  },
  watch: {
    isLogin:function (newVal, oldVal) {
      if(newVal){
        if(newVal!=oldVal){
          this.getData()
        }else{
          let wishlistHandel=wishlistAction.showProudectDataFilter(this.data.wishlist,{compareKey:'productId'});
          this.setData({wishlist:wishlistHandel})
        }
      }
    }
  },
  onLoad: function (options) {
    watch.setWatcher(this);
    if(!this.isLogin){
      return
    }
    this.getData()
  },
  getData:function (append) {
    let _t=this,
      dataArguments={
        count:_t.data.pageInfo.count,
        page:_t.data.pageInfo.page,
        stockFirst:1
      };
    wishlist.wishlist({
      data:dataArguments,
      success:function (res) {
        _t.data.isLoading=false;
        let dataRes=res.data
        if(dataRes.code==100){
          let wishlist=wishlistAction.showProudectDataFilter(dataRes.data.wishlist,{compareKey:'productId'});
          dataRes.data.wishlist=wishlist
          if(append){
            dataRes.data.wishlist=_t.data.wishlist.concat(dataRes.data.wishlist);
          }
          _t.setData({pageInfo:dataRes.data.pageInfo,wishlist:dataRes.data.wishlist})
        }
        _t.setData({isShowEmpty:true})
      }
    })
  },



  dataAction:function (data,append) {
    var _t=this;
    //如果改变筛选逻辑 数据清空处理
    if(append){
      data.productList=_t.data.productList.concat(data.productList);
    }
    return us.extend({},data)
  },
  doWishlist:function (event) {
    wishlistAction.wishlistEventAction(event,this)
  },
  toDetail:function (event) {
    var productid=event.currentTarget.dataset.productid;
    var path=event.currentTarget.dataset.path;
    let formId = event.detail.formId;
    commitPushForm.send(formId);
    wx.navigateTo({
      url: '../product/product?id='+productid+'&path='+encodeURIComponent(path)
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom:function () {
    var _t=this,
      data=this.data.pageInfo;
    if(!_t.isLoading && Number(data.page)<Number(data.totalPage)){
      data.page=Number(data.page)+1;

      this.setData({pageInfo:data,isLoading:true});
      // console.log(_t.data);
      _t.getData(true);
    }else{
      if(data.totalPage!=0){
        this.setData({isLastPage:true,isLoading:false});
      }
    }
  },
  ...navfooter
})