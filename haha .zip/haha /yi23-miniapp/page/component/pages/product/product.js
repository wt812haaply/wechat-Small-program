import newProduct from "../../../../api/product";
var product = require('../../../../service/product.js');
var Session = require('../../../../common/session.js');
var commitPushForm = require('../../../../common/commitPushForm');
var pageView = require('../../../../common/pageView.js');
var constants = require('../../../../common/lib/constants');
var wishlistAction = require('../../../common/wishlist');
import Auth from '../../../../common/auth'
var WX_SCENE_KEY_FLAG = constants.WX_SCENE_KEY_FLAG;
import oldBeltNew from '../../../mixins/oldBeltNew';
Page({
    data: {
        showDialog: false,
        showCenterDialog: false,
        isStoreUp:false,
        storeUpDesc:{
            imgA:'https://yimg.yi23.net/webimg/web/images/2019/0225/storeUp-jt@2x.png',
            imgB:'https://yimg.yi23.net/webimg/web/images/2019/0225/storeUp-mb@2x.png',
            text:'点击这里 添加到我的小程序\n回微信首页下拉聊天列表，\n从“我的小程序”中打开“衣二三”'
        },
        swiperNum:0,
        pid:'',
        selectSkuId:'',
        product_info:null,
        showShareBox:false,
        isShowOpenAppBtn:false,
        isHideGuide:0,
        isMember:0,// 0.非会员; 1.会员;
        isLogin:0,
        showShareTips:0,
        feedbackList:[],
        pageInfo:'',
        pageData:{
            page:1,
            feedbackTest:'查看更多评价',
        },

        doSelect:false,
        skuId:'',
        gallery:{
            slideshow:false,
            picture:[]
        },
        bannerScale:{
            slideshow:false,
            picture:[]
        },
        mildLuxury:false,
        tabArr:{
            curHdIndex:3
        },
        show_add_button:0,
    },

    onShareAppMessage: function (res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
            // console.log(res.target)
        }
        var userInfo= Session.get(),referId='';
        if(userInfo.uid){
            referId='&referId='+userInfo.uid;
            // console.log("========referId: "+referId);
        }
        return {
            title:'这件单品很适合你,快看看吧👇',
            path:'/page/component/pages/product/product?id='+this.data.pid+referId,
            success: function(res) {
                // 转发成功
            },
            fail: function(res) {
                // 转发失败
            }
        }
    },
    //去短列表页
    toList:function (event) {
        var brand=event.currentTarget.dataset.brand;
        var resPage=pageView.hasRoute('page/component/pages/list/list');
        if(resPage.has){
            pageView.pages[resPage.index].setData({backSearchKey:encodeURIComponent(brand)})
            wx.navigateBack({
                delta: pageView.pages.length-resPage.index-1
            })
            // wx.redirectTo({
            //     url: '/page/component/pages/list/list?searchKey='+encodeURIComponent(brand)
            // })

        }else{
            wx.redirectTo({
                url: '/page/component/pages/list/list?searchKey='+encodeURIComponent(brand)
            })
        }
    },

    currentNumber:function (event) {
        var swiperNum = event.detail.current
        this.setData({swiperNum})
    },

    //评价图,banner放大处理
    galleryAction:function (event) {
        var gallery=event.currentTarget.dataset.gallery;
        if(gallery && gallery.length && gallery.length>0){
            this.setData({gallery:{
                    slideshow:true,
                    picture:gallery
                }})
        }
    },
    //隐藏评价图
    hideGallery:function () {
        this.setData({gallery:{
                slideshow:false,
                picture:[]
            }})
    },
    hideMildLuxury:function () {
        this.setData({mildLuxury:false},function () {
        });
    },
    onReady: function () {
        console.log('onReadyProduct');
    },
    onLoad: function (options) {
        var _t=this;
        var referId=options.referId;
        var path=options.path?options.path:'';
        pageView.init();
        if(referId){
            _t.referAction(referId);
        }
        let scene = options.scene
        if (scene) {
            scene=decodeURIComponent(scene)
            let sceneJson = scene.split('=')
            this.setData({
                pid: sceneJson[1]
            })
        }else{
            _t.setData({pid:options.id,path:path});
        }

        // _t.setData({pid:12393});
    },
    onShow:function () {
        var userInfo= Session.get(),_t=this,flag= wx.getStorageSync(WX_SCENE_KEY_FLAG);
        _t.getNewproductDetail(function () {
            _t.getProdDetailRecommend();
            _t.getProductFeedback()
        })
        setTimeout(function () {
            _t.setData({showShareTips:0})
        },3000);

        if(!wx.getStorageSync('storeUp')){
            _t.setData({isStoreUp:true});
        }
        // step
        let res = wx.getStorageSync('storeUp');
        if (res) {
            _t.setData({
                isStoreUp: false
            })
        }
        if(flag){
            _t.setData({isShowOpenAppBtn:true})
        }
        if(userInfo && userInfo.isMember){
            _t.setData({isMember:userInfo.isMember,isHideGuide:userInfo.isMember,isLogin:userInfo.isLogin,showShareTips:userInfo.isLogin});
        }else {
            Auth.getLoginStatus().then((res) => {
                if(res.code == 'SUCCESS'){
                    this.getNewproductDetail()
                    Auth.updateUserInfo().then(res =>{
                        let  userInfo= Session.get()
                        _t.setData({isMember:userInfo.isMember,isHideGuide:userInfo.isMember,isLogin:userInfo.isLogin,showShareTips:userInfo.isLogin});
                    })
                }
            })
        }
    },
    // 图中搭配 、推荐搭配、相似单品
    getProdDetailRecommend:function(){
        let dataArguments={
            pid:this.data.pid,
            path:this.data.path
        };
        newProduct.productDetailRecommend(dataArguments).then((res)=>{
            if(res.data && res.data.code==100){
                res.data.data.relatedProducts=wishlistAction.showProudectDataFilter(res.data.data.relatedProducts,{compareKey:'product_id'})
                res.data.data.recommendedProducts=wishlistAction.showProudectDataFilter(res.data.data.recommendedProducts,{compareKey:'product_id'})
                res.data.data.innerProducts=wishlistAction.showProudectDataFilter(res.data.data.innerProducts,{compareKey:'product_id'})
                this.setData({
                    relatedProducts:res.data.data.relatedProducts,
                    recommendedProducts:res.data.data.recommendedProducts,
                    innerProducts:res.data.data.innerProducts
                });
            }
        })
    },

    //评论
    getProductFeedback:function(){
        let dataArguments={
            productId:this.data.pid,
            count:5,
            page:this.data.pageData.page
        };
        if(!this.data.pageData.page){
            return false;
        }
        newProduct.productFeedback(dataArguments).then((res)=>{
            if(res.data && res.data.code==100){
                res.data.data.feedbackList = this.data.feedbackList.concat(res.data.data.feedbackList);
                this.setData({
                    feedbackList:res.data.data.feedbackList,
                    pageInfo:res.data.data.pageInfo
                });
                if(this.data.pageInfo.totalPage==this.data.pageData.page){
                    this.setData({pageData:{feedbackTest:'已加载全部精选评价'}});
                    this.data.pageData.page = -1;
                }
                this.data.pageData.page = this.data.pageData.page+1;
            }
        })

    },
    // 详情页
    getNewproductDetail:function(callback){
        let  dataArguments = {
                pid:this.data.pid,
                path:encodeURIComponent(this.data.path),
                apiLevel:1
            }
        newProduct.newproductDetail(dataArguments).then((res)=>{
            if(res.data && res.data.code==100){
                let picture = res.data.data.product_info.picture;
                if(picture){
                    picture.forEach((t,v)=>{
                        if(t.charAt(t.length - 1) === 'w'){
                            picture[v] = t.substring(0,t.length - 1)
                        }
                    })
                }
                let prodData=res.data.data
                var prodInfo = res.data.data.product_info;
                let prodArray=[],prodArrayRes;
                prodArray.push(prodInfo)
                prodArrayRes=wishlistAction.showProudectDataFilter(prodArray,{compareKey:'product_id'})
                res.data.data.product_info=prodArrayRes[0]
                if (prodInfo) {
                    if (prodInfo.stocknum <=0 || (prodInfo.sale_time != null && prodInfo.server_time != null && ((prodInfo.sale_time - prodInfo.server_time) > 0) && prodInfo.presaleDisplay == 1 )) {
                        this.setData({
                            show_add_button: 0
                        });
                    } else {
                        this.setData({
                            show_add_button: 1
                        });
                    }
                    this.setData(prodData, function () {
                        // console.log(this.data)
                    });
                    callback && callback()
                }
            }
        })
    },
    // 标签文字
    tagText(item){
        item.forEach((t,v)=>{
            if(+t.stockNum === 0){
                return false;
            }else if(+t.is_star === 2){
                t.tagTxt='秋冬限定';
            }else if(+t.is_new === 1){
                t.tagTxt='刚刚上架';
            }else if(+t.is_star === 1){
                t.tagTxt='明星同款';
            }
        })
        return item;

    },
    //推荐处理
    toDetail:function (event) {
        var productid=event.currentTarget.dataset.productid;
        let formId = event.detail.formId;
        commitPushForm.send(formId);
        wx.redirectTo({
            url: '/page/component/pages/product/product?id='+productid
        })
    },
    //去衣箱页面
    toUserBox:function () {
        var _t=this;
        wx.navigateTo({
            url: '../box/box'
        })
    },
    buyVip:function () {//会员购买页
        var userInfo= Session.get();
        if(userInfo && userInfo.isLogin!=1){
            wx.navigateTo({
                url: '/page/component/pages/login/login?redirect='+encodeURIComponent('/page/component/pages/pay/pay')
            });
        }else{
            wx.navigateTo({
                url: '/page/component/pages/pay/pay'
            });
        }
    },

    addUserBoxBuySize:function (event) {
        var _t=this;
        var productid= event.currentTarget.dataset.productid;
        _t.setData({skuId:productid},function () {
        });
    },
    addUserBox: function(){
        let _t = this;
        if(!_t.data.skuId){
            wx.showToast({title: '请选择尺码',icon: 'none', duration: 3000})
        } else {
            _t.addcart(_t.data.skuId)
            _t.showSize()

        }
    },
    showSize:function(){
        let _t = this;
        _t.setData({skuId:''});
        _t.closeDialogSize()
    },

    //关闭size遮罩
    closeDialogSize:function(){
        let _t = this;
        _t.setData({
            showDialog: !this.data.showDialog
        });
    },

    toIndex:function () {
        wx.reLaunch({
            url: '/page/component/pages/index/index'
        })
    },
    addcart:function (pid) {
        var _t=this;
        product.addItemToCart({
            data:{skuId:pid,path:_t.data.path},
            success:function (res) {
                if(res.data && res.data.code==100){
                    _t.setData({doSelect:false},function () {
                    });
                    wx.showToast({title: res.data.msg,icon: 'none', duration: 3000})
                }else{
                    _t.setData({doSelect:false},function () {
                    });
                    if(res.data && res.data.code==105){
                        wx.showToast({title: res.data.msg ,icon: 'none', duration: 3000})
                    }else if(res.data && res.data.code==109){
                        _t.setData({mildLuxury:true},function () {
                        });
                    }
                }
            }
        })
    },
  launchAppError: function(e) {
    console.log(e.detail.errMsg)
    wx.showModal({
      title: '无法打开衣二三',
      content: '请前往应用商店下载衣二三APP',
      confirmColor:"#ff544b",
      success: function(res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  doWishlist:function (event) {
    wishlistAction.wishlistEventAction(event,this)
  },
    storeUp:function () {
        var _t=this;
        wx.setStorageSync('storeUp',1)
        _t.setData({
            isStoreUp:false
        })
    },
    ...oldBeltNew
})