var Filter = require('../../../../service/filter.js');
var us = require('../../../../common/lib/underscore.js');
var common = require('../../../../common/common.js');
var pageView = require('../../../../common/pageView.js');
var carFilter = require('../../../../common/categoryFilter.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
      seletedFilter:{
          color_id:[],
          filterId:[],
          tagId:[],
          season:[],
          size:[],
          type_id:[],
          scene:[],
          tagList:[],
      },
      openButt:{},
      barSelect:[],
      tagMap:[],
      // sortFilterList:[{sortName:'在架优先',stockFirst:1},{sortName:'全部单品',stockFirst:0}]
  },
    //展开所有筛选项
  showFilter: function (event) {
    let filterName=event.currentTarget.dataset.filter;
    let filterTag=event.currentTarget.dataset.tad||'';
    if(filterTag){
        this.data.openButt.tagList[filterTag] = !this.data.openButt.tagList[filterTag];
    }else{
        this.data.openButt[filterName] = !this.data.openButt[filterName];
    }
    this.setData({
        openButt:this.data.openButt
    })
  },
  //收起部分筛选项
  hideFilter: function (event) {
      let filterName=event.currentTarget.dataset.filter;
      this.setData({
          [filterName]:false
      })
  },
  //选择与取消筛选项
  doFilter:function (event) {
    let _t = this,
        doFilterList = {
          key : event.currentTarget.dataset.key || '',
          id : event.currentTarget.dataset.id || '',
          name: event.currentTarget.dataset.name || '',
          tag : event.currentTarget.dataset.tag || '',
          category : event.currentTarget.dataset.category || '',
          seleted : _t.data.seletedFilter,
          barSelect : _t.data.barSelect,
          tagMap : _t.data.tagMap,
        };
    if(doFilterList.key === 'size'){
        doFilterList.id = doFilterList.name;
    }
    if(us.isArray(doFilterList.seleted[doFilterList.key])){
        if(doFilterList.seleted[doFilterList.key].indexOf(doFilterList.id)==-1){
            doFilterList.seleted[doFilterList.key].push(doFilterList.id);
            carFilter.addFilter(doFilterList);
        }else{
            if(doFilterList.tag && doFilterList.tag.length>0){
                carFilter.cancelFilterTag(doFilterList);
            }
            carFilter.cancelFilter(doFilterList);
        }
    }else{
        doFilterList.seleted[doFilterList.key]=doFilterList.id;
        carFilter.addFilter(doFilterList);
    }
   this.setData({seletedFilter:doFilterList.seleted,tagMap:doFilterList.tagMap,barSelect:doFilterList.barSelect})
  },
  dataAction:function (data) {
      let dataList = {};
      let openButt = this.data.openButt;
      for ( let dataKey in data) {
          switch(dataKey){
              case 'colorFilterList':
                  dataList.color_id = data[dataKey];
                  openButt.color_id = dataList.color_id.length<=12;
                  break;
              case 'customizedFilter':
                  dataList.filterId = data[dataKey].dataList;
                  openButt.filterId = dataList.filterId.length<=8;
                  break;
              case 'featuredTagsFilter':
                  dataList.tagId = data[dataKey].dataList;
                  openButt.tagId = dataList.tagId.length<=8;
                  break;
              case 'productSeasonFilter':
                  dataList.season = data[dataKey].dataList;
                  openButt.season = dataList.season.length<=8;
                  break;
              case 'productSizeFilter':
                  dataList.size = data[dataKey].dataList;
                  openButt.size = dataList.size.length<=12;
                  break;
              case 'productTypeFilter':
                  dataList.type_id = data[dataKey].dataList;
                  openButt.type_id = dataList.type_id.length<=8;
                  break;
              case 'sceneFilter':
                  dataList.scene = data[dataKey].dataList;
                  openButt.scene = dataList.scene.length<=8;
                  break;
              case 'tagCategoryList':
                  dataList.tagList = data[dataKey];
                  openButt.tagList = {};
                  dataList.tagList.forEach((v,t)=>{
                      openButt.tagList[v.id] = v.tagFilters.length<=8;
                  });
                  break;
              default :
                  break;
          }

      }
      this.setData({openButt:openButt,...dataList})
  },
  //重置
  doRest:function () {
      this.setData({
          seletedFilter:{
          color_id:[],
          filterId:[],
          tagId:[],
          season:[],
          size:[],
          type_id:[],
          scene:[],
          tagList:[]
      },
      barSelect:[],
      tagMap:[],
      })
  },
  //保存筛选项
  saveFilter:function () {
      var _t=this;
      pageView.prevPage.initFilter(_t.data.seletedFilter,_t.data.barSelect,_t.data.tagMap);

      wx.navigateBack({
          delta: 1
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      console.log('onLoad')
      console.log(options)
      if(options.seletedFilter){
          this.setData({seletedFilter:JSON.parse(options.seletedFilter)})
      }
      if(options.tagMap){
          this.setData({tagMap:JSON.parse(options.tagMap)})
      }
      if(options.barSelect){
          this.setData({barSelect:JSON.parse(options.barSelect)})
      }
      pageView.init();
      var _t=this;
      Filter.queryProductFilters({
          success:function (res) {
              if(res.data && res.data.code==100){
                    _t.dataAction(res.data.data);
              }else{
                  common.showMsg(res.data.msg);
              }
              console.log(res)
          }
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
        console.log('onReady')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      console.log('onShow')
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  }
})