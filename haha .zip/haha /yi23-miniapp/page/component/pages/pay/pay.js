// pages/pay/pay.js
import Device from "../../../../common/device";

var Pay = require('../../../../service/pay.js');
var CheckUserZhima = require('../../../../service/checkUserZhima.js');
const hSwiper=require("hSwiper.js");
var common = require('../../../../common/common.js');
var Session = require('../../../../common/session.js');
var trackPoint = require('../../../../util/track_point.js');
var constants = require('../../../../common/lib/constants');
import  Auth from '../../../../common/auth';
var Login = require('../../../../common/login_authorize');
import * as  watch  from "../../../../util/watch.js";

Page({
  data: {
      couponId:'',
      inviteCode:'',
      isOpenContinueCard:true, // 是否开启连续包月
      inputCode:'',
      couponInfo:'',
      showcontractTips:false,
      checkInfo:{step:0,status:0,idCard:'',name:''},
      showInfo:'',
      depositInfo:'',
      contractStauts:false,
      inviteCodeTitle:'使用好友的邀请码',
      inputInviteCodeRes:'1',
      inviteCodeError:'邀请码错误，请重新输入',
      inviteCodeOpen:false,
      depositPopTitle:'押金提示',
      depositPopP:'押金在您会员期结束后即可申请退还。您也可以下载衣二三APP申请免押。',
      depositPopOpen:false,
      showInvitation:null,
      swiperIndex:0,
      depositWaived:'',//0有押金 1没有押金
      payType:'1',
      extra: '',
	    isFirstPay:'',
	    promotion13time:'',
	    serialPopOpen:false
     
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      watch.setWatcher(this);
  },
  checkStatus:function () {
    let status= wx.getStorageSync(constants.WX_CONTRACT_STATUS)
    let _t=this;
    if(status){
      wx.removeStorageSync(constants.WX_CONTRACT_STATUS);
      Device.deleteSignSalt()//清除登录信息
      this.setData({contractStauts:true})
      setTimeout(()=>{
        if(status==1){// 中间状态
            Auth.login().then(res =>{
                _t.doStatus()
            }).catch(res => {
                _t.doStatus()
            })

        }else  if(status==2){//签约成功
          wx.navigateTo({
            url: '/page/component/pages/openCardSuccess/openCardSuccess'
          })
        }
      },6100)
    }
  },
  doStatus:function () {
    let _t=this
    let userInfo= Session.get();
    if(userInfo.isMember==1){
      wx.navigateTo({
        url: '/page/component/pages/openCardSuccess/openCardSuccess'
      })
    }else{
      _t.initPayList()
    }
    _t.setData({contractStauts:false})
  },
  initPayList:function () {
    var _t=this;
      Pay.cardList({
          data:{
            apiLevel:1
          },
          success:function (res) {
              var data=res.data;
              if(data && data.code==100){
                  if(!_t.data.isOpenContinueCard){
                    let showInfo= data.data.showInfo
                    console.log(showInfo)
                    data.data.showInfo =showInfo.filter(function (el) {
                      return el.payType!=9
                    });
                  }

                  // data.data.showInfo[0].depositWaived=1
                  _t.setData({showInfo:data.data.showInfo[0],isFirstPay:data.data.isFirstPay||0,promotion13time:data.data.promotion13time||'',inviteCode:data.data.inviteCode?data.data.inviteCode:'',showInvitation:data.data.showInvitation?data.data.showInvitation:0,payType:data.data.showInfo[0].payType})
                  _t.getValidCouponListByPayType(function () {
                    _t.checkStatus()
                    _t.realPay(data.data.showInfo[0]);
                    _t.setData({showInfo:data.data.showInfo[0]},function () {
                      _t.initSwiper(data)
                    })
                  })
              }
          },
      })
  },
    realPay:function (data) {//实付金额计算
        var _t=this;
        data.realPay=data.payCost;
        if(_t.data.couponInfo){
            if(_t.data.couponInfo.couponType==1){
                data.realPay=data.payCost - _t.data.couponInfo.value
            }else{
                data.realPay=Math.ceil(data.payCost*_t.data.couponInfo.value)
            }
        }
        if(data.payReduce){
            data.realPay=data.realPay-data.payReduce
        }
        if(data.realPay<0){
            data.realPay=0
        }
        // if( data.isUseDeposit == 0 ){//开启押金后置
            // data.depositName = data.noDepositText
        // }else
       if(data.depositWaived==0){//depositWaived =0 没有交押金
            data.realPay=data.realPay+data.depositAmount
        }
      if(data.cardDesc && (typeof data.cardDesc == 'string')) {
        data.cardDesc=data.cardDesc.split('\n')
      }
      _t.setData({showInfo:data })
    },
    initSwiper:function (data) {
        let _t=this;
        let swiper=new hSwiper({reduceDistance:120,varStr:"hSwiperVar",list:data.data.showInfo});
        console.log(swiper)
        swiper.afterViewChange = function (data, index) {
            if(data.templateId != _t.data.showInfo.templateId){
              _t.setData({showInfo:data,swiperIndex:index,payType:data.payType},function () {
                _t.getValidCouponListByPayType(function () {
                  _t.realPay(data);
                })
                _t.realPay(data);
              })
            }
          
        };
        // swiper.to
        if(_t.data.swiperIndex >0){
            swiper.moveViewTo(_t.data.swiperIndex)
        }
    },
    //邀请码相关 start
    doShowInviteCodeBox:function () {
      this.setData({inviteCodeOpen:true})
    },
    inputInviteCodeAction:function (e) {
      this.setData({inputCode:e.detail.value})
    },
    doCannelInviteCode:function () {
      this.setData({inviteCodeOpen:false,inputInviteCodeRes:'1'})
    },
    doSubmitInviteCode:function () {
      let _t=this;
      Pay.bindingInvitationRelation({
        data:{inviteCode:_t.data.inputCode},
        success:function (res) {
          var data=res.data;
          if(data && data.code==100){
            _t.doCannelInviteCode()
            _t.initPayList();
          }else{
            _t.setData({inputInviteCodeRes:'0',inviteCodeError:data.msg},function () {
              // _t.initPayList();
            })

          }
        },
      })
    },
  //邀请码相关 end
    getValidCouponListByPayType:function (callback) {
      var _t=this;
        Pay.getValidCouponListByPayType({
            data:{payType:_t.data.payType},
            success:function (res) {
                var data=res.data;
                if(data && data.code==100){
                    console.log(data)
                    if(data.data && data.data.length>=0){
                        let couponList=data.data.filter(function (e) {
                          if(e.status==3){
                            return e
                          }
                        })
                        if(couponList && couponList.length>0){
                          _t.setData({couponInfo:couponList[0],couponId:couponList[0].couponId},function () {
                          });
                        }else{
                          _t.setData({couponInfo:'',couponId:''},function () {
                          });
                        }


                    }
                }
            },
            complete:function () {
                callback && callback()
            }
        })
    },
    doBuy:function (event) {
       var _t=this,
           payid= event.currentTarget.dataset.payid,
           payType= event.currentTarget.dataset.paytype;
       if(payType==9){
         _t.setData({showcontractTips:true},function () {
         });

       }else{
         _t.doPay(payid);
       }

    },
  //取消签约
    doCannelSign:function () {
      this.setData({showcontractTips:false},function () {
      });
    },
    doOpenContinueVipEvent:function (event) {
      var _t=this;
      var  payid= event.currentTarget.dataset.payid;
      _t.doOpenContinueVip(payid)
    },
    //纯签约 连续包月处理
    doOpenContinueVip:function (payid) {
      var _t=this;
      let options={
        cardTemplateId:payid,
        payType:'WECHAT_APPLET_CONTRACT_BINDING',
      }
      options.couponId=_t.data.couponId
      Pay.purchaseCard({
        data:options,
        success:function (res) {
          // console.log(res)
          if(res.data.code==100){
            console.log(res.data.data.paymentInfo.contractLink)
            wx.navigateToMiniProgram({
              appId:'wxbd687630cd02ce1d',
              path:'pages/index/index',
              extraData:res.data.data.paymentInfo.contractLink,
              success(res) {
                // 成功跳转到签约小程序
              },
              fail(res) {
                // 未成功跳转到签约小程序
              }
            })
          }else {
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 2000
            })
          }
        }
      })
    },
    //芝麻 start
    checkUserZhima:function () {
        var _t=this;
        _t.setData({checkInfo:{step:1,status:0}})
    },
    closeCheck:function (event) {
        let step=event.currentTarget.dataset.step;
        this.setData({checkInfo:{step:step,status:0}})
    },
    checkUserZhimaStep2:function () {
        var _t=this;
        if(_t.data.checkInfo.name){
            _t.data.checkInfo.step=2;
            _t.data.checkInfo.status=0;
            _t.setData({checkInfo:_t.data.checkInfo})
        }
    },
    checkUserZhimaStep3:function () {
        var _t=this;
        if(_t.data.checkInfo.idCard){
            _t.data.checkInfo.status=2;
            _t.setData({checkInfo:_t.data.checkInfo});
            CheckUserZhima.checkUserZhima({
                data:{idCard:_t.data.checkInfo.idCard,name:_t.data.checkInfo.name},
                success:function (res) {
                    var data=res.data;
                    if(data && data.code==100){
                        _t.data.checkInfo.step=3;
                        _t.setData({checkInfo:_t.data.checkInfo})
                        setTimeout(()=>{
                            _t.initPayList(_t.data.swiperIndex);
                            _t.setData({checkInfo:{step:0,status:0}})
                        },3000)
                    }else{
                        _t.data.checkInfo.status=1;
                        _t.setData({checkInfo:_t.data.checkInfo});
                        common.showMsg(data.msg);
                    }
                }
            })
        }
    },
    idCardInput:function (e) {
        var _t=this;
        if(e.detail.value){
            _t.data.checkInfo.idCard=e.detail.value;
            _t.data.checkInfo.status=1;
            _t.setData({checkInfo:_t.data.checkInfo})
        }else{
            _t.data.checkInfo.idCard=e.detail.value;
            _t.data.checkInfo.status=0;
            _t.setData({checkInfo:_t.data.checkInfo})
        }
    },
    checkInfoNameInput:function (e) {
        var _t=this;
        if(e.detail.value){
            _t.data.checkInfo.name=e.detail.value;
            _t.data.checkInfo.status=1;
            _t.setData({checkInfo:_t.data.checkInfo})
        }else{
            _t.data.checkInfo.name=e.detail.value;
            _t.data.checkInfo.status=0;
            _t.setData({checkInfo:_t.data.checkInfo})
        }
    },
    // 芝麻end
    couponSelectCallBack:function () {
        var _t=this;
        _t.realPay(_t.data.showInfo);
        _t.setData({showInfo:_t.data.showInfo})
    },
    toCouponList:function (event) {
      let payType= event.currentTarget.dataset.paytype;
        wx.navigateTo({
            url: '/page/component/pages/coupon/coupon?payType='+payType
        })
    },
    doPay:function (payid) {
        var _t=this;
        let options={
            cardTemplateId:payid,
            payType:'WECHAT_APPLET',
            // inviteCode:_t.data.inviteCode
        }
        // if(payid!=10){
            options.couponId=_t.data.couponId
        // }
        Pay.purchaseCard({
            data:options,
            success:function (res) {
               // console.log(res)
                var data=res.data;
                if(data && data.code==100){
                  // console.log(data)
                  var info=data.data.paymentInfo;
                    wx.requestPayment({
                            "timeStamp": info.timestamp,
                            "package": info.package,
                            "paySign": info.sign,
                            "signType": 'MD5',
                            "nonceStr": info.noncestr,
                            'success':function(res){
                                trackPoint.paySuccess(_t.data.showInfo.realPay);
                                wx.redirectTo({
                                    url: '/page/component/pages/paystatus/paystatus'
                                })
                            },
                            'fail':function(res){
                                console.log(res)

                            }
                        })
                }else if(data && data.code==110){
                    wx.redirectTo({
                        url: '/page/component/pages/paystatus/paystatus'
                    })
                }else{
                  wx.showToast({
                    title: res.data.msg,
                    icon: 'none',
                    duration: 2500
                  })
                }
            }
        })

    },
    depositPop:function () {
        this.setData({depositPopOpen : !this.data.depositPopOpen})
    },
	  serialPop:function () {
      this.setData({serialPopOpen : !this.data.serialPopOpen})
    },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (options) {
    var _t=this;
      if(!Auth.isLogin()){
          Auth.login().then(code =>{
                if(code == 'SUCCESS'){
                    this.setData({
                        isLogin:true
                    })
                }
          }).catch((error)=>{
              console.log(error)
          })
      }else{
          if(!_t.data.isGoback){
              _t.initPayList();
          }
          this.setData({
              isLogin:true
          })
      }


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    this.setData({showcontractTips:false},function () {
    });
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
  watch: {
    isLogin:function (newVal, oldVal){
        if(newVal){
            this.initPayList();
        }
    }
  },

})