var search = require('../../../../service/search.js');
var us = require('../../../../common/lib/underscore.js');
Page({
    data:{
        searchKey:'',
        tagsList:[]
    },
    onLoad:function () {
        var _t=this;
        search.queryTagsList({
            success:function (res) {
                if(res.data && res.data.code==100){
                    _t.setData({
                        tagsList:res.data.data
                    });
                }
            }
        })
    },
    bindKeyInput:function (e) {
        this.doRedirect(e.detail.value);
    },
    cannelInput:function(e){
        this.setData({
            searchKey:''
        });
    },
    tagsJump:function (event) {
        var _t=this,
            tagname=event.currentTarget.dataset.tagname;
        _t.doRedirect(tagname);
    },
    clearAllBtn:function () {
        wx.clearStorageSync();
    },
    doRedirect:function (searchkey) {
        console.log(searchkey);
        var s='pp@Y@123';
        if(searchkey=='pp@Y@123'){
            this.setData({yi23Search:true});
            return false;
        }
        wx.redirectTo({
            url: '../list/list?searchKey='+searchkey
        })
    }
})