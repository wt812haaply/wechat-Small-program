var utils = require('../../../../util/util.js');
import clothCouponList from '../../../../api/user';
import Box from '../../../../api/box';
import pay from '../../../../api/pay';
import pointItemDetail from "../../../../api/product";
import Device from '../../../../common/device'
Page({
    /**
     * 页面的初始数据
     */
    data: {
        isTrue: 2,
        itemId:'',
        payWay: '2',
        showDialog: false,
        showCenterDialog: false,
        icon:{
            integral:`https://yimg.yi23.net/webimg/web/images/2019/0225/integral-icon.png`,
            wechat:`https://yimg.yi23.net/webimg/web/images/2019/0225/wechat-icon.png`
        }
    },

    getPointItemDetail:function(itemId){
        let dataArguments={
            itemId
        };
        pointItemDetail.pointItemDetail(dataArguments).then((res)=>{
            if(res.data && res.data.code==100){
                this.setData({
                    itemInfo:res.data.data.itemInfo,
                    priceDesc:'\xa0\xa0会员积分\xa0\xa0',
                    price: res.data.data.itemInfo.price,
                    moneyPriceDesc:'\xa0\xa0微信支付\xa0\xa0',
                    moneyPrice: res.data.data.itemInfo.moneyPrice / 100,
                    payValue: '￥' + res.data.data.itemInfo.moneyPrice / 100,
                })
            }
        })
    },

    getClothCouponList:function(){
        return new Promise((resolve,reject )=>{
            clothCouponList.clothCouponList().then((res)=>{
                if(res.data && res.data.code==100){
                    let expDate = res.data.data.couponVOList.map((el) => {
                        el.expDate=utils.timeFormat(el.expDate)
                        el.startDate=utils.timeFormat(el.startDate)
                        return el
                    })
                    this.setData({
                        couponVOList:expDate,
                        moreCouponList:res.data.data.moreCouponList,
                        userPoint:res.data.data.userPoint,
                    });

                }
                resolve(res)
            })
        })

    },
    selectCoupon(e){
        let couponId = e.currentTarget.dataset.id;
        Box.useAddClothCoupon({cid:couponId}).then(res =>{
            if(res.data && res.data.code==100){

                wx.navigateBack({
                    delta: 1,
                    success(res) {
                       setTimeout(function () {
                           wx.showToast({
                               title: '使用加衣券成功',
                               icon: 'none',
                               duration: 2000
                           })
                       },1800)
                    }
                })

            }else {
                wx.showToast({
                    title: res.data.msg,
                    icon: 'none',
                    duration: 1000
                })
            }
        })
    },
    getPay:function(){

        let itemId = this.data.itemId
        let openid=Device.getOpenId();
        let dataArguments = {
            payWay: this.data.payWay,
            payType: 7,
            openid,
            itemId,
        }
        pay.pay(dataArguments).then((res)=>{
            console.log(res)
            if(res.data && res.data.code==110){
                this.getClothCouponList().then(res =>{
                    wx.showToast({
                        title: '加衣券购买成功，可立即使用',
                        icon: 'none',
                        duration: 2000
                    })
                })

            }else if(res.data && res.data.code==100 && this.data.payWay ==2){// 微信支付
                let info= res.data.data.paymentInfo
                wx.requestPayment({
                    "timeStamp": info.timeStamp,
                    "package": info.package,
                    "paySign": info.paySign,
                    "signType": 'MD5',
                    "nonceStr": info.nonceStr,
                    'success':(res)=>{
                        this.getClothCouponList().then(res =>{
                            wx.showToast({
                                title: '加衣券购买成功，可立即使用',
                                icon: 'none',
                                duration: 2000
                            })
                        })
                    },
                    'fail':function(res){
                        console.log(res)

                    }
                })
            } else if(res.data && res.data.code==105){
                wx.showToast({
                    title: res.data.msg,
                    icon: 'none',
                    duration: 2000
                })
            }
        })
        this.onClickdiaView()
    },

    formSubmit: function () {
        if(this.data.payWay == 4){
            wx.showModal({
                title: '确认使用'+ this.data.price +'积分兑换商品？',
                content: '您将使用'+ this.data.price +'会员积分兑换' + this.data.couponItem.itemName +'\r\n'+'当前积分余额：'+ this.data.userPoint,
                success:(res)=>{
                    if (res.confirm) {
                        this.getPay();
                        this.setData({isTrue:2,payWay:2})
                    } else if (res.cancel) {
                        //充值默认选择
                        this.setData({isTrue:2,payWay:2})
                    }
                }
            })
        } else {
            this.getPay();
        }
    },

    radioChange:function(e) {
        console.log('radio发生value值：', e.detail.value, e)
        this.setData({
            payValue: JSON.parse(e.detail.value).price,
            payWay: JSON.parse(e.detail.value).payWay,
        })
    },


    showBuy:function(e){
        let item = e.currentTarget.dataset.item;
        this.getPointItemDetail(item.itemId)
        this.setData({
            showDialog: !this.data.showDialog,
            couponItem:item,
            itemId:item.itemId
        });
    },
    onClickdiaView:function(){
        this.setData({
            showDialog: !this.data.showDialog,
            isTrue: 2,
        });
    },
    onClickdiaCenterView:function(){
        this.setData({
            showCenterDialog: !this.data.showCenterDialog
        });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function () {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getClothCouponList()
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    // onShareAppMessage: function () {
    //
    // }
})