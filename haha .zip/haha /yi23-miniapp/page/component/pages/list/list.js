var list = require('../../../../service/list.js');
var us = require('../../../../common/lib/underscore.js');
var ClothesCount = require('../../../../common/clothesCount');
var Session = require('../../../../common/session');
var commitPushForm = require('../../../../common/commitPushForm');
var wishlistAction = require('../../../common/wishlist');
import oldBeltNew from '../../../mixins/oldBeltNew';
let appInstance = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data:{
      isMember:0,// 0.非会员; 1.会员;
      productTag:'',
      productSize:'',
      productList:[],
      selectedTag:'',
      searchKey:'',
      backSearchKey:'',
      showProductBox:false,
      selectedSize:[],
      pageInfo:{
          count:16,
          page:1,
          totalPage:''
      },
      referId:'',
      showShareBox:false,
      isLastPage:false,
      isLoading:false
  },
onShareAppMessage: function (res) {
    var userInfo= Session.get(),referId='';
    if(userInfo.uid){
        referId='&referId='+userInfo.uid
    }
    if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target)
    }
    return {
        title: this.data.searchKey+'，戳这里',
        path: '/page/component/pages/list/list?searchKey='+decodeURIComponent(this.data.searchKey)+referId,
        success: function(res) {
            // 转发成功
        },
        fail: function(res) {
            // 转发失败
        }
    }
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _t=this;
        _t.data.searchKey= decodeURIComponent(options.searchKey);
     var referId=options.referId;
        if(referId){
            _t.referAction(referId);
        }
      wx.setNavigationBarTitle({
          title: _t.data.searchKey
      });
     var userInfo= Session.get();
     if(userInfo){
       _t.setData({isMember:userInfo.isMember})
     }
    _t.getData();
  },
  dataAction:function (data,append) {
      var _t=this,
          productTag=_t.data.productTag?_t.data.productTag:data.productTag,
          productSize;
          data.isLoading=false;
      if(_t.data.productTag){
          for(var i=0;i<productTag.length ;i++){
              if(productTag[i].isActive){
                  delete productTag[i].isActive;
              }
              if(productTag[i].tagId==_t.data.selectedTag){
                  productTag[i].isActive=true;
              }
          }
      }
      delete data.productTag;
      data.productTag=productTag;
      data.showProductBox=true;
      //如果改变筛选逻辑 数据清空处理
      if(append){
          data.productList=_t.data.productList.concat(data.productList);
      }
      return us.extend({},data)
  },
    goUserBox:function (event) {
        let formId = event.detail.formId;
        commitPushForm.send(formId);
        wx.navigateTo({
            url: '/page/component/pages/box/box'
        })
    },
  getData:function (append) {
      var _t=this,
          dataArguments={
            searchKey:_t.data.searchKey,
            count:_t.data.pageInfo.count,
            page:_t.data.pageInfo.page,

      };
      console.log(_t.data.selectedTag);
      if(_t.data.selectedTag){
          dataArguments['tagId[]']=_t.data.selectedTag;
      }
      if(_t.data.selectedSize && _t.data.selectedSize.length>0){
          var sizeArguments=_t.data.selectedSize.join(',');
          sizeArguments=sizeArguments.replace('均码','F');
          dataArguments['size[]']=sizeArguments;
      }
      list.queryList({
          data:dataArguments,
          success:function (res) {
              if(res.data && res.data.code==100){
                  let productList=wishlistAction.showProudectDataFilter(res.data.data.productList,{compareKey:'product_id'})
                  res.data.data.productList=productList
                  var renderData=_t.dataAction(res.data.data,append);
                  _t.setData(renderData,function () {
                  });
              }else{

              }
          },
          complete:function (res) {
              console.log(res)
          }
      });
  },
  sizeSelect:function (event) {
      var _t=this,
          sizeJon={
              state:event.currentTarget.dataset.state,
              size:event.currentTarget.dataset.size
          };
      if(sizeJon.state==1){
          _t.data.selectedSize.push(sizeJon.size);
          _t.setData({
              selectedSize:_t.data.selectedSize,
              product_list:[],
              isLastPage:false,
              pageInfo:{
                  count:15,
                  page:1
              }
          })
          _t.getData();
      }else{
          _t.data.selectedSize=us.without(_t.data.selectedSize,sizeJon.size);
          _t.setData({
              selectedSize:_t.data.selectedSize,
              product_list:[],
              isLastPage:false,
              pageInfo:{
                  count:15,
                  page:1
              }
          })
          _t.getData();
      }
  },
  tagSelect:function (event) {
      var _t=this,
          tagJon={
          state:event.currentTarget.dataset.state,
          tagid:event.currentTarget.dataset.tagid
      };
      console.log(tagJon);
      if(tagJon.state==1){
        _t.setData({
            selectedTag:tagJon.tagid,
            product_list:[],
            isLastPage:false,
            pageInfo:{
                count:15,
                page:1
            }
        },function () {

        })
          _t.getData();
      }else{
          _t.setData({
              selectedTag:'',
              product_list:[],
              isLastPage:false,
              pageInfo:{
                  count:15,
                  page:1
              }
          },function () {
              console.log('--success--');

          })
          _t.getData();
      }
  },
    toDetail:function (event) {
       var productid=event.currentTarget.dataset.productid;
       var path=event.currentTarget.dataset.path;
      var index=event.currentTarget.dataset.index;
      appInstance.globalData.wishlistActionData={
        dataKey:'productList',
        compareKey:'product_id',
        index:index,
        data:this.data.productList,
        that:this
      }
        let formId = event.detail.formId;
        commitPushForm.send(formId);
        wx.navigateTo({
            url: '../product/product?id='+productid+'&path='+encodeURIComponent(path)
        })
    },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log('onReadyList');
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      var _t=this;
      ClothesCount.getForRq(function (res) {
          _t.setData(res)
      })
      if(_t.data.backSearchKey){
          _t.data.searchKey=decodeURIComponent(_t.data.backSearchKey)
          wx.setNavigationBarTitle({
              title: _t.data.searchKey
          });
          _t.data.backSearchKey='';
      }
    wishlistAction.doChangeWishlistStatus()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var _t=this,
    data=this.data.pageInfo;
    if(!data.isLoading && data.page<data.totalPage){
      data.page=data.page+1;
      this.setData({pageInfo:data,isLoading:true});
      // console.log(_t.data);
      _t.getData(true);
    }else{
        if(data.totalPage!=0){
            this.setData({isLastPage:true,isLoading:false});
        }
    }
  },
  doWishlist:function (event) {
    wishlistAction.wishlistEventAction(event,this)
  },
  ...oldBeltNew
})