// pages/paydeposit/paydeposit.js
var CheckUserZhima = require('../../../../service/checkUserZhima.js');
var common = require('../../../../common/common.js');
var Pay = require('../../../../service/pay.js');
var serviceOrder = require('../../../../service/order.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
      timer:'',
      backRun:false,
      checkInfo:{step:0,status:0,idCard:'',name:''},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      let info=decodeURIComponent(options.info);
      let _t=this;
      if(info){
          info=JSON.parse(info);
      }
      console.log(info)
      this.setData({info:info})
      let remainingTime=info.reserveEndTime-info.systemNow
      console.log(remainingTime)
      //
      if(info){
          this.data.timer= setInterval(()=>{
             remainingTime= remainingTime-990
             // console.log(remainingTime)
             if(remainingTime<0){
                 clearInterval(this.data.timer);
                 _t.cancelPendingOrder()
             }
          },1000)
      }
  },
    cancelPendingOrder:function (notMessage) {
        serviceOrder.cancelPendingOrder({
            success:function (res) {
                if(res.data && res.data.code==100){
                    if(!notMessage){
                        wx.showModal({
                            title: '订单超时',
                            content: '等的太久了，订单已被取消。请重新下单',
                            showCancel:false,
                            success: function(res) {
                                if (res.confirm) {
                                    wx.navigateBack({
                                        delta: 1
                                    })
                                }
                            }
                        })
                    }
                }
            }
        });
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onShow: function () {
        console.log(this.data.backRun)
        console.log('--show----'+this.data.backRun)
        if(this.data.backRun){
            this.data.backRun=false;
            wx.navigateBack({
                delta: 1
            })
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
        this.data.backRun=true;
        console.log('---hide---'+this.data.backRun)
    },
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
        console.log('-Unload---')
        this.cancelPendingOrder(true);
        clearTimeout(this.data.timer);
    },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
    doPay:function () {
        var _t=this;
        let options={
            payType:12,
            payWay:2,
            version:'2.7.1'
        }
        Pay.pay({
            data:options,
            success:function (res) {
                console.log(res)
                var data=res.data;
                if(data && data.code==100){
                    var info=data.data;
                    wx.requestPayment({
                        "timeStamp": info.timeStamp,
                        "package": info.package,
                        "paySign": info.paySign,
                        "signType": info.signType,
                        "nonceStr": info.nonceStr,
                        'success':function(res){
                            console.log(res);
                            wx.redirectTo({
                                url: '/page/component/pages/order/order'
                            })
                        },
                        'fail':function(res){
                            console.log(res)
                        }
                    })
                }else if(data && data.code==110){
                    wx.redirectTo({
                        url: '/page/component/pages/order/order'
                    })
                }
            }
        })
    },
    //芝麻 start
    checkUserZhima:function () {
        var _t=this;
        _t.setData({checkInfo:{step:1,status:0}})
    },
    closeCheck:function (event) {
        let step=event.currentTarget.dataset.step;
        this.setData({checkInfo:{step:step,status:0}})
    },
    checkUserZhimaStep2:function () {
        var _t=this;
        if(_t.data.checkInfo.name){
            _t.data.checkInfo.step=2;
            _t.data.checkInfo.status=0;
            _t.setData({checkInfo:_t.data.checkInfo})
        }
    },
    checkUserZhimaStep3:function () {
        var _t=this;
        if(_t.data.checkInfo.idCard){
            _t.data.checkInfo.status=2;
            _t.setData({checkInfo:_t.data.checkInfo});
            CheckUserZhima.checkUserZhima({
                data:{idCard:_t.data.checkInfo.idCard,name:_t.data.checkInfo.name},
                success:function (res) {
                    var data=res.data;
                    if(data && data.code==100){
                        _t.data.checkInfo.step=3;
                        _t.setData({checkInfo:_t.data.checkInfo})
                        setTimeout(()=>{
                            wx.redirectTo({
                                url: '/page/component/pages/order/order'
                            })
                        },3000)
                    }else{
                        _t.data.checkInfo.status=1;
                        _t.setData({checkInfo:_t.data.checkInfo});
                        common.showMsg(data.msg);
                    }
                }
            })
        }
    },
    idCardInput:function (e) {
        var _t=this;
        if(e.detail.value){
            _t.data.checkInfo.idCard=e.detail.value;
            _t.data.checkInfo.status=1;
            _t.setData({checkInfo:_t.data.checkInfo})
        }else{
            _t.data.checkInfo.idCard=e.detail.value;
            _t.data.checkInfo.status=0;
            _t.setData({checkInfo:_t.data.checkInfo})
        }
    },
    checkInfoNameInput:function (e) {
        var _t=this;
        if(e.detail.value){
            _t.data.checkInfo.name=e.detail.value;
            _t.data.checkInfo.status=1;
            _t.setData({checkInfo:_t.data.checkInfo})
        }else{
            _t.data.checkInfo.name=e.detail.value;
            _t.data.checkInfo.status=0;
            _t.setData({checkInfo:_t.data.checkInfo})
        }
    }
    // 芝麻end
})