var serviceBox = require('../../../../service/box.js');
var Session = require('../../../../common/session.js');
var common = require('../../../../common/common.js');
import navfooter from '../../../mixins/navfooter';
import loginMixin from '../../../mixins/login';
import * as  watch  from "../../../../util/watch.js";
import Box from '../../../../api/box.js';
Page({
    ...loginMixin,
    data:{
        clothesCountInBox:0,
        isBox:true,
        showNotInit:false,//选择收获地址 缓存处理
        cart:[],
        addBtnList:0,
        userCard:{
            name:'',
            id:''
        },
        boxesInUse:'',
        depositInfo:'',//押金后置
        needUserIdentityCard:-1,//1不需要 0 需要 -1未请求过
        showUserIdentityCardBox:1,//0 展示 1不展示
        addSlot:3,
    },
    watch: {
        isLogin:function (newVal, oldVal){
            if(newVal){
                this.itemInit();
            }
        }
    },
    onLoad: function (options) {
        watch.setWatcher(this);
    },
    onShow:function () {
        var _t=this;
        _t.setLoginStatus()
        if(!this.isLogin){
            return
        }
        _t.itemInit();
    },
    itemInit:function () {
        var _t=this;
        return new Promise((resolve, reject) => {
            Box.userCloset().then((res)=>{
                resolve()
                if(res.data && res.data.code==100){
                    var boxData=res.data.data,sum=boxData.userBoxMeta.userBoxSlotCount+boxData.userBoxMeta.extendedBoxSlotCount;
                    let lengthNum=0;
                    for (let k in boxData.canRentUserClosetItems){
                        lengthNum= lengthNum+boxData.canRentUserClosetItems[k].boxSlot
                    }
                    let allUseSlot=0;
                    let userDefulatSlot=boxData.userBoxMeta.userBoxSlotCount

                    for(let key in boxData.userBoxItems){
                        allUseSlot=allUseSlot+boxData.userBoxItems[key].boxSlot
                    }
                    let handlingUserBoxItems= boxData.userBoxItems.reduce((accumulator,currentValue)=>{
                        accumulator.push(currentValue)
                        for(let n=1;n< currentValue.boxSlot;n++){
                            accumulator.push({boxSlot:currentValue.boxSlot,isGray:true})
                        }
                        return accumulator
                    },[])
                    if(handlingUserBoxItems.length<sum){
                        let slotRes=new Array(sum)
                        slotRes=slotRes.slice(handlingUserBoxItems.length)
                        handlingUserBoxItems=[...handlingUserBoxItems,...slotRes]
                    }
                    let handlingDataLength=handlingUserBoxItems.length-1;
                    _t.setData({
                        userAllSlot:sum,// 用户总盒子
                        useSlot:allUseSlot,//用户已使用 盒子
                        userDefulatSlot:userDefulatSlot,//用户默认盒子

                        userBoxItems:boxData.userBoxItems,
                        handlingUserBoxItems:handlingUserBoxItems,
                        remainSlot:sum-allUseSlot,//剩余盒子
                        couponCellTopBorder:!handlingUserBoxItems[handlingDataLength] || handlingUserBoxItems[handlingDataLength].isGray==true ,
                        userBoxMeta:boxData.userBoxMeta,
                        orderRestriction:boxData.orderRestriction,
                        depositInfo:boxData.depositInfo
                    })
                    _t.getBoxesInUse()
                }
            })
        })


        // ClothesCount.getForRq(function(res) {
        //   _t.setData(res)
        // })

    },
    delItem:function (id,callback) {
        var _t=this;
        serviceBox.delUserBoxItemList({
            data:{
                skuId:id
            },
            success:function (res) {
                callback && callback(res);
            }
        })
    },
    addrAction:function () {
        var _t=this;
        if(_t.loginAction()){
            console.log('--addrAction--')
            _t.setData({showNotInit:false})
            wx.navigateTo({
                url: '../addrList/addrList'
            })
        }
    },
    doOrder:function () {
        var _t=this;
        if(!_t.doVip()){
            //判断是否是会员
            return;
        }
        if(_t.data.depositInfo.isUseDeposit){
            //押金后置
            common.showMsg('小仙女，衣物贵重需要交纳押金，APP下单可以免押哦');
            return false;
        }
        wx.navigateTo({
            url: '/page/component/pages/comfirmOrder/comfirmOrder?delayDays='+(this.data.userBoxMeta.delayDays || 0)
        });
    },
    doVip:function () {
        var userInfo= Session.get(),memberStatus=false;
        if(userInfo && userInfo.isMember==1){
            memberStatus=true;
        }else{
            wx.navigateTo({
                url: '/page/component/pages/pay/pay'
            });
            memberStatus=false;
        }
        return memberStatus;
    },
    toProDetail:function (event) {
        var id= event.currentTarget.dataset.id;
        console.log('box: -go- '+id);
        wx.reLaunch({
            url: '../product/product?id='+id
        })
    },
    delCartItem:function (event) {
        var _t=this;
        var id= event.currentTarget.dataset.id;
        console.log('box: -del- '+id);
        _t.delItem(id,function (res) {
            if(res.data && res.data.code==100){
                _t.itemInit();
            }
        })
    },
    setUserCardName:function (e) {
        var _t=this;
        _t.setData({userCard:{name:e.detail.value,id:_t.data.userCard.id}})
    },
    setUserCardCode:function (e) {
        var _t=this;
        _t.setData({userCard:{id:e.detail.value,name:_t.data.userCard.name}})
    },

    closeUserCardBox:function () {
        var _t=this;
        _t.setData({showUserIdentityCardBox:1})
    },
    //关闭引导
    closeFooterTipsBox: function () {
        var _t = this;
        wx.setStorage({
            key:'FooterTipsBox',
            data:1,
            complete:function(data){
            }
        });
    },
    //使用衣箱处理
    getBoxesInUse:function () {
        var _t=this;
        serviceBox.queryUserBoxList( {
            data:{
                version:'2.7.1'
            },
            success:function (res) {
                if(res.data && res.data.code==100){
                    let boxData=res.data.data
                    _t.setData({
                        boxesInUse:boxData.boxesInUse,
                    })
                }
            }
        })
    },
    //去使用加衣券
    toCouponList(){
        wx.navigateTo({
            url: '/page/component/pages/clothCoupon/clothCoupon'
        })
    },
    cannelCounpon(){
        wx.showModal({
            title: '',
            content: '确定不使用加衣券吗?',
            confirmColor:'#ff554b',
            success:(res)=>{
                if (res.confirm) {
                    Box.cancelAddClothCoupon().then(res =>{
                        this.itemInit().then(res =>{
                            setTimeout(function () {
                                wx.showToast({
                                    title: '取消使用加衣券成功',
                                    icon: 'none',
                                    delay:0,
                                    duration: 3000
                                })
                            },1000)

                        })
                    })
                } else if (res.cancel) {

                }
            }
        })
    },
    ...navfooter
})