var constants = require('../../../../common/lib/constants')
var Login = require('../../../../common/login_authorize');
var wishlistAction = require('../../../common/wishlist');
var sensors = require('../../../../util/sensorsdata.min.js');
var Session = require('../../../../common/session');
Page({
  data: {
  },
  onLoad: function (options) {
  },
  onShow: function () {
  },
  onHide: function () {
  },
  onGotUserInfo: function (e) {
    var _t = this
    if (e.detail.errMsg == 'getUserInfo:ok') {
      wx.redirectTo({
        url: '/page/component/pages/loginByTel/login'
      })
    }
  },
  btnCannel: function (e) {
    wx.navigateBack({
      delta: 1
    })
  }
})