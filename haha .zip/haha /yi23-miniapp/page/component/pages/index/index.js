var commitPushForm = require('../../../../common/commitPushForm');
var ProductList = require('../../../../service/productList.js');
var serviceIndex = require('../../../../service/index.js');
var Session = require('../../../../common/session.js');
var trackPoint = require('../../../../util/track_point.js');
var utils = require('../../../../util/util.js');
var Filter = require('../../../../service/filter.js');
var us = require('../../../../common/lib/underscore.js');
var wishlistAction = require('../../../common/wishlist');
var carFilter = require('../../../../common/categoryFilter.js');
var common = require('../../../../common/common.js');
let appInstance = getApp()
import keyMapData from './temKeyData.js';
import navfooter from '../../../mixins/navfooter';
import oldBeltNew from '../../../mixins/oldBeltNew';

Page({
  data: {
    isIndex:true,
    isTips: false,
    firstTip: true,
      secondTip: false,
      thirdTip: false,
    fourTip:false,
    filterTopNum: '',
    filterTopStatus: false, //是否已经吸顶
    isMember: 0, // 0.非会员; 1.会员;
    searchItems: [],
    clothesCountInBox: 0,
    itemListAll: [],
    swiperIn: 1,
    isShowFilter: false,
    seletedFilterStatus: { sort: false, size: false, other: false },
      // seletedFilter:{
      //     filterId:[],
      //     tagId:[],
      //     season:[],
      //     size:[],
      //     type_id:[],
      //     scene:[]
      // },
    select: {
      color_id: [],
      filterId: [],
      tagId: [],
      tagList:[],
      season: [],
      size: [],
      type_id: [],
      scene: [],
    },
    tagMap: [],
    barSelect:[],
    pageInfo: {
      totalNum: '1',
      "count": 10,
      "page": 1
    },
    productList: [],
    showShareBox: false,
    isLastPage: false,
    isShow: true,
    isBackFromFilter: false,
    isLoading: false,
    isFooterTipsIndex: false,
    dialog: {
      isShow: false,
      data: null
    },
    allGoodsFilte: [
      { name: '专人配送', value: '0', checked: false },
    ],
    emptyFilt:true
  },
  onLoad: function(options) {
    var _t = this;

    var referId = options.referId;
    if (referId) {
      _t.referAction(referId);
    }
    _t.getProdouctList();
  },
  //首页弹窗展示
  isPopupViewShow: function() {
    var _t = this;
    var userInfo = Session.get();
    if(!userInfo) return;
    //通过全局变量判断是否加载弹窗数据
    if (this.isExpiresLocalStorage('yi23-popViewIndex')) {
      serviceIndex.popupView({
        data: {
          vid: 2
        },
        success: function(res) {
          if (res.data.code == 100 && res.data.data != '') {
            //弹窗数据展示
            _t.setData({
              'dialog.isShow': true,
              'dialog.data': res.data.data
            })
            wx.setStorageSync('yi23-popViewIndex',{value:1,timer:utils.toLocaleDateStringFormat(new Date().getTime())});
            trackPoint.popViewVisit({'popupViewId':res.data.data.id})
          }
        }
      })
    }
  },
  isExpiresLocalStorage: function(name){
    let timer = wx.getStorageSync(name) && wx.getStorageSync(name).timer;
    let now = utils.toLocaleDateStringFormat(new Date().getTime());

    if(!timer || Number(now)>Number(timer)){
      return true
    }
    return false
  },
  dialog_BannerJump: function(event) {
    var url = event.currentTarget.dataset.url;
    trackPoint.popviewTapCount({'popupViewId':this.data.dialog.data.id});
    this.dialog_Closed();
    if (url) {
      wx.navigateTo({
        url: url
      })
    }
  },
  dialog_Closed: function() {
    this.setData({
      'dialog.isShow': false
    })
  },
  //初始化头部数据
  getHeaderData: function() {
    var _t = this;
    serviceIndex.queryHome({
      success: function(res) {
        if (res.data.code == 100) {
          let data = res.data.data;

          let itemList = data.itemList.map((el) => {
            if (keyMapData[el.itemType]) {
              el.temName = keyMapData[el.itemType].templateName
            }
            return el
          })
          _t.setData({
            itemListAll: itemList,
            hoverItem:res.data.data.hoverItem?res.data.data.hoverItem:'',
            isShowFilter: true
          }, function() {
            _t.offsetTop()
          });
        }
      }
    })
  },
    optionsAction:function () {

    },
  getProdouctList:function (append) {
      var page = append?this.data.pageInfo.page:1;
      var data={
          stockFirst:1,
          page:page,
          count:this.data.pageInfo.count,
      },_t=this,select=_t.data.select,numEmpt=0;
      for (var k in select) {
          if(k==='tagList'){
              data['tagId[]'] = select[k].join(',');
          }else {
              data[k + '[]'] = select[k].join(',');
          }
      }
    ProductList.queryList({
      data: data,
      success: function(res) {
        if (res.data.code == 100) {
          var data = res.data.data;
          let productList=wishlistAction.showProudectDataFilter(data.productList,{compareKey:'product_id'})
          data.productList=productList
          if (append) {
            data.productList = _t.data.productList.concat(data.productList);
          }
          _t.setData({ pageInfo: data.pageInfo, productList: data.productList, isLoading: false }) //isNothing

        }
      }
    })

  },
  //筛选项
  getCategory:function () {
      var _t=this;
      Filter.queryProductFilters({
          success:function (res) {

              if(res.data && res.data.code==100){
                  var category={};
                  category.color_id=res.data.data.colorFilterList;
                  category.filterId=res.data.data.customizedFilter.dataList;
                  category.tagId=res.data.data.featuredTagsFilter.dataList;
                  category.season=res.data.data.productSeasonFilter.dataList;
                  category.size=res.data.data.productSizeFilter.dataList;
                  category.type_id=res.data.data.productTypeFilter.dataList;
                  category.scene=res.data.data.sceneFilter.dataList;
                  category.tagList=res.data.data.tagCategoryList;
                  _t.setData({category:category})

        } else {
                wx.showToast({
                  title: res.data.msg,
                  icon: 'none',
                  duration: 2000
                })
        }
      }
    })
  },
    //选择与取消筛选项
    doFilter:function (event) {
        let _t = this,
            doFilterList = {
                key : event.currentTarget.dataset.key || '',
                id : event.currentTarget.dataset.id || '',
                name: event.currentTarget.dataset.name || '',
                tag : event.currentTarget.dataset.tag || '',
                category : event.currentTarget.dataset.category || '',
                seleted : _t.data.select,
                barSelect : _t.data.barSelect,
                tagMap : _t.data.tagMap,
            };
        if(doFilterList.key === 'size'){
            doFilterList.id = doFilterList.name;
        }
        if(us.isArray(doFilterList.seleted[doFilterList.key])){
            if(doFilterList.seleted[doFilterList.key].indexOf(doFilterList.id)==-1){
                doFilterList.seleted[doFilterList.key].push(doFilterList.id);
                carFilter.addFilter(doFilterList);
            }else{
                if(doFilterList.tag && doFilterList.tag.length>0){
                    carFilter.cancelFilterTag(doFilterList);
                }
                carFilter.cancelFilter(doFilterList);
            }
        }else{
            doFilterList.seleted[doFilterList.key]=doFilterList.id;
            carFilter.addFilter(doFilterList);
        }
        this.setData({select:doFilterList.seleted,tagMap:doFilterList.tagMap,barSelect:doFilterList.barSelect});
        _t.getProdouctList();
    },
  toDetail:function (event) {
    var productid=event.currentTarget.dataset.productid;
    var index=event.currentTarget.dataset.index;
    appInstance.globalData.wishlistActionData={
      dataKey:'productList',
      compareKey:'product_id',
      index:index,
      data:this.data.productList,
      that:this
    }
    let formId = event.detail.formId;
    var path = event.currentTarget.dataset.path;
    commitPushForm.send(formId);
    wx.navigateTo({
      url: '../product/product?id=' + productid + '&path=' + encodeURIComponent(path)
    })
  },
  // swiper指示点
  swiperChange: function(e) {
    this.setData({
      swiperIn: e.detail.current + 1
    })
  },
  bannerJump: function(event) {
    let url = event.currentTarget.dataset.url;
    wx.navigateTo({
      url: url
    })
  },
  menuJump: function(event) {
    let url = event.currentTarget.dataset.url;
    trackPoint.getBanner(url);
    wx.navigateTo({
      url: url
    })
  },
  initFilter: function(data,bar,tagMap) {
    var _t = this;
    var filterStatus = { sort: false, size: false, other: false };
    // console.log(data);
    if (data) {
      filterStatus.sort = (data.sort == 1 ? false : true);
      filterStatus.size = (data.size.length > 0 ? true : false);
      if (data.scene.length > 0 || data.type_id.length > 0 || data.color_id.length > 0) {
        filterStatus.other = true;
      }
    }
      // bar.unshift.apply( bar, this.data.barSelect);
      // bar.unshift.apply( bar, this.data.barSelect);
      // bar.unshift.apply( bar, this.data.barSelect);
    _t.setData({ seletedFilterStatus: filterStatus, isBackFromFilter: true, filterTopStatus: false, select: data, barSelect: bar, tagMap: tagMap, pageInfo: { page: 1, count: 10, totalNum: 1 } });
    _t.getProdouctList();
    console.log('----index---initFilter');

  },
  //初始化元素距顶位置
  offsetTop: function() {
    var _t = this;
    var query = wx.createSelectorQuery();
    query.select('#filterBox').boundingClientRect();
    query.selectViewport().scrollOffset();
    query.exec(function(res) {
      if (res && res[0] && res[0].top) {
        _t.setData({ filterTopNum: res[0].top });
      }

    })
  },
  selectedFilter: function() {
    let url = '/page/component/pages/category/category?seletedFilter=' + JSON.stringify(this.data.select) + '&barSelect=' + JSON.stringify(this.data.barSelect) + '&tagMap=' + JSON.stringify(this.data.tagMap);
    wx.navigateTo({
      url: url
    })
  },
  onPageScroll: function(optios) {
    var _t = this,
      topNum = _t.data.filterTopNum;
    console.log("topNum: " + topNum)
    if (_t.data.isShow) {
      if (!topNum) {
        _t.offsetTop()
      }
      // console.log(optios.scrollTop > topNum)
      if (optios.scrollTop > topNum) {
        if (!_t.data.filterTopStatus) {
          _t.setData({ filterTopStatus: true })
        }
      } else {
        if (_t.data.filterTopStatus) {
          _t.setData({ filterTopStatus: false })
        }
      }
    }
  },
  onReady: function() {
  },
  doFixboxClick:function (event) {
    let url = event.currentTarget.dataset.url;
    trackPoint.getBanner(url);
    wx.navigateTo({
      url: url
    })
  },

    goUserCenter: function() {
        wx.reLaunch({
            url: '/page/component/pages/my/my'
        })
    },
  //滚动到最底部处理
  onReachBottom: function() {
    // console.log('end ')
    var _t = this,
      data = this.data.pageInfo;
    if (!data.isLoading && data.page < data.totalPage) {
      data.page = data.page + 1;
      this.setData({ pageInfo: data, isLoading: true, isLastPage: false });
      // console.log(_t.data);
      _t.getProdouctList(true);
    } else {
      if (data.totalPage != 0) {
        this.setData({ isLastPage: true, isLoading: false });
      }
    }
  },
  onHide: function() {
    this.setData({ isShow: false, isBackFromFilter: false })
  },
  onShow: function() {
    var _t = this;
    _t.getHeaderData();
    wishlistAction.doChangeWishlistStatus()
    _t.getCategory();
    _t.setData({ isShow: true });
    // ClothesCount.getForRq(function(res) {
    //   var userInfo = Session.get();
    //   if (userInfo) {
    //     _t.setData({ isMember: userInfo.isMember })
    //   }
    //   _t.setData(res)
    // })
    if (this.data.isBackFromFilter) {
      if (wx.pageScrollTo) {
        wx.pageScrollTo({
          scrollTop: 0
        })
      }
    }
    if (!wx.getStorageSync('FooterTipsIndex')) {
      _t.setData({ isFooterTipsIndex: true });
    }
    if(!wx.getStorageSync('tips')){
      _t.setData({isTips:true});
    }

    // step
    let res = wx.getStorageSync('tips');
    if (res) {
      _t.setData({
        isTips: false
      })
    }
    _t.isPopupViewShow();
  },

  onShareAppMessage: function(res) {
    var userInfo = Session.get(),
      referId = '';
    if (userInfo.uid) {
      referId = '?referId=' + userInfo.uid
    }
    return {
      title: '快来和我一起包月换穿全球大牌时装',
      imageUrl: 'https://yimg.yi23.net/webimg/web/images/2018/1207/share_222.png',
      path: '/page/component/pages/index/index' + referId,
      success: function(res) {
        // 转发成功
      },
      fail: function(res) {
        // 转发失败
      }
    }
  },

  //关闭引导
  // closeFooterTipsIndex: function() {
  //   var _t = this;
  //   wx.setStorage({
  //     key: 'FooterTipsIndex',
  //     data: 1,
  //     complete: function(data) {}
  //   });
  //   _t.setData({ isFooterTipsIndex: false });
  // },

  stepOne() {
    this.setData({
      firstTip: false,
      secondTip: true,
    });
  },
  stepTwo() {
    this.setData({
      secondTip: false,
      thirdTip: true,
    });
  },
  // stepThree() {
  //   wx.setStorageSync(
  //    'tips', 1
  //   );
  //   this.setData({
  //     isTips: false,
  //   });
  //
  // },




  stepThree() {
    this.setData({
      thirdTip:false,
      fourTip:true
    });

  },

  stepFour() {
    wx.setStorageSync(
        'tips', 1
    );
    this.setData({
      isTips: false,
    });

  },


    doWishlist:function (event) {
        wishlistAction.wishlistEventAction(event,this)
    },
  ...navfooter,
  ...oldBeltNew,
})