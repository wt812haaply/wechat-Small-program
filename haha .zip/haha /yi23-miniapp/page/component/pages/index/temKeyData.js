/**
 * Created by ahu on 2017/12/27.
 */
export default {
    '5': {
        templateName: 'searchItem'
    },
    '12': {
        templateName: 'swiperAll'
    }
}