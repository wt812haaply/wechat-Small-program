import Login from '../../../../api/login';
var common = require('../../../../common/common.js')
var pageView = require('../../../../common/pageView.js');
import Auth from '../../../../common/auth'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isSend: false,
    showContent:true,
    mobile: '',
    code: '',
    phoneCode: 60,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _t = this
    pageView.init();

  },
  mobileInput: function (e) {
    var _t = this
    _t.setData({mobile: e.detail.value})
  },
  codeInput: function (e) {
    var _t = this
    _t.setData({code: e.detail.value})
  },
  bindMobile: function () {
    var _t = this

    if (_t.data.code == '' || _t.data.mobile == '') {
      common.showMsg('请输入正确的手机号')
      return false
    }
    var dataJson = {
      verifyCode: _t.data.code,
      mobile: _t.data.mobile,
    }

    Auth.bindMobile(dataJson)
  },
  getVerification: function () {
    var _t = this
    if (_t.data.mobile != '') {
      console.log('获取短信验证码： ' + _t.data.mobile)
      _t.setData({isSend: true})

      let time = setInterval(() => {
        let phoneCode = _t.data.phoneCode
        phoneCode--
        _t.setData({
          phoneCode: phoneCode
        })
        if (phoneCode == 0) {
          clearInterval(time)
          _t.setData({
            phoneCode: '60',
            isSend: false
          })
        }
      }, 1000)
      Login.sendVerification({mobile: _t.data.mobile}).then((res)=>{
        if(res.data.code != 100){
          wx.showToast({
            title: res.data.msg,
            icon:'none',
            duration: 1500
          })
        }
      })
    } else {
      wx.showToast({
        title: '请输入手机号',
        duration: 1500
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})