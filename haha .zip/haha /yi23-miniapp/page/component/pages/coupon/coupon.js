var Pay = require('../../../../service/pay.js');
var pageView = require('../../../../common/pageView.js');
Page({

  /**
   * 页面的初始数据valueType:2 折扣券 valueType：0 加一衣券  1：金额券
   */
  data: {
      couponList:[],
      payType:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var _t=this;
      if(options.payType){
        _t.setData({payType:options.payType})
      }
      _t.initCouponList();
      pageView.init();
  },
  initCouponList:function (callback) {
      var _t=this;
      Pay.getValidCouponListByPayType({
          data:{payType:_t.data.payType},
          success:function (res) {
              var data=res.data;
              if(data && data.code==100){
                  var data=res.data;
                  if(data && data.code==100){
                      _t.setData({couponList:data.data})
                  }
              }
          },
          complete:function () {
              callback && callback()
          }
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  selectedCoupon:function (event) {
      var info= event.currentTarget.dataset.info;
      if(pageView.routeEqual(pageView.prevPage,'pay/pay')){
          pageView.prevPage.setData({couponInfo:info,couponId:info.couponId,isGoback:true},function () {

          });
          // pageView.prevPage.initPayList();
          pageView.prevPage.couponSelectCallBack();
          wx.navigateBack({
              delta: 1
          })
      }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})