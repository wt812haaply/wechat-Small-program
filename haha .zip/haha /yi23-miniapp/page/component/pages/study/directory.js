// directory.js
var address1 = require('./city.js');
var address = require('./city_1.js').data;
Page({

  /**
   * 页面的初始数据
   * 当前    provinces:所有省份
   * citys选择省对应的所有市,
   * areas选择市对应的所有区
   * provinces：当前被选中的省
   * city当前被选中的市
   * areas当前被选中的区
   */
  data: {
    isVisible: false,
    animationData: {},
    animationAddressMenu: {},
    addressMenuIsShow: false,
    value: [0, 0, 0],
    provinces: [],
    citys: [],
    areas: [],
    areaId: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 初始化动画变量
      this.initStudy();
  },
  initStudy:function () {
        var animation = wx.createAnimation({
            duration: 500,
            transformOrigin: "50% 50%",
            timingFunction: 'ease',
        })
        this.animation = animation;
        // 默认联动显示北京
        var id = 0,
            provinces=address.str.split(','),
            citys=address.list[provinces[id]].str.split(','),
            areas=address.list[provinces[id]].list[citys[id]];

        this.setData({
            provinces: provinces,
            citys: citys,
            areas: areas,
        })
        console.log(this.data)
    },
  // 执行动画
  startAnimation: function (isShow, offset) {
    var that = this
    var offsetTem
    if (offset == 0) {
      offsetTem = offset
    } else {
      offsetTem = offset + 'rpx'
    }
    this.animation.translateY(offset).step()
    this.setData({
      animationData: this.animation.export(),
      isVisible: isShow
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 点击所在地区弹出选择框
  selectDistrict: function (e) {
    var that = this
    if (that.data.addressMenuIsShow) {
      return
    }
    that.startAddressAnimation(true)
  },
  // 执行动画
  startAddressAnimation: function (isShow) {
    console.log(isShow)
    var that = this
    if (isShow) {
      that.animation.translateY(0 + 'vh').step()
    } else {
      that.animation.translateY(40 + 'vh').step()
    }
    that.setData({
      animationAddressMenu: that.animation.export(),
      addressMenuIsShow: isShow,
    })
  },
  // 点击地区选择取消按钮
  cityCancel: function (e) {
    this.startAddressAnimation(false)
  },
  // 点击地区选择确定按钮
  citySure: function (e) {
    var that = this
    var value = that.data.value
    that.startAddressAnimation(false);
    // 将选择的城市信息显示到输入框
    var areaInfo = that.data.provinces[value[0]] + ',' + that.data.citys[value[1]] + ',' + that.data.areas[value[2]].name;
    that.setData({
      areaInfo: areaInfo,
      areaId:that.data.areas[value[2]].rgn
    })
      console.log(that.data);
  },
  hideCitySelected: function (e) {
    console.log(e)
    this.startAddressAnimation(false)
  },
  // 处理省市县联动逻辑
  cityChange: function (e) {
      var value = e.detail.value
      var provinceNum = value[0],
          cityNum = value[1],
          countyNum = value[2],
          provinces = this.data.provinces,
          citys = address.list[provinces[provinceNum]].str.split(','),
          areas = address.list[provinces[provinceNum]].list[citys[cityNum]];
    if (this.data.value[0] != provinceNum) {
      this.setData({
        value: [provinceNum, 0, 0],
        citys: citys,
        areas: areas,
      })
    } else if (this.data.value[1] != cityNum) {
      this.setData({
        value: [provinceNum, cityNum, 0],
        areas: areas,
      })
    } else {
        console.log(countyNum)
        this.setData({
          value: [provinceNum, cityNum, countyNum]
        })
    }
    console.log(this.data)
  },

})