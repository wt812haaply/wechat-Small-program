import box from "../../../../api/box"
import address from "../../../../api/address"
var common = require('../../../../common/common.js');
var Session = require('../../../../common/session')
var Region = require('../../../../common/region.js');
const weekDays = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info: null,
    addrInfo: null,
    showNotInit: false,
    expressNotice: false,
    delDate: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      delDate:options.delayDays
    })
    this.getOrderInfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    this.initArriveTime()

    if(this.data.showNotInit){
      return;
    }
    this.addrInit()
  },
  getOrderInfo() {
    box.userCloset().then((res) => {
      if (res.data && res.data.code == 100) {
        this.setData({
          info: res.data.data.userBoxItems,
          depositInfo: res.data.data.depositInfo,
          userBoxItems: res.data.data.userBoxItems
        })
        if (res.data.data.userBoxMeta) {
          let deliveryTime = res.data.data.userBoxMeta.estimatedShippingDate
          this.setData({
            deliveryTime:  this.getDate(deliveryTime),
            delayDays: res.data.data.userBoxMeta.delayDays
          })
        }
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000
        })
      }
    })
  },
  initArriveTime() {
    if (this.data.addrInfo) {
      this.setData({
        arriveTime: this.getDate(this.data.addrInfo.devDate)
      })
    }
  },
  getDate(del) {
    const myDate = new Date(Date.parse(del));
    const date = {
      expressDate: del,
      week: weekDays[myDate.getDay()],
    }
    return date
  },
  addrInit() {
    let delay = 0
    if (this.data.delDate) {
      delay = this.data.delDate
    }
    address.addrListUrl({delay}).then((res) => {
     if (res.data && res.data.code == 100) {
        this.setData({
          addrInfo: res.data.data[0] || '',
          // arriveTime: this.getDate(res.data.data[0].devDate)
        })
       this.initArriveTime()
     } else {
       wx.showToast({
         title: res.data.msg,
         icon: 'none',
         duration: 2000
       })
     }
   })
  },
  submitOrder() {
    if (this.data.depositInfo.isUseDeposit == 1) {
      common.showMsg('小仙女，衣物贵重，需要交纳押金哦。')
    } else {
      if (!this.data.addrInfo) {
        common.showMsg('请填写详细地址')
      } else {
        let items=this.data.userBoxItems.map(function (el) {
          return el.userBoxItemId
        })
        let region=Region.get();
        if (region && (this.data.addrInfo.cityRgn != region.rgnId)) {
            wx.showModal({
            title: '确定更改收件城市吗?',
            content:`已选城市与收件城市不符，一些衣箱中的单品可能在${this.data.addrInfo.city}无货哦，更改地址后你可能需要重新选择单品`,
            success: (res) => {
              if (res.confirm) {
                Region.set({rgnId:this.data.addrInfo.cityRgn,cityName:this.data.addrInfo.city});
                wx.navigateBack({
                  delta: 1
                })
              }
            }
          })
          return
        }
        box.placeOrderUrl({ addrId:this.data.addrInfo.addrId, date: this.data.arriveTime.expressDate, 'items[]': items.join(',')}).then((res) => {
          if (res.data && res.data.code == 100) {
              wx.redirectTo({
                url: '/page/component/pages/order/order'
              })
          } else {
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 2000
            })
          }
        })
      }
    }
  },
  addrAction:function () {
      wx.navigateTo({
        url: '../addrList/addrList?delayDays='+(this.data.delayDays || 0)
      })
  },
  hideNotice() {
    this.setData({
      expressNotice: !this.data.expressNotice
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})