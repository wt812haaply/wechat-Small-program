/**
 * Created by ahu on 2017/12/27.
 */
export default {
    "code": 100,
    "msg": "内容获取成功",
    "data": {
    "postingId": 0,
        "titleZh": "小程序测试",
        "shareTitle": "小程序测试",
        "titleEn": "WeChat",
        "shareImgUrl": "https://yi23imgtest.oss-cn-beijing.aliyuncs.com/posting/14-20171220_151350-1513754030474.png",
        "shareDescription": "小程序测试",
        "sharePageUrl": "",
        "postingParts": [
        {
            "partType": 8, // input 输入领券
            "partWidth": 750,
            "partHeight": 300,
            "linkUrl": "",
            "eventId":'22222',
            "bgImg":'https://yimg.yi23.net/webimg/web/images/201712/postingpar/6.jpg',             // 大块背景图
            "placeholder":'请输入手机号',       // 占位文案
            "placeholderColor":'red',  // 占位文案 颜色
            "inputColor":'#fff',        // 输入框字体颜色
            "inputBgColor":'#000',      // 输入框背景色
            "inputBorderColor":'red',  // 输入框边线颜色
            "inputBorder":'2px',       //输入框边线值
            "btnBgColor":'#cdcdcd',        //按钮背景
            "btnText":'一件领取',
            "btnColor":'red',      //按钮字体颜色
            // "successInfo":{
            //     "successImgUrl":'https://yimg.yi23.net/webimg/web/images/201712/postingpar/2a.jpg',
            //     "successImgJump":'/page/component/pages/index/index',
            //     "partWidth": 750,
            //     "partHeight": 40
            // }
        },
        {
            "partType": 9,         // 领取按钮
            "imgUrl": "https://yi23imgtest.oss-cn-beijing.aliyuncs.com/posting/14-20171220_151350-1513754030474.png",
            "partWidth": 1024,
            "partHeight": 1024,
            "eventId":'22222',
            "successInfo":{
                "successImgUrl":'https://yimg.yi23.net/webimg/web/images/201712/postingpar/3c.jpg',
                "successImgJump":'/page/component/pages/index/index',
                "partWidth": 750,
                "partHeight": 40
            }
        },
        {
            "partType": 6,//吸顶
            "itemList":[
                {
                    "partWidth": 750,
                    "partHeight": 40,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/g999.png",
                    "linkUrl": "/page/component/pages/index/index",
                },
                {
                    "partWidth": 750,
                    "partHeight": 88,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/g998.png",
                    "linkUrl": "/page/component/index",
                }
            ]
        },
        {
            "partType": 7,//分栏 最多四列
            "itemList":[
                {
                    "partWidth": 188,
                    "partHeight": 292,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/4a.jpg",
                    "linkUrl": "",
                },
                {
                    "partWidth": 188,
                    "partHeight": 292,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/4b.jpg",
                    "linkUrl": "/page/component/pages/index/index",
                },
                {
                    "partWidth": 188,
                    "partHeight": 292,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/4c.jpg",
                    "linkUrl": "",
                },
                {
                    "partWidth": 188,
                    "partHeight": 292,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/4d.jpg",
                    "linkUrl": "",
                }
            ]
        },
        {
            "partType": 10,//吸低
            "itemList":[
                {
                    "partWidth": 750,
                    "partHeight": 88,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/footer.jpg",
                    "linkUrl": "",
                },
                {
                    "partWidth": 750,
                    "partHeight": 88,
                    "imgUrl": "https://yimg.yi23.net/webimg/web/images/201712/postingpar/footer.jpg",
                    "linkUrl": "",
                }
            ]
        },
        {
            "partType": 0,// 单张图
            "imgUrl": "https://yi23imgtest.oss-cn-beijing.aliyuncs.com/posting/14-20171220_151536-1513754136190.jpeg",
            "partWidth": 1080,
            "partHeight": 1920,
            "linkUrl": "/page/component/pages/index/index",
        },
        {
            "partType": 5, //纯文本
            "linkUrl": "",
            "postingText": [
                '这里输入内容...小程新客、、想、、、父母那，。那麻烦，a.nm,a.nm,anm,fasnm,.n吗，饭，麻烦那么，哪方面，按，m.nam,.nfm,anm,fnam,.nm,饭',
                '哪方面，案方面，三门，f.nsam,.nfm,a.nfm,.anfm,.anm,f.nam,fnm,a.fnm,a.nfm,.anfm,.anfm'
            ],
            "partHeight": 0,
            "products": [
            ]
        },
        {
            "partType": 1, //商品列表pid
            "products": [
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 12098,
                    "productName": "动物绣花连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/b0d089afe64040e7bde851abae231150.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=12098&jumpNativeType=6&jumpNativeId=12098",
                    "sort": 0,
                    "brandName": "Peacebird",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 11820,
                    "productName": "长款连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/1c7456c7f45343b2977e8e5e402e3cb8.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=11820&jumpNativeType=6&jumpNativeId=11820",
                    "sort": 0,
                    "brandName": "Peacebird",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 10737,
                    "productName": "网纱绣花连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/ed678c255b8441c7be51e78b5a263621.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=10737&jumpNativeType=6&jumpNativeId=10737",
                    "sort": 0,
                    "brandName": "Lychee Fizz",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 10119,
                    "productName": "粉色网纱波点连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/3db03642fa714a77a2f71a889e415169.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=10119&jumpNativeType=6&jumpNativeId=10119",
                    "sort": 0,
                    "brandName": "Satellite",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 9743,
                    "productName": "藏蓝色印花挂脖式连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/a648ff795f9e4e318f7be9426edd4bba.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=9743&jumpNativeType=6&jumpNativeId=9743",
                    "sort": 0,
                    "brandName": "Smart&Joy",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 9518,
                    "productName": "蓝色印花图案连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/01c6d115dcee41b3872eb0f6718c4b30.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=9518&jumpNativeType=6&jumpNativeId=9518",
                    "sort": 0,
                    "brandName": "Le Soleil",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 9730,
                    "productName": "灰色植物印花露肩连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/8ffed6b2a0e34f2fba517acf7c277050.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=9730&jumpNativeType=6&jumpNativeId=9730",
                    "sort": 0,
                    "brandName": "Smart&Joy",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 10082,
                    "productName": "艺术印花百褶长裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/d7d7155b6ff84c2284f85a1e38079166.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=10082&jumpNativeType=6&jumpNativeId=10082",
                    "sort": 0,
                    "brandName": "Art Fusion",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 10723,
                    "productName": "蓝色纹纱网状连衣裙",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/9177e4d0049644ec972793d3ca9076a5.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=10723&jumpNativeType=6&jumpNativeId=10723",
                    "sort": 0,
                    "brandName": "Jethro",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                },
                {
                    "postingProductId": 0,
                    "postingPartId": 0,
                    "productId": 9425,
                    "productName": "粉色网纱T恤",
                    "productThumbnailUrl": "http://tu.yi23.net/Thumbs/07a1f9039a5c4e6e9ef854819a621a90.jpg",
                    "productLink": "http://www.95vintage.com/yi23/Home/Subscribe/pdtDetailPage?pid=9425&jumpNativeType=6&jumpNativeId=9425",
                    "sort": 0,
                    "brandName": "Lychee Fizz",
                    "xIndex": 0.0,
                    "yIndex": 0.0
                }
            ]
        }

    ],
        "shareType": 0,
        "url": "",
        "postingType": 0
    }
}