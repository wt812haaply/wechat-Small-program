/**
 * Created by ahu on 2017/12/27.
 */
export default {
    "6":{templateName: 'topFix'}, //吸顶
    "7":{templateName: 'columnTem'}, //分栏组件
    "8":{templateName: 'couponByInput'}, //input输入框 领券
    "9":{templateName: 'couponByBtn'}, //btn 按钮直接领券
    "5":{templateName: 'textTem'}, //纯文本组件
    "0":{templateName: 'bannerTem'}, //单图
    "1":{templateName: 'productListTem'}, //商品pid
    "10":{templateName: 'bottomFix'} //吸低
}