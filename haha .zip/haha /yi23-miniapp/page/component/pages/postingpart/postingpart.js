// pages/postingpart/postingpart.js
import postingData from './postingData'
import temKeyData from './temKeyData'
const Posting = require('../../../../service/posting.js');
const Session = require('../../../../common/session.js');
var us = require('../../../../common/lib/underscore.js');
const commitPushForm = require('../../../../common/commitPushForm');
var countAction = require('../../../../common/countAction');
Page({

  /**
   * 页面的初始数据
   */
  data: {
      animationData: {},
      errorMsg: '',
      selfUrl:'/page/component/pages/postingpart/postingpart',
      userInfo:'',
      temList: [],
      shareInfo:{shareTitle:'',shareImgUrl:'',sharePageUrl:''},
      getCouponRes: '',
      couponInput:'',
      fixInfo:{ top:0,  bottom:0 },
      btnRes:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      this.data.postingId=options.postingId;
      let source=options.source;
      if(source){
          countAction.setSource(source)
      }
      // this.data.postingId=6628;
      this.animation = wx.createAnimation({
          duration: 1000,
          timingFunction: 'ease',
      })
      var _t=this;
      this.data.referId=options.referId?options.referId:'';
      Posting.queryPosting({
          data:{postingId: this.data.postingId},
          success:function (res) {
              console.log(res);
              if(res.data && res.data.code==100){
                  wx.setNavigationBarTitle({
                      title: res.data.data.titleZh
                  });
                  _t.dataAction(res.data.data)
              }else{
                  _t.showErrorMsg(res.data.msg);
              }
          }
      })

  },
  onShareAppMessage: function (res) {
    return {
        title:this.data.shareInfo.shareTitle,
        imageUrl:this.data.shareInfo.shareImgUrl,
        path:this.data.shareInfo.sharePageUrl?this.data.shareInfo.sharePageUrl:this.data.selfUrl+'?postingId='+this.data.postingId,
        success: function(res) {
            // 转发成功
        },
        fail: function(res) {
            // 转发失败
        }
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      var userInfo= Session.get();
      this.setData({userInfo:userInfo})
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  //数据处理
  dataAction: function (data) {
      let info={top:0,bottom:0}
      let temList = data.postingParts.map( (element) => {
          element.temName=temKeyData[element.partType].templateName
          if(element.temName == 'topFix'){
                element.itemList.forEach((t,v)=>{
                    info.top += t.partHeight/t.partWidth*100
                })
          }else if(element.temName == "bottomFix"){
              element.itemList.forEach((t,v)=>{
                  info.bottom += t.partHeight/t.partWidth*100
              })
          }
          return element
      })
      this.setData({temList:temList,fixInfo:info,shareInfo:{shareTitle:data.shareTitle,shareImgUrl:data.shareImgUrl,sharePageUrl:data.sharePageUrl}})
  },
  toDetail:function (event) {
    var productid=event.currentTarget.dataset.productid;
    let formId = event.detail.formId;
      var path=event.currentTarget.dataset.path;
    commitPushForm.send(formId);
    wx.navigateTo({
        url: '../product/product?id='+productid+'&path='+encodeURIComponent(path)
    })
  },
  doJump:function (event) {
     let url = event.currentTarget.dataset.url;
     console.log(url)
     if(url){
         wx.navigateTo({
             url: url
         })
     }
  },
  couponInput:function (e) {
      var _t=this;
      _t.setData({couponInput:e.detail.value})
  },
  getCouponByInput:function (event) {
      let id= event.currentTarget.dataset.id,
          successInfo=event.currentTarget.dataset.info,
          _t=this;
      if(this.data.couponInput == ''){
          this.showErrorMsg('请填写手机号')
      }else{
          Posting.registerAndPromotion({
              data:{
                  eventId:id,
                  mobile:_t.data.couponInput,
                  client:JSON.stringify(Session.get().userInfo),
                  referId:_t.data.referId
              },
              success:function (res) {
                  if(res.data && res.data.code==100){
                      if(successInfo){
                          _t.setData({getCouponRes:successInfo})
                      }else {
                          _t.showErrorMsg(res.data.msg)
                      }
                  }else{
                      _t.showErrorMsg(res.data.msg)
                  }
              }
          })
      }
  },
  getCouponByBtn:function (event) {
    let id= event.currentTarget.dataset.id,
        successInfo=event.currentTarget.dataset.info,
        _t=this;

    let userInfo=this.data.userInfo;
      if(userInfo && userInfo.isLogin!=1){
          wx.navigateTo({
              url: '/page/component/pages/login/login?redirect='+encodeURIComponent(this.data.selfUrl+'?postingId='+this.data.postingId)
          });
      }else{
          Posting.promotionCouponSet({
              data:{eventId:id},
              success:function (res) {
                  if(res.data && res.data.code==100){
                      if(successInfo){
                          _t.setData({getCouponRes:successInfo})
                      }else {
                          _t.showErrorMsg(res.data.msg)
                      }
                  }else{
                      _t.showErrorMsg(res.data.msg)
                  }
              }
          })
      }
  },
  closeCouponRes:function () {
        this.setData({getCouponRes:''})
  },
  showErrorMsg: function (msg) {
      this.animation.translateY(-56).step()
      this.setData({animationData: this.animation.export(),errorMsg:msg})
      setTimeout( () => {
          this.animation.translateY(0).step()
          this.setData({
              animationData:this.animation.export()
          })
      }, 2000)
  }

})