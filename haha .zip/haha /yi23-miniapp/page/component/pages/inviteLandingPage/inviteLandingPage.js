var Invite = require('../../../../service/invite.js')
var trackPoint = require('../../../../util/track_point.js');
var Session = require('../../../../common/session.js');
/**
 * getStatus
 * 红包领取状态
 * 0 ： 领取成功
 * 1 ： 非新人
 * 2 ： 重复领取
 */
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pid: '',
    referId: '',
    info: null,
    getStatus:'',
    message: {
      success: {
        isShow: false,
        title: '红包领取成功！',
        message: '现在成为会员，还可再减##¥200##',
        imgUrl: 'https://yimg.yi23.net/webimg/web/images/2018/1204/success@2x.png',
        type: 0,
        btnText: '立即成为会员'
      },
      fail1: {
        isShow: false,
        title: '红包仅限新人领取',
        message: '你已经是衣二三的老朋友啦！\n快去首页看看最近上新的美衣吧~',
        imgUrl: 'https://yimg.yi23.net/webimg/web/images/2018/1204/member@2x.png',
        type: 0,
        btnText: '去首页'
      },
      fail2: {
        isShow: false,
        title: '你已领取过¥50红包',
        message: '现在支付即可享受¥50立减\n新人还可再减##¥200##',
        imgUrl: 'https://yimg.yi23.net/webimg/web/images/2018/1204/member@2x.png',
        type: 0,
        btnText: '成为会员'
      },
    },
    showMessage: {
      isShow: false,
      title: '',
      message: '',
      imgUrl: '',
      btnText: ''
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let scene = options.scene
    console.log(scene)
    if (scene) {
      scene=decodeURIComponent(scene)
      let sceneJson = scene.split('#')
      this.setData({
        pid: sceneJson[0],
        referId: sceneJson[1],
      })
    }
    this.getData()

  },
  getData: function () {
    let _t = this
    Invite.orderShareApplet({
      data: {
        uid: this.data.referId,
        pid: this.data.pid
      },
      success: function (res) {
        var data = res.data
        if (data && data.code == 100) {
          data.data.appletMessage=_t.textAction( data.data.appletMessage)
          _t.setData({info: data.data})
        }
      }
    })
  },
  getCoupon: function () {
   let _t=this;
    if(!_t.isLogin()){
      wx.navigateTo({
        url: '/page/component/pages/login/login'
      });
      trackPoint.clickCount('BTN_OIN_Registration',{'status':'0'})
      return false
    }else{
      trackPoint.clickCount('BTN_OIN_Registration',{'status':'1'})
    }
    Invite.getRedPacketReceiveStatus({
      data: {
        referUid: this.data.referId
      },
      success: function (res) {
        var data = res.data
        if (data && data.code == 100) {
          _t.setData({getStatus: data.data.redPacketReceiveStatus})
          _t.messageAction(data.data.redPacketReceiveStatus+'')
        }
      }
    })
  },
  closeMessage: function () {
    trackPoint.clickCount('BTN_Close_PopWindow',{'status':this.data.getStatus})
    this.setData({showMessage: {isShow: false}})
  },
  doClick: function () {
    let status=this.data.getStatus+''
    /**
     * getStatus
     * 红包领取状态
     * 0 ： 领取成功
     * 1 ： 非新人
     * 2 ： 重复领取
     */
     switch (status){
       case '0':
         wx.navigateTo({
           url: '/page/component/pages/pay/pay'
         })
         trackPoint.clickCount('BTN_New_GoToPayment',{'status':'0'})
         break;
       case '1':
         wx.reLaunch({
           url: '/page/component/pages/index/index'
         })
         trackPoint.clickCount('BTN_GoTo_Hompage',{'status':'0'})
         break;
       case '2':
         wx.navigateTo({
           url: '/page/component/pages/pay/pay'
         })
         trackPoint.clickCount('BTN_Old_GoToPayment',{'status':'0'})
         break;
     }


  },
  messageAction: function (type) {
    switch (type) {
      case '0':
        let info = JSON.parse(JSON.stringify(this.data.message.success))
        info.message = this.textAction(info.message)
        info.isShow = true
        this.setData({showMessage: info})
        break
      case '1':
        let info1 = JSON.parse(JSON.stringify(this.data.message.fail1))
        info1.message = this.textAction(info1.message)
        info1.isShow = true
        this.setData({showMessage: info1})
        break
      case '2':
        let info2 = JSON.parse(JSON.stringify(this.data.message.fail2))
        info2.message = this.textAction(info2.message)
        info2.isShow = true
        this.setData({showMessage: info2})
        break
    }
  },
  textAction: function (text) {
    text.match(/([^#]+)([#]{2}([\s\S]*)[#]{2})?([\s\S]*)/)
    return {info1: RegExp.$1, red: RegExp.$3, info2: RegExp.$4}
  },
  isLogin:function () {
    let  userInfo= Session.get();
    let loginRes=false;
    if(userInfo && userInfo.isLogin==1){
      loginRes=true
    }
    if(!userInfo){// 如果 userInfo 不存在 app.js 异步方法会跳转 授权页
      loginRes=true
    }
    return loginRes
  },
  toDetail:function (event) {
    var productid=event.currentTarget.dataset.productid;
    wx.navigateTo({
      url: '../product/product?id='+productid
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  //
  // }
})