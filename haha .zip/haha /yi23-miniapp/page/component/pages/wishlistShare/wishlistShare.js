var wishlist = require('../../../../service/wishlist.js')
var us = require('../../../../common/lib/underscore.js')
var Session = require('../../../../common/session.js')
var constants = require('../../../../common/lib/constants');
var commitPushForm = require('../../../../common/commitPushForm')
var wishlistAction = require('../../../common/wishlist')
var trackPoint = require('../../../../util/track_point.js');
var bindMobile = require('../../../../service/bindMobile')
Page({
  data: {
    isLikes: true,
    clothesCountInBox: 0,
    isShowEmpty: false,
    isLoading: false,
    isNotLogin: true,
    isOldPeople: false,
    showWisthlistTips:true,
    isShow:false,
    productShareRecordId:'',
    productShareList:[]
  },
  onLoad:function (options) {
    let productShareRecordId = options && options.productShareRecordId
    console.log('---------------')
    console.log(productShareRecordId)
    console.log('---------------')
    this.setData({productShareRecordId: productShareRecordId})
    this.referAction(options.referId)
  },
  onShow: function () {
    this.init()
  },
  init:function () {
    this.getData(this.data.productShareRecordId)
    if (this.isLogin()) {
      this.setData({isNotLogin: false})
    }
    if(wx.getStorageSync('yi23wishlistShareTips')){
      this.setData({showWisthlistTips: false})
    }
  },
  isLogin: function () {
    let userInfo = Session.get()
    let loginRes = false
    if (userInfo && userInfo.isLogin == 1) {
      loginRes = true
    }
    return loginRes
  },
  myCatchTouch: function () {
    return false
  },
  getData: function (productShareRecordId) {
    let _t = this
    var userInfo= Session.get(),referId='';
    let params={
      productShareRecordId: productShareRecordId,
      device:'Applet',
      uid:userInfo?userInfo.uid:'0',
      regionId:wx.getStorageSync(constants.WX_REGION_ID_KEY)?wx.getStorageSync(constants.WX_REGION_ID_KEY).rgnId:'52',
    }
    wishlist.share({
      data: params,
      success: function (res) {
        let dataRes=res.data
        if (dataRes.code == 100) {
          let productList=wishlistAction.showProudectDataFilter(dataRes.data.productShareList,{compareKey:'productId'})
          dataRes.data.productShareList=productList
          _t.setData({
            productShareList: dataRes.data.productShareList,
            referralCode:dataRes.data.referralCode?dataRes.data.referralCode:'',
            isOldPeople:dataRes.data.referralCode?false:true,
            bannerInfo:dataRes.data.bannerInfo
          })
        }
      }

    })
  },
  doCopy:function (event) {
    let code= event.currentTarget.dataset.code;
    let _t=this
    trackPoint.clickCount('BTN_SP_Copy')
    wx.setClipboardData({
      data: code,
      success(res) {
        wx.hideToast();
        setTimeout(function () {
          _t.setData({'isShow': true})
        },200)
      }
    })
  },
  doLogin:function () {
    trackPoint.clickCount('BTN_SP_Login')
    wx.navigateTo({
      url: '/page/component/pages/login/login'
    });
  },
  dataAction: function (data, append) {
    var _t = this
    //如果改变筛选逻辑 数据清空处理
    if (append) {
      data.productList = _t.data.productList.concat(data.productList)
    }
    return us.extend({}, data)
  },
  doWishlist: function (event) {
    this.hiddenTips()
    wishlistAction.wishlistEventAction(event, this)
  },
  hiddenTips:function () {
    wx.setStorageSync('yi23wishlistShareTips', true);
    this.setData({showWisthlistTips: false})
  },
  toDetail: function (event) {
    var productid = event.currentTarget.dataset.productid
    var path = event.currentTarget.dataset.path
    let formId = event.detail.formId
    commitPushForm.send(formId)
    wx.navigateTo({
      url: '../product/product?id=' + productid + '&path=' + encodeURIComponent(path)
    })
  },
  hideDialog: function() {
    this.setData({
      'isShow': false
    })
  },
  toIndex:function () {
    trackPoint.clickCount('BTN_SP_Homepage')
    wx.reLaunch({
      url: '/page/component/pages/index/index'
    })
  },
  referAction:function (referId) {
    if(referId){
      wx.setStorage({
        key:'referId',
        data:referId,
        complete:function(data){

        }
      });
    }
  },
  /**
   * 自动路处理
   */
  bindMobile: function (header) {
    var _t = this
    var dataJson = {}
    var referId = wx.getStorageSync('referId')
    if (referId) {
      dataJson.referId = referId
    }
    bindMobile.bindMobile({
      data: dataJson,
      header: header,
      success: function (res) {
        console.log(res)
        if (res.data && res.data.code == 100) {
          var user = Session.get()
          var info = us.extend({}, user, res.data.data)
          trackPoint.mobile(res.data.data.mobile)
          Session.set(info)
          wishlistAction.setWishlistProds()//更新 用户心愿单数据
          _t.init()
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2500
          })
          setTimeout(function () {
            wx.navigateTo({
              url: '/page/component/pages/login/login?redirectInvalid=true'
            })
          }, 2600)

        }
      }
    })
  },
  getPhoneNumber: function (e) {
    var _t = this
    console.log(e.detail.errMsg)
    if (e.detail.errMsg == 'getPhoneNumber:ok') {
      var header = {
        'X-WX-Encrypted-Data': e.detail.encryptedData,
        'X-WX-IV': e.detail.iv,
        'content-type': 'application/x-www-form-urlencoded'
      }
      console.log(header)
      _t.bindMobile(header)
    } else {
      wx.navigateTo({
        url: '/page/component/pages/login/login?redirectInvalid=true'
      })
    }
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})