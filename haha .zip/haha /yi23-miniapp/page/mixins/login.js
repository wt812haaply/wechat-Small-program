import Auth from '../../common/auth'
export default {
    mixinLogin(){
        Auth.login()
    },
    setLoginStatus(){
       if(Auth.isLogin()){
           this.setData({
               isLogin:true
           })
       } else{
           Auth.getLoginStatus().then((res)=>{
               console.log(res)
               this.setData({
                   isLogin:res.isLogin
               })
           },()=>{})
       }
    }
}