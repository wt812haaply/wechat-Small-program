import Auth from '../../common/auth'
import Device from '../../common/device'
export default {
    loginAgain(){
        Device.deleteSignSalt()
        Auth.login()
    }
}