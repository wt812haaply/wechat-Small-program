export  default {
    goUserBox: function(event) {
        // let formId = event.detail.formId;
        // commitPushForm.send(formId);
        wx.reLaunch({
            url: '/page/component/pages/box/box'
        })
    },
    goIndex: function() {
        wx.reLaunch({
            url: '/page/component/pages/index/index'
        })
    },

    goWishList: function() {
        wx.reLaunch({
            url: '/page/component/pages/wishlist/wishlist'
        })
    },

    goUserCenter: function() {
        wx.reLaunch({
            url: '/page/component/pages/my/my'
        })
    },
}