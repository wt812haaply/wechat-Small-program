// 新老带新 处理 start
import Session from '../../common/session'
export default {
    referAction: function(referId) {
        var _t = this;
        var userInfo = Session.get();
        if (userInfo && userInfo.isMember == 1) {
            return false;
        }
        wx.setStorage({
            key: 'referId',
            data: referId,
            complete: function(data) {

            }
        });
        _t.setData({ showShareBox: true });
    },
    toPostingPage: function() {
        wx.navigateTo({
            url: '/page/component/pages/posting/posting'
        })
    },
    closeShareBox: function() {
        var _t = this;
        _t.setData({
            showShareBox: false
        })
    },
}