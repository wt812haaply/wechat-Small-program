/**
 * Created by ahu on 2019/1/21
 */
const Session = require('../../common/session.js')
var us = require('../../common/lib/underscore.js')
const bindMobile = require('../../service/bindMobile')
const trackPoint = require('../../util/track_point.js');
const wishlistAction = require('./wishlist')
const loginByPhoneNumber={
  isLogin:function () {
    let userInfo = Session.get()
    let loginRes = false
    if (userInfo && userInfo.isLogin == 1) {
      loginRes = true
    }
    return loginRes
  },
  bindMobile: function (header) {
    const _t = this
    let dataJson = {}
    let referId = wx.getStorageSync('referId')
    if (referId) {
      dataJson.referId = referId
    }
    bindMobile.bindMobile({
      data: dataJson,
      header: header,
      success: function (res) {
        console.log(res)
        if (res.data && res.data.code == 100) {
          const user = Session.get()
          const info = us.extend({}, user, res.data.data)
          trackPoint.mobile(res.data.data.mobile)
          Session.set(info)
          wishlistAction.setWishlistProds()//更新 用户心愿单数据
          _t.doLoginNext && _t.doLoginNext()
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2500
          })
          setTimeout(function () {
            wx.navigateTo({
              url: '/page/component/pages/login/login?redirectInvalid=true'
            })
          }, 2600)

        }
      }
    })
  },
  getPhoneNumber:function (e) {
    var _t = this
    if (e.detail.errMsg == 'getPhoneNumber:ok') {
      var header = {
        'X-WX-Encrypted-Data': e.detail.encryptedData,
        'X-WX-IV': e.detail.iv,
        'content-type': 'application/x-www-form-urlencoded'
      }
      _t.bindMobile(header)
    } else {
      wx.navigateTo({
        url: '/page/component/pages/login/login?redirectInvalid=true'
      })
    }
  }
}
module.exports = loginByPhoneNumber;