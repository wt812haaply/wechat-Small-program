/**
 * Created by ahu on 2018/9/6
 */

const wishlist = require('../../service/wishlist.js');
const us = require('../../common/lib/underscore.js');
var Session = require('../../common/session.js');
var constants = require('../../common/lib/constants');
import  Auth from '../../common/auth';

const wishlistAction={
  setWishlistProds:function (callback) {
    let _t=this;
    if(!Auth.isLogin()){
       return false
    }
    wishlist.wishlistPids({
      success:function (res) {
        let data= res.data
        if(data.code==100){
            // _t.wishlistPids=data.data
            wx.setStorageSync(constants.WX_WISHLIST_DATA,data.data.join(','))
        }
      },
      complete:function () {
        callback &&  callback()
      }
    })
  },
  getLocalWishlist:function () {
    let _t=this;
    let localData=wx.getStorageSync(constants.WX_WISHLIST_DATA);
    let resArray=[];
    if(localData ){//&& Auth.isLogin()
      resArray=localData.split(',')
    }
    return resArray;
  },
  /**
   * pid 商品id string
   * options object
   *    {
   *      sourceKey:'',  //数据源 key
   *      editKey:'',   //要修改的字段名
   *      index:'',  //下标
   *      that:''     //page 对象
   *    }
   * */
  addWishlist:function (pid,options,callback) {
    let _t=this;
    let localData=_t.getLocalWishlist()
    localData.push(pid+'')
    wx.setStorageSync(constants.WX_WISHLIST_DATA,localData.join(','))
    if(options){
      _t.dataAction(options,'add')
    }
    callback && callback()
    wishlist.addWishListItem({
       data:{pid:pid},
       success:function (res) {
         // console.log(res)
       }
    })
  },
  delWishlist:function (pid,options,callback) {
    let _t=this;
    let localData=_t.getLocalWishlist();
    let index=localData.indexOf(pid+'')
    if(index!=-1){
      localData.splice(index,1)
    }
    // console.log(localData.join(','))
    wx.setStorageSync(constants.WX_WISHLIST_DATA,localData.join(','))
    if(options){
      _t.dataAction(options,'del')
    }
    callback && callback()
    wishlist.delWishListItem({
      data:{pid:pid},
      success:function (res) {
        // console.log(res)
      }
    })
  },
  dataAction:function (options,action) {
    let name=options.editKey?options.editKey:'favor';
    let keys;
    if(options.index==-1){
      keys=options.sourceKey+'.'+name
    }else{
      keys=options.sourceKey+"["+options.index+"]."+name;
    }
    if(action=='add'){
      options.that.setData({[keys]:1})
      options=null

    }else if(action=='del'){
      options.that.setData({[keys]:0})
      options=null
    }
  },
  wishlistEventAction:function (event,that,callback) {
    let _t=this;
    let options={
      that:that,
      sourceKey:event.currentTarget.dataset.key,
      index:event.currentTarget.dataset.index
    };
    _t.doFilterAction().then((res)=>{
      let favor=event.currentTarget.dataset.favor;
      let pid=event.currentTarget.dataset.pid;
      if(favor==0){
        _t.addWishlist(pid,options,callback)
      }else{
        _t.delWishlist(pid,options,callback)
      }
    }).catch((error)=>{
      console.error(error)
    })
    // if( _t.doFilterAction() ){
    //   return false
    // }

  },
  /**
   * 增加删除心愿单操作处理
   * 拦截处理
   * */
  doFilterAction:function(){
    return new Promise((resolve,reject)=>{
      if(Auth.isLogin()){
        resolve()
      }else{
        Auth.login().then((res)=>{
          if(res =='SUCCESS'){
            resolve(res)
          }
        })
      }
    })

  },
  /**
   * compareKey  要对比的key
   * editKey 要修改的key  默认 favor
   *
   * */
  showProudectDataFilter:function (data,options) {
    let _t=this;
    let editKey=options.editKey?options.editKey:'favor'
    let localData=_t.getLocalWishlist();
    return data.map(function (element) {
        if(localData.indexOf(element[options.compareKey]+'')!=-1){
          element[editKey]=1
        }else{
          element[editKey]=0
        }
        // return element
        return _t.imgSizeAction(element)
    })
  },
  imgSizeAction:function (el) {
    if(el.picture){
      el.picture=el.picture.map((element)=>{
        let res=/(.*.((jpg)|(jpeg)|(png)|(gif)))(.*)/.exec(element)
        if(res && res[1]){
          return res[1]+'?x-oss-process=image/resize,m_lfit,w_750'
        }else{
          return element
        }

      })
    }
    if(el.thumb_pic){
      let res=/(.*.((jpg)|(jpeg)|(png)|(gif)))(.*)/.exec(el.thumb_pic)
      if(res && res[1]){
        el.thumb_pic=res[1]+'?x-oss-process=image/resize,m_lfit,w_300'
      }

    }
    if(el.thumbPic){
      let res=/(.*.((jpg)|(jpeg)|(png)|(gif)))(.*)/.exec(el.thumbPic)
      if(res && res[1]){
        el.thumbPic=res[1]+'?x-oss-process=image/resize,m_lfit,w_300'
      }
    }
    return el
  },
  ossProcessed(url){
    return url.indexOf('x-oss-process') !=-1
  },
  hasOptins:function(url){
    return url.indexOf('?')!=-1
  },
  /**
   * globalData.wishlistActionData
   *  index  下标
   *   compareKey  要对比的key
   *  editKey 要修改的key  默认 favor
   *  dataKey 要处理的数据字段名
   *  that 组建对象
   *  data 要修改的数据
   */
  doChangeWishlistStatus:function () {
    let _t=this;
    let appInstance = getApp()
    let wishlistActionData=appInstance.globalData.wishlistActionData;
    if(wishlistActionData) {
         let localData=_t.getLocalWishlist();
         let index=wishlistActionData.index
         let editKey=wishlistActionData.editKey?wishlistActionData.editKey:'favor'
         if(localData.indexOf(wishlistActionData.data[index][wishlistActionData.compareKey]+'')!=-1){
           wishlistActionData.data[index][editKey]=1
         }else {
           wishlistActionData.data[index][editKey]=0
         }
         let keysName=wishlistActionData.dataKey+'['+index+']';
          wishlistActionData.that.setData({[keysName]:wishlistActionData.data[index]})
          appInstance.globalData.wishlistActionData=''
     }
    appInstance=null
  }
}
module.exports = wishlistAction;